package a0;

public final class e {
  public static final int[] a = new int[] { 16843173, 16843551, 16844359, 2130903085, 2130903570 };
  
  public static final int[] b = new int[] { 2130903477, 2130903478, 2130903479, 2130903480, 2130903481, 2130903482, 2130903483 };
  
  public static final int[] c = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903475, 2130903484, 2130903485, 2130903486, 2130904047 };
  
  public static final int[] d = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] e = new int[] { 16843173, 16844052 };
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */