package a5;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import d5.c;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import javax.annotation.Nullable;

public class a {
  public static final Object b = new Object();
  
  @Nullable
  public static volatile a c;
  
  public ConcurrentHashMap<ServiceConnection, ServiceConnection> a = new ConcurrentHashMap<ServiceConnection, ServiceConnection>();
  
  public static a b() {
    if (c == null)
      synchronized (b) {
        if (c == null)
          c = new a(); 
      }  
    a a1 = c;
    Objects.requireNonNull(a1, "null reference");
    return a1;
  }
  
  public static final boolean e(Context paramContext, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt, @Nullable Executor paramExecutor) {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 29) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool && paramExecutor != null) ? paramContext.bindService(paramIntent, paramInt, paramExecutor, paramServiceConnection) : paramContext.bindService(paramIntent, paramServiceConnection, paramInt);
  }
  
  public boolean a(Context paramContext, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt) {
    return d(paramContext, paramContext.getClass().getName(), paramIntent, paramServiceConnection, paramInt, true, null);
  }
  
  public void c(Context paramContext, ServiceConnection paramServiceConnection) {
    if ((paramServiceConnection instanceof x4.s0 ^ true) != 0 && this.a.containsKey(paramServiceConnection))
      try {
        ServiceConnection serviceConnection = this.a.get(paramServiceConnection);
        try {
          paramContext.unbindService(serviceConnection);
        } catch (IllegalArgumentException|IllegalStateException|java.util.NoSuchElementException illegalArgumentException) {}
        return;
      } finally {
        this.a.remove(paramServiceConnection);
      }  
    try {
      paramContext.unbindService(paramServiceConnection);
      return;
    } catch (IllegalArgumentException|IllegalStateException|java.util.NoSuchElementException illegalArgumentException) {
      return;
    } 
  }
  
  public final boolean d(Context paramContext, String paramString, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt, boolean paramBoolean, @Nullable Executor paramExecutor) {
    ComponentName componentName = paramIntent.getComponent();
    if (componentName != null) {
      String str = componentName.getPackageName();
      "com.google.android.gms".equals(str);
      try {
        int i = (c.a(paramContext).a(str, 0)).flags;
        if ((i & 0x200000) != 0) {
          Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
          return false;
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    } 
    if ((paramServiceConnection instanceof x4.s0 ^ true) != 0) {
      ServiceConnection serviceConnection = this.a.putIfAbsent(paramServiceConnection, paramServiceConnection);
      if (serviceConnection != null && paramServiceConnection != serviceConnection)
        Log.w("ConnectionTracker", String.format("Duplicate binding with the same ServiceConnection: %s, %s, %s.", new Object[] { paramServiceConnection, paramString, paramIntent.getAction() })); 
      try {
        paramBoolean = e(paramContext, paramIntent, paramServiceConnection, paramInt, paramExecutor);
        if (paramBoolean)
          return paramBoolean; 
        return false;
      } finally {
        this.a.remove(paramServiceConnection, paramServiceConnection);
      } 
    } 
    return e(paramContext, paramIntent, paramServiceConnection, paramInt, paramExecutor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */