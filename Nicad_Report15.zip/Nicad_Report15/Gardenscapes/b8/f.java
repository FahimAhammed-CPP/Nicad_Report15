package b8;

import a6.h;
import com.google.firebase.installations.local.PersistedInstallation;
import com.google.firebase.installations.local.b;

public class f implements h {
  public final h<String> a;
  
  public f(h<String> paramh) {
    this.a = paramh;
  }
  
  public boolean a(b paramb) {
    boolean bool;
    if (paramb.f() == PersistedInstallation.RegistrationStatus.h) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool || paramb.j() || paramb.h()) {
      this.a.b(paramb.c());
      return true;
    } 
    return false;
  }
  
  public boolean onException(Exception paramException) {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */