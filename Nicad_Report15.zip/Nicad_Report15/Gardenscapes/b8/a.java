package b8;

import com.google.firebase.installations.b;

public final class a extends b {
  public final String a;
  
  public final long b;
  
  public final long c;
  
  public a(String paramString, long paramLong1, long paramLong2, a parama) {
    this.a = paramString;
    this.b = paramLong1;
    this.c = paramLong2;
  }
  
  public String a() {
    return this.a;
  }
  
  public long b() {
    return this.c;
  }
  
  public long c() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof b) {
      paramObject = paramObject;
      return (this.a.equals(paramObject.a()) && this.b == paramObject.c() && this.c == paramObject.b());
    } 
    return false;
  }
  
  public int hashCode() {
    int i = this.a.hashCode();
    long l = this.b;
    int j = (int)(l ^ l >>> 32L);
    l = this.c;
    return ((i ^ 0xF4243) * 1000003 ^ j) * 1000003 ^ (int)(l ^ l >>> 32L);
  }
  
  public String toString() {
    StringBuilder stringBuilder = android.support.v4.media.a.a("InstallationTokenResult{token=");
    stringBuilder.append(this.a);
    stringBuilder.append(", tokenExpirationTimestamp=");
    stringBuilder.append(this.b);
    stringBuilder.append(", tokenCreationTimestamp=");
    stringBuilder.append(this.c);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */