package a7;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import s.h;
import s0.a;

public class a extends a {
  public static final Parcelable.Creator<a> CREATOR = (Parcelable.Creator<a>)new a();
  
  public final h<String, Bundle> h;
  
  public a(Parcel paramParcel, ClassLoader paramClassLoader, a parama) {
    super(paramParcel, paramClassLoader);
    int j = paramParcel.readInt();
    String[] arrayOfString = new String[j];
    paramParcel.readStringArray(arrayOfString);
    Bundle[] arrayOfBundle = new Bundle[j];
    paramParcel.readTypedArray((Object[])arrayOfBundle, Bundle.CREATOR);
    this.h = new h(j);
    int i;
    for (i = 0; i < j; i++)
      this.h.put(arrayOfString[i], arrayOfBundle[i]); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = android.support.v4.media.a.a("ExtendableSavedState{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" states=");
    stringBuilder.append(this.h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable(this.f, paramInt);
    int i = this.h.h;
    paramParcel.writeInt(i);
    String[] arrayOfString = new String[i];
    Bundle[] arrayOfBundle = new Bundle[i];
    for (paramInt = 0; paramInt < i; paramInt++) {
      arrayOfString[paramInt] = (String)this.h.h(paramInt);
      arrayOfBundle[paramInt] = (Bundle)this.h.k(paramInt);
    } 
    paramParcel.writeStringArray(arrayOfString);
    paramParcel.writeTypedArray((Parcelable[])arrayOfBundle, 0);
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new a(param1Parcel, null, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new a(param1Parcel, param1ClassLoader, null);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new a[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */