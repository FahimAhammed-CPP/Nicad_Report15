package a6;

import java.util.concurrent.Executor;

public abstract class g<TResult> {
  public g<TResult> a(Executor paramExecutor, b paramb) {
    throw new UnsupportedOperationException("addOnCanceledListener is not implemented");
  }
  
  public g<TResult> b(c<TResult> paramc) {
    throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
  }
  
  public g<TResult> c(Executor paramExecutor, c<TResult> paramc) {
    throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
  }
  
  public abstract g<TResult> d(d paramd);
  
  public abstract g<TResult> e(Executor paramExecutor, d paramd);
  
  public abstract g<TResult> f(e<? super TResult> parame);
  
  public abstract g<TResult> g(Executor paramExecutor, e<? super TResult> parame);
  
  public <TContinuationResult> g<TContinuationResult> h(Executor paramExecutor, a<TResult, TContinuationResult> parama) {
    throw new UnsupportedOperationException("continueWith is not implemented");
  }
  
  public <TContinuationResult> g<TContinuationResult> i(a<TResult, g<TContinuationResult>> parama) {
    throw new UnsupportedOperationException("continueWithTask is not implemented");
  }
  
  public <TContinuationResult> g<TContinuationResult> j(Executor paramExecutor, a<TResult, g<TContinuationResult>> parama) {
    throw new UnsupportedOperationException("continueWithTask is not implemented");
  }
  
  public abstract Exception k();
  
  public abstract TResult l();
  
  public abstract <X extends Throwable> TResult m(Class<X> paramClass) throws X;
  
  public abstract boolean n();
  
  public abstract boolean o();
  
  public abstract boolean p();
  
  public <TContinuationResult> g<TContinuationResult> q(Executor paramExecutor, f<TResult, TContinuationResult> paramf) {
    throw new UnsupportedOperationException("onSuccessTask is not implemented");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */