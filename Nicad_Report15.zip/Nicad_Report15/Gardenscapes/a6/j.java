package a6;

import com.google.android.gms.common.internal.e;
import com.google.android.gms.tasks.f;
import h5.tr;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import u2.w0;

public final class j {
  public static <TResult> TResult a(g<TResult> paramg) {
    e.h("Must not be called on the main application thread");
    e.j(paramg, "Task must not be null");
    if (paramg.o())
      return f(paramg); 
    tr tr = new tr(13);
    Executor executor = i.b;
    paramg.g(executor, (e<? super TResult>)tr);
    paramg.e(executor, (d)tr);
    paramg.a(executor, (b)tr);
    tr.zza();
    return f(paramg);
  }
  
  public static <TResult> TResult b(g<TResult> paramg, long paramLong, TimeUnit paramTimeUnit) {
    e.h("Must not be called on the main application thread");
    e.j(paramg, "Task must not be null");
    e.j(paramTimeUnit, "TimeUnit must not be null");
    if (paramg.o())
      return f(paramg); 
    tr tr = new tr(13);
    Executor executor = i.b;
    paramg.g(executor, (e<? super TResult>)tr);
    paramg.e(executor, (d)tr);
    paramg.a(executor, (b)tr);
    if (((CountDownLatch)tr.g).await(paramLong, paramTimeUnit))
      return f(paramg); 
    throw new TimeoutException("Timed out waiting for Task");
  }
  
  @Deprecated
  public static <TResult> g<TResult> c(Executor paramExecutor, Callable<TResult> paramCallable) {
    e.j(paramExecutor, "Executor must not be null");
    e.j(paramCallable, "Callback must not be null");
    f f = new f();
    paramExecutor.execute((Runnable)new w0(f, paramCallable));
    return (g<TResult>)f;
  }
  
  public static <TResult> g<TResult> d(Exception paramException) {
    f f = new f();
    f.r(paramException);
    return (g<TResult>)f;
  }
  
  public static <TResult> g<TResult> e(TResult paramTResult) {
    f f = new f();
    f.s(paramTResult);
    return (g<TResult>)f;
  }
  
  public static <TResult> TResult f(g<TResult> paramg) {
    if (paramg.p())
      return paramg.l(); 
    if (paramg.n())
      throw new CancellationException("Task is already canceled"); 
    throw new ExecutionException(paramg.k());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */