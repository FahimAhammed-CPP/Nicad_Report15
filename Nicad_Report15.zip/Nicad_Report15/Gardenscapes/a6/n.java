package a6;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import u5.a;

public final class n implements Executor {
  public final Handler f = (Handler)new a(Looper.getMainLooper());
  
  public final void execute(Runnable paramRunnable) {
    this.f.post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */