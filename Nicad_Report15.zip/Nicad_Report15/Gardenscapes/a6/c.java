package a6;

public interface c<TResult> {
  void onComplete(g<TResult> paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */