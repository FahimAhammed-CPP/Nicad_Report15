package a6;

import com.google.android.gms.tasks.f;
import h5.l9;
import h5.m9;
import java.util.concurrent.Executor;
import u2.v0;

public final class k<TResult, TContinuationResult> implements l<TResult> {
  public final Executor g;
  
  public final a<TResult, TContinuationResult> h;
  
  public final f<TContinuationResult> i;
  
  public k(Executor paramExecutor, a<TResult, TContinuationResult> parama, f<TContinuationResult> paramf, int paramInt) {
    this.g = paramExecutor;
    this.h = parama;
    this.i = paramf;
  }
  
  public k(Executor paramExecutor, f paramf, f<TContinuationResult> paramf1) {
    this.g = paramExecutor;
    this.h = (a<TResult, TContinuationResult>)paramf;
    this.i = paramf1;
  }
  
  public final void a(g paramg) {
    switch (this.f) {
      case 1:
        this.g.execute((Runnable)new m9(this, paramg));
        return;
      case 0:
        this.g.execute((Runnable)new l9(this, paramg));
        return;
    } 
    this.g.execute((Runnable)new v0(this, paramg));
  }
  
  public void c(Exception paramException) {
    switch (this.f) {
      case 1:
        this.i.r(paramException);
        return;
    } 
    this.i.r(paramException);
  }
  
  public void d() {
    switch (this.f) {
      case 1:
        this.i.t();
        return;
    } 
    this.i.t();
  }
  
  public void onSuccess(Object paramObject) {
    switch (this.f) {
      case 1:
        this.i.s(paramObject);
        return;
    } 
    this.i.s(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */