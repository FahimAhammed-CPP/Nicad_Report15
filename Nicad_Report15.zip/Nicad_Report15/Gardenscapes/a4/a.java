package a4;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import androidx.savedstate.d;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import i5.c;
import i5.d;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.GuardedBy;
import t4.f;

@ParametersAreNonnullByDefault
public class a {
  @GuardedBy("this")
  public t4.a a;
  
  @GuardedBy("this")
  public i5.b b;
  
  @GuardedBy("this")
  public boolean c;
  
  public final Object d = new Object();
  
  @GuardedBy("mAutoDisconnectTaskLock")
  public b e;
  
  @GuardedBy("this")
  public final Context f;
  
  public final boolean g;
  
  public final long h;
  
  public a(Context paramContext, long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    Objects.requireNonNull(paramContext, "null reference");
    Context context = paramContext;
    if (paramBoolean1) {
      context = paramContext.getApplicationContext();
      if (context == null)
        context = paramContext; 
    } 
    this.f = context;
    this.c = false;
    this.h = paramLong;
    this.g = paramBoolean2;
  }
  
  public static a b(Context paramContext) {
    // Byte code:
    //   0: new a4/c
    //   3: dup
    //   4: aload_0
    //   5: invokespecial <init> : (Landroid/content/Context;)V
    //   8: astore #6
    //   10: aload #6
    //   12: ldc 'gads:ad_id_app_context:enabled'
    //   14: invokevirtual m : (Ljava/lang/String;)Z
    //   17: istore_2
    //   18: aload #6
    //   20: getfield g : Ljava/lang/Object;
    //   23: astore #5
    //   25: aload #5
    //   27: checkcast android/content/SharedPreferences
    //   30: ifnonnull -> 36
    //   33: goto -> 65
    //   36: aload #5
    //   38: checkcast android/content/SharedPreferences
    //   41: ldc 'gads:ad_id_app_context:ping_ratio'
    //   43: fconst_0
    //   44: invokeinterface getFloat : (Ljava/lang/String;F)F
    //   49: fstore_1
    //   50: goto -> 67
    //   53: astore #5
    //   55: ldc 'GmscoreFlag'
    //   57: ldc 'Error while reading from SharedPreferences '
    //   59: aload #5
    //   61: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   64: pop
    //   65: fconst_0
    //   66: fstore_1
    //   67: aload #6
    //   69: getfield g : Ljava/lang/Object;
    //   72: astore #5
    //   74: aload #5
    //   76: checkcast android/content/SharedPreferences
    //   79: ifnonnull -> 85
    //   82: goto -> 116
    //   85: aload #5
    //   87: checkcast android/content/SharedPreferences
    //   90: ldc 'gads:ad_id_use_shared_preference:experiment_id'
    //   92: ldc ''
    //   94: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore #5
    //   101: goto -> 120
    //   104: astore #5
    //   106: ldc 'GmscoreFlag'
    //   108: ldc 'Error while reading from SharedPreferences '
    //   110: aload #5
    //   112: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   115: pop
    //   116: ldc ''
    //   118: astore #5
    //   120: new a4/a
    //   123: dup
    //   124: aload_0
    //   125: ldc2_w -1
    //   128: iload_2
    //   129: aload #6
    //   131: ldc 'gads:ad_id_use_persistent_service:enabled'
    //   133: invokevirtual m : (Ljava/lang/String;)Z
    //   136: invokespecial <init> : (Landroid/content/Context;JZZ)V
    //   139: astore_0
    //   140: invokestatic elapsedRealtime : ()J
    //   143: lstore_3
    //   144: aload_0
    //   145: iconst_0
    //   146: invokevirtual h : (Z)V
    //   149: aload_0
    //   150: invokevirtual c : ()La4/a$a;
    //   153: astore #6
    //   155: aload_0
    //   156: aload #6
    //   158: iload_2
    //   159: fload_1
    //   160: invokestatic elapsedRealtime : ()J
    //   163: lload_3
    //   164: lsub
    //   165: aload #5
    //   167: aconst_null
    //   168: invokevirtual i : (La4/a$a;ZFJLjava/lang/String;Ljava/lang/Throwable;)Z
    //   171: pop
    //   172: aload_0
    //   173: invokevirtual a : ()V
    //   176: aload #6
    //   178: areturn
    //   179: astore #6
    //   181: aload_0
    //   182: aconst_null
    //   183: iload_2
    //   184: fload_1
    //   185: ldc2_w -1
    //   188: aload #5
    //   190: aload #6
    //   192: invokevirtual i : (La4/a$a;ZFJLjava/lang/String;Ljava/lang/Throwable;)Z
    //   195: pop
    //   196: aload #6
    //   198: athrow
    //   199: astore #5
    //   201: aload_0
    //   202: invokevirtual a : ()V
    //   205: aload #5
    //   207: athrow
    // Exception table:
    //   from	to	target	type
    //   18	33	53	finally
    //   36	50	53	finally
    //   67	82	104	finally
    //   85	101	104	finally
    //   140	172	179	finally
    //   181	199	199	finally
  }
  
  public static boolean d(Context paramContext) {
    null = new c(paramContext);
    a a1 = new a(paramContext, -1L, null.m("gads:ad_id_app_context:enabled"), null.m("com.google.android.gms.ads.identifier.service.PERSISTENT_START"));
    try {
      a1.h(false);
      return a1.j();
    } finally {
      a1.a();
    } 
  }
  
  public static i5.b e(t4.a parama) {
    try {
      IBinder iBinder = parama.a(10000L, TimeUnit.MILLISECONDS);
      int i = c.f;
      return (i5.b)((iInterface instanceof i5.b) ? iInterface : new d(iBinder));
    } catch (InterruptedException interruptedException) {
      throw new IOException("Interrupted exception");
    } finally {
      parama = null;
    } 
  }
  
  public static t4.a f(Context paramContext, boolean paramBoolean) {
    try {
      paramContext.getPackageManager().getPackageInfo("com.android.vending", 0);
      int i = f.b.d(paramContext, 12451000);
      if (i == 0 || i == 2) {
        String str;
        if (paramBoolean) {
          str = "com.google.android.gms.ads.identifier.service.PERSISTENT_START";
        } else {
          str = "com.google.android.gms.ads.identifier.service.START";
        } 
        t4.a a1 = new t4.a();
        Intent intent = new Intent(str);
        intent.setPackage("com.google.android.gms");
        try {
          paramBoolean = a5.a.b().a(paramContext, intent, (ServiceConnection)a1, 1);
          if (paramBoolean)
            return a1; 
          throw new IOException("Connection failure");
        } finally {
          paramContext = null;
        } 
      } 
      throw new IOException("Google Play services not available");
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new GooglePlayServicesNotAvailableException(9);
    } 
  }
  
  public final void a() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic h : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield f : Landroid/content/Context;
    //   11: ifnull -> 78
    //   14: aload_0
    //   15: getfield a : Lt4/a;
    //   18: astore_1
    //   19: aload_1
    //   20: ifnonnull -> 26
    //   23: goto -> 78
    //   26: aload_0
    //   27: getfield c : Z
    //   30: ifeq -> 60
    //   33: invokestatic b : ()La5/a;
    //   36: aload_0
    //   37: getfield f : Landroid/content/Context;
    //   40: aload_0
    //   41: getfield a : Lt4/a;
    //   44: invokevirtual c : (Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   47: goto -> 60
    //   50: astore_1
    //   51: ldc 'AdvertisingIdClient'
    //   53: ldc 'AdvertisingIdClient unbindService failed.'
    //   55: aload_1
    //   56: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   59: pop
    //   60: aload_0
    //   61: iconst_0
    //   62: putfield c : Z
    //   65: aload_0
    //   66: aconst_null
    //   67: putfield b : Li5/b;
    //   70: aload_0
    //   71: aconst_null
    //   72: putfield a : Lt4/a;
    //   75: aload_0
    //   76: monitorexit
    //   77: return
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    //   81: astore_1
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_1
    //   85: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	81	finally
    //   26	47	50	finally
    //   51	60	81	finally
    //   60	77	81	finally
    //   78	80	81	finally
    //   82	84	81	finally
  }
  
  public a c() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic h : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifne -> 94
    //   14: aload_0
    //   15: getfield d : Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield e : La4/a$b;
    //   25: astore_2
    //   26: aload_2
    //   27: ifnull -> 78
    //   30: aload_2
    //   31: getfield i : Z
    //   34: ifeq -> 78
    //   37: aload_1
    //   38: monitorexit
    //   39: aload_0
    //   40: iconst_0
    //   41: invokevirtual h : (Z)V
    //   44: aload_0
    //   45: getfield c : Z
    //   48: ifeq -> 54
    //   51: goto -> 94
    //   54: new java/io/IOException
    //   57: dup
    //   58: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: athrow
    //   65: astore_1
    //   66: new java/io/IOException
    //   69: dup
    //   70: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   73: aload_1
    //   74: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   77: athrow
    //   78: new java/io/IOException
    //   81: dup
    //   82: ldc_w 'AdvertisingIdClient is not connected.'
    //   85: invokespecial <init> : (Ljava/lang/String;)V
    //   88: athrow
    //   89: astore_2
    //   90: aload_1
    //   91: monitorexit
    //   92: aload_2
    //   93: athrow
    //   94: aload_0
    //   95: getfield a : Lt4/a;
    //   98: ldc 'null reference'
    //   100: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   103: pop
    //   104: aload_0
    //   105: getfield b : Li5/b;
    //   108: ldc 'null reference'
    //   110: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   113: pop
    //   114: new a4/a$a
    //   117: dup
    //   118: aload_0
    //   119: getfield b : Li5/b;
    //   122: invokeinterface getId : ()Ljava/lang/String;
    //   127: aload_0
    //   128: getfield b : Li5/b;
    //   131: iconst_1
    //   132: invokeinterface K2 : (Z)Z
    //   137: invokespecial <init> : (Ljava/lang/String;Z)V
    //   140: astore_1
    //   141: aload_0
    //   142: monitorexit
    //   143: aload_0
    //   144: invokevirtual g : ()V
    //   147: aload_1
    //   148: areturn
    //   149: astore_1
    //   150: ldc 'AdvertisingIdClient'
    //   152: ldc_w 'GMS remote exception '
    //   155: aload_1
    //   156: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   159: pop
    //   160: new java/io/IOException
    //   163: dup
    //   164: ldc_w 'Remote exception'
    //   167: invokespecial <init> : (Ljava/lang/String;)V
    //   170: athrow
    //   171: astore_1
    //   172: aload_0
    //   173: monitorexit
    //   174: aload_1
    //   175: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	171	finally
    //   21	26	89	finally
    //   30	39	89	finally
    //   39	44	65	java/lang/Exception
    //   39	44	171	finally
    //   44	51	171	finally
    //   54	65	171	finally
    //   66	78	171	finally
    //   78	89	89	finally
    //   90	92	89	finally
    //   92	94	171	finally
    //   94	114	171	finally
    //   114	141	149	android/os/RemoteException
    //   114	141	171	finally
    //   141	143	171	finally
    //   150	171	171	finally
    //   172	174	171	finally
  }
  
  public void finalize() {
    a();
    super.finalize();
  }
  
  public final void g() {
    synchronized (this.d) {
      b b1 = this.e;
      if (b1 != null) {
        b1.h.countDown();
        try {
          this.e.join();
        } catch (InterruptedException interruptedException) {}
      } 
      if (this.h > 0L)
        this.e = new b(this, this.h); 
      return;
    } 
  }
  
  public final void h(boolean paramBoolean) {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic h : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifeq -> 18
    //   14: aload_0
    //   15: invokevirtual a : ()V
    //   18: aload_0
    //   19: getfield f : Landroid/content/Context;
    //   22: aload_0
    //   23: getfield g : Z
    //   26: invokestatic f : (Landroid/content/Context;Z)Lt4/a;
    //   29: astore_2
    //   30: aload_0
    //   31: aload_2
    //   32: putfield a : Lt4/a;
    //   35: aload_0
    //   36: aload_2
    //   37: invokestatic e : (Lt4/a;)Li5/b;
    //   40: putfield b : Li5/b;
    //   43: aload_0
    //   44: iconst_1
    //   45: putfield c : Z
    //   48: iload_1
    //   49: ifeq -> 56
    //   52: aload_0
    //   53: invokevirtual g : ()V
    //   56: aload_0
    //   57: monitorexit
    //   58: return
    //   59: astore_2
    //   60: aload_0
    //   61: monitorexit
    //   62: aload_2
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   7	18	59	finally
    //   18	48	59	finally
    //   52	56	59	finally
    //   56	58	59	finally
    //   60	62	59	finally
  }
  
  public final boolean i(a parama, boolean paramBoolean, float paramFloat, long paramLong, String paramString, Throwable paramThrowable) {
    String str1;
    if (Math.random() > paramFloat)
      return false; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String str2 = "1";
    if (paramBoolean) {
      str1 = "1";
    } else {
      str1 = "0";
    } 
    hashMap.put("app_context", str1);
    if (parama != null) {
      if (parama.b) {
        str1 = str2;
      } else {
        str1 = "0";
      } 
      hashMap.put("limit_ad_tracking", str1);
    } 
    if (parama != null) {
      String str = parama.a;
      if (str != null)
        hashMap.put("ad_id_size", Integer.toString(str.length())); 
    } 
    if (paramThrowable != null)
      hashMap.put("error", paramThrowable.getClass().getName()); 
    if (paramString != null && !paramString.isEmpty())
      hashMap.put("experiment_id", paramString); 
    hashMap.put("tag", "AdvertisingIdClient");
    hashMap.put("time_spent", Long.toString(paramLong));
    (new b(hashMap)).start();
    return true;
  }
  
  public final boolean j() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic h : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield c : Z
    //   11: ifne -> 94
    //   14: aload_0
    //   15: getfield d : Ljava/lang/Object;
    //   18: astore_2
    //   19: aload_2
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield e : La4/a$b;
    //   25: astore_3
    //   26: aload_3
    //   27: ifnull -> 78
    //   30: aload_3
    //   31: getfield i : Z
    //   34: ifeq -> 78
    //   37: aload_2
    //   38: monitorexit
    //   39: aload_0
    //   40: iconst_0
    //   41: invokevirtual h : (Z)V
    //   44: aload_0
    //   45: getfield c : Z
    //   48: ifeq -> 54
    //   51: goto -> 94
    //   54: new java/io/IOException
    //   57: dup
    //   58: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: athrow
    //   65: astore_2
    //   66: new java/io/IOException
    //   69: dup
    //   70: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   73: aload_2
    //   74: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   77: athrow
    //   78: new java/io/IOException
    //   81: dup
    //   82: ldc_w 'AdvertisingIdClient is not connected.'
    //   85: invokespecial <init> : (Ljava/lang/String;)V
    //   88: athrow
    //   89: astore_3
    //   90: aload_2
    //   91: monitorexit
    //   92: aload_3
    //   93: athrow
    //   94: aload_0
    //   95: getfield a : Lt4/a;
    //   98: ldc 'null reference'
    //   100: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   103: pop
    //   104: aload_0
    //   105: getfield b : Li5/b;
    //   108: ldc 'null reference'
    //   110: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   113: pop
    //   114: aload_0
    //   115: getfield b : Li5/b;
    //   118: invokeinterface zzc : ()Z
    //   123: istore_1
    //   124: aload_0
    //   125: monitorexit
    //   126: aload_0
    //   127: invokevirtual g : ()V
    //   130: iload_1
    //   131: ireturn
    //   132: astore_2
    //   133: ldc 'AdvertisingIdClient'
    //   135: ldc_w 'GMS remote exception '
    //   138: aload_2
    //   139: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   142: pop
    //   143: new java/io/IOException
    //   146: dup
    //   147: ldc_w 'Remote exception'
    //   150: invokespecial <init> : (Ljava/lang/String;)V
    //   153: athrow
    //   154: astore_2
    //   155: aload_0
    //   156: monitorexit
    //   157: aload_2
    //   158: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	154	finally
    //   21	26	89	finally
    //   30	39	89	finally
    //   39	44	65	java/lang/Exception
    //   39	44	154	finally
    //   44	51	154	finally
    //   54	65	154	finally
    //   66	78	154	finally
    //   78	89	89	finally
    //   90	92	89	finally
    //   92	94	154	finally
    //   94	114	154	finally
    //   114	124	132	android/os/RemoteException
    //   114	124	154	finally
    //   124	126	154	finally
    //   133	154	154	finally
    //   155	157	154	finally
  }
  
  public static final class a {
    public final String a;
    
    public final boolean b;
    
    public a(String param1String, boolean param1Boolean) {
      this.a = param1String;
      this.b = param1Boolean;
    }
    
    public final String toString() {
      String str = this.a;
      boolean bool = this.b;
      StringBuilder stringBuilder = new StringBuilder(d.a(str, 7));
      stringBuilder.append("{");
      stringBuilder.append(str);
      stringBuilder.append("}");
      stringBuilder.append(bool);
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends Thread {
    public WeakReference<a> f;
    
    public long g;
    
    public CountDownLatch h;
    
    public boolean i;
    
    public b(a param1a, long param1Long) {
      this.f = new WeakReference<a>(param1a);
      this.g = param1Long;
      this.h = new CountDownLatch(1);
      this.i = false;
      start();
    }
    
    public final void run() {
      try {
        if (!this.h.await(this.g, TimeUnit.MILLISECONDS)) {
          a a = this.f.get();
          if (a != null) {
            a.a();
            this.i = true;
          } 
        } 
        return;
      } catch (InterruptedException interruptedException) {
        a a = this.f.get();
        if (a != null) {
          a.a();
          this.i = true;
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */