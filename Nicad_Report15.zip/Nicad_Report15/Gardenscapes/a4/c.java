package a4;

import a6.c;
import a6.g;
import a6.h;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import c4.i;
import com.google.android.gms.common.api.b;
import com.google.android.gms.common.api.internal.g;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.zzccn;
import com.google.android.gms.internal.ads.zzdqz;
import com.google.android.gms.internal.games_v2.a;
import f.r;
import h5.cp0;
import h5.cv0;
import h5.du;
import h5.ef;
import h5.f0;
import h5.fg0;
import h5.if;
import h5.ix;
import h5.j80;
import h5.lb1;
import h5.m51;
import h5.mn0;
import h5.ph0;
import h5.qi;
import h5.rd1;
import h5.tw;
import h5.uw;
import h5.uy;
import h5.x9;
import h5.z20;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.Objects;
import java.util.concurrent.ScheduledFuture;
import q.a;
import q5.m;
import t4.b;
import v4.j;
import v4.m;
import v4.s0;

public final class c implements s0, qi, ix, uw, i, uy, fg0, mn0, c, m {
  public Object g;
  
  public c(Context paramContext) {
    try {
      return;
    } finally {
      paramContext = null;
      Log.w("GmscoreFlag", "Error while getting SharedPreferences ", (Throwable)paramContext);
      this.g = null;
    } 
  }
  
  public c(zzccn paramzzccn) {
    this.g = paramzzccn;
  }
  
  public c(cp0 paramcp0) {}
  
  public c(ef paramef) {
    this.g = paramef;
  }
  
  public c(j80 paramj80) {
    this.g = paramj80;
  }
  
  public c(lb1 paramlb1) {
    this.g = paramlb1;
  }
  
  public c(rd1 paramrd1) {
    this.g = paramrd1;
  }
  
  public c(x9 paramx9) {}
  
  public c(z20 paramz20) {}
  
  public c(ByteBuffer paramByteBuffer) {
    this.g = paramByteBuffer.slice();
  }
  
  public void b(Object paramObject) {
    rd1 rd1;
    lb1 lb1;
    zzccn zzccn;
    switch (this.f) {
      case 8:
        rd1 = (rd1)this.g;
        ((f0)paramObject).I3(rd1);
        return;
      case 5:
        lb1 = (lb1)this.g;
        ((tw)paramObject).C(lb1);
        return;
      case 4:
        zzccn = (zzccn)this.g;
        ((du)paramObject).p(zzccn);
        return;
      case 2:
        paramObject = paramObject;
        a.a("Releasing engine reference.");
        ((x9)this.g).i.l();
        return;
    } 
    ef ef = (ef)this.g;
    ((if)paramObject).o3(ef);
  }
  
  public void d(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    cv0 cv0 = (cv0)this.g;
    int j = cv0.R0;
    int k = cv0.N0;
    int i3 = cv0.r1;
    int i70 = ((j ^ k) & (i3 ^ 0xFFFFFFFF) ^ cv0.C ^ cv0.o0 ^ 0xFFFFFFFF) & cv0.t1 ^ cv0.v2 ^ cv0.U;
    int i12 = cv0.i2;
    int n = i12 ^ 0xFFFFFFFF;
    int i34 = i70 & n;
    int i39 = cv0.M;
    int i2 = i70 ^ 0xFFFFFFFF;
    int i71 = i39 & i2;
    int i48 = i70 & i12;
    j = (i48 ^ 0xFFFFFFFF) & i12;
    int i10 = cv0.B1 ^ i48;
    int i72 = i39 & i70 ^ i48;
    int i73 = cv0.y0;
    int i49 = cv0.r2 ^ i48;
    int i54 = cv0.g0;
    int i74 = cv0.E;
    int i63 = i74 ^ 0xFFFFFFFF;
    int i16 = i70 | i12;
    k = i39 & i16;
    int i75 = j ^ k;
    int i76 = cv0.p1;
    n = i16 & n;
    int i1 = i73 ^ 0xFFFFFFFF;
    int i65 = i2 & i12;
    int i19 = cv0.g ^ i65;
    int i77 = i19 & i1;
    int i21 = n ^ i39 & i65;
    int i66 = i70 ^ i12;
    int i23 = i39 & (i66 ^ 0xFFFFFFFF);
    int i20 = cv0.c0;
    int i67 = i39 & i66;
    int i11 = ((i49 | i73) ^ i10 ^ ((i34 ^ i67) & i1 ^ i48) & i63) & i20 ^ j ^ i23 ^ (i73 | n ^ k) ^ (i21 ^ ((n ^ 0xFFFFFFFF) & i39 ^ i34) & i1 | i74) ^ cv0.z1;
    j = cv0.N1;
    n = cv0.a0;
    i1 = cv0.w1;
    int i24 = cv0.M0;
    k = cv0.X;
    i2 = cv0.i;
    int i22 = cv0.f2;
    int i13 = (k & i11 ^ i2) & i22 ^ (cv0.i0 | i11) ^ i1 ^ i39;
    cv0.X = i13;
    int i29 = cv0.m0;
    int i18 = i13 & i29;
    int i14 = i18 ^ 0xFFFFFFFF;
    k = i29 ^ 0xFFFFFFFF;
    int i25 = i13 & k;
    int i32 = cv0.o;
    int i17 = i13 ^ i29;
    int i26 = i29 | i13;
    int i15 = i13 ^ 0xFFFFFFFF;
    int i30 = i29 & i15;
    int i4 = ((cv0.y1 ^ 0xFFFFFFFF) & i11 ^ cv0.d ^ 0xFFFFFFFF) & i22 ^ j & i11 ^ n ^ cv0.y;
    int i5 = cv0.I0;
    int i84 = i4 | i5;
    int i6 = cv0.S;
    int i7 = i6 ^ 0xFFFFFFFF;
    int i9 = i4 ^ 0xFFFFFFFF;
    cv0.N1 = i9;
    int i8 = i5 ^ i4;
    j = cv0.U1;
    n = cv0.m2;
    i2 = cv0.n0;
    i2 = cv0.r ^ (i2 ^ 0xFFFFFFFF) & i11 ^ (n ^ j & i11 ^ 0xFFFFFFFF) & i22 ^ cv0.P0;
    cv0.P0 = i2;
    j = cv0.s1;
    n = j ^ 0xFFFFFFFF;
    int i27 = i2 & n;
    cv0.U1 = i27;
    cv0.n0 = i27;
    i27 = (cv0.Q1 & i11 ^ cv0.j2 ^ 0xFFFFFFFF) & i22 ^ i1 & i11 ^ i24 ^ cv0.Q;
    i1 = cv0.u1;
    int i28 = i27 ^ 0xFFFFFFFF;
    cv0.a0 = i28;
    i19 = i21 ^ (i12 ^ i23 | i73) ^ (i75 ^ i73 & (i12 ^ i39 & (i16 ^ 0xFFFFFFFF))) & i63 ^ (i10 ^ i73 & i49 ^ (i19 ^ i73 & (i34 ^ i23)) & i63 ^ 0xFFFFFFFF) & i20 ^ i3;
    i21 = cv0.B2;
    i23 = i19 ^ 0xFFFFFFFF;
    int i68 = cv0.x2;
    i24 = cv0.K0;
    int i31 = cv0.v1;
    i3 = cv0.T0;
    int i33 = cv0.a;
    i16 = cv0.F0;
    int i69 = cv0.S0;
    int i78 = cv0.I1;
    i10 = cv0.M1;
    int i35 = cv0.h2;
    i10 = (i10 ^ 0xFFFFFFFF) & i19 ^ i35 ^ ((cv0.O0 | i19) ^ cv0.y2 ^ 0xFFFFFFFF) & i3 ^ (((cv0.W | i19) ^ cv0.R) & i3 ^ i35 ^ i24 & i23 | i16) ^ cv0.C1;
    cv0.C1 = i10;
    int i57 = i10 & i15;
    int i58 = i13 ^ i57;
    int i46 = i10 & i18;
    int i59 = i17 ^ i46;
    int i55 = i14 & i10;
    int i50 = i32 ^ 0xFFFFFFFF;
    int i61 = i59 ^ i55 & i50;
    cv0.M1 = i61;
    int i52 = i58 ^ (i32 | i55);
    cv0.R = i52;
    i18 = i10 & (i26 ^ 0xFFFFFFFF);
    int i60 = i26 ^ i18 | i32;
    cv0.O0 = i60;
    int i51 = i10 & k;
    int i47 = i17 ^ i10 & i13 ^ (i25 ^ i10 & i29) & i50;
    cv0.B1 = i47;
    int i53 = i13 ^ i10 ^ i32;
    cv0.y2 = i53;
    int i64 = i46 ^ i32 & (i29 & i14 ^ i10 ^ 0xFFFFFFFF);
    cv0.w1 = i64;
    int i62 = i29 ^ i10 & i30 ^ (i32 | i18);
    cv0.p1 = i62;
    int i56 = i32 & (i29 ^ i46) ^ i46;
    cv0.i0 = i56;
    int i81 = cv0.z2;
    int i82 = i16 ^ 0xFFFFFFFF;
    int i86 = cv0.s;
    int i87 = cv0.L1;
    i14 = cv0.A2;
    int i88 = cv0.C2;
    i18 = i88 ^ i14 & i23 ^ i12;
    i17 = i18 ^ 0xFFFFFFFF;
    cv0.K0 = i17;
    int i79 = cv0.J0;
    int i80 = cv0.f0;
    int i40 = i80 ^ i79 & i19 ^ cv0.I;
    cv0.I = i40;
    int i38 = i1 ^ 0xFFFFFFFF;
    int i41 = i40 & i38;
    int i98 = i40 ^ 0xFFFFFFFF;
    int i36 = i1 & i98;
    i35 = i40 & i1;
    int i43 = i35 ^ 0xFFFFFFFF;
    int i44 = i1 & i43;
    cv0.j2 = i44;
    int i42 = i40 ^ i1;
    cv0.m2 = i98;
    int i45 = i40 | i1;
    int i37 = i45 & i38;
    int i83 = cv0.b2;
    int i85 = cv0.k1;
    i14 = i88 ^ (i14 ^ 0xFFFFFFFF) & i19 ^ cv0.e1;
    cv0.e1 = i14;
    cv0.A2 = i14 & j;
    i12 = cv0.k2;
    i88 = cv0.g2;
    i12 = (i86 ^ (i19 | i81) ^ i87) & i82 ^ (i12 | i19) ^ i88 ^ cv0.O1 ^ cv0.u;
    cv0.u = i12;
    i21 = (i78 ^ i69 & i23 ^ 0xFFFFFFFF) & i3 ^ i24 ^ i19 ^ (i21 & i23 ^ i68 ^ (i81 ^ cv0.t & i19 ^ 0xFFFFFFFF) & i3) & i82 ^ cv0.F1;
    cv0.F1 = i21;
    i31 = ((i83 | i19) ^ i85) & i3 ^ i88 & i23 ^ cv0.s0 ^ ((i31 ^ (i19 | i24) ^ 0xFFFFFFFF) & i3 ^ i33 | i16) ^ i70;
    i33 = i31 ^ 0xFFFFFFFF;
    cv0.s0 = i33;
    i23 = i80 ^ (i79 | i19) ^ cv0.T1;
    i24 = i23 ^ 0xFFFFFFFF;
    cv0.J0 = i24;
    i78 = i48 ^ i71;
    i48 = cv0.j ^ i66 ^ i39 & i34 ^ (i70 ^ i39 & i48 | i73) ^ ((i54 ^ i70) & i73 ^ i49) & i63 ^ i20 & (i78 ^ i73 & i72 ^ (i74 | i78 ^ i73 & (i65 ^ i67)) ^ 0xFFFFFFFF);
    i34 = cv0.L0;
    i67 = i48 | i34;
    i86 = cv0.l1;
    int i123 = cv0.i1;
    i39 = i34 & (i48 ^ 0xFFFFFFFF);
    i49 = cv0.D1;
    i54 = i123 ^ 0xFFFFFFFF;
    i85 = cv0.c2;
    i79 = i48 & (i34 ^ 0xFFFFFFFF);
    i80 = cv0.o1;
    i81 = cv0.J;
    i65 = cv0.X1;
    int i128 = cv0.E1;
    i63 = i48 ^ i34;
    i66 = i86 ^ 0xFFFFFFFF;
    i82 = cv0.l0;
    i83 = i63 ^ cv0.f1;
    i65 = i63 ^ i86 ^ i67 & i123 ^ (i34 & (i39 ^ 0xFFFFFFFF) ^ (i79 ^ i65 ^ 0xFFFFFFFF) & i123 ^ 0xFFFFFFFF) & i128;
    int i99 = (i48 ^ (i86 | i67) ^ i123 & (i67 ^ 0xFFFFFFFF) ^ (i85 ^ (i63 ^ i63 & i66) & i123 ^ 0xFFFFFFFF) & i128 | i82) ^ i65 ^ cv0.A;
    cv0.A = i99;
    int i135 = (i99 ^ 0xFFFFFFFF) & i21;
    int i119 = i99 & i45;
    int i113 = i99 ^ i21;
    int i100 = i99 & i1;
    int i101 = i40 ^ i100;
    int i102 = i99 & i98;
    int i103 = i99 & (i44 ^ 0xFFFFFFFF);
    int i116 = i42 ^ i103;
    int i104 = i27 | i1 ^ i102;
    i88 = i99 & i21;
    int i136 = i21 & (i88 ^ 0xFFFFFFFF);
    int i129 = cv0.b1;
    int i137 = i99 | i21;
    int i138 = i21 ^ 0xFFFFFFFF;
    int i130 = i99 & i138;
    cv0.J1 = i130;
    int i131 = i129 & i130;
    int i117 = i45 ^ i103;
    int i105 = i117 ^ (i27 | i99 & i36);
    cv0.a = i105;
    int i120 = i116 ^ (i27 | i103);
    cv0.u0 = i120;
    int i107 = i99 & (i42 ^ 0xFFFFFFFF);
    int i108 = i101 ^ (i1 ^ i99 & i38) & i28;
    cv0.H = i108;
    int i109 = i42 ^ i102;
    int i118 = i37 ^ i99 & i41 ^ i109 & i28;
    cv0.Q = i118;
    int i125 = i109 ^ (i36 ^ i99 & (i37 ^ 0xFFFFFFFF)) & i28;
    cv0.v2 = i125;
    int i121 = i35 ^ i119 ^ i1 & i28;
    cv0.Q1 = i121;
    i36 = i48 & i66;
    i35 = cv0.K;
    i66 = (i39 ^ (i83 ^ 0xFFFFFFFF) & i123 ^ i128 & (i63 ^ i36 ^ i123 & (i79 ^ (i86 | i63) ^ 0xFFFFFFFF) ^ 0xFFFFFFFF)) & i82 ^ i65 ^ i74;
    cv0.E = i66;
    i67 = i6 ^ i66;
    cv0.g0 = i67;
    i68 = i6 & i66;
    i37 = i66 ^ 0xFFFFFFFF;
    i65 = i6 & i37;
    cv0.f1 = i65;
    i69 = i66 & i7;
    i63 = i66 & (i69 ^ 0xFFFFFFFF);
    cv0.h1 = i37;
    i37 = (i34 | i79) ^ (i86 | i48);
    i49 = (i39 ^ i49) & i54 ^ i85 ^ (i36 ^ (i123 | i37)) & i128 ^ (i83 ^ i83 & i54 ^ i36 & i123 & i128 | i82) ^ cv0.O;
    cv0.O = i49;
    i54 = i49 ^ 0xFFFFFFFF;
    cv0.i = i54;
    i38 = i81 ^ i39 ^ i80 ^ i123 & (i79 ^ 0xFFFFFFFF) ^ (i82 ^ 0xFFFFFFFF) & (i37 ^ i83 & i123 ^ (i37 ^ (i48 & i34 ^ i35) & i123) & i128) ^ cv0.m;
    cv0.m = i38;
    i79 = i38 ^ 0xFFFFFFFF;
    i36 = i12 & i79;
    cv0.J = i36 & n;
    i39 = i38 ^ i12;
    i35 = i38 & (i12 ^ 0xFFFFFFFF);
    cv0.r0 = i35;
    i37 = i35 | i12;
    cv0.C = i37;
    cv0.D1 = i79;
    int i127 = i76 ^ (i73 | i75) ^ (i74 | i71 ^ i77) ^ i20 & (i78 ^ (i72 | i73) ^ (i74 | i70 ^ i77)) ^ cv0.j0;
    int i110 = cv0.W0;
    i70 = i127 & (i110 ^ 0xFFFFFFFF);
    i81 = cv0.G1;
    int i139 = i81 ^ i70;
    cv0.Q0 = i139;
    i71 = cv0.N;
    i72 = i127 & (i71 ^ 0xFFFFFFFF);
    int i132 = cv0.b;
    i73 = cv0.p;
    i74 = i73 ^ 0xFFFFFFFF;
    int i133 = cv0.D0;
    i75 = cv0.F;
    i76 = cv0.p2 & i127;
    i77 = cv0.Z1;
    int i134 = cv0.j1;
    i78 = i127 & (i81 ^ 0xFFFFFFFF);
    i79 = cv0.x;
    i80 = cv0.E2;
    int i140 = i81 & i127 ^ i71 ^ (i73 | i127 & (i80 ^ 0xFFFFFFFF));
    cv0.q0 = i140;
    i85 = (cv0.V1 ^ 0xFFFFFFFF) & i127 ^ cv0.A1 ^ cv0.d2;
    int i89 = i5 ^ i85 & i5 & i9;
    i87 = i89 ^ i8 & i6;
    cv0.g = i87;
    i86 = i85 ^ 0xFFFFFFFF;
    i82 = i85 & (i5 ^ 0xFFFFFFFF);
    i81 = i82 ^ i82 & i9 ^ (i5 ^ i84) & i7;
    cv0.y1 = i81;
    int i90 = i4 | i82;
    i82 = i5 ^ i85 & i9;
    int i92 = i82 ^ ((i85 | i5) ^ i4) & i6;
    cv0.B0 = i92;
    cv0.c1 = i86;
    i83 = i85 ^ i5;
    int i93 = i83 ^ i84;
    int i91 = i4 | i83;
    i84 = i6 | i85 ^ i91;
    int i111 = i5 ^ i91;
    int i112 = i83 ^ i4 ^ (i6 | i5 & i9);
    cv0.d = i112;
    int i106 = i85 ^ i83 & i9 ^ i93 & i7;
    cv0.D2 = i106;
    i91 = cv0.S1;
    int i141 = cv0.q2 ^ (i91 ^ 0xFFFFFFFF) & i127 ^ cv0.c;
    int i146 = i21 & i141;
    i91 = i141 & i9;
    int i155 = i141 ^ 0xFFFFFFFF;
    int i114 = i137 & i155;
    int i149 = i130 ^ i114;
    cv0.A1 = i149;
    int i115 = i141 | i136;
    int i142 = cv0.k;
    int i152 = i113 ^ i129 & i141 ^ i142 & (i88 ^ i141 ^ i129 & i88 ^ 0xFFFFFFFF);
    cv0.a1 = i152;
    int i156 = i141 | i137;
    int i153 = i137 ^ i156;
    cv0.S1 = i153;
    int i124 = i141 | i4;
    int i94 = i124 ^ (i91 ^ i21 & i91) & i23;
    cv0.m1 = i94;
    int i145 = i21 & i124;
    int i150 = i135 & i155;
    int i147 = i113 ^ i150;
    cv0.z = i147;
    cv0.d1 = i155;
    int i154 = i137 ^ (i141 | i21);
    int i95 = i4 & i155;
    int i96 = i21 & i95;
    i88 = i141 ^ i4;
    int i97 = i4 ^ i21 & (i88 ^ 0xFFFFFFFF);
    int i143 = i113 & i155;
    cv0.f0 = i143;
    int i144 = i143 ^ i129 & i147;
    cv0.z0 = i144;
    int i148 = i21 ^ i115;
    int i122 = i147 ^ (i148 | i129);
    cv0.o0 = i122;
    i113 = i122 ^ i142 & (i130 & i155 ^ 0xFFFFFFFF) ^ (i40 | i147 ^ i129 & (i113 ^ i114) ^ i142 & (i115 ^ 0xFFFFFFFF));
    cv0.x0 = i113;
    cv0.T ^= i113;
    int i158 = i21 ^ i114;
    int i159 = (i154 ^ 0xFFFFFFFF) & i129 ^ i158;
    cv0.o2 = i159;
    int i160 = i129 ^ 0xFFFFFFFF;
    i113 = i141 & i4;
    i114 = i21 & i113;
    int i157 = i113 ^ 0xFFFFFFFF;
    i115 = i21 & i157;
    int i151 = i113 ^ i145 ^ (i141 ^ i115) & i24;
    cv0.t = i151;
    i122 = i4 ^ i115;
    cv0.q1 = i122;
    int i126 = i113 ^ i146 ^ (i141 ^ i146) & i24;
    cv0.t2 = i126;
    i155 = i155 & i21 ^ i21;
    i135 = i135 ^ (i141 | i137 & i138) ^ i129 & (i136 ^ i156) ^ (i153 ^ i155 & i160 ^ 0xFFFFFFFF) & i142;
    cv0.y = i135;
    cv0.R1 = i135 ^ (i40 | i154 ^ i158 & i160 ^ i142 & (i153 ^ i131)) ^ i71;
    i98 = ((i149 ^ i129 & i155) & i142 ^ i159) & i98 ^ i152;
    cv0.q2 = i98;
    cv0.e0 = i98 ^ cv0.e0 ^ 0xFFFFFFFF;
    i98 = i99 ^ i150;
    cv0.o1 = i98;
    i136 = (i98 ^ i131 ^ 0xFFFFFFFF) & i142 ^ i148 ^ (i147 ^ 0xFFFFFFFF) & i129;
    cv0.Y1 = i136;
    i98 = i88 ^ i146;
    cv0.P1 = i98;
    i131 = i23 & (i124 & i9 ^ (i4 & i157 ^ 0xFFFFFFFF) & i21 ^ 0xFFFFFFFF) ^ i98;
    cv0.x1 = i131;
    i131 ^= (i4 ^ i145 ^ (i23 | i124 ^ i21 & (i124 ^ 0xFFFFFFFF))) & i54;
    cv0.n2 = i131;
    i135 = i151 ^ (i49 | i97 ^ i98 & i24);
    cv0.T1 = i135;
    cv0.E1 = i136 ^ (i40 | i144 ^ i142 & (i143 ^ (i130 ^ i141 ^ 0xFFFFFFFF) & i129)) ^ i128;
    i130 = cv0.h;
    i129 = i127 & (i130 ^ 0xFFFFFFFF);
    i128 = i127 ^ i129 & i74;
    cv0.c = i128;
    i136 = i140 ^ (i75 | i139 ^ (i73 | i127 & (i77 ^ 0xFFFFFFFF) ^ i130));
    cv0.N = i136;
    i136 = i136 ^ i79 & (i132 ^ i78 ^ (i75 | i127 & (i133 ^ 0xFFFFFFFF) ^ i130) ^ 0xFFFFFFFF) ^ cv0.Y;
    i137 = i136 ^ 0xFFFFFFFF;
    cv0.D0 = i137;
    i138 = i77 ^ i127;
    cv0.Z1 = i138;
    i129 = (i73 | i129) ^ i138;
    cv0.U0 = i129;
    i138 = i127 & (cv0.g1 ^ 0xFFFFFFFF) ^ cv0.A0;
    cv0.g1 = i138;
    i138 ^= cv0.w;
    cv0.w = i138;
    i61 ^= (i10 & i25 ^ 0xFFFFFFFF) & i138;
    cv0.F2 = i61;
    i57 = i64 ^ i138 & ((i30 ^ i57) & i32 ^ i58);
    cv0.W = i57;
    i32 = i57 ^ i66 & (i60 ^ (i59 ^ i32 & i13 ^ 0xFFFFFFFF) & i138);
    cv0.M0 = i32;
    cv0.d0 = i32 ^ cv0.d0 ^ 0xFFFFFFFF;
    i32 = i62 ^ i138 & (i30 ^ i55);
    cv0.v1 = i32;
    i30 = i61 ^ i66 & (i52 ^ i138 & i30 ^ 0xFFFFFFFF);
    cv0.H0 = i30;
    cv0.D = i30 ^ cv0.D;
    i29 = i53 ^ (i29 ^ i51 ^ i51 & i50 ^ 0xFFFFFFFF) & i138;
    cv0.h2 = i29;
    i29 ^= (i56 ^ (i46 ^ 0xFFFFFFFF) & i138) & i66;
    cv0.w0 = i29;
    cv0.i1 = i29 ^ i123;
    i25 = i66 & (i47 ^ i138 & (i25 ^ i10 & i26) ^ 0xFFFFFFFF) ^ i32;
    cv0.I1 = i25;
    cv0.Z = i25 ^ cv0.Z ^ 0xFFFFFFFF;
    i25 = i127 & cv0.Y0 ^ cv0.B;
    cv0.Y0 = i25;
    i25 ^= cv0.e;
    cv0.e = i25;
    i26 = i120 ^ (i119 ^ (i27 | i45 ^ i99 & (i45 ^ 0xFFFFFFFF)) ^ 0xFFFFFFFF) & i25;
    cv0.a2 = i26;
    i29 = i125 ^ (i117 ^ (i27 | i116) ^ 0xFFFFFFFF) & i25;
    cv0.O1 = i29;
    i29 ^= i118 ^ i25 & (i107 ^ i42 & i27) | i136;
    cv0.r = i29;
    cv0.h = i130 ^ i29 ^ 0xFFFFFFFF;
    i26 ^= i44 ^ i25 & (i45 ^ i99 & i43 ^ i107 & i28) | i136;
    cv0.L1 = i26;
    cv0.f2 = i26 ^ i22 ^ 0xFFFFFFFF;
    cv0.V = i137 & (i121 ^ (i103 ^ i104 ^ 0xFFFFFFFF) & i25) ^ i105 ^ ((i41 ^ i102) & i28 ^ 0xFFFFFFFF) & i25 ^ cv0.V;
    cv0.v = i108 ^ ((i42 ^ i99 & i40) & i27 ^ 0xFFFFFFFF) & i25 ^ (i136 | i109 ^ i104 ^ i25 & (i100 ^ i101 & i28)) ^ cv0.v;
    i26 = i110 ^ i70;
    i22 = i75 ^ 0xFFFFFFFF;
    i41 = i77 ^ i76 ^ i134 ^ (i75 | (i127 & i132 ^ i71) & i73 ^ i26) ^ i79 & (i133 ^ (i132 ^ i72) & i74 ^ (cv0.u2 ^ i26) & i22 ^ 0xFFFFFFFF) ^ i20;
    cv0.c0 = i41;
    i28 = i41 | i6 | i66;
    i45 = i41 | i66;
    i44 = i67 ^ i45 ^ i63 & i33;
    cv0.M = i44;
    i46 = i41 ^ 0xFFFFFFFF;
    i27 = i69 & i46;
    cv0.j1 = i27;
    i20 = i41 | i69;
    i29 = i66 ^ i20;
    cv0.v0 = i29;
    i47 = i6 ^ i28;
    cv0.s = i47;
    i42 = i63 ^ i45;
    cv0.k2 = i42;
    i30 = i66 & i46 ^ (i31 | i69 ^ i27);
    cv0.S0 = i30;
    i40 = i65 & i46;
    i43 = i65 ^ i40;
    cv0.W0 = i43;
    i32 = i66 ^ i6 & i46;
    i28 = i32 ^ (i31 | i67 ^ i28);
    cv0.b = i28;
    i28 ^= i18 | i68 & i46 & i33;
    cv0.Y = i28;
    i50 = i27 ^ i31 & i32;
    cv0.u2 = i50;
    i32 = i69 ^ (i41 | i6) ^ (i31 | i47);
    cv0.V0 = i32;
    cv0.b2 = (i50 ^ (i18 | i47 ^ (i31 | i6))) & i15 ^ i67 & i46 ^ (i66 ^ i45) & i33 ^ (i18 | i47 ^ i20 & i33) ^ i127 ^ 0xFFFFFFFF;
    cv0.S = i46;
    i45 = i68 ^ i27;
    i44 = ((i31 | i45) ^ i43) & i17 ^ i44;
    cv0.X1 = i44;
    i41 = (i45 & i33 ^ i42) & i17 ^ (i31 | i43) ^ i6 ^ i41;
    cv0.k1 = i41;
    i40 = i67 ^ i40;
    cv0.z2 = i40;
    i30 = (i13 | i30 ^ (i18 | i40 ^ i31 & i6)) ^ i44;
    cv0.g2 = i30;
    cv0.j = i30 ^ i48;
    i29 = i40 & i33 ^ i29;
    cv0.x2 = i29;
    i15 = i41 ^ (i29 ^ (i18 | i27 ^ (i66 | i65) & i33)) & i15;
    cv0.r2 = i15;
    cv0.r1 = i15 ^ i19;
    i15 = i65 ^ i20;
    cv0.y0 = i15;
    i13 = (i13 | (i15 ^ (i31 | i63)) & i17 ^ i32) ^ i28;
    cv0.t1 = i13;
    cv0.z1 = i13 ^ i11 ^ 0xFFFFFFFF;
    i11 = i129 ^ (i73 | i26) & i22;
    cv0.B2 = i11;
    i11 ^= i79 & (i128 ^ (i75 | i110 ^ i76) ^ 0xFFFFFFFF);
    cv0.n = i11;
    i11 ^= cv0.G;
    cv0.G = i11;
    cv0.L = i135 ^ (i11 | (i88 ^ i96 ^ i88 & i24) & i54) ^ cv0.L;
    i13 = i131 ^ ((i98 ^ (i23 | i124)) & i54 ^ i126 | i11);
    cv0.Z0 = i13;
    cv0.L0 = i13 ^ i34;
    i13 = i112 ^ (i111 ^ i111 & i7 ^ 0xFFFFFFFF) & i11;
    cv0.I0 = i13;
    i15 = (i92 ^ i11 & (i89 ^ (i6 | i82))) & i17 ^ i13;
    cv0.W1 = i15;
    cv0.F0 = i15 ^ i16 ^ 0xFFFFFFFF;
    cv0.H1 = i13 ^ i18 & (i87 ^ (i5 ^ i90 ^ i84 ^ 0xFFFFFFFF) & i11 ^ 0xFFFFFFFF) ^ i75 ^ 0xFFFFFFFF;
    i13 = i106 ^ i11 & (i90 ^ (i6 | i93));
    cv0.h0 = i13;
    i9 = i13 ^ (i18 | i11 & (i85 & i7 ^ i5 ^ i5 & i86 & i9));
    cv0.d2 = i9;
    cv0.P = i9 ^ cv0.P;
    i9 = i11 ^ 0xFFFFFFFF;
    i13 = i91 ^ i21 ^ (i23 | i95) ^ (i122 ^ i96 & i24) & i54 ^ (i94 ^ (i49 | i97 ^ i95 & i23)) & i9;
    cv0.k0 = i13;
    cv0.p0 = i13 ^ cv0.p0;
    i13 = i81 ^ (i5 ^ i84 ^ 0xFFFFFFFF) & i11;
    cv0.q = i13;
    cv0.G0 = i8 ^ i83 & i6 ^ i11 & (i5 ^ i82 & i7 ^ 0xFFFFFFFF) ^ i13 & i17 ^ cv0.G0;
    cv0.X0 = i88 ^ (i23 | i115) ^ (i49 | i114) ^ (i114 ^ (i49 | i21 & i4 ^ (i23 | i113))) & i9 ^ i73 ^ 0xFFFFFFFF;
    i4 = i80 ^ i76;
    i9 = (i78 ^ i4 & i74) & i22 ^ i77 ^ i70 ^ (i73 | i4) ^ i79 & (i76 ^ (i75 | i71 ^ i72)) ^ cv0.K1;
    cv0.K1 = i9;
    i4 = i9 ^ 0xFFFFFFFF;
    i11 = i2 & i9;
    cv0.F = i11;
    cv0.p2 = i10 & (i14 & i11 & n ^ 0xFFFFFFFF);
    i5 = j | i9;
    cv0.p = i5 | i14;
    i7 = i9 | i12;
    i8 = i39 ^ i7;
    i6 = (i12 ^ i12 & i38 & i4) & j ^ i8 ^ i25 & (i39 ^ (j | i12 ^ i38 & i4) ^ 0xFFFFFFFF);
    cv0.j0 = i6;
    i13 = i2 & i4;
    i15 = i13 & n;
    cv0.N0 = i11 ^ i15 ^ i14 & i4;
    cv0.t0 = i14 & i13;
    cv0.C2 = (i10 & (i15 ^ (i2 ^ 0xFFFFFFFF) & i14) ^ (i14 ^ 0xFFFFFFFF) & i5) & k;
    cv0.R0 = i13 ^ j ^ i14;
    k = i9 | i39;
    i2 = i12 ^ k;
    cv0.E2 = i2;
    cv0.C0 = i11 ^ i9 & n;
    i2 = (j | i36 & i4) ^ i2;
    cv0.K = i2;
    cv0.V1 = i25 & (i39 ^ j & (i12 ^ (i9 | i38) ^ 0xFFFFFFFF)) ^ i2;
    k = i38 ^ k;
    n = i12 ^ i37 & i4 ^ i8 & n ^ i25 & ((i36 ^ i7) & n ^ k);
    i2 = n & i1 ^ i6;
    cv0.i2 = i2;
    cv0.l = i2 ^ cv0.l;
    cv0.T0 = (i1 | n) ^ i6 ^ i3;
    cv0.G1 = i25 & (k ^ j & (i35 ^ i12 & i4 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
    cv0.c2 = i5;
    cv0.U = i4;
  }
  
  public void e() {
    synchronized (((z20)this.g).g) {
      if (null.k) {
        if (null.j > 0L && null.l.isCancelled())
          null.N(null.j); 
        null.k = false;
      } 
      return;
    } 
  }
  
  public g f(b paramb) {
    Snapshot snapshot = (Snapshot)this.g;
    m.a a = new m.a();
    a.a = (j)new r(snapshot);
    a.d = 6723;
    return paramb.d(1, a.a());
  }
  
  public void g() {
    synchronized (((z20)this.g).g) {
      if (!null.k) {
        ScheduledFuture scheduledFuture = null.l;
        if (scheduledFuture != null && !scheduledFuture.isCancelled()) {
          null.l.cancel(true);
          null.j = null.i - null.h.c();
        } else {
          null.j = -1L;
        } 
        null.k = true;
      } 
      return;
    } 
  }
  
  public void h(Bundle paramBundle) {
    ((g)this.g).r.lock();
    try {
      Object object = this.g;
      ((g)object).p = b.j;
      g.p((g)object);
      return;
    } finally {
      ((g)this.g).r.unlock();
    } 
  }
  
  public void i(MessageDigest[] paramArrayOfMessageDigest, long paramLong, int paramInt) {
    ByteBuffer byteBuffer;
    MessageDigest messageDigest;
    synchronized ((ByteBuffer)this.g) {
      ByteBuffer byteBuffer1 = (ByteBuffer)this.g;
      int j = (int)paramLong;
      byteBuffer1.position(j);
      ((ByteBuffer)this.g).limit(j + paramInt);
      byteBuffer1 = ((ByteBuffer)this.g).slice();
      j = paramArrayOfMessageDigest.length;
      for (paramInt = 0; paramInt < j; paramInt++) {
        messageDigest = paramArrayOfMessageDigest[paramInt];
        byteBuffer1.position(0);
        messageDigest.update(byteBuffer1);
      } 
      return;
    } 
  }
  
  public void j(b paramb) {
    ((g)this.g).r.lock();
    try {
      Object object = this.g;
      ((g)object).p = paramb;
      g.p((g)object);
      return;
    } finally {
      ((g)this.g).r.unlock();
    } 
  }
  
  public void k(boolean paramBoolean, Context paramContext) {
    j80 j80 = (j80)this.g;
    try {
      ((ph0)j80.b).b(paramBoolean);
      ph0 ph0 = (ph0)j80.b;
      Objects.requireNonNull(ph0);
      try {
        return;
      } finally {
        ph0 = null;
      } 
    } catch (zzdqz zzdqz) {
      a.j("Cannot show rewarded video.", (Throwable)zzdqz);
      throw new zzccn(zzdqz.getCause());
    } 
  }
  
  public void l(int paramInt, boolean paramBoolean) {
    ((g)this.g).r.lock();
    try {
      Object object = this.g;
      g g = (g)object;
      if (g.q) {
        g.q = false;
        object = object;
        ((g)object).g.l(paramInt, paramBoolean);
        ((g)object).p = null;
        ((g)object).o = null;
        object = ((g)this.g).r;
      } else {
        g.q = true;
        ((g)object).i.I(paramInt);
        object = ((g)this.g).r;
      } 
      return;
    } finally {
      ((g)this.g).r.unlock();
    } 
  }
  
  public boolean m(String paramString) {
    try {
      return ((SharedPreferences)object == null) ? false : ((SharedPreferences)object).getBoolean(paramString, false);
    } finally {
      paramString = null;
      Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", (Throwable)paramString);
    } 
  }
  
  public void onComplete(g paramg) {
    h h = (h)this.g;
    if (paramg.p()) {
      h.b(paramg.l());
      return;
    } 
    Exception exception = paramg.k();
    a.a(exception);
    h.a(exception);
  }
  
  public long zza() {
    return ((ByteBuffer)this.g).capacity();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */