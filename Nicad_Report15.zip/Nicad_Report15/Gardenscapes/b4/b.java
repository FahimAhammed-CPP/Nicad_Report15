package b4;

import androidx.annotation.RecentlyNonNull;

public interface b {
  void onInitializationComplete(@RecentlyNonNull a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */