package android.support.v4.media;

import android.os.Bundle;
import b.b;

class MediaBrowserCompat$CustomActionResultReceiver extends b {
  public void a(int paramInt, Bundle paramBundle) {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$CustomActionResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */