package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import androidx.core.graphics.drawable.IconCompatParcelizer;
import o1.a;

public final class IconCompatParcelizer extends IconCompatParcelizer {
  public static IconCompat read(a parama) {
    return IconCompatParcelizer.read(parama);
  }
  
  public static void write(IconCompat paramIconCompat, a parama) {
    IconCompatParcelizer.write(paramIconCompat, parama);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\android\support\v4\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */