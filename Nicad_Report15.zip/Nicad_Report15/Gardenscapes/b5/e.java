package b5;

import android.database.CharArrayBuffer;
import android.text.TextUtils;

public final class e {
  public static void a(String paramString, CharArrayBuffer paramCharArrayBuffer) {
    if (TextUtils.isEmpty(paramString)) {
      paramCharArrayBuffer.sizeCopied = 0;
      return;
    } 
    char[] arrayOfChar = paramCharArrayBuffer.data;
    if (arrayOfChar == null || arrayOfChar.length < paramString.length()) {
      paramCharArrayBuffer.data = paramString.toCharArray();
    } else {
      paramString.getChars(0, paramString.length(), paramCharArrayBuffer.data, 0);
    } 
    paramCharArrayBuffer.sizeCopied = paramString.length();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */