package b5;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

public final class g {
  public static Boolean a;
  
  public static Boolean b;
  
  public static Boolean c;
  
  public static Boolean d;
  
  public static Boolean e;
  
  public static boolean a(Context paramContext) {
    if (c == null) {
      PackageManager packageManager = paramContext.getPackageManager();
      boolean bool = packageManager.hasSystemFeature("com.google.android.feature.services_updater");
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        bool1 = bool2;
        if (packageManager.hasSystemFeature("cn.google.services"))
          bool1 = true; 
      } 
      c = Boolean.valueOf(bool1);
    } 
    return c.booleanValue();
  }
  
  @TargetApi(20)
  public static boolean b(Context paramContext) {
    PackageManager packageManager = paramContext.getPackageManager();
    if (a == null) {
      int i = Build.VERSION.SDK_INT;
      boolean bool2 = false;
      if (i >= 20) {
        i = 1;
      } else {
        i = 0;
      } 
      boolean bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (packageManager.hasSystemFeature("android.hardware.type.watch"))
          bool1 = true; 
      } 
      a = Boolean.valueOf(bool1);
    } 
    return a.booleanValue();
  }
  
  @TargetApi(26)
  public static boolean c(Context paramContext) {
    boolean bool = b(paramContext);
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      boolean bool3;
      if (Build.VERSION.SDK_INT >= 24) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      if (bool3) {
        bool1 = bool2;
        if (d(paramContext))
          return !j.b(); 
      } else {
        bool1 = true;
      } 
    } 
    return bool1;
  }
  
  @TargetApi(21)
  public static boolean d(Context paramContext) {
    if (b == null) {
      boolean bool = j.a();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        bool1 = bool2;
        if (paramContext.getPackageManager().hasSystemFeature("cn.google"))
          bool1 = true; 
      } 
      b = Boolean.valueOf(bool1);
    } 
    return b.booleanValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */