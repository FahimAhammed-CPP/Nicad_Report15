package b5;

import android.os.SystemClock;

public class f implements b {
  public static final f a = new f();
  
  public final long a() {
    return System.currentTimeMillis();
  }
  
  public final long b() {
    return SystemClock.currentThreadTimeMillis();
  }
  
  public final long c() {
    return SystemClock.elapsedRealtime();
  }
  
  public final long d() {
    return System.nanoTime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */