package b5;

import android.content.Context;
import android.util.Log;
import java.util.Objects;

public final class d {
  public static boolean a(Context paramContext, Throwable paramThrowable) {
    try {
      Objects.requireNonNull(paramContext, "null reference");
      Objects.requireNonNull(paramThrowable, "null reference");
    } catch (Exception exception) {
      Log.e("CrashUtils", "Error adding exception to DropBox!", exception);
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */