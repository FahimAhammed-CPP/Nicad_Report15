package b5;

public class h {
  public static final char[] a = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  public static final char[] b = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  public static String a(byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length;
    char[] arrayOfChar = new char[i + i];
    i = 0;
    int j = 0;
    while (i < paramArrayOfbyte.length) {
      int k = paramArrayOfbyte[i] & 0xFF;
      int m = j + 1;
      char[] arrayOfChar1 = b;
      arrayOfChar[j] = arrayOfChar1[k >>> 4];
      j = m + 1;
      arrayOfChar[m] = arrayOfChar1[k & 0xF];
      i++;
    } 
    return new String(arrayOfChar);
  }
  
  public static byte[] b(String paramString) {
    int i = paramString.length();
    if (i % 2 == 0) {
      byte[] arrayOfByte = new byte[i / 2];
      for (int j = 0; j < i; j = k) {
        int k = j + 2;
        arrayOfByte[j / 2] = (byte)Integer.parseInt(paramString.substring(j, k), 16);
      } 
      return arrayOfByte;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Hex string has odd number of characters");
    throw illegalArgumentException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */