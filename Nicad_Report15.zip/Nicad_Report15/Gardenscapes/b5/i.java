package b5;

import java.io.InputStream;
import java.io.OutputStream;

@Deprecated
public final class i {
  @Deprecated
  public static long a(InputStream paramInputStream, OutputStream paramOutputStream, boolean paramBoolean, int paramInt) {
    // Byte code:
    //   0: iload_3
    //   1: newarray byte
    //   3: astore #7
    //   5: lconst_0
    //   6: lstore #5
    //   8: aload_0
    //   9: aload #7
    //   11: iconst_0
    //   12: iload_3
    //   13: invokevirtual read : ([BII)I
    //   16: istore #4
    //   18: iload #4
    //   20: iconst_m1
    //   21: if_icmpeq -> 44
    //   24: lload #5
    //   26: iload #4
    //   28: i2l
    //   29: ladd
    //   30: lstore #5
    //   32: aload_1
    //   33: aload #7
    //   35: iconst_0
    //   36: iload #4
    //   38: invokevirtual write : ([BII)V
    //   41: goto -> 8
    //   44: iload_2
    //   45: ifeq -> 64
    //   48: aload_0
    //   49: invokeinterface close : ()V
    //   54: aload_1
    //   55: ifnull -> 64
    //   58: aload_1
    //   59: invokeinterface close : ()V
    //   64: lload #5
    //   66: lreturn
    //   67: astore #7
    //   69: iload_2
    //   70: ifeq -> 93
    //   73: aload_0
    //   74: ifnull -> 83
    //   77: aload_0
    //   78: invokeinterface close : ()V
    //   83: aload_1
    //   84: ifnull -> 93
    //   87: aload_1
    //   88: invokeinterface close : ()V
    //   93: goto -> 99
    //   96: aload #7
    //   98: athrow
    //   99: goto -> 96
    //   102: astore_0
    //   103: goto -> 54
    //   106: astore_0
    //   107: lload #5
    //   109: lreturn
    //   110: astore_0
    //   111: goto -> 83
    //   114: astore_0
    //   115: goto -> 93
    // Exception table:
    //   from	to	target	type
    //   8	18	67	finally
    //   32	41	67	finally
    //   48	54	102	java/io/IOException
    //   58	64	106	java/io/IOException
    //   77	83	110	java/io/IOException
    //   87	93	114	java/io/IOException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */