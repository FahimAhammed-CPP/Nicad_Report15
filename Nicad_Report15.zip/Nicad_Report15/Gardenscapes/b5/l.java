package b5;

import android.os.Process;
import android.os.WorkSource;
import android.util.Log;
import java.lang.reflect.Method;

public class l {
  public static final Method a;
  
  public static final Method b;
  
  static {
    Process.myUid();
    Exception exception2 = null;
    try {
      Method method = WorkSource.class.getMethod("add", new Class[] { int.class });
    } catch (Exception null) {
      exception1 = null;
    } 
    a = (Method)exception1;
    try {
      Method method = WorkSource.class.getMethod("add", new Class[] { int.class, String.class });
    } catch (Exception exception1) {
      exception1 = exception2;
    } 
    b = (Method)exception1;
    try {
      WorkSource.class.getMethod("size", new Class[0]);
    } catch (Exception exception) {}
    try {
      WorkSource.class.getMethod("get", new Class[] { int.class });
    } catch (Exception exception) {}
    try {
      WorkSource.class.getMethod("getName", new Class[] { int.class });
    } catch (Exception exception) {}
    if (j.c())
      try {
        WorkSource.class.getMethod("createWorkChain", new Class[0]);
      } catch (Exception exception) {
        Log.w("WorkSourceUtil", "Missing WorkChain API createWorkChain", exception);
      }  
    if (j.c())
      try {
        Class.forName("android.os.WorkSource$WorkChain").getMethod("addNode", new Class[] { int.class, String.class });
      } catch (Exception exception) {
        Log.w("WorkSourceUtil", "Missing WorkChain class", exception);
      }  
    if (j.c())
      try {
        WorkSource.class.getMethod("isEmpty", new Class[0]).setAccessible(true);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */