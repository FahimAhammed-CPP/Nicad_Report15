package b5;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import com.google.android.gms.common.a;
import d5.b;
import d5.c;
import java.util.Objects;
import t4.h;

public final class k {
  public static boolean a(Context paramContext, int paramInt) {
    if (!b(paramContext, paramInt, "com.google.android.gms"))
      return false; 
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo("com.google.android.gms", 64);
      a a = a.a(paramContext);
      Objects.requireNonNull(a);
      if (packageInfo == null)
        return false; 
      if (a.d(packageInfo, false))
        return true; 
      if (a.d(packageInfo, true)) {
        if (h.b(a.a))
          return true; 
        Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
      } 
      return false;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      if (Log.isLoggable("UidVerifier", 3))
        Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false"); 
      return false;
    } 
  }
  
  @TargetApi(19)
  public static boolean b(Context paramContext, int paramInt, String paramString) {
    b b = c.a(paramContext);
    Objects.requireNonNull(b);
    try {
      AppOpsManager appOpsManager = (AppOpsManager)b.a.getSystemService("appops");
      if (appOpsManager != null) {
        appOpsManager.checkPackage(paramInt, paramString);
        return true;
      } 
      throw new NullPointerException("context.getSystemService(Context.APP_OPS_SERVICE) is null");
    } catch (SecurityException securityException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */