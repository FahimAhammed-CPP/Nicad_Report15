package c4;

import android.content.Context;
import android.view.View;
import com.google.android.gms.internal.ads.l2;
import com.google.android.gms.internal.ads.p0;
import com.google.android.gms.internal.ads.y;
import g3.d;
import h5.dh0;
import h5.eb0;
import h5.fb0;
import h5.hy;
import h5.jq;
import h5.n9;
import h5.pr0;
import h5.py;
import h5.v80;
import h5.yg0;
import h5.yo0;
import java.security.interfaces.ECPrivateKey;
import java.util.Map;
import java.util.TreeMap;
import m3.h;

public final class n implements d, yo0 {
  public final Object f;
  
  public final Object g;
  
  public final Map<String, String> h;
  
  public Object i;
  
  public Object j;
  
  public n(Context paramContext, String paramString) {
    this.f = paramContext.getApplicationContext();
    this.g = paramString;
    this.h = new TreeMap<String, String>();
  }
  
  public n(v80 paramv80, p0 paramp0, dh0 paramdh0, yg0 paramyg0, l2 paraml2) {}
  
  public n(ECPrivateKey paramECPrivateKey, byte[] paramArrayOfbyte, String paramString, int paramInt, pr0 parampr0) {
    this.f = paramECPrivateKey;
    this.i = new n9(paramECPrivateKey);
    this.j = paramArrayOfbyte;
    this.g = paramString;
    this.h = (Map<String, String>)parampr0;
  }
  
  public void f(View paramView) {
    null = (p0)this.f;
    d d1 = (d)((v80)this.h).e;
    dh0 dh0 = (dh0)this.g;
    yg0 yg0 = (yg0)this.i;
    l2 l2 = (l2)this.j;
    fb0 fb0 = new fb0(eb0.f);
    hy hy = ((py)d1.h).c(new y(dh0, yg0, null), (h)fb0);
    synchronized (new jq(hy)) {
      l2.f = (d)null;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/google/android/gms/internal/ads/l2}, name=null} */
      null.a(hy.h());
      return;
    } 
  }
  
  public void zzb() {}
  
  public void zzc() {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */