package c4;

import android.content.Context;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.internal.b;

public abstract class b<T extends IInterface> extends b<T> {
  public b(Context paramContext, Looper paramLooper, int paramInt, b.a parama, b.b paramb) {
    super(paramContext, paramLooper, paramInt, parama, paramb, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */