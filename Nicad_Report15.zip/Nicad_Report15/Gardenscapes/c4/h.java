package c4;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelReader;

public final class h implements Parcelable.Creator<g> {
  public final Object createFromParcel(Parcel paramParcel) {
    int j = SafeParcelReader.t(paramParcel);
    String str = null;
    boolean bool6 = false;
    boolean bool5 = false;
    boolean bool4 = false;
    float f = 0.0F;
    int i = 0;
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    while (paramParcel.dataPosition() < j) {
      int k = paramParcel.readInt();
      switch ((char)k) {
        default:
          SafeParcelReader.s(paramParcel, k);
          continue;
        case '\n':
          bool1 = SafeParcelReader.l(paramParcel, k);
          continue;
        case '\t':
          bool2 = SafeParcelReader.l(paramParcel, k);
          continue;
        case '\b':
          bool3 = SafeParcelReader.l(paramParcel, k);
          continue;
        case '\007':
          i = SafeParcelReader.o(paramParcel, k);
          continue;
        case '\006':
          f = SafeParcelReader.m(paramParcel, k);
          continue;
        case '\005':
          bool4 = SafeParcelReader.l(paramParcel, k);
          continue;
        case '\004':
          str = SafeParcelReader.f(paramParcel, k);
          continue;
        case '\003':
          bool5 = SafeParcelReader.l(paramParcel, k);
          continue;
        case '\002':
          break;
      } 
      bool6 = SafeParcelReader.l(paramParcel, k);
    } 
    SafeParcelReader.k(paramParcel, j);
    return new g(bool6, bool5, str, bool4, f, i, bool3, bool2, bool1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */