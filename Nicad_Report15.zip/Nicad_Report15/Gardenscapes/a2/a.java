package a2;

import androidx.work.impl.utils.futures.AbstractFuture;
import androidx.work.impl.utils.futures.DirectExecutor;
import java.util.Objects;
import java.util.concurrent.Executor;

public final class a<V> extends AbstractFuture<V> {
  public boolean k(V paramV) {
    V v = paramV;
    if (paramV == null)
      v = (V)AbstractFuture.l; 
    if (AbstractFuture.k.b(this, null, v)) {
      AbstractFuture.d(this);
      return true;
    } 
    return false;
  }
  
  public boolean l(Throwable paramThrowable) {
    Objects.requireNonNull(paramThrowable);
    AbstractFuture.Failure failure = new AbstractFuture.Failure(paramThrowable);
    if (AbstractFuture.k.b(this, null, failure)) {
      AbstractFuture.d(this);
      return true;
    } 
    return false;
  }
  
  public boolean m(m7.a<? extends V> parama) {
    Object object1;
    Objects.requireNonNull(parama);
    Object object3 = this.f;
    Object object2 = object3;
    if (object3 == null) {
      if (((AbstractFuture)parama).isDone()) {
        object1 = AbstractFuture.g(parama);
        if (AbstractFuture.k.b(this, null, object1)) {
          AbstractFuture.d(this);
          return true;
        } 
      } else {
        object2 = new AbstractFuture.f(this, (m7.a)object1);
        if (AbstractFuture.k.b(this, null, object2)) {
          try {
            object3 = DirectExecutor.f;
            ((AbstractFuture)object1).c((Runnable)object2, (Executor)object3);
          } finally {}
          return true;
        } 
        object2 = this.f;
        if (object2 instanceof AbstractFuture.c) {
          boolean bool = ((AbstractFuture.c)object2).a;
          ((AbstractFuture)object1).cancel(bool);
        } 
      } 
      return false;
    } 
    if (object2 instanceof AbstractFuture.c) {
      boolean bool = ((AbstractFuture.c)object2).a;
      ((AbstractFuture)object1).cancel(bool);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */