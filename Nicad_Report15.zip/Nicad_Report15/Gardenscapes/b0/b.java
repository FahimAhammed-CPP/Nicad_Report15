package b0;

import android.app.Activity;

public class b implements Runnable {
  public b(Activity paramActivity) {}
  
  public void run() {
    if (!this.f.isFinishing() && !d.b(this.f))
      this.f.recreate(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */