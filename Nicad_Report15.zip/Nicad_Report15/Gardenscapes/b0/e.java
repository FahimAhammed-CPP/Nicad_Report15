package b0;

import android.util.Log;
import java.lang.reflect.Method;

public class e implements Runnable {
  public e(Object paramObject1, Object paramObject2) {}
  
  public void run() {
    try {
      Method method = d.d;
      return;
    } catch (RuntimeException runtimeException) {
      return;
    } finally {
      Exception exception = null;
      Log.e("ActivityRecreator", "Exception while invoking performStopActivity", exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */