package b0;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import c0.a;
import java.util.Arrays;

public class a extends a {
  public static void d(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    int j = paramArrayOfString.length;
    int i = 0;
    while (i < j) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        i++;
        continue;
      } 
      throw new IllegalArgumentException(v.a.a(android.support.v4.media.a.a("Permission request for permissions "), Arrays.toString(paramArrayOfString), " must not contain null or empty values"));
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (paramActivity instanceof c)
        ((c)paramActivity).validateRequestPermissionsRequestCode(paramInt); 
      paramActivity.requestPermissions(paramArrayOfString, paramInt);
      return;
    } 
    if (paramActivity instanceof b)
      (new Handler(Looper.getMainLooper())).post(new a(paramArrayOfString, paramActivity, paramInt)); 
  }
  
  public class a implements Runnable {
    public a(a this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.f.length];
      PackageManager packageManager = this.g.getPackageManager();
      String str = this.g.getPackageName();
      int j = this.f.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.f[i], str); 
      ((a.b)this.g).onRequestPermissionsResult(this.h, this.f, arrayOfInt);
    }
  }
  
  public static interface b {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface c {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */