package b0;

import android.app.Notification;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import i0.a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import s.c;

public class p implements i {
  public final Context a;
  
  public final Notification.Builder b;
  
  public final m c;
  
  public final List<Bundle> d;
  
  public final Bundle e;
  
  public p(m paramm) {
    boolean bool;
    this.d = new ArrayList<Bundle>();
    this.e = new Bundle();
    this.c = paramm;
    this.a = paramm.a;
    int j = Build.VERSION.SDK_INT;
    if (j >= 26) {
      this.b = new Notification.Builder(paramm.a, paramm.u);
    } else {
      this.b = new Notification.Builder(paramm.a);
    } 
    Notification notification = paramm.w;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramm.e).setContentText(paramm.f).setContentInfo(null).setContentIntent(paramm.g).setDeleteIntent(notification.deleteIntent);
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(null, bool).setLargeIcon(paramm.h).setNumber(paramm.i).setProgress(0, 0, false);
    if (j < 21)
      this.b.setSound(notification.sound, notification.audioStreamType); 
    this.b.setSubText(paramm.m).setUsesChronometer(false).setPriority(paramm.j);
    for (j j1 : paramm.b) {
      j = Build.VERSION.SDK_INT;
      if (j >= 20) {
        Notification.Action.Builder builder2;
        Bundle bundle2;
        IconCompat iconCompat = j1.a();
        if (j >= 23) {
          if (iconCompat != null) {
            Icon icon = iconCompat.f();
          } else {
            iconCompat = null;
          } 
          builder2 = new Notification.Action.Builder((Icon)iconCompat, j1.j, j1.k);
        } else {
          if (builder2 != null) {
            j = builder2.c();
          } else {
            j = 0;
          } 
          builder2 = new Notification.Action.Builder(j, j1.j, j1.k);
        } 
        t[] arrayOfT = j1.c;
        if (arrayOfT != null) {
          int k = arrayOfT.length;
          RemoteInput[] arrayOfRemoteInput = new RemoteInput[k];
          for (j = 0; j < arrayOfT.length; j++) {
            Objects.requireNonNull(arrayOfT[j]);
            RemoteInput.Builder builder3 = (new RemoteInput.Builder(null)).setLabel(null).setChoices(null).setAllowFreeFormInput(false).addExtras(null);
            if (Build.VERSION.SDK_INT >= 29)
              builder3.setEditChoicesBeforeSending(0); 
            arrayOfRemoteInput[j] = builder3.build();
          } 
          for (j = 0; j < k; j++)
            builder2.addRemoteInput(arrayOfRemoteInput[j]); 
        } 
        if (j1.a != null) {
          bundle2 = new Bundle(j1.a);
        } else {
          bundle2 = new Bundle();
        } 
        bundle2.putBoolean("android.support.allowGeneratedReplies", j1.e);
        j = Build.VERSION.SDK_INT;
        if (j >= 24)
          builder2.setAllowGeneratedReplies(j1.e); 
        bundle2.putInt("android.support.action.semanticAction", j1.g);
        if (j >= 28)
          builder2.setSemanticAction(j1.g); 
        if (j >= 29)
          builder2.setContextual(j1.h); 
        bundle2.putBoolean("android.support.action.showsUserInterface", j1.f);
        builder2.addExtras(bundle2);
        this.b.addAction(builder2.build());
        continue;
      } 
      List<Bundle> list = this.d;
      Notification.Builder builder1 = this.b;
      Object object = q.a;
      object = j1.a();
      if (object != null) {
        j = object.c();
      } else {
        j = 0;
      } 
      builder1.addAction(j, j1.j, j1.k);
      Bundle bundle1 = new Bundle(j1.a);
      object = j1.c;
      if (object != null)
        bundle1.putParcelableArray("android.support.remoteInputs", (Parcelable[])q.b((t[])object)); 
      object = j1.d;
      if (object != null)
        bundle1.putParcelableArray("android.support.dataRemoteInputs", (Parcelable[])q.b((t[])object)); 
      bundle1.putBoolean("android.support.allowGeneratedReplies", j1.e);
      list.add(bundle1);
    } 
    Bundle bundle = paramm.q;
    if (bundle != null)
      this.e.putAll(bundle); 
    j = Build.VERSION.SDK_INT;
    if (j < 20) {
      if (paramm.p)
        this.e.putBoolean("android.support.localOnly", true); 
      String str = paramm.n;
      if (str != null) {
        this.e.putString("android.support.groupKey", str);
        if (paramm.o) {
          this.e.putBoolean("android.support.isGroupSummary", true);
        } else {
          this.e.putBoolean("android.support.useSideChannel", true);
        } 
      } 
    } 
    this.b.setShowWhen(paramm.k);
    if (j < 21) {
      List<String> list = a(b(paramm.c), paramm.x);
      if (list != null && !list.isEmpty())
        this.e.putStringArray("android.people", list.<String>toArray(new String[list.size()])); 
    } 
    if (j >= 20)
      this.b.setLocalOnly(paramm.p).setGroup(paramm.n).setGroupSummary(paramm.o).setSortKey(null); 
    if (j >= 21) {
      List<String> list;
      this.b.setCategory(null).setColor(paramm.r).setVisibility(paramm.s).setPublicVersion(paramm.t).setSound(notification.sound, notification.audioAttributes);
      if (j < 28) {
        list = a(b(paramm.c), paramm.x);
      } else {
        list = paramm.x;
      } 
      if (list != null && !list.isEmpty())
        for (String str : list)
          this.b.addPerson(str);  
      if (paramm.d.size() > 0) {
        if (paramm.q == null)
          paramm.q = new Bundle(); 
        Bundle bundle2 = paramm.q.getBundle("android.car.EXTENSIONS");
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        Bundle bundle3 = new Bundle(bundle1);
        Bundle bundle4 = new Bundle();
        for (j = 0; j < paramm.d.size(); j++) {
          boolean bool1;
          String str = Integer.toString(j);
          j j1 = paramm.d.get(j);
          Object object = q.a;
          Bundle bundle5 = new Bundle();
          object = j1.a();
          if (object != null) {
            bool1 = object.c();
          } else {
            bool1 = false;
          } 
          bundle5.putInt("icon", bool1);
          bundle5.putCharSequence("title", j1.j);
          bundle5.putParcelable("actionIntent", (Parcelable)j1.k);
          if (j1.a != null) {
            object = new Bundle(j1.a);
          } else {
            object = new Bundle();
          } 
          object.putBoolean("android.support.allowGeneratedReplies", j1.e);
          bundle5.putBundle("extras", (Bundle)object);
          bundle5.putParcelableArray("remoteInputs", (Parcelable[])q.b(j1.c));
          bundle5.putBoolean("showsUserInterface", j1.f);
          bundle5.putInt("semanticAction", j1.g);
          bundle4.putBundle(str, bundle5);
        } 
        bundle1.putBundle("invisible_actions", bundle4);
        bundle3.putBundle("invisible_actions", bundle4);
        if (paramm.q == null)
          paramm.q = new Bundle(); 
        paramm.q.putBundle("android.car.EXTENSIONS", bundle1);
        this.e.putBundle("android.car.EXTENSIONS", bundle3);
      } 
    } 
    j = Build.VERSION.SDK_INT;
    if (j >= 24)
      this.b.setExtras(paramm.q).setRemoteInputHistory(null); 
    if (j >= 26) {
      this.b.setBadgeIconType(0).setSettingsText(null).setShortcutId(null).setTimeoutAfter(0L).setGroupAlertBehavior(0);
      if (!TextUtils.isEmpty(paramm.u))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (j >= 28)
      for (s s : paramm.c) {
        Notification.Builder builder1 = this.b;
        Objects.requireNonNull(s);
        builder1.addPerson((new Person.Builder()).setName(null).setIcon(null).setUri(null).setKey(null).setBot(false).setImportant(false).build());
      }  
    if (Build.VERSION.SDK_INT >= 29) {
      this.b.setAllowSystemGeneratedContextualActions(paramm.v);
      this.b.setBubbleMetadata(null);
    } 
    a.a();
  }
  
  public static List<String> a(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    int j = paramList1.size();
    c c = new c(paramList2.size() + j);
    c.addAll(paramList1);
    c.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)c);
  }
  
  public static List<String> b(List<s> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<s> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      arrayList.add("");
    } 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */