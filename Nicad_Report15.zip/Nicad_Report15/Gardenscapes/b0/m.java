package b0;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseArray;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Objects;

public class m {
  public Context a;
  
  public ArrayList<j> b = new ArrayList<j>();
  
  public ArrayList<s> c = new ArrayList<s>();
  
  public ArrayList<j> d = new ArrayList<j>();
  
  public CharSequence e;
  
  public CharSequence f;
  
  public PendingIntent g;
  
  public Bitmap h;
  
  public int i;
  
  public int j;
  
  public boolean k = true;
  
  public o l;
  
  public CharSequence m;
  
  public String n;
  
  public boolean o;
  
  public boolean p = false;
  
  public Bundle q;
  
  public int r = 0;
  
  public int s = 0;
  
  public Notification t;
  
  public String u;
  
  public boolean v;
  
  public Notification w;
  
  @Deprecated
  public ArrayList<String> x;
  
  public m(Context paramContext, String paramString) {
    Notification notification = new Notification();
    this.w = notification;
    this.a = paramContext;
    this.u = paramString;
    notification.when = System.currentTimeMillis();
    this.w.audioStreamType = -1;
    this.j = 0;
    this.x = new ArrayList<String>();
    this.v = true;
  }
  
  public static CharSequence c(CharSequence paramCharSequence) {
    if (paramCharSequence == null)
      return paramCharSequence; 
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence.length() > 5120)
      charSequence = paramCharSequence.subSequence(0, 5120); 
    return charSequence;
  }
  
  public m a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent) {
    IconCompat iconCompat;
    ArrayList<j> arrayList = this.b;
    if (paramInt == 0) {
      iconCompat = null;
    } else {
      iconCompat = IconCompat.b(null, "", paramInt);
    } 
    arrayList.add(new j(iconCompat, paramCharSequence, paramPendingIntent, new Bundle(), null, null, true, 0, true, false));
    return this;
  }
  
  public Notification b() {
    Notification notification;
    p p = new p(this);
    o o1 = p.c.l;
    if (o1 != null)
      o1.b(p); 
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      notification = p.b.build();
    } else if (i >= 24) {
      notification = p.b.build();
    } else if (i >= 21) {
      p.b.setExtras(p.e);
      notification = p.b.build();
    } else if (i >= 20) {
      p.b.setExtras(p.e);
      notification = p.b.build();
    } else {
      SparseArray<Bundle> sparseArray = q.a(p.d);
      if (sparseArray != null)
        p.e.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      p.b.setExtras(p.e);
      notification = p.b.build();
    } 
    Objects.requireNonNull(p.c);
    if (i >= 21 && o1 != null)
      Objects.requireNonNull(p.c.l); 
    if (o1 != null) {
      Bundle bundle = notification.extras;
      if (bundle != null)
        o1.a(bundle); 
    } 
    return notification;
  }
  
  public m d(CharSequence paramCharSequence) {
    this.f = c(paramCharSequence);
    return this;
  }
  
  public m e(CharSequence paramCharSequence) {
    this.e = c(paramCharSequence);
    return this;
  }
  
  public m f(int paramInt) {
    Notification notification = this.w;
    notification.defaults = paramInt;
    if ((paramInt & 0x4) != 0)
      notification.flags |= 0x1; 
    return this;
  }
  
  public final void g(int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      Notification notification1 = this.w;
      notification1.flags = paramInt | notification1.flags;
      return;
    } 
    Notification notification = this.w;
    notification.flags = (paramInt ^ 0xFFFFFFFF) & notification.flags;
  }
  
  public m h(Bitmap paramBitmap) {
    Bitmap bitmap = paramBitmap;
    if (paramBitmap != null)
      if (Build.VERSION.SDK_INT >= 27) {
        bitmap = paramBitmap;
      } else {
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(2131099759);
        int j = resources.getDimensionPixelSize(2131099758);
        if (paramBitmap.getWidth() <= i && paramBitmap.getHeight() <= j) {
          Bitmap bitmap1 = paramBitmap;
        } else {
          double d1 = i;
          double d2 = Math.max(1, paramBitmap.getWidth());
          Double.isNaN(d1);
          Double.isNaN(d2);
          Double.isNaN(d1);
          Double.isNaN(d2);
          d1 /= d2;
          d2 = j;
          double d3 = Math.max(1, paramBitmap.getHeight());
          Double.isNaN(d2);
          Double.isNaN(d3);
          Double.isNaN(d2);
          Double.isNaN(d3);
          d1 = Math.min(d1, d2 / d3);
          d2 = paramBitmap.getWidth();
          Double.isNaN(d2);
          Double.isNaN(d2);
          i = (int)Math.ceil(d2 * d1);
          d2 = paramBitmap.getHeight();
          Double.isNaN(d2);
          Double.isNaN(d2);
          bitmap = Bitmap.createScaledBitmap(paramBitmap, i, (int)Math.ceil(d2 * d1), true);
        } 
      }  
    this.h = bitmap;
    return this;
  }
  
  public m i(Uri paramUri) {
    Notification notification = this.w;
    notification.sound = paramUri;
    notification.audioStreamType = -1;
    if (Build.VERSION.SDK_INT >= 21)
      notification.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build(); 
    return this;
  }
  
  public m j(o paramo) {
    if (this.l != paramo) {
      this.l = paramo;
      if (paramo != null && paramo.a != this) {
        paramo.a = this;
        j(paramo);
      } 
    } 
    return this;
  }
  
  public m k(CharSequence paramCharSequence) {
    this.w.tickerText = c(paramCharSequence);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */