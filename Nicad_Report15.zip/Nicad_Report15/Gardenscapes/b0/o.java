package b0;

import android.os.Bundle;

public abstract class o {
  public m a;
  
  public CharSequence b;
  
  public CharSequence c;
  
  public boolean d = false;
  
  public void a(Bundle paramBundle) {
    if (this.d)
      paramBundle.putCharSequence("android.summaryText", this.c); 
    CharSequence charSequence = this.b;
    if (charSequence != null)
      paramBundle.putCharSequence("android.title.big", charSequence); 
    charSequence = c();
    if (charSequence != null)
      paramBundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
  }
  
  public abstract void b(i parami);
  
  public abstract String c();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */