package b0;

import android.app.Notification;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import androidx.core.graphics.drawable.IconCompat;

public class k extends o {
  public Bitmap e;
  
  public IconCompat f;
  
  public boolean g;
  
  public void b(i parami) {
    int j = Build.VERSION.SDK_INT;
    p p = (p)parami;
    Notification.BigPictureStyle bigPictureStyle = (new Notification.BigPictureStyle(p.b)).setBigContentTitle(this.b).bigPicture(this.e);
    if (this.g) {
      IconCompat iconCompat = this.f;
      parami = null;
      if (iconCompat == null) {
        a.a(bigPictureStyle, null);
      } else if (j >= 23) {
        b.a(bigPictureStyle, iconCompat.g(p.a));
      } else if (iconCompat.d() == 1) {
        StringBuilder stringBuilder;
        Object object = this.f;
        int m = ((IconCompat)object).a;
        if (m == -1 && j >= 23) {
          object = ((IconCompat)object).b;
          if (object instanceof Bitmap)
            Bitmap bitmap = (Bitmap)object; 
        } else if (m == 1) {
          Bitmap bitmap = (Bitmap)((IconCompat)object).b;
        } else if (m == 5) {
          Bitmap bitmap = IconCompat.a((Bitmap)((IconCompat)object).b, true);
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("called getBitmap() on ");
          stringBuilder.append(object);
          throw new IllegalStateException(stringBuilder.toString());
        } 
        a.a(bigPictureStyle, (Bitmap)stringBuilder);
      } else {
        a.a(bigPictureStyle, null);
      } 
    } 
    if (this.d)
      a.b(bigPictureStyle, this.c); 
    if (j >= 31)
      c.a(bigPictureStyle, false); 
  }
  
  public String c() {
    return "androidx.core.app.NotificationCompat$BigPictureStyle";
  }
  
  public k d(Bitmap paramBitmap) {
    IconCompat iconCompat;
    if (paramBitmap == null) {
      paramBitmap = null;
    } else {
      PorterDuff.Mode mode = IconCompat.k;
      IconCompat iconCompat1 = new IconCompat(1);
      iconCompat1.b = paramBitmap;
      iconCompat = iconCompat1;
    } 
    this.f = iconCompat;
    this.g = true;
    return this;
  }
  
  public static class a {
    public static void a(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      param1BigPictureStyle.bigLargeIcon(param1Bitmap);
    }
    
    public static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      param1BigPictureStyle.setSummaryText(param1CharSequence);
    }
  }
  
  public static class b {
    public static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      param1BigPictureStyle.bigLargeIcon(param1Icon);
    }
  }
  
  public static class c {
    public static void a(Notification.BigPictureStyle param1BigPictureStyle, boolean param1Boolean) {
      param1BigPictureStyle.showBigPictureWhenCollapsed(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */