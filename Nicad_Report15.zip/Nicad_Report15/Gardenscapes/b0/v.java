package b0;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.Iterator;

public final class v implements Iterable<Intent> {
  public final ArrayList<Intent> f = new ArrayList<Intent>();
  
  public final Context g;
  
  public v(Context paramContext) {
    this.g = paramContext;
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.f.iterator();
  }
  
  public static interface a {
    Intent getSupportParentActivityIntent();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */