package b0;

import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class d {
  public static final Class<?> a;
  
  public static final Field b;
  
  public static final Field c;
  
  public static final Method d;
  
  public static final Method e;
  
  public static final Method f;
  
  public static final Handler g;
  
  static {
    // Byte code:
    //   0: new android/os/Handler
    //   3: dup
    //   4: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   7: invokespecial <init> : (Landroid/os/Looper;)V
    //   10: putstatic b0/d.g : Landroid/os/Handler;
    //   13: aconst_null
    //   14: astore_1
    //   15: ldc 'android.app.ActivityThread'
    //   17: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   20: astore_0
    //   21: goto -> 26
    //   24: aconst_null
    //   25: astore_0
    //   26: aload_0
    //   27: putstatic b0/d.a : Ljava/lang/Class;
    //   30: ldc android/app/Activity
    //   32: ldc 'mMainThread'
    //   34: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   37: astore_0
    //   38: aload_0
    //   39: iconst_1
    //   40: invokevirtual setAccessible : (Z)V
    //   43: goto -> 48
    //   46: aconst_null
    //   47: astore_0
    //   48: aload_0
    //   49: putstatic b0/d.b : Ljava/lang/reflect/Field;
    //   52: ldc android/app/Activity
    //   54: ldc 'mToken'
    //   56: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   59: astore_0
    //   60: aload_0
    //   61: iconst_1
    //   62: invokevirtual setAccessible : (Z)V
    //   65: goto -> 70
    //   68: aconst_null
    //   69: astore_0
    //   70: aload_0
    //   71: putstatic b0/d.c : Ljava/lang/reflect/Field;
    //   74: getstatic b0/d.a : Ljava/lang/Class;
    //   77: astore_0
    //   78: aload_0
    //   79: ifnonnull -> 87
    //   82: aconst_null
    //   83: astore_0
    //   84: goto -> 119
    //   87: aload_0
    //   88: ldc 'performStopActivity'
    //   90: iconst_3
    //   91: anewarray java/lang/Class
    //   94: dup
    //   95: iconst_0
    //   96: ldc android/os/IBinder
    //   98: aastore
    //   99: dup
    //   100: iconst_1
    //   101: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   104: aastore
    //   105: dup
    //   106: iconst_2
    //   107: ldc java/lang/String
    //   109: aastore
    //   110: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   113: astore_0
    //   114: aload_0
    //   115: iconst_1
    //   116: invokevirtual setAccessible : (Z)V
    //   119: aload_0
    //   120: putstatic b0/d.d : Ljava/lang/reflect/Method;
    //   123: getstatic b0/d.a : Ljava/lang/Class;
    //   126: astore_0
    //   127: aload_0
    //   128: ifnonnull -> 136
    //   131: aconst_null
    //   132: astore_0
    //   133: goto -> 163
    //   136: aload_0
    //   137: ldc 'performStopActivity'
    //   139: iconst_2
    //   140: anewarray java/lang/Class
    //   143: dup
    //   144: iconst_0
    //   145: ldc android/os/IBinder
    //   147: aastore
    //   148: dup
    //   149: iconst_1
    //   150: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   153: aastore
    //   154: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   157: astore_0
    //   158: aload_0
    //   159: iconst_1
    //   160: invokevirtual setAccessible : (Z)V
    //   163: aload_0
    //   164: putstatic b0/d.e : Ljava/lang/reflect/Method;
    //   167: getstatic b0/d.a : Ljava/lang/Class;
    //   170: astore_2
    //   171: aload_1
    //   172: astore_0
    //   173: invokestatic a : ()Z
    //   176: ifeq -> 257
    //   179: aload_2
    //   180: ifnonnull -> 188
    //   183: aload_1
    //   184: astore_0
    //   185: goto -> 257
    //   188: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   191: astore_0
    //   192: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   195: astore_3
    //   196: aload_2
    //   197: ldc 'requestRelaunchActivity'
    //   199: bipush #9
    //   201: anewarray java/lang/Class
    //   204: dup
    //   205: iconst_0
    //   206: ldc android/os/IBinder
    //   208: aastore
    //   209: dup
    //   210: iconst_1
    //   211: ldc java/util/List
    //   213: aastore
    //   214: dup
    //   215: iconst_2
    //   216: ldc java/util/List
    //   218: aastore
    //   219: dup
    //   220: iconst_3
    //   221: aload_0
    //   222: aastore
    //   223: dup
    //   224: iconst_4
    //   225: aload_3
    //   226: aastore
    //   227: dup
    //   228: iconst_5
    //   229: ldc android/content/res/Configuration
    //   231: aastore
    //   232: dup
    //   233: bipush #6
    //   235: ldc android/content/res/Configuration
    //   237: aastore
    //   238: dup
    //   239: bipush #7
    //   241: aload_3
    //   242: aastore
    //   243: dup
    //   244: bipush #8
    //   246: aload_3
    //   247: aastore
    //   248: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   251: astore_0
    //   252: aload_0
    //   253: iconst_1
    //   254: invokevirtual setAccessible : (Z)V
    //   257: aload_0
    //   258: putstatic b0/d.f : Ljava/lang/reflect/Method;
    //   261: return
    //   262: astore_0
    //   263: goto -> 24
    //   266: astore_0
    //   267: goto -> 46
    //   270: astore_0
    //   271: goto -> 68
    //   274: astore_0
    //   275: goto -> 82
    //   278: astore_0
    //   279: goto -> 131
    //   282: astore_0
    //   283: aload_1
    //   284: astore_0
    //   285: goto -> 257
    // Exception table:
    //   from	to	target	type
    //   15	21	262	finally
    //   30	43	266	finally
    //   52	65	270	finally
    //   87	119	274	finally
    //   136	163	278	finally
    //   188	257	282	finally
  }
  
  public static boolean a() {
    int i = Build.VERSION.SDK_INT;
    return (i == 26 || i == 27);
  }
  
  public static boolean b(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return true;
    } 
    if (a() && f == null)
      return false; 
    if (e == null && d == null)
      return false; 
    try {
      Object object1 = c.get(paramActivity);
      if (object1 == null)
        return false; 
      Object object2 = b.get(paramActivity);
      if (object2 == null)
        return false; 
      Application application = paramActivity.getApplication();
      c c = new c(paramActivity);
      application.registerActivityLifecycleCallbacks(c);
      Handler handler = g;
      handler.post(new a(c, object1));
    } finally {
      paramActivity = null;
    } 
  }
  
  public class a implements Runnable {
    public a(d this$0, Object param1Object) {}
    
    public void run() {
      this.f.f = this.g;
    }
  }
  
  public class b implements Runnable {
    public b(d this$0, d.c param1c) {}
    
    public void run() {
      this.f.unregisterActivityLifecycleCallbacks(this.g);
    }
  }
  
  public static final class c implements Application.ActivityLifecycleCallbacks {
    public Object f;
    
    public Activity g;
    
    public final int h;
    
    public boolean i = false;
    
    public boolean j = false;
    
    public boolean k = false;
    
    public c(Activity param1Activity) {
      this.g = param1Activity;
      this.h = param1Activity.hashCode();
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {
      if (this.g == param1Activity) {
        this.g = null;
        this.j = true;
      } 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      if (this.j && !this.k && !this.i) {
        boolean bool1;
        Object object = this.f;
        int i = this.h;
        boolean bool2 = false;
        try {
          Object object1 = d.c.get(param1Activity);
        } finally {
          param1Activity = null;
          Log.e("ActivityRecreator", "Exception while fetching field values", (Throwable)param1Activity);
        } 
        if (bool1) {
          this.k = true;
          this.f = null;
        } 
      } 
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {
      if (this.g == param1Activity)
        this.i = true; 
    }
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */