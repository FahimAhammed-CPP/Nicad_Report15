package androidx.media;

import java.util.Objects;
import o1.a;

public final class AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(a parama) {
    AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
    audioAttributesImplBase.a = parama.k(audioAttributesImplBase.a, 1);
    audioAttributesImplBase.b = parama.k(audioAttributesImplBase.b, 2);
    audioAttributesImplBase.c = parama.k(audioAttributesImplBase.c, 3);
    audioAttributesImplBase.d = parama.k(audioAttributesImplBase.d, 4);
    return audioAttributesImplBase;
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, a parama) {
    Objects.requireNonNull(parama);
    int i = paramAudioAttributesImplBase.a;
    parama.p(1);
    parama.t(i);
    i = paramAudioAttributesImplBase.b;
    parama.p(2);
    parama.t(i);
    i = paramAudioAttributesImplBase.c;
    parama.p(3);
    parama.t(i);
    i = paramAudioAttributesImplBase.d;
    parama.p(4);
    parama.t(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */