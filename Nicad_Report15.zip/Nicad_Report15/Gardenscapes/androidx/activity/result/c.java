package androidx.activity.result;

import android.annotation.SuppressLint;
import d.a;

public abstract class c<I> {
  public abstract a<I, ?> a();
  
  public abstract void b(@SuppressLint({"UnknownNullness"}) I paramI, b0.c paramc);
  
  public abstract void c();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\result\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */