package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class f implements Parcelable {
  public static final Parcelable.Creator<f> CREATOR = new a();
  
  public final IntentSender f;
  
  public final Intent g;
  
  public final int h;
  
  public final int i;
  
  public f(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.f = paramIntentSender;
    this.g = paramIntent;
    this.h = paramInt1;
    this.i = paramInt2;
  }
  
  public f(Parcel paramParcel) {
    this.f = (IntentSender)paramParcel.readParcelable(IntentSender.class.getClassLoader());
    this.g = (Intent)paramParcel.readParcelable(Intent.class.getClassLoader());
    this.h = paramParcel.readInt();
    this.i = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.f, paramInt);
    paramParcel.writeParcelable((Parcelable)this.g, paramInt);
    paramParcel.writeInt(this.h);
    paramParcel.writeInt(this.i);
  }
  
  public class a implements Parcelable.Creator<f> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new f(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new f[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\result\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */