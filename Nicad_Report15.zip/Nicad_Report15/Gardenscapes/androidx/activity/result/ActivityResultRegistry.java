package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class ActivityResultRegistry {
  public Random a = new Random();
  
  public final Map<Integer, String> b = new HashMap<Integer, String>();
  
  public final Map<String, Integer> c = new HashMap<String, Integer>();
  
  public final Map<String, d> d = new HashMap<String, d>();
  
  public ArrayList<String> e = new ArrayList<String>();
  
  public final transient Map<String, c<?>> f = new HashMap<String, c<?>>();
  
  public final Map<String, Object> g = new HashMap<String, Object>();
  
  public final Bundle h = new Bundle();
  
  public final boolean a(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    this.e.remove(str);
    c c = this.f.get(str);
    if (c != null) {
      b<Object> b = c.a;
      if (b != null) {
        b.a(c.b.parseResult(paramInt2, paramIntent));
        return true;
      } 
    } 
    this.g.remove(str);
    this.h.putParcelable(str, new a(paramInt2, paramIntent));
    return true;
  }
  
  public abstract <I, O> void b(int paramInt, d.a<I, O> parama, @SuppressLint({"UnknownNullness"}) I paramI, b0.c paramc);
  
  public final <I, O> c<I> c(String paramString, j paramj, d.a<I, O> parama, b<O> paramb) {
    d d1;
    int i;
    d d2;
    Lifecycle lifecycle = paramj.getLifecycle();
    k k = (k)lifecycle;
    if (k.b.compareTo(Lifecycle.State.i) >= 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i) {
      i = e(paramString);
      d2 = this.d.get(paramString);
      d1 = d2;
      if (d2 == null)
        d1 = new d(lifecycle); 
      h h = new h(this, paramString, paramb, parama) {
          public void a(j param1j, Lifecycle.Event param1Event) {
            if (Lifecycle.Event.ON_START.equals(param1Event)) {
              this.i.f.put(this.f, new ActivityResultRegistry.c(this.g, this.h));
              if (this.i.g.containsKey(this.f)) {
                param1j = (j)this.i.g.get(this.f);
                this.i.g.remove(this.f);
                this.g.a(param1j);
              } 
              a a1 = (a)this.i.h.getParcelable(this.f);
              if (a1 != null) {
                this.i.h.remove(this.f);
                this.g.a(this.h.parseResult(a1.f, a1.g));
                return;
              } 
            } else {
              if (Lifecycle.Event.ON_STOP.equals(param1Event)) {
                this.i.f.remove(this.f);
                return;
              } 
              if (Lifecycle.Event.ON_DESTROY.equals(param1Event))
                this.i.f(this.f); 
            } 
          }
        };
      d1.a.a((i)h);
      d1.b.add(h);
      this.d.put(paramString, d1);
      return new a(this, paramString, i, parama);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LifecycleOwner ");
    stringBuilder.append(d1);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(((k)d2).b);
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final <I, O> c<I> d(String paramString, d.a<I, O> parama, b<O> paramb) {
    int i = e(paramString);
    this.f.put(paramString, new c(paramb, parama));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      paramb.a((O)object);
    } 
    a a1 = (a)this.h.getParcelable(paramString);
    if (a1 != null) {
      this.h.remove(paramString);
      paramb.a((O)parama.parseResult(a1.f, a1.g));
    } 
    return new b(this, paramString, i, parama);
  }
  
  public final int e(String paramString) {
    Integer integer = this.c.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      this.b.put(Integer.valueOf(i), paramString);
      this.c.put(paramString, Integer.valueOf(i));
      return i;
    } 
  }
  
  public final void f(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = d.a("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = d.a("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    d d = this.d.get(paramString);
    if (d != null) {
      for (h h : d.b)
        d.a.b((i)h); 
      d.b.clear();
      this.d.remove(paramString);
    } 
  }
  
  public class a extends c<I> {
    public a(ActivityResultRegistry this$0, String param1String, int param1Int, d.a param1a) {}
    
    public d.a<I, ?> a() {
      return this.c;
    }
    
    public void b(I param1I, b0.c param1c) {
      int i;
      this.d.e.add(this.a);
      Integer integer = this.d.c.get(this.a);
      ActivityResultRegistry activityResultRegistry = this.d;
      if (integer != null) {
        i = integer.intValue();
      } else {
        i = this.b;
      } 
      activityResultRegistry.b(i, this.c, param1I, param1c);
    }
    
    public void c() {
      this.d.f(this.a);
    }
  }
  
  public class b extends c<I> {
    public b(ActivityResultRegistry this$0, String param1String, int param1Int, d.a param1a) {}
    
    public d.a<I, ?> a() {
      return this.c;
    }
    
    public void b(I param1I, b0.c param1c) {
      int i;
      this.d.e.add(this.a);
      Integer integer = this.d.c.get(this.a);
      ActivityResultRegistry activityResultRegistry = this.d;
      if (integer != null) {
        i = integer.intValue();
      } else {
        i = this.b;
      } 
      activityResultRegistry.b(i, this.c, param1I, param1c);
    }
    
    public void c() {
      this.d.f(this.a);
    }
  }
  
  public static class c<O> {
    public final b<O> a;
    
    public final d.a<?, O> b;
    
    public c(b<O> param1b, d.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  public static class d {
    public final Lifecycle a;
    
    public final ArrayList<h> b;
    
    public d(Lifecycle param1Lifecycle) {
      this.a = param1Lifecycle;
      this.b = new ArrayList<h>();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */