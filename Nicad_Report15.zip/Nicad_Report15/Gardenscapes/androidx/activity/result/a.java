package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class a implements Parcelable {
  public static final Parcelable.Creator<a> CREATOR = new a();
  
  public final int f;
  
  public final Intent g;
  
  public a(int paramInt, Intent paramIntent) {
    this.f = paramInt;
    this.g = paramIntent;
  }
  
  public a(Parcel paramParcel) {
    Intent intent;
    this.f = paramParcel.readInt();
    if (paramParcel.readInt() == 0) {
      paramParcel = null;
    } else {
      intent = (Intent)Intent.CREATOR.createFromParcel(paramParcel);
    } 
    this.g = intent;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = android.support.v4.media.a.a("ActivityResult{resultCode=");
    int i = this.f;
    if (i != -1) {
      if (i != 0) {
        str = String.valueOf(i);
      } else {
        str = "RESULT_CANCELED";
      } 
    } else {
      str = "RESULT_OK";
    } 
    stringBuilder.append(str);
    stringBuilder.append(", data=");
    stringBuilder.append(this.g);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool;
    paramParcel.writeInt(this.f);
    if (this.g == null) {
      bool = false;
    } else {
      bool = true;
    } 
    paramParcel.writeInt(bool);
    Intent intent = this.g;
    if (intent != null)
      intent.writeToParcel(paramParcel, paramInt); 
  }
  
  public class a implements Parcelable.Creator<a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new a(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new a[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\result\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */