package androidx.activity.result;

public interface e {
  ActivityResultRegistry getActivityResultRegistry();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */