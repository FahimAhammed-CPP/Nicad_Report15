package androidx.activity;

import java.util.concurrent.CopyOnWriteArrayList;

public abstract class b {
  public boolean a;
  
  public CopyOnWriteArrayList<a> b = new CopyOnWriteArrayList<a>();
  
  public b(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public abstract void a();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */