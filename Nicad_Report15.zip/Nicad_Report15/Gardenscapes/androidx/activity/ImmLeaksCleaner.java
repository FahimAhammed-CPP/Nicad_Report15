package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import java.lang.reflect.Field;

final class ImmLeaksCleaner implements h {
  public static int g;
  
  public static Field h;
  
  public static Field i;
  
  public static Field j;
  
  public Activity f;
  
  public ImmLeaksCleaner(Activity paramActivity) {
    this.f = paramActivity;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent != Lifecycle.Event.ON_DESTROY)
      return; 
    if (g == 0)
      try {
        g = 2;
        Field field = InputMethodManager.class.getDeclaredField("mServedView");
        i = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mNextServedView");
        j = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mH");
        h = field;
        field.setAccessible(true);
        g = 1;
      } catch (NoSuchFieldException noSuchFieldException) {} 
    if (g == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.f.getSystemService("input_method");
      try {
        Object object = h.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)i.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            j.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */