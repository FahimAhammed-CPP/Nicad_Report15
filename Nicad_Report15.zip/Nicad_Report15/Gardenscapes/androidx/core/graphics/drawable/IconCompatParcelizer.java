package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import java.nio.charset.Charset;
import java.util.Objects;
import o1.a;

public class IconCompatParcelizer {
  public static IconCompat read(a parama) {
    String str1;
    Parcelable parcelable2;
    byte[] arrayOfByte1;
    IconCompat iconCompat = new IconCompat();
    iconCompat.a = parama.k(iconCompat.a, 1);
    byte[] arrayOfByte2 = iconCompat.c;
    if (parama.i(2))
      arrayOfByte2 = parama.g(); 
    iconCompat.c = arrayOfByte2;
    iconCompat.d = parama.m(iconCompat.d, 3);
    iconCompat.e = parama.k(iconCompat.e, 4);
    iconCompat.f = parama.k(iconCompat.f, 5);
    iconCompat.g = (ColorStateList)parama.m((Parcelable)iconCompat.g, 6);
    String str2 = iconCompat.i;
    if (parama.i(7))
      str2 = parama.n(); 
    iconCompat.i = str2;
    str2 = iconCompat.j;
    if (!parama.i(8)) {
      str1 = str2;
    } else {
      str1 = str1.n();
    } 
    iconCompat.j = str1;
    iconCompat.h = PorterDuff.Mode.valueOf(iconCompat.i);
    switch (iconCompat.a) {
      default:
        return iconCompat;
      case 3:
        iconCompat.b = iconCompat.c;
        return iconCompat;
      case 2:
      case 4:
      case 6:
        str1 = new String(iconCompat.c, Charset.forName("UTF-16"));
        iconCompat.b = str1;
        if (iconCompat.a == 2 && iconCompat.j == null) {
          iconCompat.j = str1.split(":", -1)[0];
          return iconCompat;
        } 
        return iconCompat;
      case 1:
      case 5:
        parcelable2 = iconCompat.d;
        if (parcelable2 != null) {
          iconCompat.b = parcelable2;
          return iconCompat;
        } 
        arrayOfByte1 = iconCompat.c;
        iconCompat.b = arrayOfByte1;
        iconCompat.a = 3;
        iconCompat.e = 0;
        iconCompat.f = arrayOfByte1.length;
        return iconCompat;
      case -1:
        break;
    } 
    Parcelable parcelable1 = iconCompat.d;
    if (parcelable1 != null) {
      iconCompat.b = parcelable1;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public static void write(IconCompat paramIconCompat, a parama) {
    Objects.requireNonNull(parama);
    paramIconCompat.i = paramIconCompat.h.name();
    switch (paramIconCompat.a) {
      case 4:
      case 6:
        paramIconCompat.c = paramIconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
        break;
      case 3:
        paramIconCompat.c = (byte[])paramIconCompat.b;
        break;
      case 2:
        paramIconCompat.c = ((String)paramIconCompat.b).getBytes(Charset.forName("UTF-16"));
        break;
      case 1:
      case 5:
        paramIconCompat.d = (Parcelable)paramIconCompat.b;
        break;
      case -1:
        paramIconCompat.d = (Parcelable)paramIconCompat.b;
        break;
    } 
    int i = paramIconCompat.a;
    if (-1 != i) {
      parama.p(1);
      parama.t(i);
    } 
    byte[] arrayOfByte = paramIconCompat.c;
    if (arrayOfByte != null) {
      parama.p(2);
      parama.r(arrayOfByte);
    } 
    Parcelable parcelable = paramIconCompat.d;
    if (parcelable != null) {
      parama.p(3);
      parama.u(parcelable);
    } 
    i = paramIconCompat.e;
    if (i != 0) {
      parama.p(4);
      parama.t(i);
    } 
    i = paramIconCompat.f;
    if (i != 0) {
      parama.p(5);
      parama.t(i);
    } 
    ColorStateList colorStateList = paramIconCompat.g;
    if (colorStateList != null) {
      parama.p(6);
      parama.u((Parcelable)colorStateList);
    } 
    String str2 = paramIconCompat.i;
    if (str2 != null) {
      parama.p(7);
      parama.v(str2);
    } 
    String str1 = paramIconCompat.j;
    if (str1 != null) {
      parama.p(8);
      parama.v(str1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */