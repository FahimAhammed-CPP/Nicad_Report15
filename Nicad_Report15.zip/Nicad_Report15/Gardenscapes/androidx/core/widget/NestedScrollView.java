package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import androidx.core.view.ScrollingView;
import java.util.WeakHashMap;
import m0.j;
import m0.k;
import m0.m;
import m0.o;
import m0.y;
import q0.d;

public class NestedScrollView extends FrameLayout implements m, j, ScrollingView {
  public static final a F = new a();
  
  public static final int[] G = new int[] { 16843130 };
  
  public c A;
  
  public final o B;
  
  public final k C;
  
  public float D;
  
  public b E;
  
  public long f;
  
  public final Rect g;
  
  public OverScroller h;
  
  public EdgeEffect i;
  
  public EdgeEffect j;
  
  public int k;
  
  public boolean l;
  
  public boolean m;
  
  public View n;
  
  public boolean o;
  
  public VelocityTracker p;
  
  public boolean q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public final int[] w;
  
  public final int[] x;
  
  public int y;
  
  public int z;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903754);
    EdgeEffect edgeEffect;
    this.g = new Rect();
    this.l = true;
    this.m = false;
    this.n = null;
    this.o = false;
    this.r = true;
    this.v = -1;
    this.w = new int[2];
    this.x = new int[2];
    if (i0.a.a()) {
      edgeEffect = d.a.a(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.i = edgeEffect;
    if (i0.a.a()) {
      edgeEffect = d.a.a(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.j = edgeEffect;
    this.h = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.s = viewConfiguration.getScaledTouchSlop();
    this.t = viewConfiguration.getScaledMinimumFlingVelocity();
    this.u = viewConfiguration.getScaledMaximumFlingVelocity();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, G, 2130903754, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.B = new o(0);
    this.C = new k((View)this);
    setNestedScrollingEnabled(true);
    y.A((View)this, F);
  }
  
  public static int c(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.D == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.D = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.D;
  }
  
  public static boolean q(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && q((View)viewParent, paramView2));
  }
  
  public boolean A(int paramInt1, int paramInt2) {
    return this.C.j(paramInt1, paramInt2);
  }
  
  public final boolean B(MotionEvent paramMotionEvent) {
    boolean bool;
    if (d.a(this.i) != 0.0F) {
      d.c(this.i, 0.0F, paramMotionEvent.getY() / getHeight());
      bool = true;
    } else {
      bool = false;
    } 
    if (d.a(this.j) != 0.0F) {
      d.c(this.j, 0.0F, 1.0F - paramMotionEvent.getY() / getHeight());
      return true;
    } 
    return bool;
  }
  
  public void C(int paramInt) {
    this.C.k(paramInt);
  }
  
  public final void a() {
    this.h.abortAnimation();
    this.C.k(1);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && r(view2, i, getHeight())) {
      view2.getDrawingRect(this.g);
      offsetDescendantRectToMyCoords(view2, this.g);
      f(d(this.g));
      view2.requestFocus(paramInt);
    } else {
      int n;
      if (paramInt == 33 && getScrollY() < i) {
        n = getScrollY();
      } else {
        n = i;
        if (paramInt == 130) {
          n = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            n = view2.getBottom();
            int i1 = layoutParams.bottomMargin;
            int i2 = getScrollY();
            n = Math.min(n + i1 - getHeight() + i2 - getPaddingBottom(), i);
          } 
        } 
      } 
      if (n == 0)
        return false; 
      if (paramInt != 130)
        n = -n; 
      f(n);
    } 
    if (view1 != null && view1.isFocused() && (r(view1, 0, getHeight()) ^ true) != 0) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield h : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield h : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield z : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield z : I
    //   39: aload_0
    //   40: getfield x : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual e : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield x : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 160
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: invokevirtual u : (IIIIIIII)Z
    //   105: pop
    //   106: aload_0
    //   107: invokevirtual getScrollY : ()I
    //   110: iload_1
    //   111: isub
    //   112: istore_1
    //   113: iload_2
    //   114: iload_1
    //   115: isub
    //   116: istore_2
    //   117: aload_0
    //   118: getfield x : [I
    //   121: astore #6
    //   123: aload #6
    //   125: iconst_1
    //   126: iconst_0
    //   127: iastore
    //   128: aload_0
    //   129: getfield w : [I
    //   132: astore #7
    //   134: aload_0
    //   135: getfield C : Lm0/k;
    //   138: iconst_0
    //   139: iload_1
    //   140: iconst_0
    //   141: iload_2
    //   142: aload #7
    //   144: iconst_1
    //   145: aload #6
    //   147: invokevirtual f : (IIII[II[I)Z
    //   150: pop
    //   151: iload_2
    //   152: aload_0
    //   153: getfield x : [I
    //   156: iconst_1
    //   157: iaload
    //   158: isub
    //   159: istore_1
    //   160: iload_1
    //   161: ifeq -> 257
    //   164: aload_0
    //   165: invokevirtual getOverScrollMode : ()I
    //   168: istore #5
    //   170: iload #5
    //   172: ifeq -> 190
    //   175: iload_3
    //   176: istore_2
    //   177: iload #5
    //   179: iconst_1
    //   180: if_icmpne -> 192
    //   183: iload_3
    //   184: istore_2
    //   185: iload #4
    //   187: ifle -> 192
    //   190: iconst_1
    //   191: istore_2
    //   192: iload_2
    //   193: ifeq -> 253
    //   196: iload_1
    //   197: ifge -> 228
    //   200: aload_0
    //   201: getfield i : Landroid/widget/EdgeEffect;
    //   204: invokevirtual isFinished : ()Z
    //   207: ifeq -> 253
    //   210: aload_0
    //   211: getfield i : Landroid/widget/EdgeEffect;
    //   214: aload_0
    //   215: getfield h : Landroid/widget/OverScroller;
    //   218: invokevirtual getCurrVelocity : ()F
    //   221: f2i
    //   222: invokevirtual onAbsorb : (I)V
    //   225: goto -> 253
    //   228: aload_0
    //   229: getfield j : Landroid/widget/EdgeEffect;
    //   232: invokevirtual isFinished : ()Z
    //   235: ifeq -> 253
    //   238: aload_0
    //   239: getfield j : Landroid/widget/EdgeEffect;
    //   242: aload_0
    //   243: getfield h : Landroid/widget/OverScroller;
    //   246: invokevirtual getCurrVelocity : ()F
    //   249: f2i
    //   250: invokevirtual onAbsorb : (I)V
    //   253: aload_0
    //   254: invokevirtual a : ()V
    //   257: aload_0
    //   258: getfield h : Landroid/widget/OverScroller;
    //   261: invokevirtual isFinished : ()Z
    //   264: ifne -> 277
    //   267: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   270: astore #6
    //   272: aload_0
    //   273: invokestatic k : (Landroid/view/View;)V
    //   276: return
    //   277: aload_0
    //   278: getfield C : Lm0/k;
    //   281: iconst_1
    //   282: invokevirtual k : (I)V
    //   285: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int n = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (n == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    n = view.getBottom() + layoutParams.bottomMargin;
    int i1 = getScrollY();
    int i2 = Math.max(0, n - i);
    if (i1 < 0)
      return n - i1; 
    i = n;
    if (i1 > i2)
      i = n + i1 - i2; 
    return i;
  }
  
  public int d(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int i2 = getHeight();
    int n = getScrollY();
    int i1 = n + i2;
    int i3 = getVerticalFadingEdgeLength();
    i = n;
    if (paramRect.top > 0)
      i = n + i3; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      n = i1 - i3;
    } else {
      n = i1;
    } 
    i3 = paramRect.bottom;
    if (i3 > n && paramRect.top > i) {
      if (paramRect.height() > i2) {
        i = paramRect.top - i;
      } else {
        i = paramRect.bottom - n;
      } 
      return Math.min(i + 0, view.getBottom() + layoutParams.bottomMargin - i1);
    } 
    i1 = bool;
    if (paramRect.top < i) {
      i1 = bool;
      if (i3 < n) {
        if (paramRect.height() > i2) {
          i = 0 - n - paramRect.bottom;
        } else {
          i = 0 - i - paramRect.top;
        } 
        i1 = Math.max(i, -getScrollY());
      } 
    } 
    return i1;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || g(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.C.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.C.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return e(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.C.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: invokevirtual getScrollY : ()I
    //   9: istore #9
    //   11: aload_0
    //   12: getfield i : Landroid/widget/EdgeEffect;
    //   15: invokevirtual isFinished : ()Z
    //   18: istore #12
    //   20: iconst_0
    //   21: istore #6
    //   23: iload #12
    //   25: ifne -> 203
    //   28: aload_1
    //   29: invokevirtual save : ()I
    //   32: istore #10
    //   34: aload_0
    //   35: invokevirtual getWidth : ()I
    //   38: istore_2
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: istore #8
    //   45: iconst_0
    //   46: iload #9
    //   48: invokestatic min : (II)I
    //   51: istore #7
    //   53: getstatic android/os/Build$VERSION.SDK_INT : I
    //   56: istore #11
    //   58: iload #11
    //   60: bipush #21
    //   62: if_icmplt -> 80
    //   65: aload_0
    //   66: invokevirtual getClipToPadding : ()Z
    //   69: ifeq -> 75
    //   72: goto -> 80
    //   75: iconst_0
    //   76: istore_3
    //   77: goto -> 101
    //   80: aload_0
    //   81: invokevirtual getPaddingLeft : ()I
    //   84: istore_3
    //   85: iload_2
    //   86: aload_0
    //   87: invokevirtual getPaddingRight : ()I
    //   90: iload_3
    //   91: iadd
    //   92: isub
    //   93: istore_2
    //   94: aload_0
    //   95: invokevirtual getPaddingLeft : ()I
    //   98: iconst_0
    //   99: iadd
    //   100: istore_3
    //   101: iload #8
    //   103: istore #5
    //   105: iload #7
    //   107: istore #4
    //   109: iload #11
    //   111: bipush #21
    //   113: if_icmplt -> 158
    //   116: iload #8
    //   118: istore #5
    //   120: iload #7
    //   122: istore #4
    //   124: aload_0
    //   125: invokevirtual getClipToPadding : ()Z
    //   128: ifeq -> 158
    //   131: aload_0
    //   132: invokevirtual getPaddingTop : ()I
    //   135: istore #4
    //   137: iload #8
    //   139: aload_0
    //   140: invokevirtual getPaddingBottom : ()I
    //   143: iload #4
    //   145: iadd
    //   146: isub
    //   147: istore #5
    //   149: iload #7
    //   151: aload_0
    //   152: invokevirtual getPaddingTop : ()I
    //   155: iadd
    //   156: istore #4
    //   158: aload_1
    //   159: iload_3
    //   160: i2f
    //   161: iload #4
    //   163: i2f
    //   164: invokevirtual translate : (FF)V
    //   167: aload_0
    //   168: getfield i : Landroid/widget/EdgeEffect;
    //   171: iload_2
    //   172: iload #5
    //   174: invokevirtual setSize : (II)V
    //   177: aload_0
    //   178: getfield i : Landroid/widget/EdgeEffect;
    //   181: aload_1
    //   182: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   185: ifeq -> 197
    //   188: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   191: astore #13
    //   193: aload_0
    //   194: invokestatic k : (Landroid/view/View;)V
    //   197: aload_1
    //   198: iload #10
    //   200: invokevirtual restoreToCount : (I)V
    //   203: aload_0
    //   204: getfield j : Landroid/widget/EdgeEffect;
    //   207: invokevirtual isFinished : ()Z
    //   210: ifne -> 406
    //   213: aload_1
    //   214: invokevirtual save : ()I
    //   217: istore #10
    //   219: aload_0
    //   220: invokevirtual getWidth : ()I
    //   223: istore #4
    //   225: aload_0
    //   226: invokevirtual getHeight : ()I
    //   229: istore #7
    //   231: aload_0
    //   232: invokevirtual getScrollRange : ()I
    //   235: iload #9
    //   237: invokestatic max : (II)I
    //   240: iload #7
    //   242: iadd
    //   243: istore #8
    //   245: getstatic android/os/Build$VERSION.SDK_INT : I
    //   248: istore #9
    //   250: iload #9
    //   252: bipush #21
    //   254: if_icmplt -> 270
    //   257: iload #6
    //   259: istore_3
    //   260: iload #4
    //   262: istore_2
    //   263: aload_0
    //   264: invokevirtual getClipToPadding : ()Z
    //   267: ifeq -> 292
    //   270: aload_0
    //   271: invokevirtual getPaddingLeft : ()I
    //   274: istore_2
    //   275: iload #4
    //   277: aload_0
    //   278: invokevirtual getPaddingRight : ()I
    //   281: iload_2
    //   282: iadd
    //   283: isub
    //   284: istore_2
    //   285: iconst_0
    //   286: aload_0
    //   287: invokevirtual getPaddingLeft : ()I
    //   290: iadd
    //   291: istore_3
    //   292: iload #8
    //   294: istore #5
    //   296: iload #7
    //   298: istore #4
    //   300: iload #9
    //   302: bipush #21
    //   304: if_icmplt -> 349
    //   307: iload #8
    //   309: istore #5
    //   311: iload #7
    //   313: istore #4
    //   315: aload_0
    //   316: invokevirtual getClipToPadding : ()Z
    //   319: ifeq -> 349
    //   322: aload_0
    //   323: invokevirtual getPaddingTop : ()I
    //   326: istore #4
    //   328: iload #7
    //   330: aload_0
    //   331: invokevirtual getPaddingBottom : ()I
    //   334: iload #4
    //   336: iadd
    //   337: isub
    //   338: istore #4
    //   340: iload #8
    //   342: aload_0
    //   343: invokevirtual getPaddingBottom : ()I
    //   346: isub
    //   347: istore #5
    //   349: aload_1
    //   350: iload_3
    //   351: iload_2
    //   352: isub
    //   353: i2f
    //   354: iload #5
    //   356: i2f
    //   357: invokevirtual translate : (FF)V
    //   360: aload_1
    //   361: ldc_w 180.0
    //   364: iload_2
    //   365: i2f
    //   366: fconst_0
    //   367: invokevirtual rotate : (FFF)V
    //   370: aload_0
    //   371: getfield j : Landroid/widget/EdgeEffect;
    //   374: iload_2
    //   375: iload #4
    //   377: invokevirtual setSize : (II)V
    //   380: aload_0
    //   381: getfield j : Landroid/widget/EdgeEffect;
    //   384: aload_1
    //   385: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   388: ifeq -> 400
    //   391: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   394: astore #13
    //   396: aload_0
    //   397: invokestatic k : (Landroid/view/View;)V
    //   400: aload_1
    //   401: iload #10
    //   403: invokevirtual restoreToCount : (I)V
    //   406: return
  }
  
  public boolean e(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.C.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public final void f(int paramInt) {
    if (paramInt != 0) {
      if (this.r) {
        z(0, paramInt, 250, false);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public boolean g(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/graphics/Rect;
    //   4: invokevirtual setEmpty : ()V
    //   7: aload_0
    //   8: invokevirtual getChildCount : ()I
    //   11: istore_2
    //   12: iconst_0
    //   13: istore #6
    //   15: iload_2
    //   16: ifle -> 75
    //   19: aload_0
    //   20: iconst_0
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: astore #7
    //   26: aload #7
    //   28: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   31: checkcast android/widget/FrameLayout$LayoutParams
    //   34: astore #8
    //   36: aload #7
    //   38: invokevirtual getHeight : ()I
    //   41: aload #8
    //   43: getfield topMargin : I
    //   46: iadd
    //   47: aload #8
    //   49: getfield bottomMargin : I
    //   52: iadd
    //   53: aload_0
    //   54: invokevirtual getHeight : ()I
    //   57: aload_0
    //   58: invokevirtual getPaddingTop : ()I
    //   61: isub
    //   62: aload_0
    //   63: invokevirtual getPaddingBottom : ()I
    //   66: isub
    //   67: if_icmple -> 75
    //   70: iconst_1
    //   71: istore_2
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_2
    //   78: ifne -> 150
    //   81: aload_0
    //   82: invokevirtual isFocused : ()Z
    //   85: ifeq -> 148
    //   88: aload_1
    //   89: invokevirtual getKeyCode : ()I
    //   92: iconst_4
    //   93: if_icmpeq -> 148
    //   96: aload_0
    //   97: invokevirtual findFocus : ()Landroid/view/View;
    //   100: astore #7
    //   102: aload #7
    //   104: astore_1
    //   105: aload #7
    //   107: aload_0
    //   108: if_acmpne -> 113
    //   111: aconst_null
    //   112: astore_1
    //   113: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   116: aload_0
    //   117: aload_1
    //   118: sipush #130
    //   121: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   124: astore_1
    //   125: aload_1
    //   126: ifnull -> 146
    //   129: aload_1
    //   130: aload_0
    //   131: if_acmpeq -> 146
    //   134: aload_1
    //   135: sipush #130
    //   138: invokevirtual requestFocus : (I)Z
    //   141: ifeq -> 146
    //   144: iconst_1
    //   145: ireturn
    //   146: iconst_0
    //   147: ireturn
    //   148: iconst_0
    //   149: ireturn
    //   150: aload_1
    //   151: invokevirtual getAction : ()I
    //   154: ifne -> 421
    //   157: aload_1
    //   158: invokevirtual getKeyCode : ()I
    //   161: istore_3
    //   162: bipush #33
    //   164: istore_2
    //   165: iload_3
    //   166: bipush #19
    //   168: if_icmpeq -> 399
    //   171: iload_3
    //   172: bipush #20
    //   174: if_icmpeq -> 376
    //   177: iload_3
    //   178: bipush #62
    //   180: if_icmpeq -> 185
    //   183: iconst_0
    //   184: ireturn
    //   185: aload_1
    //   186: invokevirtual isShiftPressed : ()Z
    //   189: ifeq -> 195
    //   192: goto -> 199
    //   195: sipush #130
    //   198: istore_2
    //   199: iload_2
    //   200: sipush #130
    //   203: if_icmpne -> 211
    //   206: iconst_1
    //   207: istore_3
    //   208: goto -> 213
    //   211: iconst_0
    //   212: istore_3
    //   213: aload_0
    //   214: invokevirtual getHeight : ()I
    //   217: istore #4
    //   219: iload_3
    //   220: ifeq -> 312
    //   223: aload_0
    //   224: getfield g : Landroid/graphics/Rect;
    //   227: aload_0
    //   228: invokevirtual getScrollY : ()I
    //   231: iload #4
    //   233: iadd
    //   234: putfield top : I
    //   237: aload_0
    //   238: invokevirtual getChildCount : ()I
    //   241: istore_3
    //   242: iload_3
    //   243: ifle -> 343
    //   246: aload_0
    //   247: iload_3
    //   248: iconst_1
    //   249: isub
    //   250: invokevirtual getChildAt : (I)Landroid/view/View;
    //   253: astore_1
    //   254: aload_1
    //   255: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   258: checkcast android/widget/FrameLayout$LayoutParams
    //   261: astore #7
    //   263: aload_1
    //   264: invokevirtual getBottom : ()I
    //   267: istore_3
    //   268: aload #7
    //   270: getfield bottomMargin : I
    //   273: istore #5
    //   275: aload_0
    //   276: invokevirtual getPaddingBottom : ()I
    //   279: iload_3
    //   280: iload #5
    //   282: iadd
    //   283: iadd
    //   284: istore_3
    //   285: aload_0
    //   286: getfield g : Landroid/graphics/Rect;
    //   289: astore_1
    //   290: aload_1
    //   291: getfield top : I
    //   294: iload #4
    //   296: iadd
    //   297: iload_3
    //   298: if_icmple -> 343
    //   301: aload_1
    //   302: iload_3
    //   303: iload #4
    //   305: isub
    //   306: putfield top : I
    //   309: goto -> 343
    //   312: aload_0
    //   313: getfield g : Landroid/graphics/Rect;
    //   316: aload_0
    //   317: invokevirtual getScrollY : ()I
    //   320: iload #4
    //   322: isub
    //   323: putfield top : I
    //   326: aload_0
    //   327: getfield g : Landroid/graphics/Rect;
    //   330: astore_1
    //   331: aload_1
    //   332: getfield top : I
    //   335: ifge -> 343
    //   338: aload_1
    //   339: iconst_0
    //   340: putfield top : I
    //   343: aload_0
    //   344: getfield g : Landroid/graphics/Rect;
    //   347: astore_1
    //   348: aload_1
    //   349: getfield top : I
    //   352: istore_3
    //   353: iload #4
    //   355: iload_3
    //   356: iadd
    //   357: istore #4
    //   359: aload_1
    //   360: iload #4
    //   362: putfield bottom : I
    //   365: aload_0
    //   366: iload_2
    //   367: iload_3
    //   368: iload #4
    //   370: invokevirtual x : (III)Z
    //   373: pop
    //   374: iconst_0
    //   375: ireturn
    //   376: aload_1
    //   377: invokevirtual isAltPressed : ()Z
    //   380: ifne -> 391
    //   383: aload_0
    //   384: sipush #130
    //   387: invokevirtual b : (I)Z
    //   390: ireturn
    //   391: aload_0
    //   392: sipush #130
    //   395: invokevirtual l : (I)Z
    //   398: ireturn
    //   399: aload_1
    //   400: invokevirtual isAltPressed : ()Z
    //   403: ifne -> 413
    //   406: aload_0
    //   407: bipush #33
    //   409: invokevirtual b : (I)Z
    //   412: ireturn
    //   413: aload_0
    //   414: bipush #33
    //   416: invokevirtual l : (I)Z
    //   419: istore #6
    //   421: iload #6
    //   423: ireturn
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int n = getHeight();
    int i1 = getPaddingBottom();
    n = view.getBottom() + layoutParams.bottomMargin - getScrollY() - n - i1;
    return (n < i) ? (n / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.B.a();
  }
  
  public int getScrollRange() {
    int n = getChildCount();
    int i = 0;
    if (n > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int n = getScrollY();
    return (n < i) ? (n / i) : 1.0F;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    o o1 = this.B;
    if (paramInt2 == 1) {
      o1.b = paramInt1;
    } else {
      o1.a = paramInt1;
    } 
    A(2, paramInt2);
  }
  
  public boolean hasNestedScrollingParent() {
    return p(0);
  }
  
  public void i(View paramView, int paramInt) {
    o o1 = this.B;
    if (paramInt == 1) {
      o1.b = 0;
    } else {
      o1.a = 0;
    } 
    this.C.k(paramInt);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.C.d;
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    e(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void k(int paramInt) {
    if (getChildCount() > 0) {
      this.h.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      w(true);
    } 
  }
  
  public boolean l(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int n = getHeight();
    Rect rect = this.g;
    rect.top = 0;
    rect.bottom = n;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        Rect rect2 = this.g;
        i = view.getBottom();
        int i1 = layoutParams.bottomMargin;
        rect2.bottom = getPaddingBottom() + i + i1;
        Rect rect1 = this.g;
        rect1.top = rect1.bottom - n;
      } 
    } 
    rect = this.g;
    return x(paramInt, rect.top, rect.bottom);
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    s(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramInt2 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt2, layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramInt3 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt3 + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    s(paramInt4, paramInt5, null);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.m = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.o) {
        float f = paramMotionEvent.getAxisValue(9);
        if (f != 0.0F) {
          int n = (int)(f * getVerticalScrollFactorCompat());
          int i = getScrollRange();
          int i1 = getScrollY();
          n = i1 - n;
          if (n < 0) {
            i = 0;
          } else if (n <= i) {
            i = n;
          } 
          if (i != i1) {
            super.scrollTo(getScrollX(), i);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_2
    //   5: iconst_1
    //   6: istore #7
    //   8: iconst_1
    //   9: istore #6
    //   11: iload_2
    //   12: iconst_2
    //   13: if_icmpne -> 25
    //   16: aload_0
    //   17: getfield o : Z
    //   20: ifeq -> 25
    //   23: iconst_1
    //   24: ireturn
    //   25: iload_2
    //   26: sipush #255
    //   29: iand
    //   30: istore_2
    //   31: iload_2
    //   32: ifeq -> 281
    //   35: iload_2
    //   36: iconst_1
    //   37: if_icmpeq -> 223
    //   40: iload_2
    //   41: iconst_2
    //   42: if_icmpeq -> 67
    //   45: iload_2
    //   46: iconst_3
    //   47: if_icmpeq -> 223
    //   50: iload_2
    //   51: bipush #6
    //   53: if_icmpeq -> 59
    //   56: goto -> 512
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual t : (Landroid/view/MotionEvent;)V
    //   64: goto -> 512
    //   67: aload_0
    //   68: getfield v : I
    //   71: istore_2
    //   72: iload_2
    //   73: iconst_m1
    //   74: if_icmpne -> 80
    //   77: goto -> 512
    //   80: aload_1
    //   81: iload_2
    //   82: invokevirtual findPointerIndex : (I)I
    //   85: istore_3
    //   86: iload_3
    //   87: iconst_m1
    //   88: if_icmpne -> 135
    //   91: new java/lang/StringBuilder
    //   94: dup
    //   95: invokespecial <init> : ()V
    //   98: astore_1
    //   99: aload_1
    //   100: ldc_w 'Invalid pointerId='
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload_1
    //   108: iload_2
    //   109: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_1
    //   114: ldc_w ' in onInterceptTouchEvent'
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: ldc_w 'NestedScrollView'
    //   124: aload_1
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   131: pop
    //   132: goto -> 512
    //   135: aload_1
    //   136: iload_3
    //   137: invokevirtual getY : (I)F
    //   140: f2i
    //   141: istore_2
    //   142: iload_2
    //   143: aload_0
    //   144: getfield k : I
    //   147: isub
    //   148: invokestatic abs : (I)I
    //   151: aload_0
    //   152: getfield s : I
    //   155: if_icmple -> 512
    //   158: iconst_2
    //   159: aload_0
    //   160: invokevirtual getNestedScrollAxes : ()I
    //   163: iand
    //   164: ifne -> 512
    //   167: aload_0
    //   168: iconst_1
    //   169: putfield o : Z
    //   172: aload_0
    //   173: iload_2
    //   174: putfield k : I
    //   177: aload_0
    //   178: getfield p : Landroid/view/VelocityTracker;
    //   181: ifnonnull -> 191
    //   184: aload_0
    //   185: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   188: putfield p : Landroid/view/VelocityTracker;
    //   191: aload_0
    //   192: getfield p : Landroid/view/VelocityTracker;
    //   195: aload_1
    //   196: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   199: aload_0
    //   200: iconst_0
    //   201: putfield y : I
    //   204: aload_0
    //   205: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   208: astore_1
    //   209: aload_1
    //   210: ifnull -> 512
    //   213: aload_1
    //   214: iconst_1
    //   215: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   220: goto -> 512
    //   223: aload_0
    //   224: iconst_0
    //   225: putfield o : Z
    //   228: aload_0
    //   229: iconst_m1
    //   230: putfield v : I
    //   233: aload_0
    //   234: invokevirtual v : ()V
    //   237: aload_0
    //   238: getfield h : Landroid/widget/OverScroller;
    //   241: aload_0
    //   242: invokevirtual getScrollX : ()I
    //   245: aload_0
    //   246: invokevirtual getScrollY : ()I
    //   249: iconst_0
    //   250: iconst_0
    //   251: iconst_0
    //   252: aload_0
    //   253: invokevirtual getScrollRange : ()I
    //   256: invokevirtual springBack : (IIIIII)Z
    //   259: ifeq -> 270
    //   262: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   265: astore_1
    //   266: aload_0
    //   267: invokestatic k : (Landroid/view/View;)V
    //   270: aload_0
    //   271: getfield C : Lm0/k;
    //   274: iconst_0
    //   275: invokevirtual k : (I)V
    //   278: goto -> 512
    //   281: aload_1
    //   282: invokevirtual getY : ()F
    //   285: f2i
    //   286: istore_3
    //   287: aload_1
    //   288: invokevirtual getX : ()F
    //   291: f2i
    //   292: istore_2
    //   293: aload_0
    //   294: invokevirtual getChildCount : ()I
    //   297: ifle -> 360
    //   300: aload_0
    //   301: invokevirtual getScrollY : ()I
    //   304: istore #4
    //   306: aload_0
    //   307: iconst_0
    //   308: invokevirtual getChildAt : (I)Landroid/view/View;
    //   311: astore #8
    //   313: iload_3
    //   314: aload #8
    //   316: invokevirtual getTop : ()I
    //   319: iload #4
    //   321: isub
    //   322: if_icmplt -> 360
    //   325: iload_3
    //   326: aload #8
    //   328: invokevirtual getBottom : ()I
    //   331: iload #4
    //   333: isub
    //   334: if_icmpge -> 360
    //   337: iload_2
    //   338: aload #8
    //   340: invokevirtual getLeft : ()I
    //   343: if_icmplt -> 360
    //   346: iload_2
    //   347: aload #8
    //   349: invokevirtual getRight : ()I
    //   352: if_icmpge -> 360
    //   355: iconst_1
    //   356: istore_2
    //   357: goto -> 362
    //   360: iconst_0
    //   361: istore_2
    //   362: iload_2
    //   363: ifne -> 411
    //   366: iload #6
    //   368: istore #5
    //   370: aload_0
    //   371: aload_1
    //   372: invokevirtual B : (Landroid/view/MotionEvent;)Z
    //   375: ifne -> 398
    //   378: aload_0
    //   379: getfield h : Landroid/widget/OverScroller;
    //   382: invokevirtual isFinished : ()Z
    //   385: ifne -> 395
    //   388: iload #6
    //   390: istore #5
    //   392: goto -> 398
    //   395: iconst_0
    //   396: istore #5
    //   398: aload_0
    //   399: iload #5
    //   401: putfield o : Z
    //   404: aload_0
    //   405: invokevirtual v : ()V
    //   408: goto -> 512
    //   411: aload_0
    //   412: iload_3
    //   413: putfield k : I
    //   416: aload_0
    //   417: aload_1
    //   418: iconst_0
    //   419: invokevirtual getPointerId : (I)I
    //   422: putfield v : I
    //   425: aload_0
    //   426: getfield p : Landroid/view/VelocityTracker;
    //   429: astore #8
    //   431: aload #8
    //   433: ifnonnull -> 446
    //   436: aload_0
    //   437: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   440: putfield p : Landroid/view/VelocityTracker;
    //   443: goto -> 451
    //   446: aload #8
    //   448: invokevirtual clear : ()V
    //   451: aload_0
    //   452: getfield p : Landroid/view/VelocityTracker;
    //   455: aload_1
    //   456: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   459: aload_0
    //   460: getfield h : Landroid/widget/OverScroller;
    //   463: invokevirtual computeScrollOffset : ()Z
    //   466: pop
    //   467: iload #7
    //   469: istore #5
    //   471: aload_0
    //   472: aload_1
    //   473: invokevirtual B : (Landroid/view/MotionEvent;)Z
    //   476: ifne -> 499
    //   479: aload_0
    //   480: getfield h : Landroid/widget/OverScroller;
    //   483: invokevirtual isFinished : ()Z
    //   486: ifne -> 496
    //   489: iload #7
    //   491: istore #5
    //   493: goto -> 499
    //   496: iconst_0
    //   497: istore #5
    //   499: aload_0
    //   500: iload #5
    //   502: putfield o : Z
    //   505: aload_0
    //   506: iconst_2
    //   507: iconst_0
    //   508: invokevirtual A : (II)Z
    //   511: pop
    //   512: aload_0
    //   513: getfield o : Z
    //   516: ireturn
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.l = false;
    View view = this.n;
    if (view != null && q(view, (View)this))
      y(this.n); 
    this.n = null;
    if (!this.m) {
      if (this.A != null) {
        scrollTo(getScrollX(), this.A.f);
        this.A = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int i = getPaddingTop();
      int n = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = c(paramInt3, paramInt4 - paramInt2 - i - n, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.m = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.q)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (i < paramInt2) {
        i = getPaddingLeft();
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + i + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      k((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    e(paramInt1, paramInt2, paramArrayOfint, null, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    s(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.B.a = paramInt;
    A(2, 0);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (((true ^ r(view, 0, getHeight())) != 0) ? false : view.requestFocus(i, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.A = c1;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.f = getScrollY();
    return (Parcelable)c1;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.E;
    if (b1 != null) {
      f.c c1 = (f.c)b1;
      AlertController.c((View)this, c1.a, c1.b);
    } 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (r(view, 0, paramInt4)) {
        view.getDrawingRect(this.g);
        offsetDescendantRectToMyCoords(view, this.g);
        f(d(this.g));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.B.a = 0;
    C(0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Landroid/view/VelocityTracker;
    //   4: ifnonnull -> 14
    //   7: aload_0
    //   8: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   11: putfield p : Landroid/view/VelocityTracker;
    //   14: aload_1
    //   15: invokevirtual getActionMasked : ()I
    //   18: istore #5
    //   20: iconst_0
    //   21: istore #8
    //   23: iload #5
    //   25: ifne -> 33
    //   28: aload_0
    //   29: iconst_0
    //   30: putfield y : I
    //   33: aload_1
    //   34: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    //   37: astore #13
    //   39: aload_0
    //   40: getfield y : I
    //   43: i2f
    //   44: fstore_3
    //   45: fconst_0
    //   46: fstore_2
    //   47: aload #13
    //   49: fconst_0
    //   50: fload_3
    //   51: invokevirtual offsetLocation : (FF)V
    //   54: iload #5
    //   56: ifeq -> 1163
    //   59: iload #5
    //   61: iconst_1
    //   62: if_icmpeq -> 956
    //   65: iload #5
    //   67: iconst_2
    //   68: if_icmpeq -> 234
    //   71: iload #5
    //   73: iconst_3
    //   74: if_icmpeq -> 148
    //   77: iload #5
    //   79: iconst_5
    //   80: if_icmpeq -> 118
    //   83: iload #5
    //   85: bipush #6
    //   87: if_icmpeq -> 93
    //   90: goto -> 1237
    //   93: aload_0
    //   94: aload_1
    //   95: invokevirtual t : (Landroid/view/MotionEvent;)V
    //   98: aload_0
    //   99: aload_1
    //   100: aload_1
    //   101: aload_0
    //   102: getfield v : I
    //   105: invokevirtual findPointerIndex : (I)I
    //   108: invokevirtual getY : (I)F
    //   111: f2i
    //   112: putfield k : I
    //   115: goto -> 1237
    //   118: aload_1
    //   119: invokevirtual getActionIndex : ()I
    //   122: istore #5
    //   124: aload_0
    //   125: aload_1
    //   126: iload #5
    //   128: invokevirtual getY : (I)F
    //   131: f2i
    //   132: putfield k : I
    //   135: aload_0
    //   136: aload_1
    //   137: iload #5
    //   139: invokevirtual getPointerId : (I)I
    //   142: putfield v : I
    //   145: goto -> 1237
    //   148: aload_0
    //   149: getfield o : Z
    //   152: ifeq -> 195
    //   155: aload_0
    //   156: invokevirtual getChildCount : ()I
    //   159: ifle -> 195
    //   162: aload_0
    //   163: getfield h : Landroid/widget/OverScroller;
    //   166: aload_0
    //   167: invokevirtual getScrollX : ()I
    //   170: aload_0
    //   171: invokevirtual getScrollY : ()I
    //   174: iconst_0
    //   175: iconst_0
    //   176: iconst_0
    //   177: aload_0
    //   178: invokevirtual getScrollRange : ()I
    //   181: invokevirtual springBack : (IIIIII)Z
    //   184: ifeq -> 195
    //   187: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   190: astore_1
    //   191: aload_0
    //   192: invokestatic k : (Landroid/view/View;)V
    //   195: aload_0
    //   196: iconst_m1
    //   197: putfield v : I
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield o : Z
    //   205: aload_0
    //   206: invokevirtual v : ()V
    //   209: aload_0
    //   210: getfield C : Lm0/k;
    //   213: iconst_0
    //   214: invokevirtual k : (I)V
    //   217: aload_0
    //   218: getfield i : Landroid/widget/EdgeEffect;
    //   221: invokevirtual onRelease : ()V
    //   224: aload_0
    //   225: getfield j : Landroid/widget/EdgeEffect;
    //   228: invokevirtual onRelease : ()V
    //   231: goto -> 1237
    //   234: aload_1
    //   235: aload_0
    //   236: getfield v : I
    //   239: invokevirtual findPointerIndex : (I)I
    //   242: istore #9
    //   244: iload #9
    //   246: iconst_m1
    //   247: if_icmpne -> 288
    //   250: ldc_w 'Invalid pointerId='
    //   253: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: astore_1
    //   257: aload_1
    //   258: aload_0
    //   259: getfield v : I
    //   262: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   265: pop
    //   266: aload_1
    //   267: ldc_w ' in onTouchEvent'
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: ldc_w 'NestedScrollView'
    //   277: aload_1
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   284: pop
    //   285: goto -> 1237
    //   288: aload_1
    //   289: iload #9
    //   291: invokevirtual getY : (I)F
    //   294: f2i
    //   295: istore #7
    //   297: aload_0
    //   298: getfield k : I
    //   301: iload #7
    //   303: isub
    //   304: istore #5
    //   306: aload_1
    //   307: iload #9
    //   309: invokevirtual getX : (I)F
    //   312: aload_0
    //   313: invokevirtual getWidth : ()I
    //   316: i2f
    //   317: fdiv
    //   318: fstore_3
    //   319: iload #5
    //   321: i2f
    //   322: aload_0
    //   323: invokevirtual getHeight : ()I
    //   326: i2f
    //   327: fdiv
    //   328: fstore #4
    //   330: aload_0
    //   331: getfield i : Landroid/widget/EdgeEffect;
    //   334: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   337: fconst_0
    //   338: fcmpl
    //   339: ifeq -> 381
    //   342: aload_0
    //   343: getfield i : Landroid/widget/EdgeEffect;
    //   346: fload #4
    //   348: fneg
    //   349: fload_3
    //   350: invokestatic c : (Landroid/widget/EdgeEffect;FF)F
    //   353: fneg
    //   354: fstore_3
    //   355: fload_3
    //   356: fstore_2
    //   357: aload_0
    //   358: getfield i : Landroid/widget/EdgeEffect;
    //   361: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   364: fconst_0
    //   365: fcmpl
    //   366: ifne -> 378
    //   369: aload_0
    //   370: getfield i : Landroid/widget/EdgeEffect;
    //   373: invokevirtual onRelease : ()V
    //   376: fload_3
    //   377: fstore_2
    //   378: goto -> 432
    //   381: aload_0
    //   382: getfield j : Landroid/widget/EdgeEffect;
    //   385: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   388: fconst_0
    //   389: fcmpl
    //   390: ifeq -> 432
    //   393: aload_0
    //   394: getfield j : Landroid/widget/EdgeEffect;
    //   397: fload #4
    //   399: fconst_1
    //   400: fload_3
    //   401: fsub
    //   402: invokestatic c : (Landroid/widget/EdgeEffect;FF)F
    //   405: fstore_3
    //   406: fload_3
    //   407: fstore_2
    //   408: aload_0
    //   409: getfield j : Landroid/widget/EdgeEffect;
    //   412: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   415: fconst_0
    //   416: fcmpl
    //   417: ifne -> 378
    //   420: aload_0
    //   421: getfield j : Landroid/widget/EdgeEffect;
    //   424: invokevirtual onRelease : ()V
    //   427: fload_3
    //   428: fstore_2
    //   429: goto -> 378
    //   432: fload_2
    //   433: aload_0
    //   434: invokevirtual getHeight : ()I
    //   437: i2f
    //   438: fmul
    //   439: invokestatic round : (F)I
    //   442: istore #6
    //   444: iload #6
    //   446: ifeq -> 453
    //   449: aload_0
    //   450: invokevirtual invalidate : ()V
    //   453: iload #5
    //   455: iload #6
    //   457: isub
    //   458: istore #6
    //   460: iload #6
    //   462: istore #5
    //   464: aload_0
    //   465: getfield o : Z
    //   468: ifne -> 537
    //   471: iload #6
    //   473: istore #5
    //   475: iload #6
    //   477: invokestatic abs : (I)I
    //   480: aload_0
    //   481: getfield s : I
    //   484: if_icmple -> 537
    //   487: aload_0
    //   488: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   491: astore #14
    //   493: aload #14
    //   495: ifnull -> 506
    //   498: aload #14
    //   500: iconst_1
    //   501: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   506: aload_0
    //   507: iconst_1
    //   508: putfield o : Z
    //   511: iload #6
    //   513: ifle -> 528
    //   516: iload #6
    //   518: aload_0
    //   519: getfield s : I
    //   522: isub
    //   523: istore #5
    //   525: goto -> 537
    //   528: iload #6
    //   530: aload_0
    //   531: getfield s : I
    //   534: iadd
    //   535: istore #5
    //   537: aload_0
    //   538: getfield o : Z
    //   541: ifeq -> 1237
    //   544: iload #5
    //   546: istore #6
    //   548: aload_0
    //   549: iconst_0
    //   550: iload #5
    //   552: aload_0
    //   553: getfield x : [I
    //   556: aload_0
    //   557: getfield w : [I
    //   560: iconst_0
    //   561: invokevirtual e : (II[I[II)Z
    //   564: ifeq -> 593
    //   567: iload #5
    //   569: aload_0
    //   570: getfield x : [I
    //   573: iconst_1
    //   574: iaload
    //   575: isub
    //   576: istore #6
    //   578: aload_0
    //   579: aload_0
    //   580: getfield y : I
    //   583: aload_0
    //   584: getfield w : [I
    //   587: iconst_1
    //   588: iaload
    //   589: iadd
    //   590: putfield y : I
    //   593: aload_0
    //   594: iload #7
    //   596: aload_0
    //   597: getfield w : [I
    //   600: iconst_1
    //   601: iaload
    //   602: isub
    //   603: putfield k : I
    //   606: aload_0
    //   607: invokevirtual getScrollY : ()I
    //   610: istore #11
    //   612: aload_0
    //   613: invokevirtual getScrollRange : ()I
    //   616: istore #10
    //   618: aload_0
    //   619: invokevirtual getOverScrollMode : ()I
    //   622: istore #5
    //   624: iload #5
    //   626: ifeq -> 649
    //   629: iload #5
    //   631: iconst_1
    //   632: if_icmpne -> 643
    //   635: iload #10
    //   637: ifle -> 643
    //   640: goto -> 649
    //   643: iconst_0
    //   644: istore #7
    //   646: goto -> 652
    //   649: iconst_1
    //   650: istore #7
    //   652: aload_0
    //   653: iconst_0
    //   654: iload #6
    //   656: iconst_0
    //   657: aload_0
    //   658: invokevirtual getScrollY : ()I
    //   661: iconst_0
    //   662: iload #10
    //   664: iconst_0
    //   665: iconst_0
    //   666: invokevirtual u : (IIIIIIII)Z
    //   669: ifeq -> 686
    //   672: aload_0
    //   673: iconst_0
    //   674: invokevirtual p : (I)Z
    //   677: ifne -> 686
    //   680: iconst_1
    //   681: istore #5
    //   683: goto -> 689
    //   686: iconst_0
    //   687: istore #5
    //   689: aload_0
    //   690: invokevirtual getScrollY : ()I
    //   693: iload #11
    //   695: isub
    //   696: istore #12
    //   698: aload_0
    //   699: getfield x : [I
    //   702: astore #14
    //   704: aload #14
    //   706: iconst_1
    //   707: iconst_0
    //   708: iastore
    //   709: aload_0
    //   710: getfield w : [I
    //   713: astore #15
    //   715: aload_0
    //   716: getfield C : Lm0/k;
    //   719: iconst_0
    //   720: iload #12
    //   722: iconst_0
    //   723: iload #6
    //   725: iload #12
    //   727: isub
    //   728: aload #15
    //   730: iconst_0
    //   731: aload #14
    //   733: invokevirtual f : (IIII[II[I)Z
    //   736: pop
    //   737: aload_0
    //   738: getfield k : I
    //   741: istore #12
    //   743: aload_0
    //   744: getfield w : [I
    //   747: astore #14
    //   749: aload_0
    //   750: iload #12
    //   752: aload #14
    //   754: iconst_1
    //   755: iaload
    //   756: isub
    //   757: putfield k : I
    //   760: aload_0
    //   761: aload_0
    //   762: getfield y : I
    //   765: aload #14
    //   767: iconst_1
    //   768: iaload
    //   769: iadd
    //   770: putfield y : I
    //   773: iload #7
    //   775: ifeq -> 941
    //   778: iload #6
    //   780: aload_0
    //   781: getfield x : [I
    //   784: iconst_1
    //   785: iaload
    //   786: isub
    //   787: istore #6
    //   789: iload #11
    //   791: iload #6
    //   793: iadd
    //   794: istore #7
    //   796: iload #7
    //   798: ifge -> 851
    //   801: aload_0
    //   802: getfield i : Landroid/widget/EdgeEffect;
    //   805: iload #6
    //   807: ineg
    //   808: i2f
    //   809: aload_0
    //   810: invokevirtual getHeight : ()I
    //   813: i2f
    //   814: fdiv
    //   815: aload_1
    //   816: iload #9
    //   818: invokevirtual getX : (I)F
    //   821: aload_0
    //   822: invokevirtual getWidth : ()I
    //   825: i2f
    //   826: fdiv
    //   827: invokestatic c : (Landroid/widget/EdgeEffect;FF)F
    //   830: pop
    //   831: aload_0
    //   832: getfield j : Landroid/widget/EdgeEffect;
    //   835: invokevirtual isFinished : ()Z
    //   838: ifne -> 906
    //   841: aload_0
    //   842: getfield j : Landroid/widget/EdgeEffect;
    //   845: invokevirtual onRelease : ()V
    //   848: goto -> 906
    //   851: iload #7
    //   853: iload #10
    //   855: if_icmple -> 906
    //   858: aload_0
    //   859: getfield j : Landroid/widget/EdgeEffect;
    //   862: iload #6
    //   864: i2f
    //   865: aload_0
    //   866: invokevirtual getHeight : ()I
    //   869: i2f
    //   870: fdiv
    //   871: fconst_1
    //   872: aload_1
    //   873: iload #9
    //   875: invokevirtual getX : (I)F
    //   878: aload_0
    //   879: invokevirtual getWidth : ()I
    //   882: i2f
    //   883: fdiv
    //   884: fsub
    //   885: invokestatic c : (Landroid/widget/EdgeEffect;FF)F
    //   888: pop
    //   889: aload_0
    //   890: getfield i : Landroid/widget/EdgeEffect;
    //   893: invokevirtual isFinished : ()Z
    //   896: ifne -> 906
    //   899: aload_0
    //   900: getfield i : Landroid/widget/EdgeEffect;
    //   903: invokevirtual onRelease : ()V
    //   906: aload_0
    //   907: getfield i : Landroid/widget/EdgeEffect;
    //   910: invokevirtual isFinished : ()Z
    //   913: ifeq -> 926
    //   916: aload_0
    //   917: getfield j : Landroid/widget/EdgeEffect;
    //   920: invokevirtual isFinished : ()Z
    //   923: ifne -> 941
    //   926: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   929: astore_1
    //   930: aload_0
    //   931: invokestatic k : (Landroid/view/View;)V
    //   934: iload #8
    //   936: istore #5
    //   938: goto -> 941
    //   941: iload #5
    //   943: ifeq -> 1237
    //   946: aload_0
    //   947: getfield p : Landroid/view/VelocityTracker;
    //   950: invokevirtual clear : ()V
    //   953: goto -> 1237
    //   956: aload_0
    //   957: getfield p : Landroid/view/VelocityTracker;
    //   960: astore_1
    //   961: aload_1
    //   962: sipush #1000
    //   965: aload_0
    //   966: getfield u : I
    //   969: i2f
    //   970: invokevirtual computeCurrentVelocity : (IF)V
    //   973: aload_1
    //   974: aload_0
    //   975: getfield v : I
    //   978: invokevirtual getYVelocity : (I)F
    //   981: f2i
    //   982: istore #6
    //   984: iload #6
    //   986: invokestatic abs : (I)I
    //   989: aload_0
    //   990: getfield t : I
    //   993: if_icmplt -> 1091
    //   996: aload_0
    //   997: getfield i : Landroid/widget/EdgeEffect;
    //   1000: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   1003: fconst_0
    //   1004: fcmpl
    //   1005: ifeq -> 1020
    //   1008: aload_0
    //   1009: getfield i : Landroid/widget/EdgeEffect;
    //   1012: iload #6
    //   1014: invokevirtual onAbsorb : (I)V
    //   1017: goto -> 1042
    //   1020: aload_0
    //   1021: getfield j : Landroid/widget/EdgeEffect;
    //   1024: invokestatic a : (Landroid/widget/EdgeEffect;)F
    //   1027: fconst_0
    //   1028: fcmpl
    //   1029: ifeq -> 1048
    //   1032: aload_0
    //   1033: getfield j : Landroid/widget/EdgeEffect;
    //   1036: iload #6
    //   1038: ineg
    //   1039: invokevirtual onAbsorb : (I)V
    //   1042: iconst_1
    //   1043: istore #5
    //   1045: goto -> 1051
    //   1048: iconst_0
    //   1049: istore #5
    //   1051: iload #5
    //   1053: ifne -> 1124
    //   1056: iload #6
    //   1058: ineg
    //   1059: istore #5
    //   1061: iload #5
    //   1063: i2f
    //   1064: fstore_2
    //   1065: aload_0
    //   1066: fconst_0
    //   1067: fload_2
    //   1068: invokevirtual dispatchNestedPreFling : (FF)Z
    //   1071: ifne -> 1124
    //   1074: aload_0
    //   1075: fconst_0
    //   1076: fload_2
    //   1077: iconst_1
    //   1078: invokevirtual dispatchNestedFling : (FFZ)Z
    //   1081: pop
    //   1082: aload_0
    //   1083: iload #5
    //   1085: invokevirtual k : (I)V
    //   1088: goto -> 1124
    //   1091: aload_0
    //   1092: getfield h : Landroid/widget/OverScroller;
    //   1095: aload_0
    //   1096: invokevirtual getScrollX : ()I
    //   1099: aload_0
    //   1100: invokevirtual getScrollY : ()I
    //   1103: iconst_0
    //   1104: iconst_0
    //   1105: iconst_0
    //   1106: aload_0
    //   1107: invokevirtual getScrollRange : ()I
    //   1110: invokevirtual springBack : (IIIIII)Z
    //   1113: ifeq -> 1124
    //   1116: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   1119: astore_1
    //   1120: aload_0
    //   1121: invokestatic k : (Landroid/view/View;)V
    //   1124: aload_0
    //   1125: iconst_m1
    //   1126: putfield v : I
    //   1129: aload_0
    //   1130: iconst_0
    //   1131: putfield o : Z
    //   1134: aload_0
    //   1135: invokevirtual v : ()V
    //   1138: aload_0
    //   1139: getfield C : Lm0/k;
    //   1142: iconst_0
    //   1143: invokevirtual k : (I)V
    //   1146: aload_0
    //   1147: getfield i : Landroid/widget/EdgeEffect;
    //   1150: invokevirtual onRelease : ()V
    //   1153: aload_0
    //   1154: getfield j : Landroid/widget/EdgeEffect;
    //   1157: invokevirtual onRelease : ()V
    //   1160: goto -> 1237
    //   1163: aload_0
    //   1164: invokevirtual getChildCount : ()I
    //   1167: ifne -> 1172
    //   1170: iconst_0
    //   1171: ireturn
    //   1172: aload_0
    //   1173: getfield o : Z
    //   1176: ifeq -> 1198
    //   1179: aload_0
    //   1180: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1183: astore #14
    //   1185: aload #14
    //   1187: ifnull -> 1198
    //   1190: aload #14
    //   1192: iconst_1
    //   1193: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   1198: aload_0
    //   1199: getfield h : Landroid/widget/OverScroller;
    //   1202: invokevirtual isFinished : ()Z
    //   1205: ifne -> 1212
    //   1208: aload_0
    //   1209: invokevirtual a : ()V
    //   1212: aload_0
    //   1213: aload_1
    //   1214: invokevirtual getY : ()F
    //   1217: f2i
    //   1218: putfield k : I
    //   1221: aload_0
    //   1222: aload_1
    //   1223: iconst_0
    //   1224: invokevirtual getPointerId : (I)I
    //   1227: putfield v : I
    //   1230: aload_0
    //   1231: iconst_2
    //   1232: iconst_0
    //   1233: invokevirtual A : (II)Z
    //   1236: pop
    //   1237: aload_0
    //   1238: getfield p : Landroid/view/VelocityTracker;
    //   1241: astore_1
    //   1242: aload_1
    //   1243: ifnull -> 1252
    //   1246: aload_1
    //   1247: aload #13
    //   1249: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   1252: aload #13
    //   1254: invokevirtual recycle : ()V
    //   1257: iconst_1
    //   1258: ireturn
  }
  
  public boolean p(int paramInt) {
    return (this.C.g(paramInt) != null);
  }
  
  public final boolean r(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.g);
    offsetDescendantRectToMyCoords(paramView, this.g);
    return (this.g.bottom + paramInt1 >= getScrollY() && this.g.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.l) {
      y(paramView2);
    } else {
      this.n = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    int i = d(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      z(0, i, 250, false);
    } 
    return bool;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      v(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.l = true;
    super.requestLayout();
  }
  
  public final void s(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.C.d(0, i, 0, paramInt1 - i, null, paramInt2, paramArrayOfint);
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i5 = getWidth();
      int i6 = getPaddingLeft();
      int i7 = getPaddingRight();
      int i8 = view.getWidth();
      int i9 = layoutParams.leftMargin;
      int i10 = layoutParams.rightMargin;
      int i = getHeight();
      int n = getPaddingTop();
      int i1 = getPaddingBottom();
      int i2 = view.getHeight();
      int i3 = layoutParams.topMargin;
      int i4 = layoutParams.bottomMargin;
      paramInt1 = c(paramInt1, i5 - i6 - i7, i8 + i9 + i10);
      paramInt2 = c(paramInt2, i - n - i1, i2 + i3 + i4);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.q) {
      this.q = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.C.i(paramBoolean);
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.E = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.r = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.C.j(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.C.k(0);
  }
  
  public final void t(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.v) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.k = (int)paramMotionEvent.getY(i);
      this.v = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.p;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean u(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #11
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: istore #9
    //   12: aload_0
    //   13: invokevirtual computeHorizontalScrollExtent : ()I
    //   16: istore #10
    //   18: iconst_0
    //   19: istore #14
    //   21: iload #9
    //   23: iload #10
    //   25: if_icmple -> 34
    //   28: iconst_1
    //   29: istore #9
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #9
    //   37: aload_0
    //   38: invokevirtual computeVerticalScrollRange : ()I
    //   41: aload_0
    //   42: invokevirtual computeVerticalScrollExtent : ()I
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #10
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #10
    //   57: iload #11
    //   59: ifeq -> 82
    //   62: iload #11
    //   64: iconst_1
    //   65: if_icmpne -> 76
    //   68: iload #9
    //   70: ifeq -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #9
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #9
    //   85: iload #11
    //   87: ifeq -> 110
    //   90: iload #11
    //   92: iconst_1
    //   93: if_icmpne -> 104
    //   96: iload #10
    //   98: ifeq -> 104
    //   101: goto -> 110
    //   104: iconst_0
    //   105: istore #10
    //   107: goto -> 113
    //   110: iconst_1
    //   111: istore #10
    //   113: iload_3
    //   114: iload_1
    //   115: iadd
    //   116: istore_3
    //   117: iload #9
    //   119: ifne -> 127
    //   122: iconst_0
    //   123: istore_1
    //   124: goto -> 130
    //   127: iload #7
    //   129: istore_1
    //   130: iload #4
    //   132: iload_2
    //   133: iadd
    //   134: istore #4
    //   136: iload #10
    //   138: ifne -> 146
    //   141: iconst_0
    //   142: istore_2
    //   143: goto -> 149
    //   146: iload #8
    //   148: istore_2
    //   149: iload_1
    //   150: ineg
    //   151: istore #7
    //   153: iload_1
    //   154: iload #5
    //   156: iadd
    //   157: istore_1
    //   158: iload_2
    //   159: ineg
    //   160: istore #5
    //   162: iload_2
    //   163: iload #6
    //   165: iadd
    //   166: istore #6
    //   168: iload_3
    //   169: iload_1
    //   170: if_icmple -> 181
    //   173: iconst_1
    //   174: istore #12
    //   176: iload_1
    //   177: istore_2
    //   178: goto -> 198
    //   181: iload_3
    //   182: iload #7
    //   184: if_icmpge -> 193
    //   187: iload #7
    //   189: istore_1
    //   190: goto -> 173
    //   193: iconst_0
    //   194: istore #12
    //   196: iload_3
    //   197: istore_2
    //   198: iload #4
    //   200: iload #6
    //   202: if_icmple -> 214
    //   205: iload #6
    //   207: istore_1
    //   208: iconst_1
    //   209: istore #13
    //   211: goto -> 233
    //   214: iload #4
    //   216: iload #5
    //   218: if_icmpge -> 227
    //   221: iload #5
    //   223: istore_1
    //   224: goto -> 208
    //   227: iconst_0
    //   228: istore #13
    //   230: iload #4
    //   232: istore_1
    //   233: iload #13
    //   235: ifeq -> 263
    //   238: aload_0
    //   239: iconst_1
    //   240: invokevirtual p : (I)Z
    //   243: ifne -> 263
    //   246: aload_0
    //   247: getfield h : Landroid/widget/OverScroller;
    //   250: iload_2
    //   251: iload_1
    //   252: iconst_0
    //   253: iconst_0
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getScrollRange : ()I
    //   259: invokevirtual springBack : (IIIIII)Z
    //   262: pop
    //   263: aload_0
    //   264: iload_2
    //   265: iload_1
    //   266: iload #12
    //   268: iload #13
    //   270: invokevirtual onOverScrolled : (IIZZ)V
    //   273: iload #12
    //   275: ifne -> 287
    //   278: iload #14
    //   280: istore #12
    //   282: iload #13
    //   284: ifeq -> 290
    //   287: iconst_1
    //   288: istore #12
    //   290: iload #12
    //   292: ireturn
  }
  
  public final void v() {
    VelocityTracker velocityTracker = this.p;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.p = null;
    } 
  }
  
  public final void w(boolean paramBoolean) {
    if (paramBoolean) {
      A(2, 1);
    } else {
      this.C.k(1);
    } 
    this.z = getScrollY();
    WeakHashMap weakHashMap = y.a;
    y.d.k((View)this);
  }
  
  public final boolean x(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getHeight : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getScrollY : ()I
    //   10: istore #10
    //   12: iload #4
    //   14: iload #10
    //   16: iadd
    //   17: istore #11
    //   19: iload_1
    //   20: bipush #33
    //   22: if_icmpne -> 31
    //   25: iconst_1
    //   26: istore #6
    //   28: goto -> 34
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: iconst_2
    //   36: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   39: astore #18
    //   41: aload #18
    //   43: invokeinterface size : ()I
    //   48: istore #12
    //   50: aconst_null
    //   51: astore #16
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #7
    //   61: iload #12
    //   63: if_icmpge -> 285
    //   66: aload #18
    //   68: iload #7
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: checkcast android/view/View
    //   78: astore #17
    //   80: aload #17
    //   82: invokevirtual getTop : ()I
    //   85: istore #9
    //   87: aload #17
    //   89: invokevirtual getBottom : ()I
    //   92: istore #13
    //   94: aload #16
    //   96: astore #15
    //   98: iload #8
    //   100: istore #5
    //   102: iload_2
    //   103: iload #13
    //   105: if_icmpge -> 268
    //   108: aload #16
    //   110: astore #15
    //   112: iload #8
    //   114: istore #5
    //   116: iload #9
    //   118: iload_3
    //   119: if_icmpge -> 268
    //   122: iload_2
    //   123: iload #9
    //   125: if_icmpge -> 140
    //   128: iload #13
    //   130: iload_3
    //   131: if_icmpge -> 140
    //   134: iconst_1
    //   135: istore #4
    //   137: goto -> 143
    //   140: iconst_0
    //   141: istore #4
    //   143: aload #16
    //   145: ifnonnull -> 159
    //   148: aload #17
    //   150: astore #15
    //   152: iload #4
    //   154: istore #5
    //   156: goto -> 268
    //   159: iload #6
    //   161: ifeq -> 174
    //   164: iload #9
    //   166: aload #16
    //   168: invokevirtual getTop : ()I
    //   171: if_icmplt -> 189
    //   174: iload #6
    //   176: ifne -> 195
    //   179: iload #13
    //   181: aload #16
    //   183: invokevirtual getBottom : ()I
    //   186: if_icmple -> 195
    //   189: iconst_1
    //   190: istore #9
    //   192: goto -> 198
    //   195: iconst_0
    //   196: istore #9
    //   198: iload #8
    //   200: ifeq -> 232
    //   203: aload #16
    //   205: astore #15
    //   207: iload #8
    //   209: istore #5
    //   211: iload #4
    //   213: ifeq -> 268
    //   216: aload #16
    //   218: astore #15
    //   220: iload #8
    //   222: istore #5
    //   224: iload #9
    //   226: ifeq -> 268
    //   229: goto -> 260
    //   232: iload #4
    //   234: ifeq -> 247
    //   237: aload #17
    //   239: astore #15
    //   241: iconst_1
    //   242: istore #5
    //   244: goto -> 268
    //   247: aload #16
    //   249: astore #15
    //   251: iload #8
    //   253: istore #5
    //   255: iload #9
    //   257: ifeq -> 268
    //   260: aload #17
    //   262: astore #15
    //   264: iload #8
    //   266: istore #5
    //   268: iload #7
    //   270: iconst_1
    //   271: iadd
    //   272: istore #7
    //   274: aload #15
    //   276: astore #16
    //   278: iload #5
    //   280: istore #8
    //   282: goto -> 59
    //   285: aload #16
    //   287: astore #15
    //   289: aload #16
    //   291: ifnonnull -> 297
    //   294: aload_0
    //   295: astore #15
    //   297: iload_2
    //   298: iload #10
    //   300: if_icmplt -> 315
    //   303: iload_3
    //   304: iload #11
    //   306: if_icmpgt -> 315
    //   309: iconst_0
    //   310: istore #14
    //   312: goto -> 341
    //   315: iload #6
    //   317: ifeq -> 328
    //   320: iload_2
    //   321: iload #10
    //   323: isub
    //   324: istore_2
    //   325: goto -> 333
    //   328: iload_3
    //   329: iload #11
    //   331: isub
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: invokevirtual f : (I)V
    //   338: iconst_1
    //   339: istore #14
    //   341: aload #15
    //   343: aload_0
    //   344: invokevirtual findFocus : ()Landroid/view/View;
    //   347: if_acmpeq -> 357
    //   350: aload #15
    //   352: iload_1
    //   353: invokevirtual requestFocus : (I)Z
    //   356: pop
    //   357: iload #14
    //   359: ireturn
  }
  
  public final void y(View paramView) {
    paramView.getDrawingRect(this.g);
    offsetDescendantRectToMyCoords(paramView, this.g);
    int i = d(this.g);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  public final void z(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.f > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getHeight();
      int n = layoutParams.topMargin;
      int i1 = layoutParams.bottomMargin;
      int i2 = getHeight();
      int i3 = getPaddingTop();
      int i4 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, i + n + i1 - i2 - i3 - i4)));
      this.h.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      w(paramBoolean);
    } else {
      if (!this.h.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.f = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public static class a extends m0.a {
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      this.a.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      param1AccessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
    }
    
    public void d(View param1View, n0.b param1b) {
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      String str = ScrollView.class.getName();
      param1b.a.setClassName(str);
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1b.a.setScrollable(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1b.a(n0.b.a.g);
            param1b.a(n0.b.a.k);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1b.a(n0.b.a.f);
            param1b.a(n0.b.a.l);
          } 
        } 
      } 
    }
    
    public boolean g(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.g(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.z(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.z(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
        return true;
      } 
      return false;
    }
  }
  
  public static interface b {}
  
  public static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = new a();
    
    public int f;
    
    public c(Parcel param1Parcel) {
      super(param1Parcel);
      this.f = param1Parcel.readInt();
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.f);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.f);
    }
    
    public class a implements Parcelable.Creator<c> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new NestedScrollView.c(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new NestedScrollView.c[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<c> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new NestedScrollView.c(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new NestedScrollView.c[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */