package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.SparseIntArray;
import android.view.FrameMetrics;
import android.view.Window;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class FrameMetricsAggregator {
  public b a;
  
  public FrameMetricsAggregator() {
    this(1);
  }
  
  public FrameMetricsAggregator(int paramInt) {
    if (Build.VERSION.SDK_INT >= 24) {
      this.a = new a(paramInt);
      return;
    } 
    this.a = new b();
  }
  
  public static class a extends b {
    public static HandlerThread e;
    
    public static Handler f;
    
    public int a;
    
    public SparseIntArray[] b = new SparseIntArray[9];
    
    public ArrayList<WeakReference<Activity>> c = new ArrayList<WeakReference<Activity>>();
    
    public Window.OnFrameMetricsAvailableListener d = new a(this);
    
    public a(int param1Int) {
      this.a = param1Int;
    }
    
    public void a(Activity param1Activity) {
      if (e == null) {
        HandlerThread handlerThread = new HandlerThread("FrameMetricsAggregator");
        e = handlerThread;
        handlerThread.start();
        f = new Handler(e.getLooper());
      } 
      for (int i = 0; i <= 8; i++) {
        SparseIntArray[] arrayOfSparseIntArray = this.b;
        if (arrayOfSparseIntArray[i] == null && (this.a & 1 << i) != 0)
          arrayOfSparseIntArray[i] = new SparseIntArray(); 
      } 
      param1Activity.getWindow().addOnFrameMetricsAvailableListener(this.d, f);
      this.c.add(new WeakReference<Activity>(param1Activity));
    }
    
    public SparseIntArray[] b() {
      return this.b;
    }
    
    public SparseIntArray[] c(Activity param1Activity) {
      for (WeakReference<Activity> weakReference : this.c) {
        if (weakReference.get() == param1Activity) {
          this.c.remove(weakReference);
          break;
        } 
      } 
      param1Activity.getWindow().removeOnFrameMetricsAvailableListener(this.d);
      return this.b;
    }
    
    public SparseIntArray[] d() {
      SparseIntArray[] arrayOfSparseIntArray = this.b;
      this.b = new SparseIntArray[9];
      return arrayOfSparseIntArray;
    }
    
    public SparseIntArray[] e() {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        WeakReference<Activity> weakReference = this.c.get(i);
        Activity activity = weakReference.get();
        if (weakReference.get() != null) {
          activity.getWindow().removeOnFrameMetricsAvailableListener(this.d);
          this.c.remove(i);
        } 
      } 
      return this.b;
    }
    
    public void f(SparseIntArray param1SparseIntArray, long param1Long) {
      if (param1SparseIntArray != null) {
        int i = (int)((500000L + param1Long) / 1000000L);
        if (param1Long >= 0L)
          param1SparseIntArray.put(i, param1SparseIntArray.get(i) + 1); 
      } 
    }
    
    public class a implements Window.OnFrameMetricsAvailableListener {
      public a(FrameMetricsAggregator.a this$0) {}
      
      public void onFrameMetricsAvailable(Window param2Window, FrameMetrics param2FrameMetrics, int param2Int) {
        FrameMetricsAggregator.a a1 = this.a;
        if ((a1.a & 0x1) != 0)
          a1.f(a1.b[0], param2FrameMetrics.getMetric(8)); 
        a1 = this.a;
        if ((a1.a & 0x2) != 0)
          a1.f(a1.b[1], param2FrameMetrics.getMetric(1)); 
        a1 = this.a;
        if ((a1.a & 0x4) != 0)
          a1.f(a1.b[2], param2FrameMetrics.getMetric(3)); 
        a1 = this.a;
        if ((a1.a & 0x8) != 0)
          a1.f(a1.b[3], param2FrameMetrics.getMetric(4)); 
        a1 = this.a;
        if ((a1.a & 0x10) != 0)
          a1.f(a1.b[4], param2FrameMetrics.getMetric(5)); 
        a1 = this.a;
        if ((a1.a & 0x40) != 0)
          a1.f(a1.b[6], param2FrameMetrics.getMetric(7)); 
        a1 = this.a;
        if ((a1.a & 0x20) != 0)
          a1.f(a1.b[5], param2FrameMetrics.getMetric(6)); 
        a1 = this.a;
        if ((a1.a & 0x80) != 0)
          a1.f(a1.b[7], param2FrameMetrics.getMetric(0)); 
        a1 = this.a;
        if ((a1.a & 0x100) != 0)
          a1.f(a1.b[8], param2FrameMetrics.getMetric(2)); 
      }
    }
  }
  
  public class a implements Window.OnFrameMetricsAvailableListener {
    public a(FrameMetricsAggregator this$0) {}
    
    public void onFrameMetricsAvailable(Window param1Window, FrameMetrics param1FrameMetrics, int param1Int) {
      FrameMetricsAggregator.a a1 = this.a;
      if ((a1.a & 0x1) != 0)
        a1.f(a1.b[0], param1FrameMetrics.getMetric(8)); 
      a1 = this.a;
      if ((a1.a & 0x2) != 0)
        a1.f(a1.b[1], param1FrameMetrics.getMetric(1)); 
      a1 = this.a;
      if ((a1.a & 0x4) != 0)
        a1.f(a1.b[2], param1FrameMetrics.getMetric(3)); 
      a1 = this.a;
      if ((a1.a & 0x8) != 0)
        a1.f(a1.b[3], param1FrameMetrics.getMetric(4)); 
      a1 = this.a;
      if ((a1.a & 0x10) != 0)
        a1.f(a1.b[4], param1FrameMetrics.getMetric(5)); 
      a1 = this.a;
      if ((a1.a & 0x40) != 0)
        a1.f(a1.b[6], param1FrameMetrics.getMetric(7)); 
      a1 = this.a;
      if ((a1.a & 0x20) != 0)
        a1.f(a1.b[5], param1FrameMetrics.getMetric(6)); 
      a1 = this.a;
      if ((a1.a & 0x80) != 0)
        a1.f(a1.b[7], param1FrameMetrics.getMetric(0)); 
      a1 = this.a;
      if ((a1.a & 0x100) != 0)
        a1.f(a1.b[8], param1FrameMetrics.getMetric(2)); 
    }
  }
  
  public static class b {
    public void a(Activity param1Activity) {}
    
    public SparseIntArray[] b() {
      return null;
    }
    
    public SparseIntArray[] c(Activity param1Activity) {
      return null;
    }
    
    public SparseIntArray[] d() {
      return null;
    }
    
    public SparseIntArray[] e() {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\app\FrameMetricsAggregator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */