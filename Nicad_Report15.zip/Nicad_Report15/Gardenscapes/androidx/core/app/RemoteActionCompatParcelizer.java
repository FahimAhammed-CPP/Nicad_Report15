package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import java.util.Objects;
import o1.a;
import o1.c;

public class RemoteActionCompatParcelizer {
  public static RemoteActionCompat read(a parama) {
    c c;
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
    IconCompat iconCompat = remoteActionCompat.a;
    if (parama.i(1))
      c = parama.o(); 
    remoteActionCompat.a = (IconCompat)c;
    CharSequence charSequence = remoteActionCompat.b;
    if (parama.i(2))
      charSequence = parama.h(); 
    remoteActionCompat.b = charSequence;
    charSequence = remoteActionCompat.c;
    if (parama.i(3))
      charSequence = parama.h(); 
    remoteActionCompat.c = charSequence;
    remoteActionCompat.d = (PendingIntent)parama.m((Parcelable)remoteActionCompat.d, 4);
    boolean bool = remoteActionCompat.e;
    if (parama.i(5))
      bool = parama.f(); 
    remoteActionCompat.e = bool;
    bool = remoteActionCompat.f;
    if (parama.i(6))
      bool = parama.f(); 
    remoteActionCompat.f = bool;
    return remoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, a parama) {
    Objects.requireNonNull(parama);
    IconCompat iconCompat = paramRemoteActionCompat.a;
    parama.p(1);
    parama.w((c)iconCompat);
    CharSequence charSequence = paramRemoteActionCompat.b;
    parama.p(2);
    parama.s(charSequence);
    charSequence = paramRemoteActionCompat.c;
    parama.p(3);
    parama.s(charSequence);
    PendingIntent pendingIntent = paramRemoteActionCompat.d;
    parama.p(4);
    parama.u((Parcelable)pendingIntent);
    boolean bool = paramRemoteActionCompat.e;
    parama.p(5);
    parama.q(bool);
    bool = paramRemoteActionCompat.f;
    parama.p(6);
    parama.q(bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\app\RemoteActionCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */