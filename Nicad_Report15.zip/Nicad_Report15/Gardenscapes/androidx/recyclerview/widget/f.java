package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.Objects;

public class f extends AnimatorListenerAdapter {
  public f(k paramk, RecyclerView.z paramz, ViewPropertyAnimator paramViewPropertyAnimator, View paramView) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.b.setListener(null);
    this.c.setAlpha(1.0F);
    this.d.c(this.a);
    this.d.q.remove(this.a);
    this.d.k();
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    Objects.requireNonNull(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */