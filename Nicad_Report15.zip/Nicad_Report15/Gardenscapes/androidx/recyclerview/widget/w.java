package androidx.recyclerview.widget;

import android.view.View;

public class w implements a.a {
  public w(RecyclerView paramRecyclerView) {}
  
  public void a(a.b paramb) {
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i != 8)
            return; 
          RecyclerView recyclerView3 = this.a;
          recyclerView3.q.g0(recyclerView3, paramb.b, paramb.d, 1);
          return;
        } 
        RecyclerView recyclerView2 = this.a;
        recyclerView2.q.i0(recyclerView2, paramb.b, paramb.d, paramb.c);
        return;
      } 
      RecyclerView recyclerView1 = this.a;
      recyclerView1.q.h0(recyclerView1, paramb.b, paramb.d);
      return;
    } 
    RecyclerView recyclerView = this.a;
    recyclerView.q.e0(recyclerView, paramb.b, paramb.d);
  }
  
  public RecyclerView.z b(int paramInt) {
    RecyclerView.z z2;
    RecyclerView recyclerView = this.a;
    int j = recyclerView.j.h();
    int i = 0;
    RecyclerView.z z1 = null;
    while (true) {
      z2 = z1;
      if (i < j) {
        z2 = RecyclerView.K(recyclerView.j.g(i));
        RecyclerView.z z = z1;
        if (z2 != null) {
          z = z1;
          if (!z2.l())
            if (z2.c != paramInt) {
              z = z1;
            } else if (recyclerView.j.k(z2.a)) {
              z = z2;
            } else {
              break;
            }  
        } 
        i++;
        z1 = z;
        continue;
      } 
      break;
    } 
    return (z2 == null) ? null : (this.a.j.k(z2.a) ? null : z2);
  }
  
  public void c(int paramInt1, int paramInt2, Object paramObject) {
    RecyclerView recyclerView = this.a;
    int i = recyclerView.j.h();
    int j = paramInt2 + paramInt1;
    for (paramInt2 = 0; paramInt2 < i; paramInt2++) {
      View view = recyclerView.j.g(paramInt2);
      RecyclerView.z z = RecyclerView.K(view);
      if (z != null && !z.t()) {
        int k = z.c;
        if (k >= paramInt1 && k < j) {
          z.b(2);
          z.a(paramObject);
          ((RecyclerView.m)view.getLayoutParams()).c = true;
        } 
      } 
    } 
    paramObject = recyclerView.g;
    paramInt2 = ((RecyclerView.r)paramObject).c.size();
    while (true) {
      i = paramInt2 - 1;
      if (i >= 0) {
        RecyclerView.z z = ((RecyclerView.r)paramObject).c.get(i);
        if (z == null) {
          paramInt2 = i;
          continue;
        } 
        int k = z.c;
        paramInt2 = i;
        if (k >= paramInt1) {
          paramInt2 = i;
          if (k < j) {
            z.b(2);
            paramObject.g(i);
            paramInt2 = i;
          } 
        } 
        continue;
      } 
      this.a.m0 = true;
      return;
    } 
  }
  
  public void d(int paramInt1, int paramInt2) {
    RecyclerView recyclerView = this.a;
    int j = recyclerView.j.h();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      RecyclerView.z z = RecyclerView.K(recyclerView.j.g(i));
      if (z != null && !z.t() && z.c >= paramInt1) {
        z.p(paramInt2, false);
        recyclerView.i0.f = true;
      } 
    } 
    RecyclerView.r r = recyclerView.g;
    j = r.c.size();
    for (i = bool; i < j; i++) {
      RecyclerView.z z = r.c.get(i);
      if (z != null && z.c >= paramInt1)
        z.p(paramInt2, true); 
    } 
    recyclerView.requestLayout();
    this.a.l0 = true;
  }
  
  public void e(int paramInt1, int paramInt2) {
    int i;
    int j;
    int k;
    RecyclerView recyclerView = this.a;
    int i1 = recyclerView.j.h();
    int n = -1;
    if (paramInt1 < paramInt2) {
      i = paramInt1;
      j = paramInt2;
      k = -1;
    } else {
      j = paramInt1;
      i = paramInt2;
      k = 1;
    } 
    int m;
    for (m = 0; m < i1; m++) {
      RecyclerView.z z = RecyclerView.K(recyclerView.j.g(m));
      if (z != null) {
        int i2 = z.c;
        if (i2 >= i && i2 <= j) {
          if (i2 == paramInt1) {
            z.p(paramInt2 - paramInt1, false);
          } else {
            z.p(k, false);
          } 
          recyclerView.i0.f = true;
        } 
      } 
    } 
    RecyclerView.r r = recyclerView.g;
    if (paramInt1 < paramInt2) {
      j = paramInt1;
      k = paramInt2;
      i = n;
    } else {
      k = paramInt1;
      j = paramInt2;
      i = 1;
    } 
    n = r.c.size();
    for (m = 0; m < n; m++) {
      RecyclerView.z z = r.c.get(m);
      if (z != null) {
        i1 = z.c;
        if (i1 >= j && i1 <= k)
          if (i1 == paramInt1) {
            z.p(paramInt2 - paramInt1, false);
          } else {
            z.p(i, false);
          }  
      } 
    } 
    recyclerView.requestLayout();
    this.a.l0 = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */