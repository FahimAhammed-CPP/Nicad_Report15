package androidx.recyclerview.widget;

import android.animation.Animator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Objects;

public class d implements Runnable {
  public d(k paramk, ArrayList paramArrayList) {}
  
  public void run() {
    for (k.a a : this.f) {
      View view1;
      k k1 = this.g;
      Objects.requireNonNull(k1);
      RecyclerView.z z1 = a.a;
      View view2 = null;
      if (z1 == null) {
        z1 = null;
      } else {
        view1 = z1.a;
      } 
      RecyclerView.z z2 = a.b;
      if (z2 != null)
        view2 = z2.a; 
      if (view1 != null) {
        ViewPropertyAnimator viewPropertyAnimator = view1.animate().setDuration(k1.f);
        k1.r.add(a.a);
        viewPropertyAnimator.translationX((a.e - a.c));
        viewPropertyAnimator.translationY((a.f - a.d));
        viewPropertyAnimator.alpha(0.0F).setListener((Animator.AnimatorListener)new i(k1, a, viewPropertyAnimator, view1)).start();
      } 
      if (view2 != null) {
        ViewPropertyAnimator viewPropertyAnimator = view2.animate();
        k1.r.add(a.b);
        viewPropertyAnimator.translationX(0.0F).translationY(0.0F).setDuration(k1.f).alpha(1.0F).setListener((Animator.AnimatorListener)new j(k1, a, viewPropertyAnimator, view2)).start();
      } 
    } 
    this.f.clear();
    this.g.n.remove(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */