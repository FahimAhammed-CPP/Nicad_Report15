package androidx.recyclerview.widget;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class k extends z {
  public static TimeInterpolator s;
  
  public ArrayList<RecyclerView.z> h = new ArrayList<RecyclerView.z>();
  
  public ArrayList<RecyclerView.z> i = new ArrayList<RecyclerView.z>();
  
  public ArrayList<b> j = new ArrayList<b>();
  
  public ArrayList<a> k = new ArrayList<a>();
  
  public ArrayList<ArrayList<RecyclerView.z>> l = new ArrayList<ArrayList<RecyclerView.z>>();
  
  public ArrayList<ArrayList<b>> m = new ArrayList<ArrayList<b>>();
  
  public ArrayList<ArrayList<a>> n = new ArrayList<ArrayList<a>>();
  
  public ArrayList<RecyclerView.z> o = new ArrayList<RecyclerView.z>();
  
  public ArrayList<RecyclerView.z> p = new ArrayList<RecyclerView.z>();
  
  public ArrayList<RecyclerView.z> q = new ArrayList<RecyclerView.z>();
  
  public ArrayList<RecyclerView.z> r = new ArrayList<RecyclerView.z>();
  
  public void e(RecyclerView.z paramz) {
    View view = paramz.a;
    view.animate().cancel();
    int i = this.j.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        i = j;
        if (((b)this.j.get(j)).a == paramz) {
          view.setTranslationY(0.0F);
          view.setTranslationX(0.0F);
          c(paramz);
          this.j.remove(j);
          i = j;
        } 
        continue;
      } 
      l(this.k, paramz);
      if (this.h.remove(paramz)) {
        view.setAlpha(1.0F);
        c(paramz);
      } 
      if (this.i.remove(paramz)) {
        view.setAlpha(1.0F);
        c(paramz);
      } 
      i = this.n.size();
      while (true) {
        if (--i >= 0) {
          ArrayList<a> arrayList = this.n.get(i);
          l(arrayList, paramz);
          if (arrayList.isEmpty())
            this.n.remove(i); 
          continue;
        } 
        i = this.m.size();
        while (true) {
          j = i - 1;
          if (j >= 0) {
            ArrayList arrayList = this.m.get(j);
            i = arrayList.size();
            while (true) {
              if (--i >= 0) {
                if (((b)arrayList.get(i)).a == paramz) {
                  view.setTranslationY(0.0F);
                  view.setTranslationX(0.0F);
                  c(paramz);
                  arrayList.remove(i);
                  if (arrayList.isEmpty())
                    this.m.remove(j); 
                  break;
                } 
                continue;
              } 
              break;
            } 
            i = j;
            continue;
          } 
          i = this.l.size();
          while (true) {
            if (--i >= 0) {
              ArrayList arrayList = this.l.get(i);
              if (arrayList.remove(paramz)) {
                view.setAlpha(1.0F);
                c(paramz);
                if (arrayList.isEmpty())
                  this.l.remove(i); 
              } 
              continue;
            } 
            this.q.remove(paramz);
            this.o.remove(paramz);
            this.r.remove(paramz);
            this.p.remove(paramz);
            k();
            return;
          } 
          break;
        } 
        break;
      } 
      break;
    } 
  }
  
  public void f() {
    int i = this.j.size();
    while (true) {
      if (--i >= 0) {
        b b = this.j.get(i);
        View view = b.a.a;
        view.setTranslationY(0.0F);
        view.setTranslationX(0.0F);
        c(b.a);
        this.j.remove(i);
        continue;
      } 
      i = this.h.size();
      while (true) {
        if (--i >= 0) {
          c(this.h.get(i));
          this.h.remove(i);
          continue;
        } 
        i = this.i.size();
        while (true) {
          if (--i >= 0) {
            RecyclerView.z z1 = this.i.get(i);
            z1.a.setAlpha(1.0F);
            c(z1);
            this.i.remove(i);
            continue;
          } 
          i = this.k.size();
          while (true) {
            if (--i >= 0) {
              a a = this.k.get(i);
              RecyclerView.z z1 = a.a;
              if (z1 != null)
                m(a, z1); 
              z1 = a.b;
              if (z1 != null)
                m(a, z1); 
              continue;
            } 
            this.k.clear();
            if (!g())
              return; 
            i = this.m.size();
            while (true) {
              int j = i - 1;
              if (j >= 0) {
                ArrayList<b> arrayList = this.m.get(j);
                for (i = arrayList.size();; i = j) {
                  if (--i >= 0) {
                    b b = arrayList.get(i);
                    View view = b.a.a;
                    view.setTranslationY(0.0F);
                    view.setTranslationX(0.0F);
                    c(b.a);
                    arrayList.remove(i);
                    if (arrayList.isEmpty())
                      this.m.remove(arrayList); 
                    continue;
                  } 
                } 
                break;
              } 
              i = this.l.size();
              while (true) {
                j = i - 1;
                if (j >= 0) {
                  ArrayList<RecyclerView.z> arrayList = this.l.get(j);
                  for (i = arrayList.size();; i = j) {
                    if (--i >= 0) {
                      RecyclerView.z z1 = arrayList.get(i);
                      z1.a.setAlpha(1.0F);
                      c(z1);
                      arrayList.remove(i);
                      if (arrayList.isEmpty())
                        this.l.remove(arrayList); 
                      continue;
                    } 
                  } 
                  break;
                } 
                i = this.n.size();
                while (true) {
                  j = i - 1;
                  if (j >= 0) {
                    ArrayList<a> arrayList = this.n.get(j);
                    for (i = arrayList.size();; i = j) {
                      if (--i >= 0) {
                        a a = arrayList.get(i);
                        RecyclerView.z z1 = a.a;
                        if (z1 != null)
                          m(a, z1); 
                        z1 = a.b;
                        if (z1 != null)
                          m(a, z1); 
                        if (arrayList.isEmpty())
                          this.n.remove(arrayList); 
                        continue;
                      } 
                    } 
                    break;
                  } 
                  j(this.q);
                  j(this.p);
                  j(this.o);
                  j(this.r);
                  d();
                  return;
                } 
                break;
              } 
              break;
            } 
            break;
          } 
          break;
        } 
        break;
      } 
      break;
    } 
  }
  
  public boolean g() {
    return (!this.i.isEmpty() || !this.k.isEmpty() || !this.j.isEmpty() || !this.h.isEmpty() || !this.p.isEmpty() || !this.q.isEmpty() || !this.o.isEmpty() || !this.r.isEmpty() || !this.m.isEmpty() || !this.l.isEmpty() || !this.n.isEmpty());
  }
  
  public boolean i(RecyclerView.z paramz, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = paramz.a;
    paramInt1 += (int)view.getTranslationX();
    paramInt2 += (int)paramz.a.getTranslationY();
    n(paramz);
    int i = paramInt3 - paramInt1;
    int j = paramInt4 - paramInt2;
    if (i == 0 && j == 0) {
      c(paramz);
      return false;
    } 
    if (i != 0)
      view.setTranslationX(-i); 
    if (j != 0)
      view.setTranslationY(-j); 
    this.j.add(new b(paramz, paramInt1, paramInt2, paramInt3, paramInt4));
    return true;
  }
  
  public void j(List<RecyclerView.z> paramList) {
    int i = paramList.size();
    while (true) {
      if (--i >= 0) {
        ((RecyclerView.z)paramList.get(i)).a.animate().cancel();
        continue;
      } 
      break;
    } 
  }
  
  public void k() {
    if (!g())
      d(); 
  }
  
  public final void l(List<a> paramList, RecyclerView.z paramz) {
    int i = paramList.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        a a = paramList.get(j);
        i = j;
        if (m(a, paramz)) {
          i = j;
          if (a.a == null) {
            i = j;
            if (a.b == null) {
              paramList.remove(a);
              i = j;
            } 
          } 
        } 
        continue;
      } 
      break;
    } 
  }
  
  public final boolean m(a parama, RecyclerView.z paramz) {
    if (parama.b == paramz) {
      parama.b = null;
    } else {
      if (parama.a == paramz) {
        parama.a = null;
        paramz.a.setAlpha(1.0F);
        paramz.a.setTranslationX(0.0F);
        paramz.a.setTranslationY(0.0F);
        c(paramz);
        return true;
      } 
      return false;
    } 
    paramz.a.setAlpha(1.0F);
    paramz.a.setTranslationX(0.0F);
    paramz.a.setTranslationY(0.0F);
    c(paramz);
    return true;
  }
  
  public final void n(RecyclerView.z paramz) {
    if (s == null)
      s = (new ValueAnimator()).getInterpolator(); 
    paramz.a.animate().setInterpolator(s);
    e(paramz);
  }
  
  public static class a {
    public RecyclerView.z a;
    
    public RecyclerView.z b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public a(RecyclerView.z param1z1, RecyclerView.z param1z2, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a = param1z1;
      this.b = param1z2;
      this.c = param1Int1;
      this.d = param1Int2;
      this.e = param1Int3;
      this.f = param1Int4;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("ChangeInfo{oldHolder=");
      stringBuilder.append(this.a);
      stringBuilder.append(", newHolder=");
      stringBuilder.append(this.b);
      stringBuilder.append(", fromX=");
      stringBuilder.append(this.c);
      stringBuilder.append(", fromY=");
      stringBuilder.append(this.d);
      stringBuilder.append(", toX=");
      stringBuilder.append(this.e);
      stringBuilder.append(", toY=");
      stringBuilder.append(this.f);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public RecyclerView.z a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public b(RecyclerView.z param1z, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a = param1z;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
      this.e = param1Int4;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */