package androidx.recyclerview.widget;

public abstract class z extends RecyclerView.i {
  public boolean g = true;
  
  public boolean a(RecyclerView.z paramz1, RecyclerView.z paramz2, RecyclerView.i.c paramc1, RecyclerView.i.c paramc2) {
    int j;
    int m;
    int n = paramc1.a;
    int i1 = paramc1.b;
    if (paramz2.t()) {
      j = paramc1.a;
      m = paramc1.b;
    } else {
      j = paramc2.a;
      m = paramc2.b;
    } 
    k k = (k)this;
    if (paramz1 == paramz2)
      return k.i(paramz1, n, i1, j, m); 
    float f1 = paramz1.a.getTranslationX();
    float f2 = paramz1.a.getTranslationY();
    float f3 = paramz1.a.getAlpha();
    k.n(paramz1);
    int i2 = (int)((j - n) - f1);
    int i3 = (int)((m - i1) - f2);
    paramz1.a.setTranslationX(f1);
    paramz1.a.setTranslationY(f2);
    paramz1.a.setAlpha(f3);
    k.n(paramz2);
    paramz2.a.setTranslationX(-i2);
    paramz2.a.setTranslationY(-i3);
    paramz2.a.setAlpha(0.0F);
    k.k.add(new k.a(paramz1, paramz2, n, i1, j, m));
    return true;
  }
  
  public abstract boolean i(RecyclerView.z paramz, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */