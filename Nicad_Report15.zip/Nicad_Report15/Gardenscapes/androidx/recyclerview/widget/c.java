package androidx.recyclerview.widget;

import android.animation.Animator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Objects;

public class c implements Runnable {
  public c(k paramk, ArrayList paramArrayList) {}
  
  public void run() {
    for (k.b b : this.f) {
      k k1 = this.g;
      RecyclerView.z z = b.a;
      int m = b.b;
      int i = b.c;
      int n = b.d;
      int j = b.e;
      Objects.requireNonNull(k1);
      View view = z.a;
      m = n - m;
      i = j - i;
      if (m != 0)
        view.animate().translationX(0.0F); 
      if (i != 0)
        view.animate().translationY(0.0F); 
      ViewPropertyAnimator viewPropertyAnimator = view.animate();
      k1.p.add(z);
      viewPropertyAnimator.setDuration(k1.e).setListener((Animator.AnimatorListener)new h(k1, z, m, view, i, viewPropertyAnimator)).start();
    } 
    this.f.clear();
    this.g.m.remove(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */