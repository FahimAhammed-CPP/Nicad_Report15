package androidx.recyclerview.widget;

import android.view.View;

public final class q extends s {
  public q(RecyclerView.l paraml) {
    super(paraml, null);
  }
  
  public int b(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.F(paramView) + m.rightMargin;
  }
  
  public int c(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.E(paramView) + m.leftMargin + m.rightMargin;
  }
  
  public int d(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.D(paramView) + m.topMargin + m.bottomMargin;
  }
  
  public int e(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.C(paramView) - m.leftMargin;
  }
  
  public int f() {
    return this.a.n;
  }
  
  public int g() {
    RecyclerView.l l = this.a;
    return l.n - l.O();
  }
  
  public int h() {
    return this.a.O();
  }
  
  public int i() {
    return this.a.l;
  }
  
  public int j() {
    return this.a.m;
  }
  
  public int k() {
    return this.a.N();
  }
  
  public int l() {
    RecyclerView.l l = this.a;
    return l.n - l.N() - this.a.O();
  }
  
  public int n(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.right;
  }
  
  public int o(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.left;
  }
  
  public void p(int paramInt) {
    this.a.X(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */