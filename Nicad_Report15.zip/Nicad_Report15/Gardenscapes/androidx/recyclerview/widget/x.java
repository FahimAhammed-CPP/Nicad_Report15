package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.Map;
import java.util.WeakHashMap;
import m0.a;
import n0.b;
import n0.c;

public class x extends a {
  public final RecyclerView d;
  
  public final a e;
  
  public x(RecyclerView paramRecyclerView) {
    this.d = paramRecyclerView;
    a a1 = this.e;
    if (a1 != null) {
      this.e = a1;
      return;
    } 
    this.e = new a(this);
  }
  
  public void c(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
    if (paramView instanceof RecyclerView && !j()) {
      RecyclerView recyclerView = (RecyclerView)paramView;
      if (recyclerView.getLayoutManager() != null)
        recyclerView.getLayoutManager().b0(paramAccessibilityEvent); 
    } 
  }
  
  public void d(View paramView, b paramb) {
    this.a.onInitializeAccessibilityNodeInfo(paramView, paramb.a);
    if (!j() && this.d.getLayoutManager() != null) {
      RecyclerView.l l = this.d.getLayoutManager();
      RecyclerView recyclerView = l.b;
      RecyclerView.r r = recyclerView.g;
      RecyclerView.w w = recyclerView.i0;
      if (recyclerView.canScrollVertically(-1) || l.b.canScrollHorizontally(-1)) {
        paramb.a.addAction(8192);
        paramb.a.setScrollable(true);
      } 
      if (l.b.canScrollVertically(1) || l.b.canScrollHorizontally(1)) {
        paramb.a.addAction(4096);
        paramb.a.setScrollable(true);
      } 
      paramb.i(b.b.a(l.S(r, w), l.z(r, w), false, 0));
    } 
  }
  
  public boolean g(View paramView, int paramInt, Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: aload_3
    //   4: invokespecial g : (Landroid/view/View;ILandroid/os/Bundle;)Z
    //   7: ifeq -> 12
    //   10: iconst_1
    //   11: ireturn
    //   12: aload_0
    //   13: invokevirtual j : ()Z
    //   16: ifne -> 233
    //   19: aload_0
    //   20: getfield d : Landroidx/recyclerview/widget/RecyclerView;
    //   23: invokevirtual getLayoutManager : ()Landroidx/recyclerview/widget/RecyclerView$l;
    //   26: ifnull -> 233
    //   29: aload_0
    //   30: getfield d : Landroidx/recyclerview/widget/RecyclerView;
    //   33: invokevirtual getLayoutManager : ()Landroidx/recyclerview/widget/RecyclerView$l;
    //   36: astore_1
    //   37: aload_1
    //   38: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   41: astore_3
    //   42: aload_3
    //   43: getfield g : Landroidx/recyclerview/widget/RecyclerView$r;
    //   46: astore #6
    //   48: iload_2
    //   49: sipush #4096
    //   52: if_icmpeq -> 133
    //   55: iload_2
    //   56: sipush #8192
    //   59: if_icmpeq -> 70
    //   62: iconst_0
    //   63: istore_2
    //   64: iconst_0
    //   65: istore #4
    //   67: goto -> 206
    //   70: aload_3
    //   71: iconst_m1
    //   72: invokevirtual canScrollVertically : (I)Z
    //   75: ifeq -> 97
    //   78: aload_1
    //   79: getfield o : I
    //   82: aload_1
    //   83: invokevirtual P : ()I
    //   86: isub
    //   87: aload_1
    //   88: invokevirtual M : ()I
    //   91: isub
    //   92: ineg
    //   93: istore_2
    //   94: goto -> 99
    //   97: iconst_0
    //   98: istore_2
    //   99: iload_2
    //   100: istore #4
    //   102: aload_1
    //   103: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   106: iconst_m1
    //   107: invokevirtual canScrollHorizontally : (I)Z
    //   110: ifeq -> 204
    //   113: aload_1
    //   114: getfield n : I
    //   117: aload_1
    //   118: invokevirtual N : ()I
    //   121: isub
    //   122: aload_1
    //   123: invokevirtual O : ()I
    //   126: isub
    //   127: ineg
    //   128: istore #4
    //   130: goto -> 191
    //   133: aload_3
    //   134: iconst_1
    //   135: invokevirtual canScrollVertically : (I)Z
    //   138: ifeq -> 159
    //   141: aload_1
    //   142: getfield o : I
    //   145: aload_1
    //   146: invokevirtual P : ()I
    //   149: isub
    //   150: aload_1
    //   151: invokevirtual M : ()I
    //   154: isub
    //   155: istore_2
    //   156: goto -> 161
    //   159: iconst_0
    //   160: istore_2
    //   161: iload_2
    //   162: istore #4
    //   164: aload_1
    //   165: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   168: iconst_1
    //   169: invokevirtual canScrollHorizontally : (I)Z
    //   172: ifeq -> 204
    //   175: aload_1
    //   176: getfield n : I
    //   179: aload_1
    //   180: invokevirtual N : ()I
    //   183: isub
    //   184: aload_1
    //   185: invokevirtual O : ()I
    //   188: isub
    //   189: istore #4
    //   191: iload_2
    //   192: istore #5
    //   194: iload #4
    //   196: istore_2
    //   197: iload #5
    //   199: istore #4
    //   201: goto -> 206
    //   204: iconst_0
    //   205: istore_2
    //   206: iload #4
    //   208: ifne -> 217
    //   211: iload_2
    //   212: ifne -> 217
    //   215: iconst_0
    //   216: ireturn
    //   217: aload_1
    //   218: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   221: iload_2
    //   222: iload #4
    //   224: aconst_null
    //   225: ldc -2147483648
    //   227: iconst_1
    //   228: invokevirtual g0 : (IILandroid/view/animation/Interpolator;IZ)V
    //   231: iconst_1
    //   232: ireturn
    //   233: iconst_0
    //   234: ireturn
  }
  
  public boolean j() {
    return this.d.M();
  }
  
  public static class a extends a {
    public final x d;
    
    public Map<View, a> e = new WeakHashMap<View, a>();
    
    public a(x param1x) {
      this.d = param1x;
    }
    
    public boolean a(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      a a1 = this.e.get(param1View);
      return (a1 != null) ? a1.a(param1View, param1AccessibilityEvent) : this.a.dispatchPopulateAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public c b(View param1View) {
      a a1 = this.e.get(param1View);
      return (a1 != null) ? a1.b(param1View) : super.b(param1View);
    }
    
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      a a1 = this.e.get(param1View);
      if (a1 != null) {
        a1.c(param1View, param1AccessibilityEvent);
        return;
      } 
      this.a.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public void d(View param1View, b param1b) {
      if (!this.d.j() && this.d.d.getLayoutManager() != null) {
        this.d.d.getLayoutManager().c0(param1View, param1b);
        a a1 = this.e.get(param1View);
        if (a1 != null) {
          a1.d(param1View, param1b);
          return;
        } 
        this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
        return;
      } 
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
    }
    
    public void e(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      a a1 = this.e.get(param1View);
      if (a1 != null) {
        a1.e(param1View, param1AccessibilityEvent);
        return;
      } 
      this.a.onPopulateAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public boolean f(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      a a1 = this.e.get(param1ViewGroup);
      return (a1 != null) ? a1.f(param1ViewGroup, param1View, param1AccessibilityEvent) : this.a.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
    
    public boolean g(View param1View, int param1Int, Bundle param1Bundle) {
      RecyclerView.r r;
      if (!this.d.j() && this.d.d.getLayoutManager() != null) {
        a a1 = this.e.get(param1View);
        if (a1 != null) {
          if (a1.g(param1View, param1Int, param1Bundle))
            return true; 
        } else if (super.g(param1View, param1Int, param1Bundle)) {
          return true;
        } 
        r = (this.d.d.getLayoutManager()).b.g;
        return false;
      } 
      return super.g((View)r, param1Int, param1Bundle);
    }
    
    public void h(View param1View, int param1Int) {
      a a1 = this.e.get(param1View);
      if (a1 != null) {
        a1.h(param1View, param1Int);
        return;
      } 
      this.a.sendAccessibilityEvent(param1View, param1Int);
    }
    
    public void i(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      a a1 = this.e.get(param1View);
      if (a1 != null) {
        a1.i(param1View, param1AccessibilityEvent);
        return;
      } 
      this.a.sendAccessibilityEventUnchecked(param1View, param1AccessibilityEvent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */