package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.widget.b0;
import java.util.List;

public class LinearLayoutManager extends RecyclerView.l implements RecyclerView.v.b {
  public final a A = new a();
  
  public final b B = new b();
  
  public int C = 2;
  
  public int[] D = new int[2];
  
  public int p = 1;
  
  public c q;
  
  public s r;
  
  public boolean s;
  
  public boolean t = false;
  
  public boolean u = false;
  
  public boolean v = false;
  
  public boolean w = true;
  
  public int x = -1;
  
  public int y = Integer.MIN_VALUE;
  
  public d z = null;
  
  public LinearLayoutManager(int paramInt, boolean paramBoolean) {
    m1(paramInt);
    d(null);
    if (paramBoolean == this.t)
      return; 
    this.t = paramBoolean;
    u0();
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.l.d d1 = RecyclerView.l.R(paramContext, paramAttributeSet, paramInt1, paramInt2);
    m1(d1.a);
    boolean bool = d1.c;
    d(null);
    if (bool != this.t) {
      this.t = bool;
      u0();
    } 
    n1(d1.d);
  }
  
  public boolean E0() {
    if (this.m != 1073741824 && this.l != 1073741824) {
      int j = x();
      int i = 0;
      while (true) {
        if (i < j) {
          ViewGroup.LayoutParams layoutParams = w(i).getLayoutParams();
          if (layoutParams.width < 0 && layoutParams.height < 0) {
            i = 1;
            break;
          } 
          i++;
          continue;
        } 
        i = 0;
        break;
      } 
      if (i != 0)
        return true; 
    } 
    return false;
  }
  
  public void G0(RecyclerView paramRecyclerView, RecyclerView.w paramw, int paramInt) {
    o o = new o(paramRecyclerView.getContext());
    o.a = paramInt;
    H0(o);
  }
  
  public boolean I0() {
    return (this.z == null && this.s == this.v);
  }
  
  public void J0(RecyclerView.w paramw, int[] paramArrayOfint) {
    int i;
    int j;
    boolean bool;
    if (paramw.a != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = this.r.l();
    } else {
      i = 0;
    } 
    if (this.q.f == -1) {
      j = 0;
      bool = i;
    } else {
      bool = false;
      j = i;
    } 
    paramArrayOfint[0] = bool;
    paramArrayOfint[1] = j;
  }
  
  public void K0(RecyclerView.w paramw, c paramc, RecyclerView.l.c paramc1) {
    int i = paramc.d;
    if (i >= 0 && i < paramw.b()) {
      int j = Math.max(0, paramc.g);
      ((m.b)paramc1).a(i, j);
    } 
  }
  
  public final int L0(RecyclerView.w paramw) {
    if (x() == 0)
      return 0; 
    P0();
    return y.a(paramw, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w);
  }
  
  public final int M0(RecyclerView.w paramw) {
    if (x() == 0)
      return 0; 
    P0();
    return y.b(paramw, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w, this.u);
  }
  
  public final int N0(RecyclerView.w paramw) {
    if (x() == 0)
      return 0; 
    P0();
    return y.c(paramw, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w);
  }
  
  public int O0(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.p == 1) ? 1 : Integer.MIN_VALUE)) : ((this.p == 0) ? 1 : Integer.MIN_VALUE)) : ((this.p == 1) ? -1 : Integer.MIN_VALUE)) : ((this.p == 0) ? -1 : Integer.MIN_VALUE)) : ((this.p == 1) ? 1 : (e1() ? -1 : 1))) : ((this.p == 1) ? -1 : (e1() ? 1 : -1));
  }
  
  public void P0() {
    if (this.q == null)
      this.q = new c(); 
  }
  
  public int Q0(RecyclerView.r paramr, c paramc, RecyclerView.w paramw, boolean paramBoolean) {
    int k = paramc.c;
    int i = paramc.g;
    if (i != Integer.MIN_VALUE) {
      if (k < 0)
        paramc.g = i + k; 
      h1(paramr, paramc);
    } 
    int j = paramc.c + paramc.h;
    b b1 = this.B;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        j = i;
        if (b1.d)
          break; 
      } 
    } 
    return k - paramc.c;
  }
  
  public final View R0(RecyclerView.r paramr, RecyclerView.w paramw) {
    return Z0(paramr, paramw, 0, x(), paramw.b());
  }
  
  public View S0(boolean paramBoolean1, boolean paramBoolean2) {
    return this.u ? Y0(0, x(), paramBoolean1, paramBoolean2) : Y0(x() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  public View T0(boolean paramBoolean1, boolean paramBoolean2) {
    return this.u ? Y0(x() - 1, -1, paramBoolean1, paramBoolean2) : Y0(0, x(), paramBoolean1, paramBoolean2);
  }
  
  public boolean U() {
    return true;
  }
  
  public int U0() {
    View view = Y0(0, x(), false, true);
    return (view == null) ? -1 : Q(view);
  }
  
  public final View V0(RecyclerView.r paramr, RecyclerView.w paramw) {
    return Z0(paramr, paramw, x() - 1, -1, paramw.b());
  }
  
  public int W0() {
    View view = Y0(x() - 1, -1, false, true);
    return (view == null) ? -1 : Q(view);
  }
  
  public View X0(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    P0();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return w(paramInt1); 
    if (this.r.e(w(paramInt1)) < this.r.k()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    return (this.p == 0) ? this.c.a(paramInt1, paramInt2, c1, c2) : this.d.a(paramInt1, paramInt2, c1, c2);
  }
  
  public View Y0(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    P0();
    char c2 = 'ŀ';
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (!paramBoolean2)
      c2 = Character.MIN_VALUE; 
    return (this.p == 0) ? this.c.a(paramInt1, paramInt2, c1, c2) : this.d.a(paramInt1, paramInt2, c1, c2);
  }
  
  public void Z(RecyclerView paramRecyclerView, RecyclerView.r paramr) {}
  
  public View Z0(RecyclerView.r paramr, RecyclerView.w paramw, int paramInt1, int paramInt2, int paramInt3) {
    View view;
    byte b1;
    P0();
    int i = this.r.k();
    int j = this.r.g();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    paramw = null;
    for (paramr = null; paramInt1 != paramInt2; paramr = r1) {
      View view1;
      View view2 = w(paramInt1);
      int k = Q(view2);
      RecyclerView.w w1 = paramw;
      RecyclerView.r r1 = paramr;
      if (k >= 0) {
        w1 = paramw;
        r1 = paramr;
        if (k < paramInt3)
          if (((RecyclerView.m)view2.getLayoutParams()).c()) {
            w1 = paramw;
            r1 = paramr;
            if (paramr == null) {
              View view3 = view2;
              w1 = paramw;
            } 
          } else if (this.r.e(view2) >= j || this.r.b(view2) < i) {
            w1 = paramw;
            r1 = paramr;
            if (paramw == null) {
              view1 = view2;
              r1 = paramr;
            } 
          } else {
            return view2;
          }  
      } 
      paramInt1 += b1;
      view = view1;
    } 
    return (View)((view != null) ? view : paramr);
  }
  
  public PointF a(int paramInt) {
    if (x() == 0)
      return null; 
    boolean bool1 = false;
    int i = Q(w(0));
    boolean bool = true;
    if (paramInt < i)
      bool1 = true; 
    paramInt = bool;
    if (bool1 != this.u)
      paramInt = -1; 
    return (this.p == 0) ? new PointF(paramInt, 0.0F) : new PointF(0.0F, paramInt);
  }
  
  public View a0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    View view1;
    View view2;
    k1();
    if (x() == 0)
      return null; 
    paramInt = O0(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    P0();
    o1(paramInt, (int)(this.r.l() * 0.33333334F), false, paramw);
    c c1 = this.q;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    Q0(paramr, c1, paramw, true);
    if (paramInt == -1) {
      if (this.u) {
        view1 = X0(x() - 1, -1);
      } else {
        view1 = X0(0, x());
      } 
    } else if (this.u) {
      view1 = X0(0, x());
    } else {
      view1 = X0(x() - 1, -1);
    } 
    if (paramInt == -1) {
      view2 = d1();
    } else {
      view2 = c1();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public final int a1(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw, boolean paramBoolean) {
    int i = this.r.g() - paramInt;
    if (i > 0) {
      i = -l1(-i, paramr, paramw);
      if (paramBoolean) {
        paramInt = this.r.g() - paramInt + i;
        if (paramInt > 0) {
          this.r.p(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public void b0(AccessibilityEvent paramAccessibilityEvent) {
    super.b0(paramAccessibilityEvent);
    if (x() > 0) {
      paramAccessibilityEvent.setFromIndex(U0());
      paramAccessibilityEvent.setToIndex(W0());
    } 
  }
  
  public final int b1(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw, boolean paramBoolean) {
    int i = paramInt - this.r.k();
    if (i > 0) {
      int j = -l1(i, paramr, paramw);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.r.k();
        i = j;
        if (paramInt > 0) {
          this.r.p(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public final View c1() {
    int i;
    if (this.u) {
      i = 0;
    } else {
      i = x() - 1;
    } 
    return w(i);
  }
  
  public void d(String paramString) {
    if (this.z == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.i(paramString); 
    } 
  }
  
  public final View d1() {
    boolean bool;
    if (this.u) {
      bool = x() - 1;
    } else {
      bool = false;
    } 
    return w(bool);
  }
  
  public boolean e() {
    return (this.p == 0);
  }
  
  public boolean e1() {
    return (J() == 1);
  }
  
  public boolean f() {
    return (this.p == 1);
  }
  
  public void f1(RecyclerView.r paramr, RecyclerView.w paramw, c paramc, b paramb) {
    View view = paramc.c(paramr);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.m m1 = (RecyclerView.m)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool1;
      boolean bool2 = this.u;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        c(view, -1, false);
      } else {
        c(view, 0, false);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.u;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        c(view, -1, true);
      } else {
        c(view, 0, true);
      } 
    } 
    RecyclerView.m m2 = (RecyclerView.m)view.getLayoutParams();
    Rect rect = this.b.L(view);
    int k = rect.left;
    int m = rect.right;
    int i = rect.top;
    int j = rect.bottom;
    int n = this.n;
    int i1 = this.l;
    int i2 = N();
    k = RecyclerView.l.y(n, i1, O() + i2 + m2.leftMargin + m2.rightMargin + k + m + 0, m2.width, e());
    m = this.o;
    n = this.m;
    i1 = P();
    i = RecyclerView.l.y(m, n, M() + i1 + m2.topMargin + m2.bottomMargin + i + j + 0, m2.height, f());
    if (D0(view, k, i, m2))
      view.measure(k, i); 
    paramb.a = this.r.c(view);
    if (this.p == 1) {
      if (e1()) {
        i = this.n - O();
        j = i - this.r.d(view);
      } else {
        j = N();
        i = this.r.d(view) + j;
      } 
      if (paramc.f == -1) {
        m = paramc.b;
        i1 = paramb.a;
        k = m;
        n = i;
        i = m - i1;
        m = j;
        j = n;
      } else {
        m = paramc.b;
        i1 = paramb.a;
        k = m;
        n = i;
        i1 += m;
        m = j;
        i = k;
        j = n;
        k = i1;
      } 
    } else {
      m = P();
      i = this.r.d(view) + m;
      if (paramc.f == -1) {
        i1 = paramc.b;
        i2 = paramb.a;
        j = i1;
        n = m;
        k = i;
        m = i1 - i2;
        i = n;
      } else {
        n = paramc.b;
        j = paramb.a;
        j += n;
        k = i;
        i = m;
        m = n;
      } 
    } 
    W(view, m, i, j, k);
    if (m1.c() || m1.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public void g1(RecyclerView.r paramr, RecyclerView.w paramw, a parama, int paramInt) {}
  
  public final void h1(RecyclerView.r paramr, c paramc) {
    if (paramc.a) {
      if (paramc.l)
        return; 
      int i = paramc.g;
      int j = paramc.i;
      if (paramc.f == -1) {
        int k = x();
        if (i < 0)
          return; 
        j = this.r.f() - i + j;
        if (this.u) {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.r.e(view) < j || this.r.o(view) < j) {
              i1(paramr, 0, i);
              return;
            } 
          } 
        } else {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.r.e(view) < j || this.r.o(view) < j) {
              i1(paramr, k, i);
              return;
            } 
          } 
        } 
      } else {
        if (i < 0)
          return; 
        j = i - j;
        int k = x();
        if (this.u) {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.r.b(view) > j || this.r.n(view) > j) {
              i1(paramr, k, i);
              return;
            } 
          } 
        } else {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.r.b(view) > j || this.r.n(view) > j) {
              i1(paramr, 0, i);
              break;
            } 
          } 
        } 
      } 
    } 
  }
  
  public void i(int paramInt1, int paramInt2, RecyclerView.w paramw, RecyclerView.l.c paramc) {
    if (this.p != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      P0();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      o1(paramInt2, Math.abs(paramInt1), true, paramw);
      K0(paramw, this.q, paramc);
    } 
  }
  
  public final void i1(RecyclerView.r paramr, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        r0(paramInt2, paramr);
        paramInt2--;
      } 
    } else {
      while (i > paramInt2) {
        r0(i, paramr);
        i--;
      } 
    } 
  }
  
  public void j(int paramInt, RecyclerView.l.c paramc) {
    int i;
    boolean bool;
    d d1 = this.z;
    byte b1 = -1;
    if (d1 != null && d1.a()) {
      d1 = this.z;
      bool = d1.h;
      i = d1.f;
    } else {
      k1();
      boolean bool1 = this.u;
      int k = this.x;
      i = k;
      bool = bool1;
      if (k == -1)
        if (bool1) {
          i = paramInt - 1;
          bool = bool1;
        } else {
          i = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    int j;
    for (j = 0; j < this.C && i >= 0 && i < paramInt; j++) {
      ((m.b)paramc).a(i, 0);
      i += b1;
    } 
  }
  
  public void j0(RecyclerView.r paramr, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   4: ifnonnull -> 15
    //   7: aload_0
    //   8: getfield x : I
    //   11: iconst_m1
    //   12: if_icmpeq -> 28
    //   15: aload_2
    //   16: invokevirtual b : ()I
    //   19: ifne -> 28
    //   22: aload_0
    //   23: aload_1
    //   24: invokevirtual o0 : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   27: return
    //   28: aload_0
    //   29: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   32: astore #12
    //   34: aload #12
    //   36: ifnull -> 58
    //   39: aload #12
    //   41: invokevirtual a : ()Z
    //   44: ifeq -> 58
    //   47: aload_0
    //   48: aload_0
    //   49: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   52: getfield f : I
    //   55: putfield x : I
    //   58: aload_0
    //   59: invokevirtual P0 : ()V
    //   62: aload_0
    //   63: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   66: iconst_0
    //   67: putfield a : Z
    //   70: aload_0
    //   71: invokevirtual k1 : ()V
    //   74: aload_0
    //   75: invokevirtual H : ()Landroid/view/View;
    //   78: astore #12
    //   80: aload_0
    //   81: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   84: astore #13
    //   86: aload #13
    //   88: getfield e : Z
    //   91: ifeq -> 173
    //   94: aload_0
    //   95: getfield x : I
    //   98: iconst_m1
    //   99: if_icmpne -> 173
    //   102: aload_0
    //   103: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   106: ifnull -> 112
    //   109: goto -> 173
    //   112: aload #12
    //   114: ifnull -> 990
    //   117: aload_0
    //   118: getfield r : Landroidx/recyclerview/widget/s;
    //   121: aload #12
    //   123: invokevirtual e : (Landroid/view/View;)I
    //   126: aload_0
    //   127: getfield r : Landroidx/recyclerview/widget/s;
    //   130: invokevirtual g : ()I
    //   133: if_icmpge -> 155
    //   136: aload_0
    //   137: getfield r : Landroidx/recyclerview/widget/s;
    //   140: aload #12
    //   142: invokevirtual b : (Landroid/view/View;)I
    //   145: aload_0
    //   146: getfield r : Landroidx/recyclerview/widget/s;
    //   149: invokevirtual k : ()I
    //   152: if_icmpgt -> 990
    //   155: aload_0
    //   156: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   159: aload #12
    //   161: aload_0
    //   162: aload #12
    //   164: invokevirtual Q : (Landroid/view/View;)I
    //   167: invokevirtual c : (Landroid/view/View;I)V
    //   170: goto -> 990
    //   173: aload #13
    //   175: invokevirtual d : ()V
    //   178: aload_0
    //   179: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   182: astore #13
    //   184: aload #13
    //   186: aload_0
    //   187: getfield u : Z
    //   190: aload_0
    //   191: getfield v : Z
    //   194: ixor
    //   195: putfield d : Z
    //   198: aload_2
    //   199: getfield g : Z
    //   202: ifne -> 649
    //   205: aload_0
    //   206: getfield x : I
    //   209: istore_3
    //   210: iload_3
    //   211: iconst_m1
    //   212: if_icmpne -> 218
    //   215: goto -> 649
    //   218: iload_3
    //   219: iflt -> 638
    //   222: iload_3
    //   223: aload_2
    //   224: invokevirtual b : ()I
    //   227: if_icmplt -> 233
    //   230: goto -> 638
    //   233: aload #13
    //   235: aload_0
    //   236: getfield x : I
    //   239: putfield b : I
    //   242: aload_0
    //   243: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   246: astore #12
    //   248: aload #12
    //   250: ifnull -> 328
    //   253: aload #12
    //   255: invokevirtual a : ()Z
    //   258: ifeq -> 328
    //   261: aload_0
    //   262: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   265: getfield h : Z
    //   268: istore #11
    //   270: aload #13
    //   272: iload #11
    //   274: putfield d : Z
    //   277: iload #11
    //   279: ifeq -> 305
    //   282: aload #13
    //   284: aload_0
    //   285: getfield r : Landroidx/recyclerview/widget/s;
    //   288: invokevirtual g : ()I
    //   291: aload_0
    //   292: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   295: getfield g : I
    //   298: isub
    //   299: putfield c : I
    //   302: goto -> 633
    //   305: aload #13
    //   307: aload_0
    //   308: getfield r : Landroidx/recyclerview/widget/s;
    //   311: invokevirtual k : ()I
    //   314: aload_0
    //   315: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   318: getfield g : I
    //   321: iadd
    //   322: putfield c : I
    //   325: goto -> 633
    //   328: aload_0
    //   329: getfield y : I
    //   332: ldc -2147483648
    //   334: if_icmpne -> 578
    //   337: aload_0
    //   338: aload_0
    //   339: getfield x : I
    //   342: invokevirtual s : (I)Landroid/view/View;
    //   345: astore #12
    //   347: aload #12
    //   349: ifnull -> 511
    //   352: aload_0
    //   353: getfield r : Landroidx/recyclerview/widget/s;
    //   356: aload #12
    //   358: invokevirtual c : (Landroid/view/View;)I
    //   361: aload_0
    //   362: getfield r : Landroidx/recyclerview/widget/s;
    //   365: invokevirtual l : ()I
    //   368: if_icmple -> 379
    //   371: aload #13
    //   373: invokevirtual a : ()V
    //   376: goto -> 633
    //   379: aload_0
    //   380: getfield r : Landroidx/recyclerview/widget/s;
    //   383: aload #12
    //   385: invokevirtual e : (Landroid/view/View;)I
    //   388: aload_0
    //   389: getfield r : Landroidx/recyclerview/widget/s;
    //   392: invokevirtual k : ()I
    //   395: isub
    //   396: ifge -> 420
    //   399: aload #13
    //   401: aload_0
    //   402: getfield r : Landroidx/recyclerview/widget/s;
    //   405: invokevirtual k : ()I
    //   408: putfield c : I
    //   411: aload #13
    //   413: iconst_0
    //   414: putfield d : Z
    //   417: goto -> 633
    //   420: aload_0
    //   421: getfield r : Landroidx/recyclerview/widget/s;
    //   424: invokevirtual g : ()I
    //   427: aload_0
    //   428: getfield r : Landroidx/recyclerview/widget/s;
    //   431: aload #12
    //   433: invokevirtual b : (Landroid/view/View;)I
    //   436: isub
    //   437: ifge -> 461
    //   440: aload #13
    //   442: aload_0
    //   443: getfield r : Landroidx/recyclerview/widget/s;
    //   446: invokevirtual g : ()I
    //   449: putfield c : I
    //   452: aload #13
    //   454: iconst_1
    //   455: putfield d : Z
    //   458: goto -> 633
    //   461: aload #13
    //   463: getfield d : Z
    //   466: ifeq -> 492
    //   469: aload_0
    //   470: getfield r : Landroidx/recyclerview/widget/s;
    //   473: aload #12
    //   475: invokevirtual b : (Landroid/view/View;)I
    //   478: istore_3
    //   479: aload_0
    //   480: getfield r : Landroidx/recyclerview/widget/s;
    //   483: invokevirtual m : ()I
    //   486: iload_3
    //   487: iadd
    //   488: istore_3
    //   489: goto -> 502
    //   492: aload_0
    //   493: getfield r : Landroidx/recyclerview/widget/s;
    //   496: aload #12
    //   498: invokevirtual e : (Landroid/view/View;)I
    //   501: istore_3
    //   502: aload #13
    //   504: iload_3
    //   505: putfield c : I
    //   508: goto -> 633
    //   511: aload_0
    //   512: invokevirtual x : ()I
    //   515: ifle -> 570
    //   518: aload_0
    //   519: aload_0
    //   520: iconst_0
    //   521: invokevirtual w : (I)Landroid/view/View;
    //   524: invokevirtual Q : (Landroid/view/View;)I
    //   527: istore_3
    //   528: aload_0
    //   529: getfield x : I
    //   532: iload_3
    //   533: if_icmpge -> 542
    //   536: iconst_1
    //   537: istore #11
    //   539: goto -> 545
    //   542: iconst_0
    //   543: istore #11
    //   545: iload #11
    //   547: aload_0
    //   548: getfield u : Z
    //   551: if_icmpne -> 560
    //   554: iconst_1
    //   555: istore #11
    //   557: goto -> 563
    //   560: iconst_0
    //   561: istore #11
    //   563: aload #13
    //   565: iload #11
    //   567: putfield d : Z
    //   570: aload #13
    //   572: invokevirtual a : ()V
    //   575: goto -> 633
    //   578: aload_0
    //   579: getfield u : Z
    //   582: istore #11
    //   584: aload #13
    //   586: iload #11
    //   588: putfield d : Z
    //   591: iload #11
    //   593: ifeq -> 616
    //   596: aload #13
    //   598: aload_0
    //   599: getfield r : Landroidx/recyclerview/widget/s;
    //   602: invokevirtual g : ()I
    //   605: aload_0
    //   606: getfield y : I
    //   609: isub
    //   610: putfield c : I
    //   613: goto -> 633
    //   616: aload #13
    //   618: aload_0
    //   619: getfield r : Landroidx/recyclerview/widget/s;
    //   622: invokevirtual k : ()I
    //   625: aload_0
    //   626: getfield y : I
    //   629: iadd
    //   630: putfield c : I
    //   633: iconst_1
    //   634: istore_3
    //   635: goto -> 651
    //   638: aload_0
    //   639: iconst_m1
    //   640: putfield x : I
    //   643: aload_0
    //   644: ldc -2147483648
    //   646: putfield y : I
    //   649: iconst_0
    //   650: istore_3
    //   651: iload_3
    //   652: ifeq -> 658
    //   655: goto -> 982
    //   658: aload_0
    //   659: invokevirtual x : ()I
    //   662: ifne -> 668
    //   665: goto -> 943
    //   668: aload_0
    //   669: invokevirtual H : ()Landroid/view/View;
    //   672: astore #12
    //   674: aload #12
    //   676: ifnull -> 744
    //   679: aload #12
    //   681: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   684: checkcast androidx/recyclerview/widget/RecyclerView$m
    //   687: astore #14
    //   689: aload #14
    //   691: invokevirtual c : ()Z
    //   694: ifne -> 722
    //   697: aload #14
    //   699: invokevirtual a : ()I
    //   702: iflt -> 722
    //   705: aload #14
    //   707: invokevirtual a : ()I
    //   710: aload_2
    //   711: invokevirtual b : ()I
    //   714: if_icmpge -> 722
    //   717: iconst_1
    //   718: istore_3
    //   719: goto -> 724
    //   722: iconst_0
    //   723: istore_3
    //   724: iload_3
    //   725: ifeq -> 744
    //   728: aload #13
    //   730: aload #12
    //   732: aload_0
    //   733: aload #12
    //   735: invokevirtual Q : (Landroid/view/View;)I
    //   738: invokevirtual c : (Landroid/view/View;I)V
    //   741: goto -> 938
    //   744: aload_0
    //   745: getfield s : Z
    //   748: aload_0
    //   749: getfield v : Z
    //   752: if_icmpeq -> 758
    //   755: goto -> 943
    //   758: aload #13
    //   760: getfield d : Z
    //   763: ifeq -> 795
    //   766: aload_0
    //   767: getfield u : Z
    //   770: ifeq -> 784
    //   773: aload_0
    //   774: aload_1
    //   775: aload_2
    //   776: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   779: astore #12
    //   781: goto -> 821
    //   784: aload_0
    //   785: aload_1
    //   786: aload_2
    //   787: invokevirtual V0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   790: astore #12
    //   792: goto -> 821
    //   795: aload_0
    //   796: getfield u : Z
    //   799: ifeq -> 813
    //   802: aload_0
    //   803: aload_1
    //   804: aload_2
    //   805: invokevirtual V0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   808: astore #12
    //   810: goto -> 821
    //   813: aload_0
    //   814: aload_1
    //   815: aload_2
    //   816: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   819: astore #12
    //   821: aload #12
    //   823: ifnull -> 943
    //   826: aload #13
    //   828: aload #12
    //   830: aload_0
    //   831: aload #12
    //   833: invokevirtual Q : (Landroid/view/View;)I
    //   836: invokevirtual b : (Landroid/view/View;I)V
    //   839: aload_2
    //   840: getfield g : Z
    //   843: ifne -> 938
    //   846: aload_0
    //   847: invokevirtual I0 : ()Z
    //   850: ifeq -> 938
    //   853: aload_0
    //   854: getfield r : Landroidx/recyclerview/widget/s;
    //   857: aload #12
    //   859: invokevirtual e : (Landroid/view/View;)I
    //   862: aload_0
    //   863: getfield r : Landroidx/recyclerview/widget/s;
    //   866: invokevirtual g : ()I
    //   869: if_icmpge -> 899
    //   872: aload_0
    //   873: getfield r : Landroidx/recyclerview/widget/s;
    //   876: aload #12
    //   878: invokevirtual b : (Landroid/view/View;)I
    //   881: aload_0
    //   882: getfield r : Landroidx/recyclerview/widget/s;
    //   885: invokevirtual k : ()I
    //   888: if_icmpge -> 894
    //   891: goto -> 899
    //   894: iconst_0
    //   895: istore_3
    //   896: goto -> 901
    //   899: iconst_1
    //   900: istore_3
    //   901: iload_3
    //   902: ifeq -> 938
    //   905: aload #13
    //   907: getfield d : Z
    //   910: ifeq -> 924
    //   913: aload_0
    //   914: getfield r : Landroidx/recyclerview/widget/s;
    //   917: invokevirtual g : ()I
    //   920: istore_3
    //   921: goto -> 932
    //   924: aload_0
    //   925: getfield r : Landroidx/recyclerview/widget/s;
    //   928: invokevirtual k : ()I
    //   931: istore_3
    //   932: aload #13
    //   934: iload_3
    //   935: putfield c : I
    //   938: iconst_1
    //   939: istore_3
    //   940: goto -> 945
    //   943: iconst_0
    //   944: istore_3
    //   945: iload_3
    //   946: ifeq -> 952
    //   949: goto -> 982
    //   952: aload #13
    //   954: invokevirtual a : ()V
    //   957: aload_0
    //   958: getfield v : Z
    //   961: ifeq -> 974
    //   964: aload_2
    //   965: invokevirtual b : ()I
    //   968: iconst_1
    //   969: isub
    //   970: istore_3
    //   971: goto -> 976
    //   974: iconst_0
    //   975: istore_3
    //   976: aload #13
    //   978: iload_3
    //   979: putfield b : I
    //   982: aload_0
    //   983: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   986: iconst_1
    //   987: putfield e : Z
    //   990: aload_0
    //   991: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   994: astore #12
    //   996: aload #12
    //   998: getfield j : I
    //   1001: iflt -> 1009
    //   1004: iconst_1
    //   1005: istore_3
    //   1006: goto -> 1011
    //   1009: iconst_m1
    //   1010: istore_3
    //   1011: aload #12
    //   1013: iload_3
    //   1014: putfield f : I
    //   1017: aload_0
    //   1018: getfield D : [I
    //   1021: astore #12
    //   1023: aload #12
    //   1025: iconst_0
    //   1026: iconst_0
    //   1027: iastore
    //   1028: aload #12
    //   1030: iconst_1
    //   1031: iconst_0
    //   1032: iastore
    //   1033: aload_0
    //   1034: aload_2
    //   1035: aload #12
    //   1037: invokevirtual J0 : (Landroidx/recyclerview/widget/RecyclerView$w;[I)V
    //   1040: iconst_0
    //   1041: aload_0
    //   1042: getfield D : [I
    //   1045: iconst_0
    //   1046: iaload
    //   1047: invokestatic max : (II)I
    //   1050: istore_3
    //   1051: aload_0
    //   1052: getfield r : Landroidx/recyclerview/widget/s;
    //   1055: invokevirtual k : ()I
    //   1058: iload_3
    //   1059: iadd
    //   1060: istore #5
    //   1062: iconst_0
    //   1063: aload_0
    //   1064: getfield D : [I
    //   1067: iconst_1
    //   1068: iaload
    //   1069: invokestatic max : (II)I
    //   1072: istore_3
    //   1073: aload_0
    //   1074: getfield r : Landroidx/recyclerview/widget/s;
    //   1077: invokevirtual h : ()I
    //   1080: iload_3
    //   1081: iadd
    //   1082: istore #6
    //   1084: iload #5
    //   1086: istore_3
    //   1087: iload #6
    //   1089: istore #4
    //   1091: aload_2
    //   1092: getfield g : Z
    //   1095: ifeq -> 1241
    //   1098: aload_0
    //   1099: getfield x : I
    //   1102: istore #7
    //   1104: iload #5
    //   1106: istore_3
    //   1107: iload #6
    //   1109: istore #4
    //   1111: iload #7
    //   1113: iconst_m1
    //   1114: if_icmpeq -> 1241
    //   1117: iload #5
    //   1119: istore_3
    //   1120: iload #6
    //   1122: istore #4
    //   1124: aload_0
    //   1125: getfield y : I
    //   1128: ldc -2147483648
    //   1130: if_icmpeq -> 1241
    //   1133: aload_0
    //   1134: iload #7
    //   1136: invokevirtual s : (I)Landroid/view/View;
    //   1139: astore #12
    //   1141: iload #5
    //   1143: istore_3
    //   1144: iload #6
    //   1146: istore #4
    //   1148: aload #12
    //   1150: ifnull -> 1241
    //   1153: aload_0
    //   1154: getfield u : Z
    //   1157: ifeq -> 1187
    //   1160: aload_0
    //   1161: getfield r : Landroidx/recyclerview/widget/s;
    //   1164: invokevirtual g : ()I
    //   1167: aload_0
    //   1168: getfield r : Landroidx/recyclerview/widget/s;
    //   1171: aload #12
    //   1173: invokevirtual b : (Landroid/view/View;)I
    //   1176: isub
    //   1177: istore #4
    //   1179: aload_0
    //   1180: getfield y : I
    //   1183: istore_3
    //   1184: goto -> 1211
    //   1187: aload_0
    //   1188: getfield r : Landroidx/recyclerview/widget/s;
    //   1191: aload #12
    //   1193: invokevirtual e : (Landroid/view/View;)I
    //   1196: aload_0
    //   1197: getfield r : Landroidx/recyclerview/widget/s;
    //   1200: invokevirtual k : ()I
    //   1203: isub
    //   1204: istore_3
    //   1205: aload_0
    //   1206: getfield y : I
    //   1209: istore #4
    //   1211: iload #4
    //   1213: iload_3
    //   1214: isub
    //   1215: istore_3
    //   1216: iload_3
    //   1217: ifle -> 1232
    //   1220: iload #5
    //   1222: iload_3
    //   1223: iadd
    //   1224: istore_3
    //   1225: iload #6
    //   1227: istore #4
    //   1229: goto -> 1241
    //   1232: iload #6
    //   1234: iload_3
    //   1235: isub
    //   1236: istore #4
    //   1238: iload #5
    //   1240: istore_3
    //   1241: aload_0
    //   1242: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1245: astore #12
    //   1247: aload #12
    //   1249: getfield d : Z
    //   1252: ifeq -> 1265
    //   1255: aload_0
    //   1256: getfield u : Z
    //   1259: ifeq -> 1272
    //   1262: goto -> 1278
    //   1265: aload_0
    //   1266: getfield u : Z
    //   1269: ifeq -> 1278
    //   1272: iconst_m1
    //   1273: istore #5
    //   1275: goto -> 1281
    //   1278: iconst_1
    //   1279: istore #5
    //   1281: aload_0
    //   1282: aload_1
    //   1283: aload_2
    //   1284: aload #12
    //   1286: iload #5
    //   1288: invokevirtual g1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Landroidx/recyclerview/widget/LinearLayoutManager$a;I)V
    //   1291: aload_0
    //   1292: aload_1
    //   1293: invokevirtual q : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   1296: aload_0
    //   1297: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1300: aload_0
    //   1301: invokevirtual j1 : ()Z
    //   1304: putfield l : Z
    //   1307: aload_0
    //   1308: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1311: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1314: pop
    //   1315: aload_0
    //   1316: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1319: iconst_0
    //   1320: putfield i : I
    //   1323: aload_0
    //   1324: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1327: astore #12
    //   1329: aload #12
    //   1331: getfield d : Z
    //   1334: ifeq -> 1550
    //   1337: aload_0
    //   1338: aload #12
    //   1340: getfield b : I
    //   1343: aload #12
    //   1345: getfield c : I
    //   1348: invokevirtual q1 : (II)V
    //   1351: aload_0
    //   1352: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1355: astore #12
    //   1357: aload #12
    //   1359: iload_3
    //   1360: putfield h : I
    //   1363: aload_0
    //   1364: aload_1
    //   1365: aload #12
    //   1367: aload_2
    //   1368: iconst_0
    //   1369: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1372: pop
    //   1373: aload_0
    //   1374: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1377: astore #12
    //   1379: aload #12
    //   1381: getfield b : I
    //   1384: istore #5
    //   1386: aload #12
    //   1388: getfield d : I
    //   1391: istore #7
    //   1393: aload #12
    //   1395: getfield c : I
    //   1398: istore #6
    //   1400: iload #4
    //   1402: istore_3
    //   1403: iload #6
    //   1405: ifle -> 1414
    //   1408: iload #4
    //   1410: iload #6
    //   1412: iadd
    //   1413: istore_3
    //   1414: aload_0
    //   1415: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1418: astore #12
    //   1420: aload_0
    //   1421: aload #12
    //   1423: getfield b : I
    //   1426: aload #12
    //   1428: getfield c : I
    //   1431: invokevirtual p1 : (II)V
    //   1434: aload_0
    //   1435: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1438: astore #12
    //   1440: aload #12
    //   1442: iload_3
    //   1443: putfield h : I
    //   1446: aload #12
    //   1448: aload #12
    //   1450: getfield d : I
    //   1453: aload #12
    //   1455: getfield e : I
    //   1458: iadd
    //   1459: putfield d : I
    //   1462: aload_0
    //   1463: aload_1
    //   1464: aload #12
    //   1466: aload_2
    //   1467: iconst_0
    //   1468: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1471: pop
    //   1472: aload_0
    //   1473: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1476: astore #12
    //   1478: aload #12
    //   1480: getfield b : I
    //   1483: istore #6
    //   1485: aload #12
    //   1487: getfield c : I
    //   1490: istore #8
    //   1492: iload #5
    //   1494: istore #4
    //   1496: iload #6
    //   1498: istore_3
    //   1499: iload #8
    //   1501: ifle -> 1762
    //   1504: aload_0
    //   1505: iload #7
    //   1507: iload #5
    //   1509: invokevirtual q1 : (II)V
    //   1512: aload_0
    //   1513: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1516: astore #12
    //   1518: aload #12
    //   1520: iload #8
    //   1522: putfield h : I
    //   1525: aload_0
    //   1526: aload_1
    //   1527: aload #12
    //   1529: aload_2
    //   1530: iconst_0
    //   1531: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1534: pop
    //   1535: aload_0
    //   1536: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1539: getfield b : I
    //   1542: istore #4
    //   1544: iload #6
    //   1546: istore_3
    //   1547: goto -> 1762
    //   1550: aload_0
    //   1551: aload #12
    //   1553: getfield b : I
    //   1556: aload #12
    //   1558: getfield c : I
    //   1561: invokevirtual p1 : (II)V
    //   1564: aload_0
    //   1565: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1568: astore #12
    //   1570: aload #12
    //   1572: iload #4
    //   1574: putfield h : I
    //   1577: aload_0
    //   1578: aload_1
    //   1579: aload #12
    //   1581: aload_2
    //   1582: iconst_0
    //   1583: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1586: pop
    //   1587: aload_0
    //   1588: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1591: astore #12
    //   1593: aload #12
    //   1595: getfield b : I
    //   1598: istore #5
    //   1600: aload #12
    //   1602: getfield d : I
    //   1605: istore #7
    //   1607: aload #12
    //   1609: getfield c : I
    //   1612: istore #6
    //   1614: iload_3
    //   1615: istore #4
    //   1617: iload #6
    //   1619: ifle -> 1628
    //   1622: iload_3
    //   1623: iload #6
    //   1625: iadd
    //   1626: istore #4
    //   1628: aload_0
    //   1629: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1632: astore #12
    //   1634: aload_0
    //   1635: aload #12
    //   1637: getfield b : I
    //   1640: aload #12
    //   1642: getfield c : I
    //   1645: invokevirtual q1 : (II)V
    //   1648: aload_0
    //   1649: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1652: astore #12
    //   1654: aload #12
    //   1656: iload #4
    //   1658: putfield h : I
    //   1661: aload #12
    //   1663: aload #12
    //   1665: getfield d : I
    //   1668: aload #12
    //   1670: getfield e : I
    //   1673: iadd
    //   1674: putfield d : I
    //   1677: aload_0
    //   1678: aload_1
    //   1679: aload #12
    //   1681: aload_2
    //   1682: iconst_0
    //   1683: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1686: pop
    //   1687: aload_0
    //   1688: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1691: astore #12
    //   1693: aload #12
    //   1695: getfield b : I
    //   1698: istore #6
    //   1700: aload #12
    //   1702: getfield c : I
    //   1705: istore #8
    //   1707: iload #6
    //   1709: istore #4
    //   1711: iload #5
    //   1713: istore_3
    //   1714: iload #8
    //   1716: ifle -> 1762
    //   1719: aload_0
    //   1720: iload #7
    //   1722: iload #5
    //   1724: invokevirtual p1 : (II)V
    //   1727: aload_0
    //   1728: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1731: astore #12
    //   1733: aload #12
    //   1735: iload #8
    //   1737: putfield h : I
    //   1740: aload_0
    //   1741: aload_1
    //   1742: aload #12
    //   1744: aload_2
    //   1745: iconst_0
    //   1746: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1749: pop
    //   1750: aload_0
    //   1751: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1754: getfield b : I
    //   1757: istore_3
    //   1758: iload #6
    //   1760: istore #4
    //   1762: iload #4
    //   1764: istore #6
    //   1766: iload_3
    //   1767: istore #5
    //   1769: aload_0
    //   1770: invokevirtual x : ()I
    //   1773: ifle -> 1870
    //   1776: aload_0
    //   1777: getfield u : Z
    //   1780: aload_0
    //   1781: getfield v : Z
    //   1784: ixor
    //   1785: ifeq -> 1824
    //   1788: aload_0
    //   1789: iload_3
    //   1790: aload_1
    //   1791: aload_2
    //   1792: iconst_1
    //   1793: invokevirtual a1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1796: istore #6
    //   1798: iload #4
    //   1800: iload #6
    //   1802: iadd
    //   1803: istore #5
    //   1805: iload_3
    //   1806: iload #6
    //   1808: iadd
    //   1809: istore #4
    //   1811: aload_0
    //   1812: iload #5
    //   1814: aload_1
    //   1815: aload_2
    //   1816: iconst_0
    //   1817: invokevirtual b1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1820: istore_3
    //   1821: goto -> 1858
    //   1824: aload_0
    //   1825: iload #4
    //   1827: aload_1
    //   1828: aload_2
    //   1829: iconst_1
    //   1830: invokevirtual b1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1833: istore #6
    //   1835: iload #4
    //   1837: iload #6
    //   1839: iadd
    //   1840: istore #5
    //   1842: iload_3
    //   1843: iload #6
    //   1845: iadd
    //   1846: istore #4
    //   1848: aload_0
    //   1849: iload #4
    //   1851: aload_1
    //   1852: aload_2
    //   1853: iconst_0
    //   1854: invokevirtual a1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   1857: istore_3
    //   1858: iload #5
    //   1860: iload_3
    //   1861: iadd
    //   1862: istore #6
    //   1864: iload #4
    //   1866: iload_3
    //   1867: iadd
    //   1868: istore #5
    //   1870: aload_2
    //   1871: getfield k : Z
    //   1874: ifeq -> 2181
    //   1877: aload_0
    //   1878: invokevirtual x : ()I
    //   1881: ifeq -> 2181
    //   1884: aload_2
    //   1885: getfield g : Z
    //   1888: ifne -> 2181
    //   1891: aload_0
    //   1892: invokevirtual I0 : ()Z
    //   1895: ifne -> 1901
    //   1898: goto -> 2181
    //   1901: aload_1
    //   1902: getfield d : Ljava/util/List;
    //   1905: astore #12
    //   1907: aload #12
    //   1909: invokeinterface size : ()I
    //   1914: istore #9
    //   1916: aload_0
    //   1917: aload_0
    //   1918: iconst_0
    //   1919: invokevirtual w : (I)Landroid/view/View;
    //   1922: invokevirtual Q : (Landroid/view/View;)I
    //   1925: istore #10
    //   1927: iconst_0
    //   1928: istore_3
    //   1929: iconst_0
    //   1930: istore #7
    //   1932: iconst_0
    //   1933: istore #4
    //   1935: iload_3
    //   1936: iload #9
    //   1938: if_icmpge -> 2052
    //   1941: aload #12
    //   1943: iload_3
    //   1944: invokeinterface get : (I)Ljava/lang/Object;
    //   1949: checkcast androidx/recyclerview/widget/RecyclerView$z
    //   1952: astore #13
    //   1954: aload #13
    //   1956: invokevirtual l : ()Z
    //   1959: ifeq -> 1965
    //   1962: goto -> 2045
    //   1965: aload #13
    //   1967: invokevirtual e : ()I
    //   1970: iload #10
    //   1972: if_icmpge -> 1981
    //   1975: iconst_1
    //   1976: istore #11
    //   1978: goto -> 1984
    //   1981: iconst_0
    //   1982: istore #11
    //   1984: iload #11
    //   1986: aload_0
    //   1987: getfield u : Z
    //   1990: if_icmpeq -> 1999
    //   1993: iconst_m1
    //   1994: istore #8
    //   1996: goto -> 2002
    //   1999: iconst_1
    //   2000: istore #8
    //   2002: iload #8
    //   2004: iconst_m1
    //   2005: if_icmpne -> 2028
    //   2008: iload #7
    //   2010: aload_0
    //   2011: getfield r : Landroidx/recyclerview/widget/s;
    //   2014: aload #13
    //   2016: getfield a : Landroid/view/View;
    //   2019: invokevirtual c : (Landroid/view/View;)I
    //   2022: iadd
    //   2023: istore #7
    //   2025: goto -> 2045
    //   2028: iload #4
    //   2030: aload_0
    //   2031: getfield r : Landroidx/recyclerview/widget/s;
    //   2034: aload #13
    //   2036: getfield a : Landroid/view/View;
    //   2039: invokevirtual c : (Landroid/view/View;)I
    //   2042: iadd
    //   2043: istore #4
    //   2045: iload_3
    //   2046: iconst_1
    //   2047: iadd
    //   2048: istore_3
    //   2049: goto -> 1935
    //   2052: aload_0
    //   2053: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2056: aload #12
    //   2058: putfield k : Ljava/util/List;
    //   2061: iload #7
    //   2063: ifle -> 2117
    //   2066: aload_0
    //   2067: aload_0
    //   2068: aload_0
    //   2069: invokevirtual d1 : ()Landroid/view/View;
    //   2072: invokevirtual Q : (Landroid/view/View;)I
    //   2075: iload #6
    //   2077: invokevirtual q1 : (II)V
    //   2080: aload_0
    //   2081: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2084: astore #12
    //   2086: aload #12
    //   2088: iload #7
    //   2090: putfield h : I
    //   2093: aload #12
    //   2095: iconst_0
    //   2096: putfield c : I
    //   2099: aload #12
    //   2101: aconst_null
    //   2102: invokevirtual a : (Landroid/view/View;)V
    //   2105: aload_0
    //   2106: aload_1
    //   2107: aload_0
    //   2108: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2111: aload_2
    //   2112: iconst_0
    //   2113: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   2116: pop
    //   2117: iload #4
    //   2119: ifle -> 2173
    //   2122: aload_0
    //   2123: aload_0
    //   2124: aload_0
    //   2125: invokevirtual c1 : ()Landroid/view/View;
    //   2128: invokevirtual Q : (Landroid/view/View;)I
    //   2131: iload #5
    //   2133: invokevirtual p1 : (II)V
    //   2136: aload_0
    //   2137: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2140: astore #12
    //   2142: aload #12
    //   2144: iload #4
    //   2146: putfield h : I
    //   2149: aload #12
    //   2151: iconst_0
    //   2152: putfield c : I
    //   2155: aload #12
    //   2157: aconst_null
    //   2158: invokevirtual a : (Landroid/view/View;)V
    //   2161: aload_0
    //   2162: aload_1
    //   2163: aload_0
    //   2164: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2167: aload_2
    //   2168: iconst_0
    //   2169: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$w;Z)I
    //   2172: pop
    //   2173: aload_0
    //   2174: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2177: aconst_null
    //   2178: putfield k : Ljava/util/List;
    //   2181: aload_2
    //   2182: getfield g : Z
    //   2185: ifne -> 2204
    //   2188: aload_0
    //   2189: getfield r : Landroidx/recyclerview/widget/s;
    //   2192: astore_1
    //   2193: aload_1
    //   2194: aload_1
    //   2195: invokevirtual l : ()I
    //   2198: putfield b : I
    //   2201: goto -> 2211
    //   2204: aload_0
    //   2205: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   2208: invokevirtual d : ()V
    //   2211: aload_0
    //   2212: aload_0
    //   2213: getfield v : Z
    //   2216: putfield s : Z
    //   2219: return
  }
  
  public boolean j1() {
    return (this.r.i() == 0 && this.r.f() == 0);
  }
  
  public int k(RecyclerView.w paramw) {
    return L0(paramw);
  }
  
  public void k0(RecyclerView.w paramw) {
    this.z = null;
    this.x = -1;
    this.y = Integer.MIN_VALUE;
    this.A.d();
  }
  
  public final void k1() {
    if (this.p == 1 || !e1()) {
      this.u = this.t;
      return;
    } 
    this.u = this.t ^ true;
  }
  
  public int l(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public void l0(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      this.z = (d)paramParcelable;
      u0();
    } 
  }
  
  public int l1(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    if (x() != 0) {
      byte b1;
      if (paramInt == 0)
        return 0; 
      P0();
      this.q.a = true;
      if (paramInt > 0) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      int i = Math.abs(paramInt);
      o1(b1, i, true, paramw);
      c c1 = this.q;
      int j = c1.g;
      j = Q0(paramr, c1, paramw, false) + j;
      if (j < 0)
        return 0; 
      if (i > j)
        paramInt = b1 * j; 
      this.r.p(-paramInt);
      this.q.j = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public int m(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public Parcelable m0() {
    d d1 = this.z;
    if (d1 != null)
      return new d(d1); 
    d1 = new d();
    if (x() > 0) {
      P0();
      int i = this.s ^ this.u;
      d1.h = i;
      if (i != 0) {
        View view1 = c1();
        d1.g = this.r.g() - this.r.b(view1);
        d1.f = Q(view1);
        return d1;
      } 
      View view = d1();
      d1.f = Q(view);
      d1.g = this.r.e(view) - this.r.k();
      return d1;
    } 
    d1.f = -1;
    return d1;
  }
  
  public void m1(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      d(null);
      if (paramInt != this.p || this.r == null) {
        s s1 = s.a(this, paramInt);
        this.r = s1;
        this.A.a = s1;
        this.p = paramInt;
        u0();
      } 
      return;
    } 
    throw new IllegalArgumentException(b0.a("invalid orientation:", paramInt));
  }
  
  public int n(RecyclerView.w paramw) {
    return L0(paramw);
  }
  
  public void n1(boolean paramBoolean) {
    d(null);
    if (this.v == paramBoolean)
      return; 
    this.v = paramBoolean;
    u0();
  }
  
  public int o(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public final void o1(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.w paramw) {
    this.q.l = j1();
    this.q.f = paramInt1;
    int[] arrayOfInt = this.D;
    boolean bool1 = false;
    arrayOfInt[0] = 0;
    boolean bool2 = true;
    boolean bool3 = true;
    arrayOfInt[1] = 0;
    J0(paramw, arrayOfInt);
    int i = Math.max(0, this.D[0]);
    int j = Math.max(0, this.D[1]);
    if (paramInt1 == 1)
      bool1 = true; 
    c c1 = this.q;
    if (bool1) {
      paramInt1 = j;
    } else {
      paramInt1 = i;
    } 
    c1.h = paramInt1;
    if (!bool1)
      i = j; 
    c1.i = i;
    if (bool1) {
      c1.h = this.r.h() + paramInt1;
      View view = c1();
      c c2 = this.q;
      paramInt1 = bool3;
      if (this.u)
        paramInt1 = -1; 
      c2.e = paramInt1;
      paramInt1 = Q(view);
      c c3 = this.q;
      c2.d = paramInt1 + c3.e;
      c3.b = this.r.b(view);
      paramInt1 = this.r.b(view) - this.r.g();
    } else {
      View view = d1();
      c c2 = this.q;
      paramInt1 = c2.h;
      c2.h = this.r.k() + paramInt1;
      c2 = this.q;
      if (this.u) {
        paramInt1 = bool2;
      } else {
        paramInt1 = -1;
      } 
      c2.e = paramInt1;
      paramInt1 = Q(view);
      c c3 = this.q;
      c2.d = paramInt1 + c3.e;
      c3.b = this.r.e(view);
      paramInt1 = -this.r.e(view) + this.r.k();
    } 
    c1 = this.q;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  public int p(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public final void p1(int paramInt1, int paramInt2) {
    boolean bool;
    this.q.c = this.r.g() - paramInt2;
    c c1 = this.q;
    if (this.u) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public final void q1(int paramInt1, int paramInt2) {
    this.q.c = paramInt2 - this.r.k();
    c c1 = this.q;
    c1.d = paramInt1;
    if (this.u) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public View s(int paramInt) {
    int i = x();
    if (i == 0)
      return null; 
    int j = paramInt - Q(w(0));
    if (j >= 0 && j < i) {
      View view = w(j);
      if (Q(view) == paramInt)
        return view; 
    } 
    return super.s(paramInt);
  }
  
  public RecyclerView.m t() {
    return new RecyclerView.m(-2, -2);
  }
  
  public int v0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.p == 1) ? 0 : l1(paramInt, paramr, paramw);
  }
  
  public void w0(int paramInt) {
    this.x = paramInt;
    this.y = Integer.MIN_VALUE;
    d d1 = this.z;
    if (d1 != null)
      d1.f = -1; 
    u0();
  }
  
  public int x0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.p == 0) ? 0 : l1(paramInt, paramr, paramw);
  }
  
  public static class a {
    public s a;
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public boolean e;
    
    public a() {
      d();
    }
    
    public void a() {
      int i;
      if (this.d) {
        i = this.a.g();
      } else {
        i = this.a.k();
      } 
      this.c = i;
    }
    
    public void b(View param1View, int param1Int) {
      if (this.d) {
        int i = this.a.b(param1View);
        this.c = this.a.m() + i;
      } else {
        this.c = this.a.e(param1View);
      } 
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int i = this.a.m();
      if (i >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.g() - i - this.a.b(param1View);
        this.c = this.a.g() - param1Int;
        if (param1Int > 0) {
          i = this.a.c(param1View);
          int j = this.c;
          int k = this.a.k();
          i = j - i - Math.min(this.a.e(param1View) - k, 0) + k;
          if (i < 0) {
            j = this.c;
            this.c = Math.min(param1Int, -i) + j;
            return;
          } 
        } 
      } else {
        int j = this.a.e(param1View);
        param1Int = j - this.a.k();
        this.c = j;
        if (param1Int > 0) {
          int k = this.a.c(param1View);
          int m = this.a.g();
          int n = this.a.b(param1View);
          i = this.a.g() - Math.min(0, m - i - n) - k + j;
          if (i < 0)
            this.c -= Math.min(param1Int, -i); 
        } 
      } 
    }
    
    public void d() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class c {
    public boolean a = true;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h = 0;
    
    public int i = 0;
    
    public int j;
    
    public List<RecyclerView.z> k = null;
    
    public boolean l;
    
    public void a(View param1View) {
      View view2;
      int k = this.k.size();
      View view1 = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (true) {
        view2 = view1;
        if (i < k) {
          View view = ((RecyclerView.z)this.k.get(i)).a;
          RecyclerView.m m1 = (RecyclerView.m)view.getLayoutParams();
          view2 = view1;
          int m = j;
          if (view != param1View)
            if (m1.c()) {
              view2 = view1;
              m = j;
            } else {
              int n = (m1.a() - this.d) * this.e;
              if (n < 0) {
                view2 = view1;
                m = j;
              } else {
                view2 = view1;
                m = j;
                if (n < j) {
                  view1 = view;
                  if (n == 0) {
                    view2 = view1;
                    break;
                  } 
                  m = n;
                  view2 = view1;
                } 
              } 
            }  
          i++;
          view1 = view2;
          j = m;
          continue;
        } 
        break;
      } 
      if (view2 == null) {
        this.d = -1;
        return;
      } 
      this.d = ((RecyclerView.m)view2.getLayoutParams()).a();
    }
    
    public boolean b(RecyclerView.w param1w) {
      int i = this.d;
      return (i >= 0 && i < param1w.b());
    }
    
    public View c(RecyclerView.r param1r) {
      List<RecyclerView.z> list = this.k;
      int i = 0;
      if (list != null) {
        int j = list.size();
        while (i < j) {
          view = ((RecyclerView.z)this.k.get(i)).a;
          RecyclerView.m m = (RecyclerView.m)view.getLayoutParams();
          if (!m.c() && this.d == m.a()) {
            a(view);
            return view;
          } 
          i++;
        } 
        return null;
      } 
      View view = (view.k(this.d, false, Long.MAX_VALUE)).a;
      this.d += this.e;
      return view;
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    public int f;
    
    public int g;
    
    public boolean h;
    
    public d() {}
    
    public d(Parcel param1Parcel) {
      this.f = param1Parcel.readInt();
      this.g = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.h = bool;
    }
    
    public d(d param1d) {
      this.f = param1d.f;
      this.g = param1d.g;
      this.h = param1d.h;
    }
    
    public boolean a() {
      return (this.f >= 0);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public static final class a implements Parcelable.Creator<d> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new LinearLayoutManager.d(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new LinearLayoutManager.d[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<d> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new LinearLayoutManager.d(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new LinearLayoutManager.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */