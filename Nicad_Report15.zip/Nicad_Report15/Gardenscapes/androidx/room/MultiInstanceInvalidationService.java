package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import f1.c;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  public int f = 0;
  
  public final HashMap<Integer, String> g = new HashMap<Integer, String>();
  
  public final RemoteCallbackList<f1.b> h = new a(this);
  
  public final c i = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.i;
  }
  
  public class a extends RemoteCallbackList<f1.b> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public void onCallbackDied(IInterface param1IInterface, Object param1Object) {
      f1.b b = (f1.b)param1IInterface;
      this.a.g.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public class b extends c {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public void I(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.f.h) {
        String str = this.f.g.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.f.h.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.f.h.getBroadcastCookie(i)).intValue();
            String str1 = this.f.g.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((f1.b)this.f.h.getBroadcastItem(i)).w1(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.f.h.finishBroadcast();
          } 
        } 
        this.f.h.finishBroadcast();
        return;
      } 
    }
    
    public int U(f1.b param1b, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.f.h) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.f;
        int i = multiInstanceInvalidationService2.f + 1;
        multiInstanceInvalidationService2.f = i;
        if (multiInstanceInvalidationService2.h.register((IInterface)param1b, Integer.valueOf(i))) {
          this.f.g.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.f;
        multiInstanceInvalidationService1.f--;
        return 0;
      } 
    }
    
    public void a0(f1.b param1b, int param1Int) {
      synchronized (this.f.h) {
        this.f.h.unregister((IInterface)param1b);
        this.f.g.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */