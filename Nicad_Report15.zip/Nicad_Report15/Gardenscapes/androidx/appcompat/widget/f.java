package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import m0.t;
import m0.y;

public class f {
  public final View a;
  
  public final k b;
  
  public int c = -1;
  
  public b1 d;
  
  public b1 e;
  
  public b1 f;
  
  public f(View paramView) {
    this.a = paramView;
    this.b = k.a();
  }
  
  public void a() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      boolean bool1;
      int i = Build.VERSION.SDK_INT;
      boolean bool2 = true;
      if ((i > 21) ? (this.d != null) : (i == 21)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        if (this.f == null)
          this.f = new b1(); 
        b1 b12 = this.f;
        PorterDuff.Mode mode = null;
        b12.a = null;
        b12.d = false;
        b12.b = null;
        b12.c = false;
        ColorStateList colorStateList = y.k(this.a);
        if (colorStateList != null) {
          b12.d = true;
          b12.a = colorStateList;
        } 
        View view = this.a;
        if (i >= 21) {
          mode = y.i.h(view);
        } else if (view instanceof t) {
          mode = ((t)view).getSupportBackgroundTintMode();
        } 
        if (mode != null) {
          b12.c = true;
          b12.b = mode;
        } 
        if (b12.d || b12.c) {
          k.f(drawable, b12, this.a.getDrawableState());
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        if (bool1)
          return; 
      } 
      b1 b11 = this.e;
      if (b11 != null) {
        k.f(drawable, b11, this.a.getDrawableState());
        return;
      } 
      b11 = this.d;
      if (b11 != null)
        k.f(drawable, b11, this.a.getDrawableState()); 
    } 
  }
  
  public ColorStateList b() {
    b1 b11 = this.e;
    return (b11 != null) ? b11.a : null;
  }
  
  public PorterDuff.Mode c() {
    b1 b11 = this.e;
    return (b11 != null) ? b11.b : null;
  }
  
  public void d(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/view/View;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #4
    //   9: getstatic e/i.z : [I
    //   12: astore #5
    //   14: iconst_0
    //   15: istore_3
    //   16: aload #4
    //   18: aload_1
    //   19: aload #5
    //   21: iload_2
    //   22: iconst_0
    //   23: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/d1;
    //   26: astore #4
    //   28: aload_0
    //   29: getfield a : Landroid/view/View;
    //   32: astore #6
    //   34: aload #6
    //   36: aload #6
    //   38: invokevirtual getContext : ()Landroid/content/Context;
    //   41: aload #5
    //   43: aload_1
    //   44: aload #4
    //   46: getfield b : Landroid/content/res/TypedArray;
    //   49: iload_2
    //   50: iconst_0
    //   51: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   54: aload #4
    //   56: iconst_0
    //   57: invokevirtual o : (I)Z
    //   60: ifeq -> 102
    //   63: aload_0
    //   64: aload #4
    //   66: iconst_0
    //   67: iconst_m1
    //   68: invokevirtual l : (II)I
    //   71: putfield c : I
    //   74: aload_0
    //   75: getfield b : Landroidx/appcompat/widget/k;
    //   78: aload_0
    //   79: getfield a : Landroid/view/View;
    //   82: invokevirtual getContext : ()Landroid/content/Context;
    //   85: aload_0
    //   86: getfield c : I
    //   89: invokevirtual d : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   92: astore_1
    //   93: aload_1
    //   94: ifnull -> 102
    //   97: aload_0
    //   98: aload_1
    //   99: invokevirtual g : (Landroid/content/res/ColorStateList;)V
    //   102: aload #4
    //   104: iconst_1
    //   105: invokevirtual o : (I)Z
    //   108: ifeq -> 226
    //   111: aload_0
    //   112: getfield a : Landroid/view/View;
    //   115: astore_1
    //   116: aload #4
    //   118: iconst_1
    //   119: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   122: astore #5
    //   124: getstatic android/os/Build$VERSION.SDK_INT : I
    //   127: istore_2
    //   128: iload_2
    //   129: bipush #21
    //   131: if_icmplt -> 208
    //   134: aload_1
    //   135: aload #5
    //   137: invokestatic q : (Landroid/view/View;Landroid/content/res/ColorStateList;)V
    //   140: iload_2
    //   141: bipush #21
    //   143: if_icmpne -> 226
    //   146: aload_1
    //   147: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   150: astore #5
    //   152: aload_1
    //   153: invokestatic g : (Landroid/view/View;)Landroid/content/res/ColorStateList;
    //   156: ifnonnull -> 378
    //   159: aload_1
    //   160: invokestatic h : (Landroid/view/View;)Landroid/graphics/PorterDuff$Mode;
    //   163: ifnull -> 373
    //   166: goto -> 378
    //   169: aload #5
    //   171: ifnull -> 226
    //   174: iload_2
    //   175: ifeq -> 226
    //   178: aload #5
    //   180: invokevirtual isStateful : ()Z
    //   183: ifeq -> 199
    //   186: aload #5
    //   188: aload_1
    //   189: invokevirtual getDrawableState : ()[I
    //   192: invokevirtual setState : ([I)Z
    //   195: pop
    //   196: goto -> 199
    //   199: aload_1
    //   200: aload #5
    //   202: invokestatic q : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   205: goto -> 226
    //   208: aload_1
    //   209: instanceof m0/t
    //   212: ifeq -> 226
    //   215: aload_1
    //   216: checkcast m0/t
    //   219: aload #5
    //   221: invokeinterface setSupportBackgroundTintList : (Landroid/content/res/ColorStateList;)V
    //   226: aload #4
    //   228: iconst_2
    //   229: invokevirtual o : (I)Z
    //   232: ifeq -> 354
    //   235: aload_0
    //   236: getfield a : Landroid/view/View;
    //   239: astore_1
    //   240: aload #4
    //   242: iconst_2
    //   243: iconst_m1
    //   244: invokevirtual j : (II)I
    //   247: aconst_null
    //   248: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   251: astore #5
    //   253: getstatic android/os/Build$VERSION.SDK_INT : I
    //   256: istore_2
    //   257: iload_2
    //   258: bipush #21
    //   260: if_icmplt -> 336
    //   263: aload_1
    //   264: aload #5
    //   266: invokestatic r : (Landroid/view/View;Landroid/graphics/PorterDuff$Mode;)V
    //   269: iload_2
    //   270: bipush #21
    //   272: if_icmpne -> 354
    //   275: aload_1
    //   276: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   279: astore #5
    //   281: aload_1
    //   282: invokestatic g : (Landroid/view/View;)Landroid/content/res/ColorStateList;
    //   285: ifnonnull -> 387
    //   288: iload_3
    //   289: istore_2
    //   290: aload_1
    //   291: invokestatic h : (Landroid/view/View;)Landroid/graphics/PorterDuff$Mode;
    //   294: ifnull -> 300
    //   297: goto -> 387
    //   300: aload #5
    //   302: ifnull -> 354
    //   305: iload_2
    //   306: ifeq -> 354
    //   309: aload #5
    //   311: invokevirtual isStateful : ()Z
    //   314: ifeq -> 327
    //   317: aload #5
    //   319: aload_1
    //   320: invokevirtual getDrawableState : ()[I
    //   323: invokevirtual setState : ([I)Z
    //   326: pop
    //   327: aload_1
    //   328: aload #5
    //   330: invokestatic q : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   333: goto -> 354
    //   336: aload_1
    //   337: instanceof m0/t
    //   340: ifeq -> 354
    //   343: aload_1
    //   344: checkcast m0/t
    //   347: aload #5
    //   349: invokeinterface setSupportBackgroundTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   354: aload #4
    //   356: getfield b : Landroid/content/res/TypedArray;
    //   359: invokevirtual recycle : ()V
    //   362: return
    //   363: aload #4
    //   365: getfield b : Landroid/content/res/TypedArray;
    //   368: invokevirtual recycle : ()V
    //   371: aload_1
    //   372: athrow
    //   373: iconst_0
    //   374: istore_2
    //   375: goto -> 169
    //   378: iconst_1
    //   379: istore_2
    //   380: goto -> 169
    //   383: astore_1
    //   384: goto -> 363
    //   387: iconst_1
    //   388: istore_2
    //   389: goto -> 300
    // Exception table:
    //   from	to	target	type
    //   54	93	383	finally
    //   97	102	383	finally
    //   102	128	383	finally
    //   134	140	383	finally
    //   146	166	383	finally
    //   178	196	383	finally
    //   199	205	383	finally
    //   208	226	383	finally
    //   226	257	383	finally
    //   263	269	383	finally
    //   275	288	383	finally
    //   290	297	383	finally
    //   309	327	383	finally
    //   327	333	383	finally
    //   336	354	383	finally
  }
  
  public void e() {
    this.c = -1;
    g(null);
    a();
  }
  
  public void f(int paramInt) {
    this.c = paramInt;
    k k1 = this.b;
    if (k1 != null) {
      ColorStateList colorStateList = k1.d(this.a.getContext(), paramInt);
    } else {
      k1 = null;
    } 
    g((ColorStateList)k1);
    a();
  }
  
  public void g(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new b1(); 
      b1 b11 = this.d;
      b11.a = paramColorStateList;
      b11.d = true;
    } else {
      this.d = null;
    } 
    a();
  }
  
  public void h(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new b1(); 
    b1 b11 = this.e;
    b11.a = paramColorStateList;
    b11.d = true;
    a();
  }
  
  public void i(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new b1(); 
    b1 b11 = this.e;
    b11.b = paramMode;
    b11.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */