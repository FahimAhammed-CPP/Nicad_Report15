package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;

public class o0 implements AdapterView.OnItemSelectedListener {
  public o0(p0 paramp0) {}
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    if (paramInt != -1) {
      k0 k0 = this.f.h;
      if (k0 != null)
        k0.setListSelectionHidden(false); 
    } 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */