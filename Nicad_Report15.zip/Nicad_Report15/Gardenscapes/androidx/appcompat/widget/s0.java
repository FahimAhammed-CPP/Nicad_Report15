package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import n1.h;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import s.h;
import s.i;

public final class s0 {
  public static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
  
  public static s0 i;
  
  public static final c j = new c(6);
  
  public WeakHashMap<Context, i<ColorStateList>> a;
  
  public h<String, e> b;
  
  public i<String> c;
  
  public final WeakHashMap<Context, s.e<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<Context, s.e<WeakReference<Drawable.ConstantState>>>(0);
  
  public TypedValue e;
  
  public boolean f;
  
  public f g;
  
  public static s0 d() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/s0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/s0.i : Landroidx/appcompat/widget/s0;
    //   6: ifnonnull -> 25
    //   9: new androidx/appcompat/widget/s0
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/s0.i : Landroidx/appcompat/widget/s0;
    //   21: aload_0
    //   22: invokestatic j : (Landroidx/appcompat/widget/s0;)V
    //   25: getstatic androidx/appcompat/widget/s0.i : Landroidx/appcompat/widget/s0;
    //   28: astore_0
    //   29: ldc androidx/appcompat/widget/s0
    //   31: monitorexit
    //   32: aload_0
    //   33: areturn
    //   34: astore_0
    //   35: ldc androidx/appcompat/widget/s0
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   3	25	34	finally
    //   25	29	34	finally
  }
  
  public static PorterDuffColorFilter h(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/s0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/s0.j : Landroidx/appcompat/widget/s0$c;
    //   6: astore #5
    //   8: aload #5
    //   10: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: pop
    //   14: iload_0
    //   15: bipush #31
    //   17: iadd
    //   18: bipush #31
    //   20: imul
    //   21: istore_2
    //   22: aload #5
    //   24: aload_1
    //   25: invokevirtual hashCode : ()I
    //   28: iload_2
    //   29: iadd
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: invokevirtual a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast android/graphics/PorterDuffColorFilter
    //   39: astore #4
    //   41: aload #4
    //   43: astore_3
    //   44: aload #4
    //   46: ifnonnull -> 84
    //   49: new android/graphics/PorterDuffColorFilter
    //   52: dup
    //   53: iload_0
    //   54: aload_1
    //   55: invokespecial <init> : (ILandroid/graphics/PorterDuff$Mode;)V
    //   58: astore_3
    //   59: aload #5
    //   61: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   64: pop
    //   65: aload #5
    //   67: aload_1
    //   68: invokevirtual hashCode : ()I
    //   71: iload_2
    //   72: iadd
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: aload_3
    //   77: invokevirtual b : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   80: checkcast android/graphics/PorterDuffColorFilter
    //   83: astore_1
    //   84: ldc androidx/appcompat/widget/s0
    //   86: monitorexit
    //   87: aload_3
    //   88: areturn
    //   89: astore_1
    //   90: ldc androidx/appcompat/widget/s0
    //   92: monitorexit
    //   93: aload_1
    //   94: athrow
    // Exception table:
    //   from	to	target	type
    //   3	14	89	finally
    //   22	41	89	finally
    //   49	84	89	finally
  }
  
  public static void j(s0 params0) {
    if (Build.VERSION.SDK_INT < 24) {
      params0.a("vector", new g());
      params0.a("animated-vector", new b());
      params0.a("animated-selector", new a());
      params0.a("drawable", new d());
    } 
  }
  
  public final void a(String paramString, e parame) {
    if (this.b == null)
      this.b = new h(); 
    this.b.put(paramString, parame);
  }
  
  public final boolean b(Context paramContext, long paramLong, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #4
    //   4: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 75
    //   14: aload_0
    //   15: getfield d : Ljava/util/WeakHashMap;
    //   18: aload_1
    //   19: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: checkcast s/e
    //   25: astore #5
    //   27: aload #5
    //   29: astore #4
    //   31: aload #5
    //   33: ifnonnull -> 56
    //   36: new s/e
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield d : Ljava/util/WeakHashMap;
    //   49: aload_1
    //   50: aload #4
    //   52: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: pop
    //   56: aload #4
    //   58: lload_2
    //   59: new java/lang/ref/WeakReference
    //   62: dup
    //   63: aload #6
    //   65: invokespecial <init> : (Ljava/lang/Object;)V
    //   68: invokevirtual g : (JLjava/lang/Object;)V
    //   71: aload_0
    //   72: monitorexit
    //   73: iconst_1
    //   74: ireturn
    //   75: aload_0
    //   76: monitorexit
    //   77: iconst_0
    //   78: ireturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	79	finally
    //   14	27	79	finally
    //   36	56	79	finally
    //   56	71	79	finally
  }
  
  public final Drawable c(Context paramContext, int paramInt) {
    LayerDrawable layerDrawable;
    if (this.e == null)
      this.e = new TypedValue(); 
    TypedValue typedValue = this.e;
    paramContext.getResources().getValue(paramInt, typedValue, true);
    long l = typedValue.assetCookie << 32L | typedValue.data;
    Drawable drawable = e(paramContext, l);
    if (drawable != null)
      return drawable; 
    f f1 = this.g;
    drawable = null;
    if (f1 != null) {
      f1 = f1;
      if (paramInt == 2131165206) {
        layerDrawable = new LayerDrawable(new Drawable[] { f(paramContext, 2131165205), f(paramContext, 2131165207) });
      } else if (paramInt == 2131165241) {
        layerDrawable = f1.c(this, paramContext, 2131099707);
      } else if (paramInt == 2131165240) {
        layerDrawable = f1.c(this, paramContext, 2131099708);
      } else if (paramInt == 2131165242) {
        layerDrawable = f1.c(this, paramContext, 2131099709);
      } 
    } 
    if (layerDrawable != null) {
      layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
      b(paramContext, l, (Drawable)layerDrawable);
    } 
    return (Drawable)layerDrawable;
  }
  
  public final Drawable e(Context paramContext, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast s/e
    //   13: astore #5
    //   15: aload #5
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload #5
    //   26: lload_2
    //   27: aconst_null
    //   28: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast java/lang/ref/WeakReference
    //   34: astore #6
    //   36: aload #6
    //   38: ifnull -> 127
    //   41: aload #6
    //   43: invokevirtual get : ()Ljava/lang/Object;
    //   46: checkcast android/graphics/drawable/Drawable$ConstantState
    //   49: astore #6
    //   51: aload #6
    //   53: ifnull -> 70
    //   56: aload #6
    //   58: aload_1
    //   59: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   62: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: areturn
    //   70: aload #5
    //   72: getfield g : [J
    //   75: aload #5
    //   77: getfield i : I
    //   80: lload_2
    //   81: invokestatic b : ([JIJ)I
    //   84: istore #4
    //   86: iload #4
    //   88: iflt -> 127
    //   91: aload #5
    //   93: getfield h : [Ljava/lang/Object;
    //   96: astore_1
    //   97: aload_1
    //   98: iload #4
    //   100: aaload
    //   101: astore #6
    //   103: getstatic s/e.j : Ljava/lang/Object;
    //   106: astore #7
    //   108: aload #6
    //   110: aload #7
    //   112: if_acmpeq -> 127
    //   115: aload_1
    //   116: iload #4
    //   118: aload #7
    //   120: aastore
    //   121: aload #5
    //   123: iconst_1
    //   124: putfield f : Z
    //   127: aload_0
    //   128: monitorexit
    //   129: aconst_null
    //   130: areturn
    //   131: astore_1
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	131	finally
    //   24	36	131	finally
    //   41	51	131	finally
    //   56	66	131	finally
    //   70	86	131	finally
    //   91	97	131	finally
    //   103	108	131	finally
    //   121	127	131	finally
  }
  
  public Drawable f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: iconst_0
    //   6: invokevirtual g : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public Drawable g(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Z
    //   6: ifeq -> 12
    //   9: goto -> 69
    //   12: iconst_1
    //   13: istore #5
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield f : Z
    //   20: aload_0
    //   21: aload_1
    //   22: ldc 2131165268
    //   24: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   27: astore #6
    //   29: aload #6
    //   31: ifnull -> 149
    //   34: iload #5
    //   36: istore #4
    //   38: aload #6
    //   40: instanceof n1/h
    //   43: ifne -> 172
    //   46: ldc 'android.graphics.drawable.VectorDrawable'
    //   48: aload #6
    //   50: invokevirtual getClass : ()Ljava/lang/Class;
    //   53: invokevirtual getName : ()Ljava/lang/String;
    //   56: invokevirtual equals : (Ljava/lang/Object;)Z
    //   59: ifeq -> 169
    //   62: iload #5
    //   64: istore #4
    //   66: goto -> 172
    //   69: aload_0
    //   70: aload_1
    //   71: iload_2
    //   72: invokevirtual k : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   75: astore #7
    //   77: aload #7
    //   79: astore #6
    //   81: aload #7
    //   83: ifnonnull -> 94
    //   86: aload_0
    //   87: aload_1
    //   88: iload_2
    //   89: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   92: astore #6
    //   94: aload #6
    //   96: astore #7
    //   98: aload #6
    //   100: ifnonnull -> 110
    //   103: aload_1
    //   104: iload_2
    //   105: invokestatic c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   108: astore #7
    //   110: aload #7
    //   112: astore #6
    //   114: aload #7
    //   116: ifnull -> 130
    //   119: aload_0
    //   120: aload_1
    //   121: iload_2
    //   122: iload_3
    //   123: aload #7
    //   125: invokevirtual l : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   128: astore #6
    //   130: aload #6
    //   132: ifnull -> 140
    //   135: aload #6
    //   137: invokestatic b : (Landroid/graphics/drawable/Drawable;)V
    //   140: aload_0
    //   141: monitorexit
    //   142: aload #6
    //   144: areturn
    //   145: astore_1
    //   146: goto -> 165
    //   149: aload_0
    //   150: iconst_0
    //   151: putfield f : Z
    //   154: new java/lang/IllegalStateException
    //   157: dup
    //   158: ldc_w 'This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.'
    //   161: invokespecial <init> : (Ljava/lang/String;)V
    //   164: athrow
    //   165: aload_0
    //   166: monitorexit
    //   167: aload_1
    //   168: athrow
    //   169: iconst_0
    //   170: istore #4
    //   172: iload #4
    //   174: ifeq -> 149
    //   177: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   2	9	145	finally
    //   15	29	145	finally
    //   38	62	145	finally
    //   69	77	145	finally
    //   86	94	145	finally
    //   103	110	145	finally
    //   119	130	145	finally
    //   135	140	145	finally
    //   149	165	145	finally
  }
  
  public ColorStateList i(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/WeakHashMap;
    //   6: astore_3
    //   7: aconst_null
    //   8: astore #5
    //   10: aload_3
    //   11: ifnull -> 162
    //   14: aload_3
    //   15: aload_1
    //   16: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast s/i
    //   22: astore_3
    //   23: aload_3
    //   24: ifnull -> 162
    //   27: aload_3
    //   28: iload_2
    //   29: aconst_null
    //   30: invokevirtual d : (ILjava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast android/content/res/ColorStateList
    //   36: astore_3
    //   37: goto -> 40
    //   40: aload_3
    //   41: astore #4
    //   43: aload_3
    //   44: ifnonnull -> 153
    //   47: aload_0
    //   48: getfield g : Landroidx/appcompat/widget/s0$f;
    //   51: astore_3
    //   52: aload_3
    //   53: ifnonnull -> 62
    //   56: aload #5
    //   58: astore_3
    //   59: goto -> 72
    //   62: aload_3
    //   63: checkcast androidx/appcompat/widget/k$a
    //   66: aload_1
    //   67: iload_2
    //   68: invokevirtual d : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   71: astore_3
    //   72: aload_3
    //   73: ifnull -> 143
    //   76: aload_0
    //   77: getfield a : Ljava/util/WeakHashMap;
    //   80: ifnonnull -> 94
    //   83: aload_0
    //   84: new java/util/WeakHashMap
    //   87: dup
    //   88: invokespecial <init> : ()V
    //   91: putfield a : Ljava/util/WeakHashMap;
    //   94: aload_0
    //   95: getfield a : Ljava/util/WeakHashMap;
    //   98: aload_1
    //   99: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   102: checkcast s/i
    //   105: astore #5
    //   107: aload #5
    //   109: astore #4
    //   111: aload #5
    //   113: ifnonnull -> 136
    //   116: new s/i
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: astore #4
    //   125: aload_0
    //   126: getfield a : Ljava/util/WeakHashMap;
    //   129: aload_1
    //   130: aload #4
    //   132: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   135: pop
    //   136: aload #4
    //   138: iload_2
    //   139: aload_3
    //   140: invokevirtual a : (ILjava/lang/Object;)V
    //   143: aload_3
    //   144: astore #4
    //   146: goto -> 153
    //   149: astore_1
    //   150: goto -> 158
    //   153: aload_0
    //   154: monitorexit
    //   155: aload #4
    //   157: areturn
    //   158: aload_0
    //   159: monitorexit
    //   160: aload_1
    //   161: athrow
    //   162: aconst_null
    //   163: astore_3
    //   164: goto -> 40
    // Exception table:
    //   from	to	target	type
    //   2	7	149	finally
    //   14	23	149	finally
    //   27	37	149	finally
    //   47	52	149	finally
    //   62	72	149	finally
    //   76	94	149	finally
    //   94	107	149	finally
    //   116	136	149	finally
    //   136	143	149	finally
  }
  
  public final Drawable k(Context paramContext, int paramInt) {
    h<String, e> h1 = this.b;
    if (h1 != null && !h1.isEmpty()) {
      i<String> i1 = this.c;
      if (i1 != null) {
        String str = (String)i1.d(paramInt, null);
        if ("appcompat_skip_skip".equals(str) || (str != null && this.b.getOrDefault(str, null) == null))
          return null; 
      } else {
        this.c = new i();
      } 
      if (this.e == null)
        this.e = new TypedValue(); 
      TypedValue typedValue = this.e;
      Resources resources = paramContext.getResources();
      resources.getValue(paramInt, typedValue, true);
      long l = typedValue.assetCookie << 32L | typedValue.data;
      Drawable drawable1 = e(paramContext, l);
      if (drawable1 != null)
        return drawable1; 
      CharSequence charSequence = typedValue.string;
      Drawable drawable2 = drawable1;
      if (charSequence != null) {
        drawable2 = drawable1;
        if (charSequence.toString().endsWith(".xml")) {
          drawable2 = drawable1;
          try {
            int j;
            XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
            drawable2 = drawable1;
            AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
            while (true) {
              drawable2 = drawable1;
              j = xmlResourceParser.next();
              if (j != 2 && j != 1)
                continue; 
              break;
            } 
            if (j == 2) {
              drawable2 = drawable1;
              String str = xmlResourceParser.getName();
              drawable2 = drawable1;
              this.c.a(paramInt, str);
              drawable2 = drawable1;
              e e = (e)this.b.get(str);
              Drawable drawable = drawable1;
              if (e != null) {
                drawable2 = drawable1;
                drawable = e.a(paramContext, (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme());
              } 
              drawable2 = drawable;
              if (drawable != null) {
                drawable2 = drawable;
                drawable.setChangingConfigurations(typedValue.changingConfigurations);
                drawable2 = drawable;
                b(paramContext, l, drawable);
                drawable2 = drawable;
              } 
            } else {
              drawable2 = drawable1;
              throw new XmlPullParserException("No start tag found");
            } 
          } catch (Exception exception) {
            Log.e("ResourceManagerInternal", "Exception while inflating drawable", exception);
          } 
        } 
      } 
      if (drawable2 == null)
        this.c.a(paramInt, "appcompat_skip_skip"); 
      return drawable2;
    } 
    return null;
  }
  
  public final Drawable l(Context paramContext, int paramInt, boolean paramBoolean, Drawable paramDrawable) {
    PorterDuff.Mode mode;
    Drawable drawable;
    ColorStateList colorStateList = i(paramContext, paramInt);
    f f1 = null;
    if (colorStateList != null) {
      Drawable drawable1 = paramDrawable;
      if (j0.a(paramDrawable))
        drawable1 = paramDrawable.mutate(); 
      paramDrawable = f0.a.k(drawable1);
      f0.a.i(paramDrawable, colorStateList);
      f f2 = this.g;
      if (f2 == null) {
        f2 = f1;
      } else {
        f2 = f2;
        f2 = f1;
        if (paramInt == 2131165255)
          mode = PorterDuff.Mode.MULTIPLY; 
      } 
      drawable = paramDrawable;
      if (mode != null) {
        f0.a.j(paramDrawable, mode);
        return paramDrawable;
      } 
    } else {
      f1 = this.g;
      if (f1 != null) {
        f1 = f1;
        boolean bool = true;
        if (paramInt == 2131165250) {
          LayerDrawable layerDrawable = (LayerDrawable)paramDrawable;
          Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
          int j = y0.c((Context)mode, 2130903244);
          PorterDuff.Mode mode1 = k.b;
          f1.e(drawable1, j, mode1);
          f1.e(layerDrawable.findDrawableByLayerId(16908303), y0.c((Context)mode, 2130903244), mode1);
          f1.e(layerDrawable.findDrawableByLayerId(16908301), y0.c((Context)mode, 2130903242), mode1);
        } else if (paramInt == 2131165241 || paramInt == 2131165240 || paramInt == 2131165242) {
          LayerDrawable layerDrawable = (LayerDrawable)paramDrawable;
          Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
          int j = y0.b((Context)mode, 2130903244);
          PorterDuff.Mode mode1 = k.b;
          f1.e(drawable1, j, mode1);
          f1.e(layerDrawable.findDrawableByLayerId(16908303), y0.c((Context)mode, 2130903242), mode1);
          f1.e(layerDrawable.findDrawableByLayerId(16908301), y0.c((Context)mode, 2130903242), mode1);
        } else {
          bool = false;
        } 
        if (bool)
          return paramDrawable; 
      } 
      drawable = paramDrawable;
      if (!m((Context)mode, paramInt, paramDrawable)) {
        drawable = paramDrawable;
        if (paramBoolean)
          drawable = null; 
      } 
    } 
    return drawable;
  }
  
  public boolean m(Context paramContext, int paramInt, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroidx/appcompat/widget/s0$f;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnull -> 216
    //   11: aload #7
    //   13: checkcast androidx/appcompat/widget/k$a
    //   16: astore #8
    //   18: aload #8
    //   20: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   23: pop
    //   24: getstatic androidx/appcompat/widget/k.b : Landroid/graphics/PorterDuff$Mode;
    //   27: astore #7
    //   29: aload #8
    //   31: aload #8
    //   33: getfield a : [I
    //   36: iload_2
    //   37: invokevirtual a : ([II)Z
    //   40: istore #6
    //   42: ldc_w 16842801
    //   45: istore #4
    //   47: iload #6
    //   49: ifeq -> 59
    //   52: ldc_w 2130903244
    //   55: istore_2
    //   56: goto -> 137
    //   59: aload #8
    //   61: aload #8
    //   63: getfield c : [I
    //   66: iload_2
    //   67: invokevirtual a : ([II)Z
    //   70: ifeq -> 80
    //   73: ldc_w 2130903242
    //   76: istore_2
    //   77: goto -> 137
    //   80: aload #8
    //   82: aload #8
    //   84: getfield d : [I
    //   87: iload_2
    //   88: invokevirtual a : ([II)Z
    //   91: ifeq -> 105
    //   94: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
    //   97: astore #7
    //   99: iload #4
    //   101: istore_2
    //   102: goto -> 137
    //   105: iload_2
    //   106: ldc_w 2131165227
    //   109: if_icmpne -> 127
    //   112: ldc_w 16842800
    //   115: istore_2
    //   116: ldc_w 40.8
    //   119: invokestatic round : (F)I
    //   122: istore #4
    //   124: goto -> 140
    //   127: iload_2
    //   128: ldc_w 2131165209
    //   131: if_icmpne -> 146
    //   134: iload #4
    //   136: istore_2
    //   137: iconst_m1
    //   138: istore #4
    //   140: iconst_1
    //   141: istore #5
    //   143: goto -> 154
    //   146: iconst_0
    //   147: istore_2
    //   148: iconst_m1
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #5
    //   154: iload #5
    //   156: ifeq -> 208
    //   159: aload_3
    //   160: astore #8
    //   162: aload_3
    //   163: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
    //   166: ifeq -> 175
    //   169: aload_3
    //   170: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   173: astore #8
    //   175: aload #8
    //   177: aload_1
    //   178: iload_2
    //   179: invokestatic c : (Landroid/content/Context;I)I
    //   182: aload #7
    //   184: invokestatic c : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   187: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   190: iload #4
    //   192: iconst_m1
    //   193: if_icmpeq -> 203
    //   196: aload #8
    //   198: iload #4
    //   200: invokevirtual setAlpha : (I)V
    //   203: iconst_1
    //   204: istore_2
    //   205: goto -> 210
    //   208: iconst_0
    //   209: istore_2
    //   210: iload_2
    //   211: ifeq -> 216
    //   214: iconst_1
    //   215: ireturn
    //   216: iconst_0
    //   217: ireturn
  }
  
  public static class a implements e {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)h.b.g(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", exception);
        return null;
      } 
    }
  }
  
  public static class b implements e {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        Resources resources = param1Context.getResources();
        n1.b b1 = new n1.b(param1Context, null, null);
        b1.inflate(resources, param1XmlPullParser, param1AttributeSet, param1Theme);
        return (Drawable)b1;
      } catch (Exception exception) {
        Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", exception);
        return null;
      } 
    }
  }
  
  public static class c extends s.f<Integer, PorterDuffColorFilter> {
    public c(int param1Int) {
      super(param1Int);
    }
  }
  
  public static class d implements e {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      String str = param1AttributeSet.getClassAttribute();
      if (str != null)
        try {
          Drawable drawable = d.class.getClassLoader().loadClass(str).<Drawable>asSubclass(Drawable.class).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
          if (Build.VERSION.SDK_INT >= 21) {
            i.c.c(drawable, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
            return drawable;
          } 
          drawable.inflate(param1Context.getResources(), param1XmlPullParser, param1AttributeSet);
          return drawable;
        } catch (Exception exception) {
          Log.e("DrawableDelegate", "Exception while inflating <drawable>", exception);
        }  
      return null;
    }
  }
  
  public static interface e {
    Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme);
  }
  
  public static interface f {}
  
  public static class g implements e {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)h.a(param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("VdcInflateDelegate", "Exception while inflating <vector>", exception);
        return null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */