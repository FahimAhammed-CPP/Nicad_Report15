package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import d0.h;
import e.i;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class c0 {
  public final TextView a;
  
  public b1 b;
  
  public b1 c;
  
  public b1 d;
  
  public b1 e;
  
  public b1 f;
  
  public b1 g;
  
  public b1 h;
  
  public final f0 i;
  
  public int j = 0;
  
  public int k = -1;
  
  public Typeface l;
  
  public boolean m;
  
  public c0(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new f0(paramTextView);
  }
  
  public static b1 c(Context paramContext, k paramk, int paramInt) {
    ColorStateList colorStateList = paramk.d(paramContext, paramInt);
    if (colorStateList != null) {
      b1 b11 = new b1();
      b11.d = true;
      b11.a = colorStateList;
      return b11;
    } 
    return null;
  }
  
  public final void a(Drawable paramDrawable, b1 paramb1) {
    if (paramDrawable != null && paramb1 != null)
      k.f(paramDrawable, paramb1, this.a.getDrawableState()); 
  }
  
  public void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  public boolean d() {
    f0 f01 = this.i;
    return (f01.i() && f01.a != 0);
  }
  
  @SuppressLint({"NewApi"})
  public void e(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #22
    //   9: invokestatic a : ()Landroidx/appcompat/widget/k;
    //   12: astore #21
    //   14: getstatic e/i.h : [I
    //   17: astore #13
    //   19: aload #22
    //   21: aload_1
    //   22: aload #13
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/d1;
    //   29: astore #14
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #15
    //   37: aload #15
    //   39: aload #15
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #13
    //   46: aload_1
    //   47: aload #14
    //   49: getfield b : Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #14
    //   59: iconst_0
    //   60: iconst_m1
    //   61: invokevirtual l : (II)I
    //   64: istore #7
    //   66: aload #14
    //   68: iconst_3
    //   69: invokevirtual o : (I)Z
    //   72: ifeq -> 93
    //   75: aload_0
    //   76: aload #22
    //   78: aload #21
    //   80: aload #14
    //   82: iconst_3
    //   83: iconst_0
    //   84: invokevirtual l : (II)I
    //   87: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   90: putfield b : Landroidx/appcompat/widget/b1;
    //   93: aload #14
    //   95: iconst_1
    //   96: invokevirtual o : (I)Z
    //   99: ifeq -> 120
    //   102: aload_0
    //   103: aload #22
    //   105: aload #21
    //   107: aload #14
    //   109: iconst_1
    //   110: iconst_0
    //   111: invokevirtual l : (II)I
    //   114: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   117: putfield c : Landroidx/appcompat/widget/b1;
    //   120: aload #14
    //   122: iconst_4
    //   123: invokevirtual o : (I)Z
    //   126: ifeq -> 147
    //   129: aload_0
    //   130: aload #22
    //   132: aload #21
    //   134: aload #14
    //   136: iconst_4
    //   137: iconst_0
    //   138: invokevirtual l : (II)I
    //   141: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   144: putfield d : Landroidx/appcompat/widget/b1;
    //   147: aload #14
    //   149: iconst_2
    //   150: invokevirtual o : (I)Z
    //   153: ifeq -> 174
    //   156: aload_0
    //   157: aload #22
    //   159: aload #21
    //   161: aload #14
    //   163: iconst_2
    //   164: iconst_0
    //   165: invokevirtual l : (II)I
    //   168: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   171: putfield e : Landroidx/appcompat/widget/b1;
    //   174: getstatic android/os/Build$VERSION.SDK_INT : I
    //   177: istore #9
    //   179: aload #14
    //   181: iconst_5
    //   182: invokevirtual o : (I)Z
    //   185: ifeq -> 206
    //   188: aload_0
    //   189: aload #22
    //   191: aload #21
    //   193: aload #14
    //   195: iconst_5
    //   196: iconst_0
    //   197: invokevirtual l : (II)I
    //   200: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   203: putfield f : Landroidx/appcompat/widget/b1;
    //   206: aload #14
    //   208: bipush #6
    //   210: invokevirtual o : (I)Z
    //   213: ifeq -> 235
    //   216: aload_0
    //   217: aload #22
    //   219: aload #21
    //   221: aload #14
    //   223: bipush #6
    //   225: iconst_0
    //   226: invokevirtual l : (II)I
    //   229: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/k;I)Landroidx/appcompat/widget/b1;
    //   232: putfield g : Landroidx/appcompat/widget/b1;
    //   235: aload #14
    //   237: getfield b : Landroid/content/res/TypedArray;
    //   240: invokevirtual recycle : ()V
    //   243: aload_0
    //   244: getfield a : Landroid/widget/TextView;
    //   247: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   250: instanceof android/text/method/PasswordTransformationMethod
    //   253: istore #12
    //   255: iload #7
    //   257: iconst_m1
    //   258: if_icmpeq -> 506
    //   261: aload #22
    //   263: iload #7
    //   265: getstatic e/i.w : [I
    //   268: invokevirtual obtainStyledAttributes : (I[I)Landroid/content/res/TypedArray;
    //   271: astore #19
    //   273: new androidx/appcompat/widget/d1
    //   276: dup
    //   277: aload #22
    //   279: aload #19
    //   281: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   284: astore #20
    //   286: iload #12
    //   288: ifne -> 317
    //   291: aload #20
    //   293: bipush #14
    //   295: invokevirtual o : (I)Z
    //   298: ifeq -> 317
    //   301: aload #20
    //   303: bipush #14
    //   305: iconst_0
    //   306: invokevirtual a : (IZ)Z
    //   309: istore #10
    //   311: iconst_1
    //   312: istore #7
    //   314: goto -> 323
    //   317: iconst_0
    //   318: istore #10
    //   320: iconst_0
    //   321: istore #7
    //   323: aload_0
    //   324: aload #22
    //   326: aload #20
    //   328: invokevirtual m : (Landroid/content/Context;Landroidx/appcompat/widget/d1;)V
    //   331: iload #9
    //   333: bipush #23
    //   335: if_icmpge -> 420
    //   338: aload #20
    //   340: iconst_3
    //   341: invokevirtual o : (I)Z
    //   344: ifeq -> 358
    //   347: aload #20
    //   349: iconst_3
    //   350: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   353: astore #13
    //   355: goto -> 361
    //   358: aconst_null
    //   359: astore #13
    //   361: aload #20
    //   363: iconst_4
    //   364: invokevirtual o : (I)Z
    //   367: ifeq -> 381
    //   370: aload #20
    //   372: iconst_4
    //   373: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   376: astore #14
    //   378: goto -> 384
    //   381: aconst_null
    //   382: astore #14
    //   384: aload #13
    //   386: astore #16
    //   388: aload #14
    //   390: astore #15
    //   392: aload #20
    //   394: iconst_5
    //   395: invokevirtual o : (I)Z
    //   398: ifeq -> 426
    //   401: aload #20
    //   403: iconst_5
    //   404: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   407: astore #17
    //   409: aload #13
    //   411: astore #16
    //   413: aload #14
    //   415: astore #13
    //   417: goto -> 433
    //   420: aconst_null
    //   421: astore #16
    //   423: aconst_null
    //   424: astore #15
    //   426: aconst_null
    //   427: astore #17
    //   429: aload #15
    //   431: astore #13
    //   433: aload #20
    //   435: bipush #15
    //   437: invokevirtual o : (I)Z
    //   440: ifeq -> 455
    //   443: aload #20
    //   445: bipush #15
    //   447: invokevirtual m : (I)Ljava/lang/String;
    //   450: astore #18
    //   452: goto -> 458
    //   455: aconst_null
    //   456: astore #18
    //   458: iload #9
    //   460: bipush #26
    //   462: if_icmplt -> 487
    //   465: aload #20
    //   467: bipush #13
    //   469: invokevirtual o : (I)Z
    //   472: ifeq -> 487
    //   475: aload #20
    //   477: bipush #13
    //   479: invokevirtual m : (I)Ljava/lang/String;
    //   482: astore #15
    //   484: goto -> 490
    //   487: aconst_null
    //   488: astore #15
    //   490: aload #19
    //   492: invokevirtual recycle : ()V
    //   495: aload #16
    //   497: astore #14
    //   499: aload #18
    //   501: astore #16
    //   503: goto -> 527
    //   506: iconst_0
    //   507: istore #10
    //   509: aconst_null
    //   510: astore #15
    //   512: iconst_0
    //   513: istore #7
    //   515: aconst_null
    //   516: astore #14
    //   518: aconst_null
    //   519: astore #13
    //   521: aconst_null
    //   522: astore #17
    //   524: aconst_null
    //   525: astore #16
    //   527: aload #22
    //   529: aload_1
    //   530: getstatic e/i.w : [I
    //   533: iload_2
    //   534: iconst_0
    //   535: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   538: astore #24
    //   540: new androidx/appcompat/widget/d1
    //   543: dup
    //   544: aload #22
    //   546: aload #24
    //   548: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   551: astore #23
    //   553: iload #10
    //   555: istore #11
    //   557: iload #7
    //   559: istore #8
    //   561: iload #12
    //   563: ifne -> 597
    //   566: iload #10
    //   568: istore #11
    //   570: iload #7
    //   572: istore #8
    //   574: aload #23
    //   576: bipush #14
    //   578: invokevirtual o : (I)Z
    //   581: ifeq -> 597
    //   584: aload #23
    //   586: bipush #14
    //   588: iconst_0
    //   589: invokevirtual a : (IZ)Z
    //   592: istore #11
    //   594: iconst_1
    //   595: istore #8
    //   597: aload #14
    //   599: astore #18
    //   601: aload #13
    //   603: astore #19
    //   605: aload #17
    //   607: astore #20
    //   609: iload #9
    //   611: bipush #23
    //   613: if_icmpge -> 687
    //   616: aload #23
    //   618: iconst_3
    //   619: invokevirtual o : (I)Z
    //   622: ifeq -> 633
    //   625: aload #23
    //   627: iconst_3
    //   628: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   631: astore #14
    //   633: aload #23
    //   635: iconst_4
    //   636: invokevirtual o : (I)Z
    //   639: ifeq -> 650
    //   642: aload #23
    //   644: iconst_4
    //   645: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   648: astore #13
    //   650: aload #14
    //   652: astore #18
    //   654: aload #13
    //   656: astore #19
    //   658: aload #17
    //   660: astore #20
    //   662: aload #23
    //   664: iconst_5
    //   665: invokevirtual o : (I)Z
    //   668: ifeq -> 687
    //   671: aload #23
    //   673: iconst_5
    //   674: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   677: astore #20
    //   679: aload #13
    //   681: astore #19
    //   683: aload #14
    //   685: astore #18
    //   687: aload #23
    //   689: bipush #15
    //   691: invokevirtual o : (I)Z
    //   694: ifeq -> 706
    //   697: aload #23
    //   699: bipush #15
    //   701: invokevirtual m : (I)Ljava/lang/String;
    //   704: astore #16
    //   706: iload #9
    //   708: bipush #26
    //   710: if_icmplt -> 735
    //   713: aload #23
    //   715: bipush #13
    //   717: invokevirtual o : (I)Z
    //   720: ifeq -> 735
    //   723: aload #23
    //   725: bipush #13
    //   727: invokevirtual m : (I)Ljava/lang/String;
    //   730: astore #15
    //   732: goto -> 735
    //   735: iload #9
    //   737: bipush #28
    //   739: if_icmplt -> 773
    //   742: aload #23
    //   744: iconst_0
    //   745: invokevirtual o : (I)Z
    //   748: ifeq -> 773
    //   751: aload #23
    //   753: iconst_0
    //   754: iconst_m1
    //   755: invokevirtual f : (II)I
    //   758: ifne -> 773
    //   761: aload_0
    //   762: getfield a : Landroid/widget/TextView;
    //   765: iconst_0
    //   766: fconst_0
    //   767: invokevirtual setTextSize : (IF)V
    //   770: goto -> 773
    //   773: aload #21
    //   775: astore #13
    //   777: aload_0
    //   778: aload #22
    //   780: aload #23
    //   782: invokevirtual m : (Landroid/content/Context;Landroidx/appcompat/widget/d1;)V
    //   785: aload #24
    //   787: invokevirtual recycle : ()V
    //   790: aload #18
    //   792: ifnull -> 804
    //   795: aload_0
    //   796: getfield a : Landroid/widget/TextView;
    //   799: aload #18
    //   801: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   804: aload #19
    //   806: ifnull -> 818
    //   809: aload_0
    //   810: getfield a : Landroid/widget/TextView;
    //   813: aload #19
    //   815: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   818: aload #20
    //   820: ifnull -> 832
    //   823: aload_0
    //   824: getfield a : Landroid/widget/TextView;
    //   827: aload #20
    //   829: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   832: iload #12
    //   834: ifne -> 851
    //   837: iload #8
    //   839: ifeq -> 851
    //   842: aload_0
    //   843: getfield a : Landroid/widget/TextView;
    //   846: iload #11
    //   848: invokevirtual setAllCaps : (Z)V
    //   851: aload_0
    //   852: getfield l : Landroid/graphics/Typeface;
    //   855: astore #14
    //   857: aload #14
    //   859: ifnull -> 895
    //   862: aload_0
    //   863: getfield k : I
    //   866: iconst_m1
    //   867: if_icmpne -> 886
    //   870: aload_0
    //   871: getfield a : Landroid/widget/TextView;
    //   874: aload #14
    //   876: aload_0
    //   877: getfield j : I
    //   880: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   883: goto -> 895
    //   886: aload_0
    //   887: getfield a : Landroid/widget/TextView;
    //   890: aload #14
    //   892: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   895: aload #15
    //   897: ifnull -> 910
    //   900: aload_0
    //   901: getfield a : Landroid/widget/TextView;
    //   904: aload #15
    //   906: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   909: pop
    //   910: aload #16
    //   912: ifnull -> 974
    //   915: iload #9
    //   917: bipush #24
    //   919: if_icmplt -> 937
    //   922: aload_0
    //   923: getfield a : Landroid/widget/TextView;
    //   926: aload #16
    //   928: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   931: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   934: goto -> 974
    //   937: iload #9
    //   939: bipush #21
    //   941: if_icmplt -> 974
    //   944: aload #16
    //   946: iconst_0
    //   947: aload #16
    //   949: bipush #44
    //   951: invokevirtual indexOf : (I)I
    //   954: invokevirtual substring : (II)Ljava/lang/String;
    //   957: astore #14
    //   959: aload_0
    //   960: getfield a : Landroid/widget/TextView;
    //   963: aload #14
    //   965: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   968: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   971: goto -> 974
    //   974: aload_0
    //   975: getfield i : Landroidx/appcompat/widget/f0;
    //   978: astore #14
    //   980: aload #14
    //   982: getfield j : Landroid/content/Context;
    //   985: astore #15
    //   987: getstatic e/i.i : [I
    //   990: astore #16
    //   992: aload #15
    //   994: aload_1
    //   995: aload #16
    //   997: iload_2
    //   998: iconst_0
    //   999: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   1002: astore #15
    //   1004: aload #14
    //   1006: getfield i : Landroid/widget/TextView;
    //   1009: astore #17
    //   1011: aload #17
    //   1013: aload #17
    //   1015: invokevirtual getContext : ()Landroid/content/Context;
    //   1018: aload #16
    //   1020: aload_1
    //   1021: aload #15
    //   1023: iload_2
    //   1024: iconst_0
    //   1025: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   1028: aload #15
    //   1030: iconst_5
    //   1031: invokevirtual hasValue : (I)Z
    //   1034: ifeq -> 1049
    //   1037: aload #14
    //   1039: aload #15
    //   1041: iconst_5
    //   1042: iconst_0
    //   1043: invokevirtual getInt : (II)I
    //   1046: putfield a : I
    //   1049: aload #15
    //   1051: iconst_4
    //   1052: invokevirtual hasValue : (I)Z
    //   1055: ifeq -> 1070
    //   1058: aload #15
    //   1060: iconst_4
    //   1061: ldc -1.0
    //   1063: invokevirtual getDimension : (IF)F
    //   1066: fstore_3
    //   1067: goto -> 1073
    //   1070: ldc -1.0
    //   1072: fstore_3
    //   1073: aload #15
    //   1075: iconst_2
    //   1076: invokevirtual hasValue : (I)Z
    //   1079: ifeq -> 1095
    //   1082: aload #15
    //   1084: iconst_2
    //   1085: ldc -1.0
    //   1087: invokevirtual getDimension : (IF)F
    //   1090: fstore #4
    //   1092: goto -> 1099
    //   1095: ldc -1.0
    //   1097: fstore #4
    //   1099: aload #15
    //   1101: iconst_1
    //   1102: invokevirtual hasValue : (I)Z
    //   1105: ifeq -> 1121
    //   1108: aload #15
    //   1110: iconst_1
    //   1111: ldc -1.0
    //   1113: invokevirtual getDimension : (IF)F
    //   1116: fstore #5
    //   1118: goto -> 1125
    //   1121: ldc -1.0
    //   1123: fstore #5
    //   1125: aload #15
    //   1127: iconst_3
    //   1128: invokevirtual hasValue : (I)Z
    //   1131: ifeq -> 1224
    //   1134: aload #15
    //   1136: iconst_3
    //   1137: iconst_0
    //   1138: invokevirtual getResourceId : (II)I
    //   1141: istore_2
    //   1142: iload_2
    //   1143: ifle -> 1224
    //   1146: aload #15
    //   1148: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1151: iload_2
    //   1152: invokevirtual obtainTypedArray : (I)Landroid/content/res/TypedArray;
    //   1155: astore #16
    //   1157: aload #16
    //   1159: invokevirtual length : ()I
    //   1162: istore #7
    //   1164: iload #7
    //   1166: newarray int
    //   1168: astore #17
    //   1170: iload #7
    //   1172: ifle -> 1219
    //   1175: iconst_0
    //   1176: istore_2
    //   1177: iload_2
    //   1178: iload #7
    //   1180: if_icmpge -> 1201
    //   1183: aload #17
    //   1185: iload_2
    //   1186: aload #16
    //   1188: iload_2
    //   1189: iconst_m1
    //   1190: invokevirtual getDimensionPixelSize : (II)I
    //   1193: iastore
    //   1194: iload_2
    //   1195: iconst_1
    //   1196: iadd
    //   1197: istore_2
    //   1198: goto -> 1177
    //   1201: aload #14
    //   1203: aload #14
    //   1205: aload #17
    //   1207: invokevirtual b : ([I)[I
    //   1210: putfield f : [I
    //   1213: aload #14
    //   1215: invokevirtual h : ()Z
    //   1218: pop
    //   1219: aload #16
    //   1221: invokevirtual recycle : ()V
    //   1224: aload #15
    //   1226: invokevirtual recycle : ()V
    //   1229: aload #14
    //   1231: invokevirtual i : ()Z
    //   1234: ifeq -> 1346
    //   1237: aload #14
    //   1239: getfield a : I
    //   1242: iconst_1
    //   1243: if_icmpne -> 1352
    //   1246: aload #14
    //   1248: getfield g : Z
    //   1251: ifne -> 1337
    //   1254: aload #14
    //   1256: getfield j : Landroid/content/Context;
    //   1259: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1262: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   1265: astore #15
    //   1267: fload #4
    //   1269: fstore #6
    //   1271: fload #4
    //   1273: ldc -1.0
    //   1275: fcmpl
    //   1276: ifne -> 1290
    //   1279: iconst_2
    //   1280: ldc_w 12.0
    //   1283: aload #15
    //   1285: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1288: fstore #6
    //   1290: fload #5
    //   1292: fstore #4
    //   1294: fload #5
    //   1296: ldc -1.0
    //   1298: fcmpl
    //   1299: ifne -> 1313
    //   1302: iconst_2
    //   1303: ldc_w 112.0
    //   1306: aload #15
    //   1308: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1311: fstore #4
    //   1313: fload_3
    //   1314: fstore #5
    //   1316: fload_3
    //   1317: ldc -1.0
    //   1319: fcmpl
    //   1320: ifne -> 1326
    //   1323: fconst_1
    //   1324: fstore #5
    //   1326: aload #14
    //   1328: fload #6
    //   1330: fload #4
    //   1332: fload #5
    //   1334: invokevirtual j : (FFF)V
    //   1337: aload #14
    //   1339: invokevirtual g : ()Z
    //   1342: pop
    //   1343: goto -> 1352
    //   1346: aload #14
    //   1348: iconst_0
    //   1349: putfield a : I
    //   1352: getstatic q0/b.d : Z
    //   1355: ifeq -> 1450
    //   1358: aload_0
    //   1359: getfield i : Landroidx/appcompat/widget/f0;
    //   1362: astore #14
    //   1364: aload #14
    //   1366: getfield a : I
    //   1369: ifeq -> 1450
    //   1372: aload #14
    //   1374: getfield f : [I
    //   1377: astore #14
    //   1379: aload #14
    //   1381: arraylength
    //   1382: ifle -> 1450
    //   1385: aload_0
    //   1386: getfield a : Landroid/widget/TextView;
    //   1389: invokevirtual getAutoSizeStepGranularity : ()I
    //   1392: i2f
    //   1393: ldc -1.0
    //   1395: fcmpl
    //   1396: ifeq -> 1440
    //   1399: aload_0
    //   1400: getfield a : Landroid/widget/TextView;
    //   1403: aload_0
    //   1404: getfield i : Landroidx/appcompat/widget/f0;
    //   1407: getfield d : F
    //   1410: invokestatic round : (F)I
    //   1413: aload_0
    //   1414: getfield i : Landroidx/appcompat/widget/f0;
    //   1417: getfield e : F
    //   1420: invokestatic round : (F)I
    //   1423: aload_0
    //   1424: getfield i : Landroidx/appcompat/widget/f0;
    //   1427: getfield c : F
    //   1430: invokestatic round : (F)I
    //   1433: iconst_0
    //   1434: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   1437: goto -> 1450
    //   1440: aload_0
    //   1441: getfield a : Landroid/widget/TextView;
    //   1444: aload #14
    //   1446: iconst_0
    //   1447: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   1450: aload #22
    //   1452: aload_1
    //   1453: getstatic e/i.i : [I
    //   1456: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   1459: astore #18
    //   1461: aload #18
    //   1463: bipush #8
    //   1465: iconst_m1
    //   1466: invokevirtual getResourceId : (II)I
    //   1469: istore_2
    //   1470: iload_2
    //   1471: iconst_m1
    //   1472: if_icmpeq -> 1488
    //   1475: aload #13
    //   1477: aload #22
    //   1479: iload_2
    //   1480: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1483: astore #14
    //   1485: goto -> 1491
    //   1488: aconst_null
    //   1489: astore #14
    //   1491: aload #13
    //   1493: astore #16
    //   1495: aload #18
    //   1497: bipush #13
    //   1499: iconst_m1
    //   1500: invokevirtual getResourceId : (II)I
    //   1503: istore_2
    //   1504: iload_2
    //   1505: iconst_m1
    //   1506: if_icmpeq -> 1522
    //   1509: aload #16
    //   1511: aload #22
    //   1513: iload_2
    //   1514: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1517: astore #13
    //   1519: goto -> 1525
    //   1522: aconst_null
    //   1523: astore #13
    //   1525: aload #18
    //   1527: bipush #9
    //   1529: iconst_m1
    //   1530: invokevirtual getResourceId : (II)I
    //   1533: istore_2
    //   1534: iload_2
    //   1535: iconst_m1
    //   1536: if_icmpeq -> 1552
    //   1539: aload #16
    //   1541: aload #22
    //   1543: iload_2
    //   1544: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1547: astore #15
    //   1549: goto -> 1555
    //   1552: aconst_null
    //   1553: astore #15
    //   1555: aload #18
    //   1557: bipush #6
    //   1559: iconst_m1
    //   1560: invokevirtual getResourceId : (II)I
    //   1563: istore_2
    //   1564: iload_2
    //   1565: iconst_m1
    //   1566: if_icmpeq -> 1581
    //   1569: aload #16
    //   1571: aload #22
    //   1573: iload_2
    //   1574: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1577: astore_1
    //   1578: goto -> 1583
    //   1581: aconst_null
    //   1582: astore_1
    //   1583: aload #18
    //   1585: bipush #10
    //   1587: iconst_m1
    //   1588: invokevirtual getResourceId : (II)I
    //   1591: istore_2
    //   1592: iload_2
    //   1593: iconst_m1
    //   1594: if_icmpeq -> 1610
    //   1597: aload #16
    //   1599: aload #22
    //   1601: iload_2
    //   1602: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1605: astore #17
    //   1607: goto -> 1613
    //   1610: aconst_null
    //   1611: astore #17
    //   1613: aload #18
    //   1615: bipush #7
    //   1617: iconst_m1
    //   1618: invokevirtual getResourceId : (II)I
    //   1621: istore_2
    //   1622: iload_2
    //   1623: iconst_m1
    //   1624: if_icmpeq -> 1640
    //   1627: aload #16
    //   1629: aload #22
    //   1631: iload_2
    //   1632: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1635: astore #16
    //   1637: goto -> 1643
    //   1640: aconst_null
    //   1641: astore #16
    //   1643: aload #17
    //   1645: ifnonnull -> 1844
    //   1648: aload #16
    //   1650: ifnull -> 1656
    //   1653: goto -> 1844
    //   1656: aload #14
    //   1658: ifnonnull -> 1675
    //   1661: aload #13
    //   1663: ifnonnull -> 1675
    //   1666: aload #15
    //   1668: ifnonnull -> 1675
    //   1671: aload_1
    //   1672: ifnull -> 1925
    //   1675: aload_0
    //   1676: getfield a : Landroid/widget/TextView;
    //   1679: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1682: astore #16
    //   1684: aload #16
    //   1686: iconst_0
    //   1687: aaload
    //   1688: ifnonnull -> 1785
    //   1691: aload #16
    //   1693: iconst_2
    //   1694: aaload
    //   1695: ifnull -> 1701
    //   1698: goto -> 1785
    //   1701: aload_0
    //   1702: getfield a : Landroid/widget/TextView;
    //   1705: invokevirtual getCompoundDrawables : ()[Landroid/graphics/drawable/Drawable;
    //   1708: astore #17
    //   1710: aload_0
    //   1711: getfield a : Landroid/widget/TextView;
    //   1714: astore #16
    //   1716: aload #14
    //   1718: ifnull -> 1724
    //   1721: goto -> 1730
    //   1724: aload #17
    //   1726: iconst_0
    //   1727: aaload
    //   1728: astore #14
    //   1730: aload #13
    //   1732: ifnull -> 1738
    //   1735: goto -> 1744
    //   1738: aload #17
    //   1740: iconst_1
    //   1741: aaload
    //   1742: astore #13
    //   1744: aload #15
    //   1746: ifnull -> 1752
    //   1749: goto -> 1758
    //   1752: aload #17
    //   1754: iconst_2
    //   1755: aaload
    //   1756: astore #15
    //   1758: aload_1
    //   1759: ifnull -> 1765
    //   1762: goto -> 1770
    //   1765: aload #17
    //   1767: iconst_3
    //   1768: aaload
    //   1769: astore_1
    //   1770: aload #16
    //   1772: aload #14
    //   1774: aload #13
    //   1776: aload #15
    //   1778: aload_1
    //   1779: invokevirtual setCompoundDrawablesWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1782: goto -> 1925
    //   1785: aload_0
    //   1786: getfield a : Landroid/widget/TextView;
    //   1789: astore #14
    //   1791: aload #16
    //   1793: iconst_0
    //   1794: aaload
    //   1795: astore #15
    //   1797: aload #13
    //   1799: ifnull -> 1805
    //   1802: goto -> 1811
    //   1805: aload #16
    //   1807: iconst_1
    //   1808: aaload
    //   1809: astore #13
    //   1811: aload #16
    //   1813: iconst_2
    //   1814: aaload
    //   1815: astore #17
    //   1817: aload_1
    //   1818: ifnull -> 1824
    //   1821: goto -> 1829
    //   1824: aload #16
    //   1826: iconst_3
    //   1827: aaload
    //   1828: astore_1
    //   1829: aload #14
    //   1831: aload #15
    //   1833: aload #13
    //   1835: aload #17
    //   1837: aload_1
    //   1838: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1841: goto -> 1925
    //   1844: aload_0
    //   1845: getfield a : Landroid/widget/TextView;
    //   1848: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1851: astore #15
    //   1853: aload_0
    //   1854: getfield a : Landroid/widget/TextView;
    //   1857: astore #14
    //   1859: aload #17
    //   1861: ifnull -> 1867
    //   1864: goto -> 1873
    //   1867: aload #15
    //   1869: iconst_0
    //   1870: aaload
    //   1871: astore #17
    //   1873: aload #13
    //   1875: ifnull -> 1881
    //   1878: goto -> 1887
    //   1881: aload #15
    //   1883: iconst_1
    //   1884: aaload
    //   1885: astore #13
    //   1887: aload #16
    //   1889: ifnull -> 1895
    //   1892: goto -> 1901
    //   1895: aload #15
    //   1897: iconst_2
    //   1898: aaload
    //   1899: astore #16
    //   1901: aload_1
    //   1902: ifnull -> 1908
    //   1905: goto -> 1913
    //   1908: aload #15
    //   1910: iconst_3
    //   1911: aaload
    //   1912: astore_1
    //   1913: aload #14
    //   1915: aload #17
    //   1917: aload #13
    //   1919: aload #16
    //   1921: aload_1
    //   1922: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1925: aload #18
    //   1927: bipush #11
    //   1929: invokevirtual hasValue : (I)Z
    //   1932: ifeq -> 2028
    //   1935: aload #18
    //   1937: bipush #11
    //   1939: invokevirtual hasValue : (I)Z
    //   1942: ifeq -> 1972
    //   1945: aload #18
    //   1947: bipush #11
    //   1949: iconst_0
    //   1950: invokevirtual getResourceId : (II)I
    //   1953: istore_2
    //   1954: iload_2
    //   1955: ifeq -> 1972
    //   1958: aload #22
    //   1960: iload_2
    //   1961: invokestatic a : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   1964: astore_1
    //   1965: aload_1
    //   1966: ifnull -> 1972
    //   1969: goto -> 1980
    //   1972: aload #18
    //   1974: bipush #11
    //   1976: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1979: astore_1
    //   1980: aload_0
    //   1981: getfield a : Landroid/widget/TextView;
    //   1984: astore #13
    //   1986: aload #13
    //   1988: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1991: pop
    //   1992: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1995: bipush #24
    //   1997: if_icmplt -> 2009
    //   2000: aload #13
    //   2002: aload_1
    //   2003: invokevirtual setCompoundDrawableTintList : (Landroid/content/res/ColorStateList;)V
    //   2006: goto -> 2028
    //   2009: aload #13
    //   2011: instanceof q0/k
    //   2014: ifeq -> 2028
    //   2017: aload #13
    //   2019: checkcast q0/k
    //   2022: aload_1
    //   2023: invokeinterface setSupportCompoundDrawablesTintList : (Landroid/content/res/ColorStateList;)V
    //   2028: aload #18
    //   2030: bipush #12
    //   2032: invokevirtual hasValue : (I)Z
    //   2035: ifeq -> 2099
    //   2038: aload #18
    //   2040: bipush #12
    //   2042: iconst_m1
    //   2043: invokevirtual getInt : (II)I
    //   2046: aconst_null
    //   2047: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   2050: astore_1
    //   2051: aload_0
    //   2052: getfield a : Landroid/widget/TextView;
    //   2055: astore #13
    //   2057: aload #13
    //   2059: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2062: pop
    //   2063: getstatic android/os/Build$VERSION.SDK_INT : I
    //   2066: bipush #24
    //   2068: if_icmplt -> 2080
    //   2071: aload #13
    //   2073: aload_1
    //   2074: invokevirtual setCompoundDrawableTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   2077: goto -> 2099
    //   2080: aload #13
    //   2082: instanceof q0/k
    //   2085: ifeq -> 2099
    //   2088: aload #13
    //   2090: checkcast q0/k
    //   2093: aload_1
    //   2094: invokeinterface setSupportCompoundDrawablesTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   2099: aload #18
    //   2101: bipush #15
    //   2103: iconst_m1
    //   2104: invokevirtual getDimensionPixelSize : (II)I
    //   2107: istore_2
    //   2108: aload #18
    //   2110: bipush #18
    //   2112: iconst_m1
    //   2113: invokevirtual getDimensionPixelSize : (II)I
    //   2116: istore #7
    //   2118: aload #18
    //   2120: bipush #19
    //   2122: iconst_m1
    //   2123: invokevirtual getDimensionPixelSize : (II)I
    //   2126: istore #8
    //   2128: aload #18
    //   2130: invokevirtual recycle : ()V
    //   2133: iload_2
    //   2134: iconst_m1
    //   2135: if_icmpeq -> 2146
    //   2138: aload_0
    //   2139: getfield a : Landroid/widget/TextView;
    //   2142: iload_2
    //   2143: invokestatic b : (Landroid/widget/TextView;I)V
    //   2146: iload #7
    //   2148: iconst_m1
    //   2149: if_icmpeq -> 2161
    //   2152: aload_0
    //   2153: getfield a : Landroid/widget/TextView;
    //   2156: iload #7
    //   2158: invokestatic c : (Landroid/widget/TextView;I)V
    //   2161: iload #8
    //   2163: iconst_m1
    //   2164: if_icmpeq -> 2176
    //   2167: aload_0
    //   2168: getfield a : Landroid/widget/TextView;
    //   2171: iload #8
    //   2173: invokestatic d : (Landroid/widget/TextView;I)V
    //   2176: return
  }
  
  public void f(Context paramContext, int paramInt) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramInt, i.w);
    d1 d1 = new d1(paramContext, typedArray);
    if (d1.o(14)) {
      boolean bool = d1.a(14, false);
      this.a.setAllCaps(bool);
    } 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      if (d1.o(3)) {
        ColorStateList colorStateList = d1.c(3);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
      if (d1.o(5)) {
        ColorStateList colorStateList = d1.c(5);
        if (colorStateList != null)
          this.a.setLinkTextColor(colorStateList); 
      } 
      if (d1.o(4)) {
        ColorStateList colorStateList = d1.c(4);
        if (colorStateList != null)
          this.a.setHintTextColor(colorStateList); 
      } 
    } 
    if (d1.o(0) && d1.f(0, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    m(paramContext, d1);
    if (paramInt >= 26 && d1.o(13)) {
      String str = d1.m(13);
      if (str != null)
        this.a.setFontVariationSettings(str); 
    } 
    typedArray.recycle();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  public void g(TextView paramTextView, InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    int i = Build.VERSION.SDK_INT;
    if (i < 30 && paramInputConnection != null) {
      CharSequence charSequence = paramTextView.getText();
      if (i >= 30) {
        paramEditorInfo.setInitialSurroundingSubText(charSequence, 0);
        return;
      } 
      Objects.requireNonNull(charSequence);
      if (i >= 30) {
        paramEditorInfo.setInitialSurroundingSubText(charSequence, 0);
        return;
      } 
      i = paramEditorInfo.initialSelStart;
      int k = paramEditorInfo.initialSelEnd;
      if (i > k) {
        j = k + 0;
      } else {
        j = i + 0;
      } 
      if (i > k) {
        i -= 0;
      } else {
        i = k + 0;
      } 
      int m = charSequence.length();
      if (j < 0 || i > m) {
        p0.a.b(paramEditorInfo, null, 0, 0);
        return;
      } 
      k = paramEditorInfo.inputType & 0xFFF;
      if (k == 129 || k == 225 || k == 18) {
        k = 1;
      } else {
        k = 0;
      } 
      if (k != 0) {
        p0.a.b(paramEditorInfo, null, 0, 0);
        return;
      } 
      if (m <= 2048) {
        p0.a.b(paramEditorInfo, charSequence, j, i);
        return;
      } 
      int i1 = i - j;
      if (i1 > 1024) {
        k = 0;
      } else {
        k = i1;
      } 
      int n = charSequence.length();
      m = 2048 - k;
      double d = m;
      Double.isNaN(d);
      Double.isNaN(d);
      Double.isNaN(d);
      Double.isNaN(d);
      Double.isNaN(d);
      int i2 = Math.min(n - i, m - Math.min(j, (int)(d * 0.8D)));
      n = Math.min(j, m - i2);
      int i3 = j - n;
      m = i3;
      int j = n;
      if (p0.a.a(charSequence, i3, 0)) {
        m = i3 + 1;
        j = n - 1;
      } 
      n = i2;
      if (p0.a.a(charSequence, i + i2 - 1, 1))
        n = i2 - 1; 
      if (k != i1) {
        charSequence = TextUtils.concat(new CharSequence[] { charSequence.subSequence(m, m + j), charSequence.subSequence(i, n + i) });
      } else {
        charSequence = charSequence.subSequence(m, j + k + n + m);
      } 
      i = j + 0;
      p0.a.b(paramEditorInfo, charSequence, i, k + i);
      return;
    } 
  }
  
  public void h(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    f0 f01 = this.i;
    if (f01.i()) {
      DisplayMetrics displayMetrics = f01.j.getResources().getDisplayMetrics();
      f01.j(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (f01.g())
        f01.a(); 
    } 
  }
  
  public void i(int[] paramArrayOfint, int paramInt) {
    f0 f01 = this.i;
    if (f01.i()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = f01.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        f01.f = f01.b(arrayOfInt1);
        if (!f01.h()) {
          StringBuilder stringBuilder = android.support.v4.media.a.a("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        f01.g = false;
      } 
      if (f01.g())
        f01.a(); 
    } 
  }
  
  public void j(int paramInt) {
    f0 f01 = this.i;
    if (f01.i())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = f01.j.getResources().getDisplayMetrics();
          f01.j(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (f01.g()) {
            f01.a();
            return;
          } 
        } else {
          throw new IllegalArgumentException(b0.a("Unknown auto-size text type: ", paramInt));
        } 
      } else {
        f01.a = 0;
        f01.d = -1.0F;
        f01.e = -1.0F;
        f01.c = -1.0F;
        f01.f = new int[0];
        f01.b = false;
      }  
  }
  
  public void k(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new b1(); 
    b1 b11 = this.h;
    b11.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    b11.d = bool;
    this.b = b11;
    this.c = b11;
    this.d = b11;
    this.e = b11;
    this.f = b11;
    this.g = b11;
  }
  
  public void l(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new b1(); 
    b1 b11 = this.h;
    b11.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    b11.c = bool;
    this.b = b11;
    this.c = b11;
    this.d = b11;
    this.e = b11;
    this.f = b11;
    this.g = b11;
  }
  
  public final void m(Context paramContext, d1 paramd1) {
    this.j = paramd1.j(2, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramd1.j(11, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = 10;
    if (paramd1.o(10) || paramd1.o(12)) {
      this.l = null;
      if (paramd1.o(12))
        i = 12; 
      int k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramd1.i(i, this.j, a);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              j = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = Typeface.create(typeface, j, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramd1.m(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = Typeface.create(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    if (paramd1.o(1)) {
      this.m = false;
      i = paramd1.j(1, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  public class a extends h.c {
    public a(c0 this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void d(int param1Int) {}
    
    public void e(Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = Typeface.create(param1Typeface, i, bool);
        } 
      } 
      c0 c01 = this.d;
      WeakReference<TextView> weakReference = this.c;
      if (c01.m) {
        c01.l = typeface;
        TextView textView = weakReference.get();
        if (textView != null) {
          WeakHashMap weakHashMap = y.a;
          if (y.g.b((View)textView)) {
            textView.post(new d0(c01, textView, typeface, c01.j));
            return;
          } 
          textView.setTypeface(typeface, c01.j);
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */