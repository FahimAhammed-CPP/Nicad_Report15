package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import m0.c;
import m0.y;

public final class v {
  public static boolean a(DragEvent paramDragEvent, TextView paramTextView, Activity paramActivity) {
    paramActivity.requestDragAndDropPermissions(paramDragEvent);
    int i = paramTextView.getOffsetForPosition(paramDragEvent.getX(), paramDragEvent.getY());
    paramTextView.beginBatchEdit();
    try {
      c.a a;
      c.c c;
      Selection.setSelection((Spannable)paramTextView.getText(), i);
      ClipData clipData = paramDragEvent.getClipData();
      if (Build.VERSION.SDK_INT >= 31) {
        a = new c.a(clipData, 3);
      } else {
        c = new c.c((ClipData)a, 3);
      } 
      y.u((View)paramTextView, c.build());
      return true;
    } finally {
      paramTextView.endBatchEdit();
    } 
  }
  
  public static boolean b(DragEvent paramDragEvent, View paramView, Activity paramActivity) {
    c.a a;
    c.c c;
    paramActivity.requestDragAndDropPermissions(paramDragEvent);
    ClipData clipData = paramDragEvent.getClipData();
    if (Build.VERSION.SDK_INT >= 31) {
      a = new c.a(clipData, 3);
    } else {
      c = new c.c((ClipData)a, 3);
    } 
    y.u(paramView, c.build());
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */