package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import m0.t;
import q0.b;
import q0.g;
import q0.k;

public class AppCompatButton extends Button implements t, b, k {
  private n mAppCompatEmojiTextHelper;
  
  private final f mBackgroundTintHelper;
  
  private final c0 mTextHelper;
  
  public AppCompatButton(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903164);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(a1.a(paramContext), paramAttributeSet, paramInt);
    y0.a((View)this, getContext());
    f f1 = new f((View)this);
    this.mBackgroundTintHelper = f1;
    f1.d(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.mTextHelper = c01;
    c01.e(paramAttributeSet, paramInt);
    c01.b();
    getEmojiTextViewHelper().a(paramAttributeSet, paramInt);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.mAppCompatEmojiTextHelper == null)
      this.mAppCompatEmojiTextHelper = new n((TextView)this); 
    return this.mAppCompatEmojiTextHelper;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.d)
      return super.getAutoSizeMaxTextSize(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? Math.round(c01.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.d)
      return super.getAutoSizeMinTextSize(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? Math.round(c01.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.d)
      return super.getAutoSizeStepGranularity(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? Math.round(c01.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.d)
      return super.getAutoSizeTextAvailableSizes(); 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.i.f : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.d;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    c0 c01 = this.mTextHelper;
    return (c01 != null) ? c01.i.a : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return g.g(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    b1 b1 = this.mTextHelper.h;
    return (b1 != null) ? b1.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    b1 b1 = this.mTextHelper.h;
    return (b1 != null) ? b1.b : null;
  }
  
  public boolean isEmojiCompatEnabled() {
    return (getEmojiTextViewHelper()).b.a.b();
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    c0 c01 = this.mTextHelper;
    if (c01 != null && !b.d)
      c01.i.a(); 
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    c0 c01 = this.mTextHelper;
    if (c01 != null && !b.d && c01.d())
      this.mTextHelper.i.a(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.d) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.h(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.d) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.i(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.d) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.j(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(g.h((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters((getEmojiTextViewHelper()).b.a.a(paramArrayOfInputFilter));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.a.setAllCaps(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.mTextHelper.k(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.mTextHelper.l(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.f(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = b.d;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    c0 c01 = this.mTextHelper;
    if (c01 != null && !bool && !c01.d())
      c01.i.f(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */