package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.d;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class r0 extends p0 implements q0 {
  public static Method I;
  
  public q0 H;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        I = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public r0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, null, paramInt1, paramInt2);
  }
  
  public void b(e parame, MenuItem paramMenuItem) {
    q0 q01 = this.H;
    if (q01 != null)
      q01.b(parame, paramMenuItem); 
  }
  
  public void d(e parame, MenuItem paramMenuItem) {
    q0 q01 = this.H;
    if (q01 != null)
      q01.d(parame, paramMenuItem); 
  }
  
  public k0 p(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends k0 {
    public final int s;
    
    public final int t;
    
    public q0 u;
    
    public MenuItem v;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == param1Context.getResources().getConfiguration().getLayoutDirection()) {
        this.s = 21;
        this.t = 22;
        return;
      } 
      this.s = 22;
      this.t = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.u != null) {
        int i;
        d d;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          d = (d)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          d = d;
        } 
        g g2 = null;
        g g1 = g2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          g1 = g2;
          if (j != -1) {
            i = j - i;
            g1 = g2;
            if (i >= 0) {
              g1 = g2;
              if (i < d.getCount())
                g1 = d.b(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.v;
        if (menuItem != g1) {
          e e = d.f;
          if (menuItem != null)
            this.u.d(e, menuItem); 
          this.v = (MenuItem)g1;
          if (g1 != null)
            this.u.b(e, (MenuItem)g1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      d d;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.s) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.t) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          d = (d)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          d = d;
        } 
        d.f.c(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)d);
    }
    
    public void setHoverListener(q0 param1q0) {
      this.u = param1q0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */