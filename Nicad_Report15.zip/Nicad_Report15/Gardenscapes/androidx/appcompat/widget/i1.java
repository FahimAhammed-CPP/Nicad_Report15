package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import m0.a0;
import m0.y;

public class i1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  public static i1 o;
  
  public static i1 p;
  
  public final View f;
  
  public final CharSequence g;
  
  public final int h;
  
  public final Runnable i;
  
  public final Runnable j;
  
  public int k;
  
  public int l;
  
  public j1 m;
  
  public boolean n;
  
  public i1(View paramView, CharSequence paramCharSequence) {
    int i;
    this.i = new a(this);
    this.j = new b(this);
    this.f = paramView;
    this.g = paramCharSequence;
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramView.getContext());
    Method method = a0.a;
    if (Build.VERSION.SDK_INT >= 28) {
      i = viewConfiguration.getScaledHoverSlop();
    } else {
      i = viewConfiguration.getScaledTouchSlop() / 2;
    } 
    this.h = i;
    a();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  public static void c(i1 parami1) {
    i1 i11 = o;
    if (i11 != null)
      i11.f.removeCallbacks(i11.i); 
    o = parami1;
    if (parami1 != null)
      parami1.f.postDelayed(parami1.i, ViewConfiguration.getLongPressTimeout()); 
  }
  
  public final void a() {
    this.k = Integer.MAX_VALUE;
    this.l = Integer.MAX_VALUE;
  }
  
  public void b() {
    if (p == this) {
      p = null;
      j1 j11 = this.m;
      if (j11 != null) {
        j11.a();
        this.m = null;
        a();
        this.f.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (o == this)
      c(null); 
    this.f.removeCallbacks(this.j);
  }
  
  public void d(boolean paramBoolean) {
    int i;
    long l;
    View view1;
    View view2 = this.f;
    WeakHashMap weakHashMap = y.a;
    if (!y.g.b(view2))
      return; 
    c(null);
    i1 i11 = p;
    if (i11 != null)
      i11.b(); 
    p = this;
    this.n = paramBoolean;
    j1 j11 = new j1(this.f.getContext());
    this.m = j11;
    View view4 = this.f;
    int j = this.k;
    int k = this.l;
    paramBoolean = this.n;
    CharSequence charSequence = this.g;
    if (j11.b.getParent() != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i)
      j11.a(); 
    j11.c.setText(charSequence);
    WindowManager.LayoutParams layoutParams1 = j11.d;
    layoutParams1.token = view4.getApplicationWindowToken();
    int m = j11.a.getResources().getDimensionPixelOffset(2131100256);
    if (view4.getWidth() >= m) {
      i = j;
    } else {
      i = view4.getWidth() / 2;
    } 
    if (view4.getHeight() >= m) {
      m = j11.a.getResources().getDimensionPixelOffset(2131100255);
      j = k + m;
      k -= m;
    } else {
      j = view4.getHeight();
      k = 0;
    } 
    layoutParams1.gravity = 49;
    Resources resources = j11.a.getResources();
    if (paramBoolean) {
      m = 2131100259;
    } else {
      m = 2131100258;
    } 
    int n = resources.getDimensionPixelOffset(m);
    View view3 = view4.getRootView();
    ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
    if (layoutParams instanceof WindowManager.LayoutParams && ((WindowManager.LayoutParams)layoutParams).type == 2) {
      view1 = view3;
    } else {
      Context context = view4.getContext();
      while (true) {
        view1 = view3;
        if (context instanceof ContextWrapper) {
          if (context instanceof Activity) {
            view1 = ((Activity)context).getWindow().getDecorView();
            break;
          } 
          context = ((ContextWrapper)context).getBaseContext();
          continue;
        } 
        break;
      } 
    } 
    if (view1 == null) {
      Log.e("TooltipPopup", "Cannot find app view");
    } else {
      view1.getWindowVisibleDisplayFrame(j11.e);
      Rect rect = j11.e;
      if (rect.left < 0 && rect.top < 0) {
        Resources resources1 = j11.a.getResources();
        m = resources1.getIdentifier("status_bar_height", "dimen", "android");
        if (m != 0) {
          m = resources1.getDimensionPixelSize(m);
        } else {
          m = 0;
        } 
        DisplayMetrics displayMetrics = resources1.getDisplayMetrics();
        j11.e.set(0, m, displayMetrics.widthPixels, displayMetrics.heightPixels);
      } 
      view1.getLocationOnScreen(j11.g);
      view4.getLocationOnScreen(j11.f);
      int[] arrayOfInt2 = j11.f;
      m = arrayOfInt2[0];
      int[] arrayOfInt3 = j11.g;
      arrayOfInt2[0] = m - arrayOfInt3[0];
      arrayOfInt2[1] = arrayOfInt2[1] - arrayOfInt3[1];
      layoutParams1.x = arrayOfInt2[0] + i - view1.getWidth() / 2;
      i = View.MeasureSpec.makeMeasureSpec(0, 0);
      j11.b.measure(i, i);
      i = j11.b.getMeasuredHeight();
      int[] arrayOfInt1 = j11.f;
      k = arrayOfInt1[1] + k - n - i;
      j = arrayOfInt1[1] + j + n;
      if (paramBoolean) {
        if (k >= 0) {
          layoutParams1.y = k;
        } else {
          layoutParams1.y = j;
        } 
      } else if (i + j <= j11.e.height()) {
        layoutParams1.y = j;
      } else {
        layoutParams1.y = k;
      } 
    } 
    ((WindowManager)j11.a.getSystemService("window")).addView(j11.b, (ViewGroup.LayoutParams)j11.d);
    this.f.addOnAttachStateChangeListener(this);
    if (this.n) {
      l = 2500L;
    } else {
      if ((y.d.g(this.f) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.f.removeCallbacks(this.j);
    this.f.postDelayed(this.j, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.m != null && this.n)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.f.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      a();
      b();
      return false;
    } 
    if (this.f.isEnabled() && this.m == null) {
      i = (int)paramMotionEvent.getX();
      int j = (int)paramMotionEvent.getY();
      if (Math.abs(i - this.k) <= this.h && Math.abs(j - this.l) <= this.h) {
        i = 0;
      } else {
        this.k = i;
        this.l = j;
        i = 1;
      } 
      if (i != 0)
        c(this); 
    } 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.k = paramView.getWidth() / 2;
    this.l = paramView.getHeight() / 2;
    d(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
  
  public class a implements Runnable {
    public a(i1 this$0) {}
    
    public void run() {
      this.f.d(false);
    }
  }
  
  public class b implements Runnable {
    public b(i1 this$0) {}
    
    public void run() {
      this.f.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */