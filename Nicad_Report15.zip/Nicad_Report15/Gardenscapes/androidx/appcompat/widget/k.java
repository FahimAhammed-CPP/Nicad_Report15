package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.Log;

public final class k {
  public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  public static k c;
  
  public s0 a;
  
  public static k a() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   6: ifnonnull -> 12
    //   9: invokestatic e : ()V
    //   12: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   15: astore_0
    //   16: ldc androidx/appcompat/widget/k
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc androidx/appcompat/widget/k
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter c(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic h : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc androidx/appcompat/widget/k
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc androidx/appcompat/widget/k
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void e() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   6: ifnonnull -> 60
    //   9: new androidx/appcompat/widget/k
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   21: aload_0
    //   22: invokestatic d : ()Landroidx/appcompat/widget/s0;
    //   25: putfield a : Landroidx/appcompat/widget/s0;
    //   28: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   31: getfield a : Landroidx/appcompat/widget/s0;
    //   34: astore_0
    //   35: new androidx/appcompat/widget/k$a
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: astore_1
    //   43: aload_0
    //   44: monitorenter
    //   45: aload_0
    //   46: aload_1
    //   47: putfield g : Landroidx/appcompat/widget/s0$f;
    //   50: aload_0
    //   51: monitorexit
    //   52: goto -> 60
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    //   60: ldc androidx/appcompat/widget/k
    //   62: monitorexit
    //   63: return
    //   64: astore_0
    //   65: ldc androidx/appcompat/widget/k
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	45	64	finally
    //   45	50	55	finally
    //   50	52	64	finally
    //   56	60	64	finally
  }
  
  public static void f(Drawable paramDrawable, b1 paramb1, int[] paramArrayOfint) {
    PorterDuff.Mode mode = s0.h;
    if (j0.a(paramDrawable) && paramDrawable.mutate() != paramDrawable) {
      Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
      return;
    } 
    boolean bool = paramb1.d;
    if (bool || paramb1.c) {
      PorterDuff.Mode mode1;
      PorterDuffColorFilter porterDuffColorFilter2 = null;
      if (bool) {
        ColorStateList colorStateList = paramb1.a;
      } else {
        mode = null;
      } 
      if (paramb1.c) {
        mode1 = paramb1.b;
      } else {
        mode1 = s0.h;
      } 
      PorterDuffColorFilter porterDuffColorFilter1 = porterDuffColorFilter2;
      if (mode != null)
        if (mode1 == null) {
          porterDuffColorFilter1 = porterDuffColorFilter2;
        } else {
          porterDuffColorFilter1 = s0.h(mode.getColorForState(paramArrayOfint, 0), mode1);
        }  
      paramDrawable.setColorFilter((ColorFilter)porterDuffColorFilter1);
    } else {
      paramDrawable.clearColorFilter();
    } 
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf(); 
  }
  
  public Drawable b(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public ColorStateList d(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual i : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public class a implements s0.f {
    public final int[] a = new int[] { 2131165266, 2131165264, 2131165190 };
    
    public final int[] b = new int[] { 2131165214, 2131165249, 2131165221, 2131165216, 2131165217, 2131165220, 2131165219 };
    
    public final int[] c = new int[] { 2131165263, 2131165265, 2131165207, 2131165259, 2131165260, 2131165261, 2131165262 };
    
    public final int[] d = new int[] { 2131165239, 2131165205, 2131165238 };
    
    public final int[] e = new int[] { 2131165257, 2131165267 };
    
    public final int[] f = new int[] { 2131165193, 2131165199, 2131165194, 2131165200 };
    
    public final boolean a(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    public final ColorStateList b(Context param1Context, int param1Int) {
      int k = y0.c(param1Context, 2130903243);
      int i = y0.b(param1Context, 2130903240);
      int[] arrayOfInt1 = y0.b;
      int[] arrayOfInt2 = y0.d;
      int j = e0.a.b(k, param1Int);
      int[] arrayOfInt3 = y0.c;
      k = e0.a.b(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, y0.f }, new int[] { i, j, k, param1Int });
    }
    
    public final LayerDrawable c(s0 param1s0, Context param1Context, int param1Int) {
      BitmapDrawable bitmapDrawable1;
      BitmapDrawable bitmapDrawable2;
      BitmapDrawable bitmapDrawable3;
      param1Int = param1Context.getResources().getDimensionPixelSize(param1Int);
      Drawable drawable2 = param1s0.f(param1Context, 2131165253);
      Drawable drawable1 = param1s0.f(param1Context, 2131165254);
      if (drawable2 instanceof BitmapDrawable && drawable2.getIntrinsicWidth() == param1Int && drawable2.getIntrinsicHeight() == param1Int) {
        bitmapDrawable1 = (BitmapDrawable)drawable2;
        bitmapDrawable2 = new BitmapDrawable(bitmapDrawable1.getBitmap());
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, param1Int, param1Int);
        drawable2.draw(canvas);
        bitmapDrawable1 = new BitmapDrawable(bitmap);
        bitmapDrawable2 = new BitmapDrawable(bitmap);
      } 
      bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
      if (drawable1 instanceof BitmapDrawable && drawable1.getIntrinsicWidth() == param1Int && drawable1.getIntrinsicHeight() == param1Int) {
        bitmapDrawable3 = (BitmapDrawable)drawable1;
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        bitmapDrawable3.setBounds(0, 0, param1Int, param1Int);
        bitmapDrawable3.draw(canvas);
        bitmapDrawable3 = new BitmapDrawable(bitmap);
      } 
      LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)bitmapDrawable1, (Drawable)bitmapDrawable3, (Drawable)bitmapDrawable2 });
      layerDrawable.setId(0, 16908288);
      layerDrawable.setId(1, 16908303);
      layerDrawable.setId(2, 16908301);
      return layerDrawable;
    }
    
    public ColorStateList d(Context param1Context, int param1Int) {
      if (param1Int == 2131165210)
        return g.a.a(param1Context, 2131034133); 
      if (param1Int == 2131165256)
        return g.a.a(param1Context, 2131034136); 
      if (param1Int == 2131165255) {
        int[][] arrayOfInt = new int[3][];
        int[] arrayOfInt1 = new int[3];
        ColorStateList colorStateList = y0.d(param1Context, 2130903275);
        if (colorStateList != null && colorStateList.isStateful()) {
          arrayOfInt[0] = y0.b;
          arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
          arrayOfInt[1] = y0.e;
          arrayOfInt1[1] = y0.c(param1Context, 2130903242);
          arrayOfInt[2] = y0.f;
          arrayOfInt1[2] = colorStateList.getDefaultColor();
        } else {
          arrayOfInt[0] = y0.b;
          arrayOfInt1[0] = y0.b(param1Context, 2130903275);
          arrayOfInt[1] = y0.e;
          arrayOfInt1[1] = y0.c(param1Context, 2130903242);
          arrayOfInt[2] = y0.f;
          arrayOfInt1[2] = y0.c(param1Context, 2130903275);
        } 
        return new ColorStateList(arrayOfInt, arrayOfInt1);
      } 
      return (param1Int == 2131165198) ? b(param1Context, y0.c(param1Context, 2130903240)) : ((param1Int == 2131165192) ? b(param1Context, 0) : ((param1Int == 2131165197) ? b(param1Context, y0.c(param1Context, 2130903238)) : ((param1Int == 2131165251 || param1Int == 2131165252) ? g.a.a(param1Context, 2131034135) : (a(this.b, param1Int) ? y0.d(param1Context, 2130903244) : (a(this.e, param1Int) ? g.a.a(param1Context, 2131034132) : (a(this.f, param1Int) ? g.a.a(param1Context, 2131034131) : ((param1Int == 2131165248) ? g.a.a(param1Context, 2131034134) : null)))))));
    }
    
    public final void e(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (j0.a(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = k.b; 
      drawable.setColorFilter((ColorFilter)k.c(param1Int, mode));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */