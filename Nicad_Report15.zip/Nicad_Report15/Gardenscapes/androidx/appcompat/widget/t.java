package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import g.a;
import m0.t;
import q0.j;

public class t extends RadioButton implements j, t {
  public final j f;
  
  public final f g;
  
  public final c0 h;
  
  public n i;
  
  public t(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(a1.a(paramContext), paramAttributeSet, paramInt);
    y0.a((View)this, getContext());
    j j1 = new j((CompoundButton)this);
    this.f = j1;
    j1.b(paramAttributeSet, paramInt);
    f f1 = new f((View)this);
    this.g = f1;
    f1.d(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.h = c01;
    c01.e(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().a(paramAttributeSet, paramInt);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.i == null)
      this.i = new n((TextView)this); 
    return this.i;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.g;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.h;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    return super.getCompoundPaddingLeft();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.g;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.g;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    j j1 = this.f;
    return (j1 != null) ? j1.b : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    j j1 = this.f;
    return (j1 != null) ? j1.c : null;
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.g;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.g;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.b(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    j j1 = this.f;
    if (j1 != null) {
      if (j1.f) {
        j1.f = false;
        return;
      } 
      j1.f = true;
      j1.a();
    } 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters((getEmojiTextViewHelper()).b.a.a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.g;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.g;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    j j1 = this.f;
    if (j1 != null) {
      j1.b = paramColorStateList;
      j1.d = true;
      j1.a();
    } 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    j j1 = this.f;
    if (j1 != null) {
      j1.c = paramMode;
      j1.e = true;
      j1.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */