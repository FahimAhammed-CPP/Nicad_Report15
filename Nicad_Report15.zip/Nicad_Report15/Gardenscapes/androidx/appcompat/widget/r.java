package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

public class r extends PopupWindow {
  public static final boolean b;
  
  public boolean a;
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT < 21) {
      bool = true;
    } else {
      bool = false;
    } 
    b = bool;
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: iload #4
    //   6: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;II)V
    //   9: aload_1
    //   10: aload_2
    //   11: getstatic e/i.s : [I
    //   14: iload_3
    //   15: iload #4
    //   17: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   20: astore_2
    //   21: aload_2
    //   22: iconst_2
    //   23: invokevirtual hasValue : (I)Z
    //   26: ifeq -> 58
    //   29: aload_2
    //   30: iconst_2
    //   31: iconst_0
    //   32: invokevirtual getBoolean : (IZ)Z
    //   35: istore #5
    //   37: getstatic androidx/appcompat/widget/r.b : Z
    //   40: ifeq -> 52
    //   43: aload_0
    //   44: iload #5
    //   46: putfield a : Z
    //   49: goto -> 58
    //   52: aload_0
    //   53: iload #5
    //   55: invokestatic a : (Landroid/widget/PopupWindow;Z)V
    //   58: aload_2
    //   59: iconst_0
    //   60: invokevirtual hasValue : (I)Z
    //   63: ifeq -> 86
    //   66: aload_2
    //   67: iconst_0
    //   68: iconst_0
    //   69: invokevirtual getResourceId : (II)I
    //   72: istore_3
    //   73: iload_3
    //   74: ifeq -> 86
    //   77: aload_1
    //   78: iload_3
    //   79: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   82: astore_1
    //   83: goto -> 92
    //   86: aload_2
    //   87: iconst_0
    //   88: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   91: astore_1
    //   92: aload_0
    //   93: aload_1
    //   94: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   97: aload_2
    //   98: invokevirtual recycle : ()V
    //   101: return
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i, paramInt3);
  }
  
  public void update(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.update(paramView, paramInt1, i, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */