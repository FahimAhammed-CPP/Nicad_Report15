package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import java.util.WeakHashMap;
import m0.y;

public class n0 extends ViewGroup {
  public boolean f;
  
  public int g;
  
  public int h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public float l;
  
  public boolean m;
  
  public int[] n;
  
  public int[] o;
  
  public Drawable p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public int t;
  
  public n0(Context paramContext) {
    this(paramContext, null);
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield f : Z
    //   12: aload_0
    //   13: iconst_m1
    //   14: putfield g : I
    //   17: aload_0
    //   18: iconst_0
    //   19: putfield h : I
    //   22: aload_0
    //   23: ldc 8388659
    //   25: putfield j : I
    //   28: getstatic e/i.n : [I
    //   31: astore #6
    //   33: aload_1
    //   34: aload_2
    //   35: aload #6
    //   37: iload_3
    //   38: iconst_0
    //   39: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   42: astore #5
    //   44: aload_0
    //   45: aload_1
    //   46: aload #6
    //   48: aload_2
    //   49: aload #5
    //   51: iload_3
    //   52: iconst_0
    //   53: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   56: aload #5
    //   58: iconst_1
    //   59: iconst_m1
    //   60: invokevirtual getInt : (II)I
    //   63: istore_3
    //   64: iload_3
    //   65: iflt -> 73
    //   68: aload_0
    //   69: iload_3
    //   70: invokevirtual setOrientation : (I)V
    //   73: aload #5
    //   75: iconst_0
    //   76: iconst_m1
    //   77: invokevirtual getInt : (II)I
    //   80: istore_3
    //   81: iload_3
    //   82: iflt -> 90
    //   85: aload_0
    //   86: iload_3
    //   87: invokevirtual setGravity : (I)V
    //   90: aload #5
    //   92: iconst_2
    //   93: iconst_1
    //   94: invokevirtual getBoolean : (IZ)Z
    //   97: istore #4
    //   99: iload #4
    //   101: ifne -> 110
    //   104: aload_0
    //   105: iload #4
    //   107: invokevirtual setBaselineAligned : (Z)V
    //   110: aload_0
    //   111: aload #5
    //   113: iconst_4
    //   114: ldc -1.0
    //   116: invokevirtual getFloat : (IF)F
    //   119: putfield l : F
    //   122: aload_0
    //   123: aload #5
    //   125: iconst_3
    //   126: iconst_m1
    //   127: invokevirtual getInt : (II)I
    //   130: putfield g : I
    //   133: aload_0
    //   134: aload #5
    //   136: bipush #7
    //   138: iconst_0
    //   139: invokevirtual getBoolean : (IZ)Z
    //   142: putfield m : Z
    //   145: aload #5
    //   147: iconst_5
    //   148: invokevirtual hasValue : (I)Z
    //   151: ifeq -> 175
    //   154: aload #5
    //   156: iconst_5
    //   157: iconst_0
    //   158: invokevirtual getResourceId : (II)I
    //   161: istore_3
    //   162: iload_3
    //   163: ifeq -> 175
    //   166: aload_1
    //   167: iload_3
    //   168: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   171: astore_1
    //   172: goto -> 182
    //   175: aload #5
    //   177: iconst_5
    //   178: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   181: astore_1
    //   182: aload_0
    //   183: aload_1
    //   184: invokevirtual setDividerDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   187: aload_0
    //   188: aload #5
    //   190: bipush #8
    //   192: iconst_0
    //   193: invokevirtual getInt : (II)I
    //   196: putfield s : I
    //   199: aload_0
    //   200: aload #5
    //   202: bipush #6
    //   204: iconst_0
    //   205: invokevirtual getDimensionPixelSize : (II)I
    //   208: putfield t : I
    //   211: aload #5
    //   213: invokevirtual recycle : ()V
    //   216: return
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void f(Canvas paramCanvas, int paramInt) {
    this.p.setBounds(getPaddingLeft() + this.t, paramInt, getWidth() - getPaddingRight() - this.t, this.r + paramInt);
    this.p.draw(paramCanvas);
  }
  
  public void g(Canvas paramCanvas, int paramInt) {
    this.p.setBounds(paramInt, getPaddingTop() + this.t, this.q + paramInt, getHeight() - getPaddingBottom() - this.t);
    this.p.draw(paramCanvas);
  }
  
  public int getBaseline() {
    if (this.g < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.g;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.g == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.h;
      i = j;
      if (this.i == 1) {
        int m = this.j & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.k;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.k) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.g;
  }
  
  public Drawable getDividerDrawable() {
    return this.p;
  }
  
  public int getDividerPadding() {
    return this.t;
  }
  
  public int getDividerWidth() {
    return this.q;
  }
  
  public int getGravity() {
    return this.j;
  }
  
  public int getOrientation() {
    return this.i;
  }
  
  public int getShowDividers() {
    return this.s;
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.l;
  }
  
  public a h() {
    int i = this.i;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a i(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  public a j(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  public boolean k(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.s & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.s & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.s & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.p == null)
      return; 
    int k = this.i;
    int j = 0;
    int i = 0;
    if (k == 1) {
      j = getVirtualChildCount();
      while (i < j) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && k(i)) {
          a a = (a)view.getLayoutParams();
          f(paramCanvas, view.getTop() - a.topMargin - this.r);
        } 
        i++;
      } 
      if (k(j)) {
        View view = getChildAt(j - 1);
        if (view == null) {
          i = getHeight() - getPaddingBottom() - this.r;
        } else {
          a a = (a)view.getLayoutParams();
          i = view.getBottom() + a.bottomMargin;
        } 
        f(paramCanvas, i);
        return;
      } 
    } else {
      k = getVirtualChildCount();
      boolean bool = l1.b((View)this);
      for (i = j; i < k; i++) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && k(i)) {
          a a = (a)view.getLayoutParams();
          if (bool) {
            j = view.getRight() + a.rightMargin;
          } else {
            j = view.getLeft() - a.leftMargin - this.q;
          } 
          g(paramCanvas, j);
        } 
      } 
      if (k(k)) {
        View view = getChildAt(k - 1);
        if (view == null) {
          if (bool) {
            i = getPaddingLeft();
          } else {
            i = getWidth() - getPaddingRight();
            j = this.q;
            i -= j;
          } 
        } else {
          a a = (a)view.getLayoutParams();
          if (bool) {
            i = view.getLeft() - a.leftMargin;
            j = this.q;
          } else {
            i = view.getRight() + a.rightMargin;
            g(paramCanvas, i);
          } 
          i -= j;
        } 
      } else {
        return;
      } 
      g(paramCanvas, i);
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.i == 1) {
      int i = getPaddingLeft();
      int j = paramInt3 - paramInt1;
      int k = getPaddingRight();
      int m = getPaddingRight();
      int n = getVirtualChildCount();
      int i1 = this.j;
      paramInt1 = i1 & 0x70;
      if (paramInt1 != 16) {
        if (paramInt1 != 80) {
          paramInt1 = getPaddingTop();
        } else {
          paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.k;
        } 
      } else {
        paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.k) / 2;
      } 
      paramInt2 = 0;
      while (paramInt2 < n) {
        View view = getChildAt(paramInt2);
        if (view == null) {
          paramInt3 = paramInt1 + 0;
          paramInt4 = paramInt2;
        } else {
          paramInt3 = paramInt1;
          paramInt4 = paramInt2;
          if (view.getVisibility() != 8) {
            int i2 = view.getMeasuredWidth();
            int i3 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            paramInt4 = a.gravity;
            paramInt3 = paramInt4;
            if (paramInt4 < 0)
              paramInt3 = 0x800007 & i1; 
            WeakHashMap weakHashMap = y.a;
            paramInt3 = Gravity.getAbsoluteGravity(paramInt3, y.e.d((View)this)) & 0x7;
            if (paramInt3 != 1) {
              if (paramInt3 != 5) {
                paramInt3 = a.leftMargin + i;
              } else {
                paramInt3 = j - k - i2;
                paramInt4 = a.rightMargin;
                paramInt3 -= paramInt4;
              } 
            } else {
              paramInt3 = (j - i - m - i2) / 2 + i + a.leftMargin;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
            paramInt4 = paramInt1;
            if (k(paramInt2))
              paramInt4 = paramInt1 + this.r; 
            paramInt1 = paramInt4 + a.topMargin;
            paramInt4 = paramInt1 + 0;
            view.layout(paramInt3, paramInt4, i2 + paramInt3, i3 + paramInt4);
            paramInt3 = d.a(i3, a.bottomMargin, 0, paramInt1);
            paramInt4 = paramInt2 + 0;
          } 
        } 
        paramInt2 = paramInt4 + 1;
        paramInt1 = paramInt3;
      } 
    } else {
      byte b;
      boolean bool = l1.b((View)this);
      int k = getPaddingTop();
      int m = paramInt4 - paramInt2;
      int n = getPaddingBottom();
      int i1 = getPaddingBottom();
      int i = getVirtualChildCount();
      paramInt2 = this.j;
      int j = paramInt2 & 0x70;
      paramBoolean = this.f;
      int[] arrayOfInt1 = this.n;
      int[] arrayOfInt2 = this.o;
      WeakHashMap weakHashMap = y.a;
      paramInt2 = Gravity.getAbsoluteGravity(0x800007 & paramInt2, y.e.d((View)this));
      if (paramInt2 != 1) {
        if (paramInt2 != 5) {
          paramInt2 = getPaddingLeft();
        } else {
          paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.k;
        } 
      } else {
        paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.k) / 2;
      } 
      if (bool) {
        paramInt1 = i - 1;
        b = -1;
      } else {
        paramInt1 = 0;
        b = 1;
      } 
      paramInt4 = 0;
      paramInt3 = j;
      j = paramInt1;
      while (paramInt4 < i) {
        int i2 = b * paramInt4 + j;
        View view = getChildAt(i2);
        if (view == null) {
          paramInt1 = paramInt2 + 0;
        } else {
          paramInt1 = paramInt2;
          if (view.getVisibility() != 8) {
            int i5 = view.getMeasuredWidth();
            int i6 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            if (paramBoolean && a.height != -1) {
              i3 = view.getBaseline();
            } else {
              i3 = -1;
            } 
            int i4 = a.gravity;
            paramInt1 = i4;
            if (i4 < 0)
              paramInt1 = paramInt3; 
            paramInt1 &= 0x70;
            if (paramInt1 != 16) {
              if (paramInt1 != 48) {
                if (paramInt1 != 80) {
                  paramInt1 = k;
                } else {
                  i4 = m - n - i6 - a.bottomMargin;
                  paramInt1 = i4;
                  if (i3 != -1) {
                    paramInt1 = view.getMeasuredHeight();
                    paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
                  } 
                } 
              } else {
                paramInt1 = a.topMargin + k;
                if (i3 != -1)
                  paramInt1 = arrayOfInt1[1] - i3 + paramInt1; 
              } 
            } else {
              paramInt1 = (m - k - i1 - i6) / 2 + k + a.topMargin - a.bottomMargin;
            } 
            int i3 = paramInt2;
            if (k(i2))
              i3 = paramInt2 + this.q; 
            paramInt2 = i3 + a.leftMargin;
            i3 = paramInt2 + 0;
            view.layout(i3, paramInt1, i5 + i3, i6 + paramInt1);
            paramInt2 = d.a(i5, a.rightMargin, 0, paramInt2);
            paramInt4 += 0;
            continue;
          } 
        } 
        paramInt2 = paramInt1;
        continue;
        paramInt4++;
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : I
    //   4: iconst_1
    //   5: if_icmpne -> 1627
    //   8: aload_0
    //   9: iconst_0
    //   10: putfield k : I
    //   13: aload_0
    //   14: invokevirtual getVirtualChildCount : ()I
    //   17: istore #17
    //   19: iload_1
    //   20: invokestatic getMode : (I)I
    //   23: istore #20
    //   25: iload_2
    //   26: invokestatic getMode : (I)I
    //   29: istore #5
    //   31: aload_0
    //   32: getfield g : I
    //   35: istore #21
    //   37: aload_0
    //   38: getfield m : Z
    //   41: istore #24
    //   43: fconst_0
    //   44: fstore_3
    //   45: iconst_0
    //   46: istore #13
    //   48: iconst_1
    //   49: istore #6
    //   51: iconst_0
    //   52: istore #9
    //   54: iconst_0
    //   55: istore #16
    //   57: iconst_0
    //   58: istore #12
    //   60: iconst_0
    //   61: istore #8
    //   63: iconst_0
    //   64: istore #11
    //   66: iconst_0
    //   67: istore #7
    //   69: iconst_0
    //   70: istore #10
    //   72: iload #11
    //   74: iload #17
    //   76: if_icmpge -> 649
    //   79: aload_0
    //   80: iload #11
    //   82: invokevirtual getChildAt : (I)Landroid/view/View;
    //   85: astore #28
    //   87: aload #28
    //   89: ifnonnull -> 105
    //   92: aload_0
    //   93: aload_0
    //   94: getfield k : I
    //   97: iconst_0
    //   98: iadd
    //   99: putfield k : I
    //   102: goto -> 121
    //   105: aload #28
    //   107: invokevirtual getVisibility : ()I
    //   110: bipush #8
    //   112: if_icmpne -> 128
    //   115: iload #11
    //   117: iconst_0
    //   118: iadd
    //   119: istore #11
    //   121: iload #11
    //   123: istore #15
    //   125: goto -> 640
    //   128: aload_0
    //   129: iload #11
    //   131: invokevirtual k : (I)Z
    //   134: ifeq -> 150
    //   137: aload_0
    //   138: aload_0
    //   139: getfield k : I
    //   142: aload_0
    //   143: getfield r : I
    //   146: iadd
    //   147: putfield k : I
    //   150: aload #28
    //   152: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   155: checkcast androidx/appcompat/widget/n0$a
    //   158: astore #26
    //   160: aload #26
    //   162: getfield weight : F
    //   165: fstore #4
    //   167: fload_3
    //   168: fload #4
    //   170: fadd
    //   171: fstore_3
    //   172: iload #5
    //   174: ldc_w 1073741824
    //   177: if_icmpne -> 234
    //   180: aload #26
    //   182: getfield height : I
    //   185: ifne -> 234
    //   188: fload #4
    //   190: fconst_0
    //   191: fcmpl
    //   192: ifle -> 234
    //   195: aload_0
    //   196: getfield k : I
    //   199: istore #13
    //   201: aload_0
    //   202: iload #13
    //   204: aload #26
    //   206: getfield topMargin : I
    //   209: iload #13
    //   211: iadd
    //   212: aload #26
    //   214: getfield bottomMargin : I
    //   217: iadd
    //   218: invokestatic max : (II)I
    //   221: putfield k : I
    //   224: iconst_1
    //   225: istore #15
    //   227: iload #12
    //   229: istore #14
    //   231: goto -> 382
    //   234: aload #26
    //   236: getfield height : I
    //   239: ifne -> 262
    //   242: fload #4
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 262
    //   249: aload #26
    //   251: bipush #-2
    //   253: putfield height : I
    //   256: iconst_0
    //   257: istore #14
    //   259: goto -> 267
    //   262: ldc_w -2147483648
    //   265: istore #14
    //   267: fload_3
    //   268: fconst_0
    //   269: fcmpl
    //   270: ifne -> 282
    //   273: aload_0
    //   274: getfield k : I
    //   277: istore #15
    //   279: goto -> 285
    //   282: iconst_0
    //   283: istore #15
    //   285: aload #26
    //   287: astore #27
    //   289: aload_0
    //   290: aload #28
    //   292: iload_1
    //   293: iconst_0
    //   294: iload_2
    //   295: iload #15
    //   297: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   300: iload #14
    //   302: ldc_w -2147483648
    //   305: if_icmpeq -> 315
    //   308: aload #27
    //   310: iload #14
    //   312: putfield height : I
    //   315: aload #28
    //   317: invokevirtual getMeasuredHeight : ()I
    //   320: istore #18
    //   322: aload_0
    //   323: getfield k : I
    //   326: istore #14
    //   328: aload_0
    //   329: iload #14
    //   331: iload #14
    //   333: iload #18
    //   335: iadd
    //   336: aload #27
    //   338: getfield topMargin : I
    //   341: iadd
    //   342: aload #27
    //   344: getfield bottomMargin : I
    //   347: iadd
    //   348: iconst_0
    //   349: iadd
    //   350: invokestatic max : (II)I
    //   353: putfield k : I
    //   356: iload #12
    //   358: istore #14
    //   360: iload #13
    //   362: istore #15
    //   364: iload #24
    //   366: ifeq -> 382
    //   369: iload #18
    //   371: iload #12
    //   373: invokestatic max : (II)I
    //   376: istore #14
    //   378: iload #13
    //   380: istore #15
    //   382: iload #21
    //   384: iflt -> 404
    //   387: iload #21
    //   389: iload #11
    //   391: iconst_1
    //   392: iadd
    //   393: if_icmpne -> 404
    //   396: aload_0
    //   397: aload_0
    //   398: getfield k : I
    //   401: putfield h : I
    //   404: iload #11
    //   406: iload #21
    //   408: if_icmpge -> 435
    //   411: aload #26
    //   413: getfield weight : F
    //   416: fconst_0
    //   417: fcmpl
    //   418: ifgt -> 424
    //   421: goto -> 435
    //   424: new java/lang/RuntimeException
    //   427: dup
    //   428: ldc_w 'A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.'
    //   431: invokespecial <init> : (Ljava/lang/String;)V
    //   434: athrow
    //   435: iload #20
    //   437: ldc_w 1073741824
    //   440: if_icmpeq -> 461
    //   443: aload #26
    //   445: getfield width : I
    //   448: iconst_m1
    //   449: if_icmpne -> 461
    //   452: iconst_1
    //   453: istore #12
    //   455: iconst_1
    //   456: istore #9
    //   458: goto -> 464
    //   461: iconst_0
    //   462: istore #12
    //   464: aload #26
    //   466: getfield leftMargin : I
    //   469: aload #26
    //   471: getfield rightMargin : I
    //   474: iadd
    //   475: istore #13
    //   477: aload #28
    //   479: invokevirtual getMeasuredWidth : ()I
    //   482: iload #13
    //   484: iadd
    //   485: istore #18
    //   487: iload #16
    //   489: iload #18
    //   491: invokestatic max : (II)I
    //   494: istore #19
    //   496: iload #8
    //   498: aload #28
    //   500: invokevirtual getMeasuredState : ()I
    //   503: invokestatic combineMeasuredStates : (II)I
    //   506: istore #16
    //   508: iload #6
    //   510: ifeq -> 528
    //   513: aload #26
    //   515: getfield width : I
    //   518: iconst_m1
    //   519: if_icmpne -> 528
    //   522: iconst_1
    //   523: istore #6
    //   525: goto -> 531
    //   528: iconst_0
    //   529: istore #6
    //   531: aload #26
    //   533: getfield weight : F
    //   536: fconst_0
    //   537: fcmpl
    //   538: ifle -> 573
    //   541: iload #12
    //   543: ifeq -> 549
    //   546: goto -> 553
    //   549: iload #18
    //   551: istore #13
    //   553: iload #10
    //   555: iload #13
    //   557: invokestatic max : (II)I
    //   560: istore #10
    //   562: iload #7
    //   564: istore #8
    //   566: iload #10
    //   568: istore #7
    //   570: goto -> 598
    //   573: iload #12
    //   575: ifeq -> 581
    //   578: goto -> 585
    //   581: iload #18
    //   583: istore #13
    //   585: iload #7
    //   587: iload #13
    //   589: invokestatic max : (II)I
    //   592: istore #8
    //   594: iload #10
    //   596: istore #7
    //   598: iload #11
    //   600: iconst_0
    //   601: iadd
    //   602: istore #18
    //   604: iload #19
    //   606: istore #11
    //   608: iload #16
    //   610: istore #12
    //   612: iload #15
    //   614: istore #13
    //   616: iload #7
    //   618: istore #10
    //   620: iload #8
    //   622: istore #7
    //   624: iload #18
    //   626: istore #15
    //   628: iload #12
    //   630: istore #8
    //   632: iload #14
    //   634: istore #12
    //   636: iload #11
    //   638: istore #16
    //   640: iload #15
    //   642: iconst_1
    //   643: iadd
    //   644: istore #11
    //   646: goto -> 72
    //   649: aload_0
    //   650: getfield k : I
    //   653: ifle -> 678
    //   656: aload_0
    //   657: iload #17
    //   659: invokevirtual k : (I)Z
    //   662: ifeq -> 678
    //   665: aload_0
    //   666: aload_0
    //   667: getfield k : I
    //   670: aload_0
    //   671: getfield r : I
    //   674: iadd
    //   675: putfield k : I
    //   678: iload #24
    //   680: ifeq -> 813
    //   683: iload #5
    //   685: istore #11
    //   687: iload #11
    //   689: ldc_w -2147483648
    //   692: if_icmpeq -> 700
    //   695: iload #11
    //   697: ifne -> 813
    //   700: aload_0
    //   701: iconst_0
    //   702: putfield k : I
    //   705: iconst_0
    //   706: istore #11
    //   708: iload #11
    //   710: iload #17
    //   712: if_icmpge -> 813
    //   715: aload_0
    //   716: iload #11
    //   718: invokevirtual getChildAt : (I)Landroid/view/View;
    //   721: astore #26
    //   723: aload #26
    //   725: ifnonnull -> 741
    //   728: aload_0
    //   729: aload_0
    //   730: getfield k : I
    //   733: iconst_0
    //   734: iadd
    //   735: putfield k : I
    //   738: goto -> 804
    //   741: aload #26
    //   743: invokevirtual getVisibility : ()I
    //   746: bipush #8
    //   748: if_icmpne -> 760
    //   751: iload #11
    //   753: iconst_0
    //   754: iadd
    //   755: istore #11
    //   757: goto -> 804
    //   760: aload #26
    //   762: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   765: checkcast androidx/appcompat/widget/n0$a
    //   768: astore #26
    //   770: aload_0
    //   771: getfield k : I
    //   774: istore #14
    //   776: aload_0
    //   777: iload #14
    //   779: iload #14
    //   781: iload #12
    //   783: iadd
    //   784: aload #26
    //   786: getfield topMargin : I
    //   789: iadd
    //   790: aload #26
    //   792: getfield bottomMargin : I
    //   795: iadd
    //   796: iconst_0
    //   797: iadd
    //   798: invokestatic max : (II)I
    //   801: putfield k : I
    //   804: iload #11
    //   806: iconst_1
    //   807: iadd
    //   808: istore #11
    //   810: goto -> 708
    //   813: iload #5
    //   815: istore #14
    //   817: aload_0
    //   818: getfield k : I
    //   821: istore #5
    //   823: aload_0
    //   824: invokevirtual getPaddingTop : ()I
    //   827: istore #11
    //   829: aload_0
    //   830: invokevirtual getPaddingBottom : ()I
    //   833: iload #11
    //   835: iadd
    //   836: iload #5
    //   838: iadd
    //   839: istore #5
    //   841: aload_0
    //   842: iload #5
    //   844: putfield k : I
    //   847: iload #5
    //   849: aload_0
    //   850: invokevirtual getSuggestedMinimumHeight : ()I
    //   853: invokestatic max : (II)I
    //   856: iload_2
    //   857: iconst_0
    //   858: invokestatic resolveSizeAndState : (III)I
    //   861: istore #18
    //   863: ldc_w 16777215
    //   866: iload #18
    //   868: iand
    //   869: aload_0
    //   870: getfield k : I
    //   873: isub
    //   874: istore #15
    //   876: iload #13
    //   878: ifne -> 1013
    //   881: iload #15
    //   883: ifeq -> 895
    //   886: fload_3
    //   887: fconst_0
    //   888: fcmpl
    //   889: ifle -> 895
    //   892: goto -> 1013
    //   895: iload #7
    //   897: iload #10
    //   899: invokestatic max : (II)I
    //   902: istore #10
    //   904: iload #24
    //   906: ifeq -> 1002
    //   909: iload #14
    //   911: ldc_w 1073741824
    //   914: if_icmpeq -> 1002
    //   917: iconst_0
    //   918: istore #5
    //   920: iload #5
    //   922: iload #17
    //   924: if_icmpge -> 1002
    //   927: aload_0
    //   928: iload #5
    //   930: invokevirtual getChildAt : (I)Landroid/view/View;
    //   933: astore #26
    //   935: aload #26
    //   937: ifnull -> 993
    //   940: aload #26
    //   942: invokevirtual getVisibility : ()I
    //   945: bipush #8
    //   947: if_icmpne -> 953
    //   950: goto -> 993
    //   953: aload #26
    //   955: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   958: checkcast androidx/appcompat/widget/n0$a
    //   961: getfield weight : F
    //   964: fconst_0
    //   965: fcmpl
    //   966: ifle -> 993
    //   969: aload #26
    //   971: aload #26
    //   973: invokevirtual getMeasuredWidth : ()I
    //   976: ldc_w 1073741824
    //   979: invokestatic makeMeasureSpec : (II)I
    //   982: iload #12
    //   984: ldc_w 1073741824
    //   987: invokestatic makeMeasureSpec : (II)I
    //   990: invokevirtual measure : (II)V
    //   993: iload #5
    //   995: iconst_1
    //   996: iadd
    //   997: istore #5
    //   999: goto -> 920
    //   1002: iload #16
    //   1004: istore #7
    //   1006: iload #10
    //   1008: istore #5
    //   1010: goto -> 1469
    //   1013: aload_0
    //   1014: getfield l : F
    //   1017: fstore #4
    //   1019: fload #4
    //   1021: fconst_0
    //   1022: fcmpl
    //   1023: ifle -> 1029
    //   1026: fload #4
    //   1028: fstore_3
    //   1029: iconst_0
    //   1030: istore #11
    //   1032: aload_0
    //   1033: iconst_0
    //   1034: putfield k : I
    //   1037: iload #8
    //   1039: istore #5
    //   1041: iload #16
    //   1043: istore #8
    //   1045: iload #15
    //   1047: istore #10
    //   1049: iload #11
    //   1051: iload #17
    //   1053: if_icmpge -> 1427
    //   1056: aload_0
    //   1057: iload #11
    //   1059: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1062: astore #26
    //   1064: aload #26
    //   1066: invokevirtual getVisibility : ()I
    //   1069: bipush #8
    //   1071: if_icmpne -> 1077
    //   1074: goto -> 1418
    //   1077: aload #26
    //   1079: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1082: checkcast androidx/appcompat/widget/n0$a
    //   1085: astore #27
    //   1087: aload #27
    //   1089: getfield weight : F
    //   1092: fstore #4
    //   1094: fload #4
    //   1096: fconst_0
    //   1097: fcmpl
    //   1098: ifle -> 1271
    //   1101: iload #10
    //   1103: i2f
    //   1104: fload #4
    //   1106: fmul
    //   1107: fload_3
    //   1108: fdiv
    //   1109: f2i
    //   1110: istore #13
    //   1112: fload_3
    //   1113: fload #4
    //   1115: fsub
    //   1116: fstore_3
    //   1117: iload #10
    //   1119: iload #13
    //   1121: isub
    //   1122: istore #12
    //   1124: aload_0
    //   1125: invokevirtual getPaddingLeft : ()I
    //   1128: istore #10
    //   1130: iload_1
    //   1131: aload_0
    //   1132: invokevirtual getPaddingRight : ()I
    //   1135: iload #10
    //   1137: iadd
    //   1138: aload #27
    //   1140: getfield leftMargin : I
    //   1143: iadd
    //   1144: aload #27
    //   1146: getfield rightMargin : I
    //   1149: iadd
    //   1150: aload #27
    //   1152: getfield width : I
    //   1155: invokestatic getChildMeasureSpec : (III)I
    //   1158: istore #15
    //   1160: aload #27
    //   1162: getfield height : I
    //   1165: ifne -> 1212
    //   1168: iload #14
    //   1170: ldc_w 1073741824
    //   1173: if_icmpeq -> 1179
    //   1176: goto -> 1212
    //   1179: iload #13
    //   1181: ifle -> 1191
    //   1184: iload #13
    //   1186: istore #10
    //   1188: goto -> 1194
    //   1191: iconst_0
    //   1192: istore #10
    //   1194: aload #26
    //   1196: iload #15
    //   1198: iload #10
    //   1200: ldc_w 1073741824
    //   1203: invokestatic makeMeasureSpec : (II)I
    //   1206: invokevirtual measure : (II)V
    //   1209: goto -> 1248
    //   1212: aload #26
    //   1214: invokevirtual getMeasuredHeight : ()I
    //   1217: iload #13
    //   1219: iadd
    //   1220: istore #10
    //   1222: iload #10
    //   1224: ifge -> 1233
    //   1227: iconst_0
    //   1228: istore #10
    //   1230: goto -> 1233
    //   1233: aload #26
    //   1235: iload #15
    //   1237: iload #10
    //   1239: ldc_w 1073741824
    //   1242: invokestatic makeMeasureSpec : (II)I
    //   1245: invokevirtual measure : (II)V
    //   1248: iload #5
    //   1250: aload #26
    //   1252: invokevirtual getMeasuredState : ()I
    //   1255: sipush #-256
    //   1258: iand
    //   1259: invokestatic combineMeasuredStates : (II)I
    //   1262: istore #5
    //   1264: iload #12
    //   1266: istore #10
    //   1268: goto -> 1271
    //   1271: aload #27
    //   1273: getfield leftMargin : I
    //   1276: aload #27
    //   1278: getfield rightMargin : I
    //   1281: iadd
    //   1282: istore #13
    //   1284: aload #26
    //   1286: invokevirtual getMeasuredWidth : ()I
    //   1289: iload #13
    //   1291: iadd
    //   1292: istore #15
    //   1294: iload #8
    //   1296: iload #15
    //   1298: invokestatic max : (II)I
    //   1301: istore #12
    //   1303: iload #20
    //   1305: ldc_w 1073741824
    //   1308: if_icmpeq -> 1326
    //   1311: aload #27
    //   1313: getfield width : I
    //   1316: iconst_m1
    //   1317: if_icmpne -> 1326
    //   1320: iconst_1
    //   1321: istore #8
    //   1323: goto -> 1329
    //   1326: iconst_0
    //   1327: istore #8
    //   1329: iload #8
    //   1331: ifeq -> 1341
    //   1334: iload #13
    //   1336: istore #8
    //   1338: goto -> 1345
    //   1341: iload #15
    //   1343: istore #8
    //   1345: iload #7
    //   1347: iload #8
    //   1349: invokestatic max : (II)I
    //   1352: istore #7
    //   1354: iload #6
    //   1356: ifeq -> 1374
    //   1359: aload #27
    //   1361: getfield width : I
    //   1364: iconst_m1
    //   1365: if_icmpne -> 1374
    //   1368: iconst_1
    //   1369: istore #6
    //   1371: goto -> 1377
    //   1374: iconst_0
    //   1375: istore #6
    //   1377: aload_0
    //   1378: getfield k : I
    //   1381: istore #8
    //   1383: aload_0
    //   1384: iload #8
    //   1386: aload #26
    //   1388: invokevirtual getMeasuredHeight : ()I
    //   1391: iload #8
    //   1393: iadd
    //   1394: aload #27
    //   1396: getfield topMargin : I
    //   1399: iadd
    //   1400: aload #27
    //   1402: getfield bottomMargin : I
    //   1405: iadd
    //   1406: iconst_0
    //   1407: iadd
    //   1408: invokestatic max : (II)I
    //   1411: putfield k : I
    //   1414: iload #12
    //   1416: istore #8
    //   1418: iload #11
    //   1420: iconst_1
    //   1421: iadd
    //   1422: istore #11
    //   1424: goto -> 1049
    //   1427: aload_0
    //   1428: getfield k : I
    //   1431: istore #10
    //   1433: aload_0
    //   1434: invokevirtual getPaddingTop : ()I
    //   1437: istore #11
    //   1439: aload_0
    //   1440: aload_0
    //   1441: invokevirtual getPaddingBottom : ()I
    //   1444: iload #11
    //   1446: iadd
    //   1447: iload #10
    //   1449: iadd
    //   1450: putfield k : I
    //   1453: iload #8
    //   1455: istore #10
    //   1457: iload #5
    //   1459: istore #8
    //   1461: iload #7
    //   1463: istore #5
    //   1465: iload #10
    //   1467: istore #7
    //   1469: iload #6
    //   1471: ifne -> 1485
    //   1474: iload #20
    //   1476: ldc_w 1073741824
    //   1479: if_icmpeq -> 1485
    //   1482: goto -> 1489
    //   1485: iload #7
    //   1487: istore #5
    //   1489: aload_0
    //   1490: invokevirtual getPaddingLeft : ()I
    //   1493: istore #6
    //   1495: aload_0
    //   1496: aload_0
    //   1497: invokevirtual getPaddingRight : ()I
    //   1500: iload #6
    //   1502: iadd
    //   1503: iload #5
    //   1505: iadd
    //   1506: aload_0
    //   1507: invokevirtual getSuggestedMinimumWidth : ()I
    //   1510: invokestatic max : (II)I
    //   1513: iload_1
    //   1514: iload #8
    //   1516: invokestatic resolveSizeAndState : (III)I
    //   1519: iload #18
    //   1521: invokevirtual setMeasuredDimension : (II)V
    //   1524: iload #9
    //   1526: ifeq -> 3952
    //   1529: aload_0
    //   1530: invokevirtual getMeasuredWidth : ()I
    //   1533: ldc_w 1073741824
    //   1536: invokestatic makeMeasureSpec : (II)I
    //   1539: istore #5
    //   1541: iconst_0
    //   1542: istore_1
    //   1543: iload_1
    //   1544: iload #17
    //   1546: if_icmpge -> 3952
    //   1549: aload_0
    //   1550: iload_1
    //   1551: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1554: astore #26
    //   1556: aload #26
    //   1558: invokevirtual getVisibility : ()I
    //   1561: bipush #8
    //   1563: if_icmpeq -> 1620
    //   1566: aload #26
    //   1568: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1571: checkcast androidx/appcompat/widget/n0$a
    //   1574: astore #27
    //   1576: aload #27
    //   1578: getfield width : I
    //   1581: iconst_m1
    //   1582: if_icmpne -> 1620
    //   1585: aload #27
    //   1587: getfield height : I
    //   1590: istore #6
    //   1592: aload #27
    //   1594: aload #26
    //   1596: invokevirtual getMeasuredHeight : ()I
    //   1599: putfield height : I
    //   1602: aload_0
    //   1603: aload #26
    //   1605: iload #5
    //   1607: iconst_0
    //   1608: iload_2
    //   1609: iconst_0
    //   1610: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   1613: aload #27
    //   1615: iload #6
    //   1617: putfield height : I
    //   1620: iload_1
    //   1621: iconst_1
    //   1622: iadd
    //   1623: istore_1
    //   1624: goto -> 1543
    //   1627: aload_0
    //   1628: iconst_0
    //   1629: putfield k : I
    //   1632: aload_0
    //   1633: invokevirtual getVirtualChildCount : ()I
    //   1636: istore #17
    //   1638: iload_1
    //   1639: invokestatic getMode : (I)I
    //   1642: istore #9
    //   1644: iload_2
    //   1645: invokestatic getMode : (I)I
    //   1648: istore #22
    //   1650: aload_0
    //   1651: getfield n : [I
    //   1654: ifnull -> 1664
    //   1657: aload_0
    //   1658: getfield o : [I
    //   1661: ifnonnull -> 1678
    //   1664: aload_0
    //   1665: iconst_4
    //   1666: newarray int
    //   1668: putfield n : [I
    //   1671: aload_0
    //   1672: iconst_4
    //   1673: newarray int
    //   1675: putfield o : [I
    //   1678: aload_0
    //   1679: getfield n : [I
    //   1682: astore #29
    //   1684: aload_0
    //   1685: getfield o : [I
    //   1688: astore #30
    //   1690: aload #29
    //   1692: iconst_3
    //   1693: iconst_m1
    //   1694: iastore
    //   1695: aload #29
    //   1697: iconst_2
    //   1698: iconst_m1
    //   1699: iastore
    //   1700: aload #29
    //   1702: iconst_1
    //   1703: iconst_m1
    //   1704: iastore
    //   1705: aload #29
    //   1707: iconst_0
    //   1708: iconst_m1
    //   1709: iastore
    //   1710: aload #30
    //   1712: iconst_3
    //   1713: iconst_m1
    //   1714: iastore
    //   1715: aload #30
    //   1717: iconst_2
    //   1718: iconst_m1
    //   1719: iastore
    //   1720: aload #30
    //   1722: iconst_1
    //   1723: iconst_m1
    //   1724: iastore
    //   1725: aload #30
    //   1727: iconst_0
    //   1728: iconst_m1
    //   1729: iastore
    //   1730: aload_0
    //   1731: getfield f : Z
    //   1734: istore #25
    //   1736: aload_0
    //   1737: getfield m : Z
    //   1740: istore #24
    //   1742: iload #9
    //   1744: ldc_w 1073741824
    //   1747: if_icmpne -> 1756
    //   1750: iconst_1
    //   1751: istore #16
    //   1753: goto -> 1759
    //   1756: iconst_0
    //   1757: istore #16
    //   1759: fconst_0
    //   1760: fstore_3
    //   1761: iconst_0
    //   1762: istore #13
    //   1764: iconst_1
    //   1765: istore #8
    //   1767: iconst_0
    //   1768: istore #10
    //   1770: iconst_0
    //   1771: istore #6
    //   1773: iconst_0
    //   1774: istore #7
    //   1776: iconst_0
    //   1777: istore #5
    //   1779: iconst_0
    //   1780: istore #11
    //   1782: iconst_0
    //   1783: istore #12
    //   1785: iconst_0
    //   1786: istore #14
    //   1788: iload #7
    //   1790: iload #17
    //   1792: if_icmpge -> 2501
    //   1795: aload_0
    //   1796: iload #7
    //   1798: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1801: astore #27
    //   1803: aload #27
    //   1805: ifnonnull -> 1821
    //   1808: aload_0
    //   1809: aload_0
    //   1810: getfield k : I
    //   1813: iconst_0
    //   1814: iadd
    //   1815: putfield k : I
    //   1818: goto -> 1849
    //   1821: iload #6
    //   1823: istore #18
    //   1825: aload #27
    //   1827: invokevirtual getVisibility : ()I
    //   1830: istore #19
    //   1832: iload #5
    //   1834: istore #15
    //   1836: iload #19
    //   1838: bipush #8
    //   1840: if_icmpne -> 1856
    //   1843: iload #7
    //   1845: iconst_0
    //   1846: iadd
    //   1847: istore #7
    //   1849: iload #8
    //   1851: istore #15
    //   1853: goto -> 2488
    //   1856: aload_0
    //   1857: iload #7
    //   1859: invokevirtual k : (I)Z
    //   1862: ifeq -> 1878
    //   1865: aload_0
    //   1866: aload_0
    //   1867: getfield k : I
    //   1870: aload_0
    //   1871: getfield q : I
    //   1874: iadd
    //   1875: putfield k : I
    //   1878: aload #27
    //   1880: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1883: checkcast androidx/appcompat/widget/n0$a
    //   1886: astore #26
    //   1888: aload #26
    //   1890: getfield weight : F
    //   1893: fstore #4
    //   1895: fload_3
    //   1896: fload #4
    //   1898: fadd
    //   1899: fstore_3
    //   1900: iload #9
    //   1902: ldc_w 1073741824
    //   1905: if_icmpne -> 2026
    //   1908: aload #26
    //   1910: getfield width : I
    //   1913: ifne -> 2026
    //   1916: fload #4
    //   1918: fconst_0
    //   1919: fcmpl
    //   1920: ifle -> 2026
    //   1923: iload #16
    //   1925: ifeq -> 1955
    //   1928: aload_0
    //   1929: getfield k : I
    //   1932: istore #15
    //   1934: aload_0
    //   1935: aload #26
    //   1937: getfield leftMargin : I
    //   1940: aload #26
    //   1942: getfield rightMargin : I
    //   1945: iadd
    //   1946: iload #15
    //   1948: iadd
    //   1949: putfield k : I
    //   1952: goto -> 1984
    //   1955: aload_0
    //   1956: getfield k : I
    //   1959: istore #15
    //   1961: aload_0
    //   1962: iload #15
    //   1964: aload #26
    //   1966: getfield leftMargin : I
    //   1969: iload #15
    //   1971: iadd
    //   1972: aload #26
    //   1974: getfield rightMargin : I
    //   1977: iadd
    //   1978: invokestatic max : (II)I
    //   1981: putfield k : I
    //   1984: iload #25
    //   1986: ifeq -> 2012
    //   1989: iconst_0
    //   1990: iconst_0
    //   1991: invokestatic makeMeasureSpec : (II)I
    //   1994: istore #15
    //   1996: aload #27
    //   1998: iload #15
    //   2000: iload #15
    //   2002: invokevirtual measure : (II)V
    //   2005: iload #7
    //   2007: istore #15
    //   2009: goto -> 2209
    //   2012: iconst_1
    //   2013: istore #13
    //   2015: iload #18
    //   2017: istore #6
    //   2019: iload #7
    //   2021: istore #15
    //   2023: goto -> 2217
    //   2026: aload #26
    //   2028: getfield width : I
    //   2031: ifne -> 2054
    //   2034: fload #4
    //   2036: fconst_0
    //   2037: fcmpl
    //   2038: ifle -> 2054
    //   2041: aload #26
    //   2043: bipush #-2
    //   2045: putfield width : I
    //   2048: iconst_0
    //   2049: istore #15
    //   2051: goto -> 2059
    //   2054: ldc_w -2147483648
    //   2057: istore #15
    //   2059: fload_3
    //   2060: fconst_0
    //   2061: fcmpl
    //   2062: ifne -> 2074
    //   2065: aload_0
    //   2066: getfield k : I
    //   2069: istore #19
    //   2071: goto -> 2077
    //   2074: iconst_0
    //   2075: istore #19
    //   2077: aload_0
    //   2078: aload #27
    //   2080: iload_1
    //   2081: iload #19
    //   2083: iload_2
    //   2084: iconst_0
    //   2085: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   2088: iload #15
    //   2090: ldc_w -2147483648
    //   2093: if_icmpeq -> 2106
    //   2096: aload #26
    //   2098: iload #15
    //   2100: putfield width : I
    //   2103: goto -> 2106
    //   2106: aload #26
    //   2108: astore #28
    //   2110: aload #27
    //   2112: invokevirtual getMeasuredWidth : ()I
    //   2115: istore #19
    //   2117: iload #16
    //   2119: ifeq -> 2154
    //   2122: aload_0
    //   2123: getfield k : I
    //   2126: istore #15
    //   2128: aload_0
    //   2129: aload #28
    //   2131: getfield leftMargin : I
    //   2134: iload #19
    //   2136: iadd
    //   2137: aload #28
    //   2139: getfield rightMargin : I
    //   2142: iconst_0
    //   2143: iload #15
    //   2145: invokestatic a : (IIII)I
    //   2148: putfield k : I
    //   2151: goto -> 2188
    //   2154: aload_0
    //   2155: getfield k : I
    //   2158: istore #15
    //   2160: aload_0
    //   2161: iload #15
    //   2163: iload #15
    //   2165: iload #19
    //   2167: iadd
    //   2168: aload #28
    //   2170: getfield leftMargin : I
    //   2173: iadd
    //   2174: aload #28
    //   2176: getfield rightMargin : I
    //   2179: iadd
    //   2180: iconst_0
    //   2181: iadd
    //   2182: invokestatic max : (II)I
    //   2185: putfield k : I
    //   2188: iload #7
    //   2190: istore #15
    //   2192: iload #24
    //   2194: ifeq -> 2209
    //   2197: iload #19
    //   2199: iload #18
    //   2201: invokestatic max : (II)I
    //   2204: istore #6
    //   2206: goto -> 2213
    //   2209: iload #15
    //   2211: istore #7
    //   2213: iload #7
    //   2215: istore #15
    //   2217: iload #5
    //   2219: istore #7
    //   2221: iload #22
    //   2223: ldc_w 1073741824
    //   2226: if_icmpeq -> 2247
    //   2229: aload #26
    //   2231: getfield height : I
    //   2234: iconst_m1
    //   2235: if_icmpne -> 2247
    //   2238: iconst_1
    //   2239: istore #18
    //   2241: iconst_1
    //   2242: istore #10
    //   2244: goto -> 2250
    //   2247: iconst_0
    //   2248: istore #18
    //   2250: aload #26
    //   2252: getfield topMargin : I
    //   2255: aload #26
    //   2257: getfield bottomMargin : I
    //   2260: iadd
    //   2261: istore #19
    //   2263: aload #27
    //   2265: invokevirtual getMeasuredHeight : ()I
    //   2268: iload #19
    //   2270: iadd
    //   2271: istore #20
    //   2273: iload #14
    //   2275: aload #27
    //   2277: invokevirtual getMeasuredState : ()I
    //   2280: invokestatic combineMeasuredStates : (II)I
    //   2283: istore #14
    //   2285: iload #25
    //   2287: ifeq -> 2375
    //   2290: aload #27
    //   2292: invokevirtual getBaseline : ()I
    //   2295: istore #23
    //   2297: iload #23
    //   2299: iconst_m1
    //   2300: if_icmpeq -> 2375
    //   2303: aload #26
    //   2305: getfield gravity : I
    //   2308: istore #21
    //   2310: iload #21
    //   2312: istore #5
    //   2314: iload #21
    //   2316: ifge -> 2325
    //   2319: aload_0
    //   2320: getfield j : I
    //   2323: istore #5
    //   2325: iload #5
    //   2327: bipush #112
    //   2329: iand
    //   2330: iconst_4
    //   2331: ishr
    //   2332: bipush #-2
    //   2334: iand
    //   2335: iconst_1
    //   2336: ishr
    //   2337: istore #5
    //   2339: aload #29
    //   2341: iload #5
    //   2343: aload #29
    //   2345: iload #5
    //   2347: iaload
    //   2348: iload #23
    //   2350: invokestatic max : (II)I
    //   2353: iastore
    //   2354: aload #30
    //   2356: iload #5
    //   2358: aload #30
    //   2360: iload #5
    //   2362: iaload
    //   2363: iload #20
    //   2365: iload #23
    //   2367: isub
    //   2368: invokestatic max : (II)I
    //   2371: iastore
    //   2372: goto -> 2375
    //   2375: iload #12
    //   2377: iload #20
    //   2379: invokestatic max : (II)I
    //   2382: istore #12
    //   2384: iload #8
    //   2386: ifeq -> 2404
    //   2389: aload #26
    //   2391: getfield height : I
    //   2394: iconst_m1
    //   2395: if_icmpne -> 2404
    //   2398: iconst_1
    //   2399: istore #5
    //   2401: goto -> 2407
    //   2404: iconst_0
    //   2405: istore #5
    //   2407: aload #26
    //   2409: getfield weight : F
    //   2412: fconst_0
    //   2413: fcmpl
    //   2414: ifle -> 2441
    //   2417: iload #18
    //   2419: ifeq -> 2425
    //   2422: goto -> 2429
    //   2425: iload #20
    //   2427: istore #19
    //   2429: iload #11
    //   2431: iload #19
    //   2433: invokestatic max : (II)I
    //   2436: istore #8
    //   2438: goto -> 2466
    //   2441: iload #18
    //   2443: ifeq -> 2449
    //   2446: goto -> 2453
    //   2449: iload #20
    //   2451: istore #19
    //   2453: iload #7
    //   2455: iload #19
    //   2457: invokestatic max : (II)I
    //   2460: istore #7
    //   2462: iload #11
    //   2464: istore #8
    //   2466: iload #15
    //   2468: iconst_0
    //   2469: iadd
    //   2470: istore #18
    //   2472: iload #5
    //   2474: istore #15
    //   2476: iload #8
    //   2478: istore #11
    //   2480: iload #7
    //   2482: istore #5
    //   2484: iload #18
    //   2486: istore #7
    //   2488: iload #7
    //   2490: iconst_1
    //   2491: iadd
    //   2492: istore #7
    //   2494: iload #15
    //   2496: istore #8
    //   2498: goto -> 1788
    //   2501: iload #5
    //   2503: istore #18
    //   2505: aload_0
    //   2506: getfield k : I
    //   2509: ifle -> 2534
    //   2512: aload_0
    //   2513: iload #17
    //   2515: invokevirtual k : (I)Z
    //   2518: ifeq -> 2534
    //   2521: aload_0
    //   2522: aload_0
    //   2523: getfield k : I
    //   2526: aload_0
    //   2527: getfield q : I
    //   2530: iadd
    //   2531: putfield k : I
    //   2534: aload #29
    //   2536: iconst_1
    //   2537: iaload
    //   2538: iconst_m1
    //   2539: if_icmpne -> 2572
    //   2542: aload #29
    //   2544: iconst_0
    //   2545: iaload
    //   2546: iconst_m1
    //   2547: if_icmpne -> 2572
    //   2550: aload #29
    //   2552: iconst_2
    //   2553: iaload
    //   2554: iconst_m1
    //   2555: if_icmpne -> 2572
    //   2558: aload #29
    //   2560: iconst_3
    //   2561: iaload
    //   2562: iconst_m1
    //   2563: if_icmpeq -> 2569
    //   2566: goto -> 2572
    //   2569: goto -> 2634
    //   2572: aload #29
    //   2574: iconst_3
    //   2575: iaload
    //   2576: aload #29
    //   2578: iconst_0
    //   2579: iaload
    //   2580: aload #29
    //   2582: iconst_1
    //   2583: iaload
    //   2584: aload #29
    //   2586: iconst_2
    //   2587: iaload
    //   2588: invokestatic max : (II)I
    //   2591: invokestatic max : (II)I
    //   2594: invokestatic max : (II)I
    //   2597: istore #5
    //   2599: iload #12
    //   2601: aload #30
    //   2603: iconst_3
    //   2604: iaload
    //   2605: aload #30
    //   2607: iconst_0
    //   2608: iaload
    //   2609: aload #30
    //   2611: iconst_1
    //   2612: iaload
    //   2613: aload #30
    //   2615: iconst_2
    //   2616: iaload
    //   2617: invokestatic max : (II)I
    //   2620: invokestatic max : (II)I
    //   2623: invokestatic max : (II)I
    //   2626: iload #5
    //   2628: iadd
    //   2629: invokestatic max : (II)I
    //   2632: istore #12
    //   2634: iload #24
    //   2636: ifeq -> 2806
    //   2639: iload #9
    //   2641: istore #5
    //   2643: iload #5
    //   2645: ldc_w -2147483648
    //   2648: if_icmpeq -> 2656
    //   2651: iload #5
    //   2653: ifne -> 2806
    //   2656: aload_0
    //   2657: iconst_0
    //   2658: putfield k : I
    //   2661: iconst_0
    //   2662: istore #5
    //   2664: iload #5
    //   2666: iload #17
    //   2668: if_icmpge -> 2806
    //   2671: aload_0
    //   2672: iload #5
    //   2674: invokevirtual getChildAt : (I)Landroid/view/View;
    //   2677: astore #26
    //   2679: aload #26
    //   2681: ifnonnull -> 2697
    //   2684: aload_0
    //   2685: aload_0
    //   2686: getfield k : I
    //   2689: iconst_0
    //   2690: iadd
    //   2691: putfield k : I
    //   2694: goto -> 2797
    //   2697: aload #26
    //   2699: invokevirtual getVisibility : ()I
    //   2702: bipush #8
    //   2704: if_icmpne -> 2716
    //   2707: iload #5
    //   2709: iconst_0
    //   2710: iadd
    //   2711: istore #5
    //   2713: goto -> 2797
    //   2716: aload #26
    //   2718: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   2721: checkcast androidx/appcompat/widget/n0$a
    //   2724: astore #26
    //   2726: iload #16
    //   2728: ifeq -> 2763
    //   2731: aload_0
    //   2732: getfield k : I
    //   2735: istore #7
    //   2737: aload_0
    //   2738: aload #26
    //   2740: getfield leftMargin : I
    //   2743: iload #6
    //   2745: iadd
    //   2746: aload #26
    //   2748: getfield rightMargin : I
    //   2751: iconst_0
    //   2752: iload #7
    //   2754: invokestatic a : (IIII)I
    //   2757: putfield k : I
    //   2760: goto -> 2797
    //   2763: aload_0
    //   2764: getfield k : I
    //   2767: istore #7
    //   2769: aload_0
    //   2770: iload #7
    //   2772: iload #7
    //   2774: iload #6
    //   2776: iadd
    //   2777: aload #26
    //   2779: getfield leftMargin : I
    //   2782: iadd
    //   2783: aload #26
    //   2785: getfield rightMargin : I
    //   2788: iadd
    //   2789: iconst_0
    //   2790: iadd
    //   2791: invokestatic max : (II)I
    //   2794: putfield k : I
    //   2797: iload #5
    //   2799: iconst_1
    //   2800: iadd
    //   2801: istore #5
    //   2803: goto -> 2664
    //   2806: iload #9
    //   2808: istore #20
    //   2810: aload_0
    //   2811: getfield k : I
    //   2814: istore #5
    //   2816: aload_0
    //   2817: invokevirtual getPaddingLeft : ()I
    //   2820: istore #7
    //   2822: aload_0
    //   2823: invokevirtual getPaddingRight : ()I
    //   2826: iload #7
    //   2828: iadd
    //   2829: iload #5
    //   2831: iadd
    //   2832: istore #5
    //   2834: aload_0
    //   2835: iload #5
    //   2837: putfield k : I
    //   2840: iload #5
    //   2842: aload_0
    //   2843: invokevirtual getSuggestedMinimumWidth : ()I
    //   2846: invokestatic max : (II)I
    //   2849: iload_1
    //   2850: iconst_0
    //   2851: invokestatic resolveSizeAndState : (III)I
    //   2854: istore #19
    //   2856: ldc_w 16777215
    //   2859: iload #19
    //   2861: iand
    //   2862: aload_0
    //   2863: getfield k : I
    //   2866: isub
    //   2867: istore #7
    //   2869: iload #13
    //   2871: ifne -> 3010
    //   2874: iload #7
    //   2876: ifeq -> 2888
    //   2879: fload_3
    //   2880: fconst_0
    //   2881: fcmpl
    //   2882: ifle -> 2888
    //   2885: goto -> 3010
    //   2888: iload #18
    //   2890: iload #11
    //   2892: invokestatic max : (II)I
    //   2895: istore #7
    //   2897: iload #24
    //   2899: ifeq -> 2995
    //   2902: iload #20
    //   2904: ldc_w 1073741824
    //   2907: if_icmpeq -> 2995
    //   2910: iconst_0
    //   2911: istore #5
    //   2913: iload #5
    //   2915: iload #17
    //   2917: if_icmpge -> 2995
    //   2920: aload_0
    //   2921: iload #5
    //   2923: invokevirtual getChildAt : (I)Landroid/view/View;
    //   2926: astore #26
    //   2928: aload #26
    //   2930: ifnull -> 2986
    //   2933: aload #26
    //   2935: invokevirtual getVisibility : ()I
    //   2938: bipush #8
    //   2940: if_icmpne -> 2946
    //   2943: goto -> 2986
    //   2946: aload #26
    //   2948: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   2951: checkcast androidx/appcompat/widget/n0$a
    //   2954: getfield weight : F
    //   2957: fconst_0
    //   2958: fcmpl
    //   2959: ifle -> 2986
    //   2962: aload #26
    //   2964: iload #6
    //   2966: ldc_w 1073741824
    //   2969: invokestatic makeMeasureSpec : (II)I
    //   2972: aload #26
    //   2974: invokevirtual getMeasuredHeight : ()I
    //   2977: ldc_w 1073741824
    //   2980: invokestatic makeMeasureSpec : (II)I
    //   2983: invokevirtual measure : (II)V
    //   2986: iload #5
    //   2988: iconst_1
    //   2989: iadd
    //   2990: istore #5
    //   2992: goto -> 2913
    //   2995: iload #19
    //   2997: istore #6
    //   2999: iload #17
    //   3001: istore #9
    //   3003: iload #14
    //   3005: istore #5
    //   3007: goto -> 3711
    //   3010: aload_0
    //   3011: getfield l : F
    //   3014: fstore #4
    //   3016: fload #4
    //   3018: fconst_0
    //   3019: fcmpl
    //   3020: ifle -> 3026
    //   3023: fload #4
    //   3025: fstore_3
    //   3026: aload #29
    //   3028: iconst_3
    //   3029: iconst_m1
    //   3030: iastore
    //   3031: aload #29
    //   3033: iconst_2
    //   3034: iconst_m1
    //   3035: iastore
    //   3036: aload #29
    //   3038: iconst_1
    //   3039: iconst_m1
    //   3040: iastore
    //   3041: aload #29
    //   3043: iconst_0
    //   3044: iconst_m1
    //   3045: iastore
    //   3046: aload #30
    //   3048: iconst_3
    //   3049: iconst_m1
    //   3050: iastore
    //   3051: aload #30
    //   3053: iconst_2
    //   3054: iconst_m1
    //   3055: iastore
    //   3056: aload #30
    //   3058: iconst_1
    //   3059: iconst_m1
    //   3060: iastore
    //   3061: aload #30
    //   3063: iconst_0
    //   3064: iconst_m1
    //   3065: iastore
    //   3066: aload_0
    //   3067: iconst_0
    //   3068: putfield k : I
    //   3071: iconst_m1
    //   3072: istore #12
    //   3074: iconst_0
    //   3075: istore #15
    //   3077: iload #14
    //   3079: istore #5
    //   3081: iload #17
    //   3083: istore #9
    //   3085: iload #20
    //   3087: istore #14
    //   3089: iload #18
    //   3091: istore #6
    //   3093: iload #19
    //   3095: istore #11
    //   3097: iload #15
    //   3099: iload #9
    //   3101: if_icmpge -> 3642
    //   3104: aload_0
    //   3105: iload #15
    //   3107: invokevirtual getChildAt : (I)Landroid/view/View;
    //   3110: astore #26
    //   3112: aload #26
    //   3114: ifnull -> 3609
    //   3117: aload #26
    //   3119: invokevirtual getVisibility : ()I
    //   3122: bipush #8
    //   3124: if_icmpne -> 3130
    //   3127: goto -> 3609
    //   3130: aload #26
    //   3132: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   3135: checkcast androidx/appcompat/widget/n0$a
    //   3138: astore #27
    //   3140: aload #27
    //   3142: getfield weight : F
    //   3145: fstore #4
    //   3147: fload #4
    //   3149: fconst_0
    //   3150: fcmpl
    //   3151: ifle -> 3320
    //   3154: iload #7
    //   3156: i2f
    //   3157: fload #4
    //   3159: fmul
    //   3160: fload_3
    //   3161: fdiv
    //   3162: f2i
    //   3163: istore #17
    //   3165: aload_0
    //   3166: invokevirtual getPaddingTop : ()I
    //   3169: istore #13
    //   3171: iload_2
    //   3172: aload_0
    //   3173: invokevirtual getPaddingBottom : ()I
    //   3176: iload #13
    //   3178: iadd
    //   3179: aload #27
    //   3181: getfield topMargin : I
    //   3184: iadd
    //   3185: aload #27
    //   3187: getfield bottomMargin : I
    //   3190: iadd
    //   3191: aload #27
    //   3193: getfield height : I
    //   3196: invokestatic getChildMeasureSpec : (III)I
    //   3199: istore #18
    //   3201: aload #27
    //   3203: getfield width : I
    //   3206: ifne -> 3253
    //   3209: iload #14
    //   3211: ldc_w 1073741824
    //   3214: if_icmpeq -> 3220
    //   3217: goto -> 3253
    //   3220: iload #17
    //   3222: ifle -> 3232
    //   3225: iload #17
    //   3227: istore #13
    //   3229: goto -> 3235
    //   3232: iconst_0
    //   3233: istore #13
    //   3235: aload #26
    //   3237: iload #13
    //   3239: ldc_w 1073741824
    //   3242: invokestatic makeMeasureSpec : (II)I
    //   3245: iload #18
    //   3247: invokevirtual measure : (II)V
    //   3250: goto -> 3289
    //   3253: aload #26
    //   3255: invokevirtual getMeasuredWidth : ()I
    //   3258: iload #17
    //   3260: iadd
    //   3261: istore #13
    //   3263: iload #13
    //   3265: ifge -> 3274
    //   3268: iconst_0
    //   3269: istore #13
    //   3271: goto -> 3274
    //   3274: aload #26
    //   3276: iload #13
    //   3278: ldc_w 1073741824
    //   3281: invokestatic makeMeasureSpec : (II)I
    //   3284: iload #18
    //   3286: invokevirtual measure : (II)V
    //   3289: iload #5
    //   3291: aload #26
    //   3293: invokevirtual getMeasuredState : ()I
    //   3296: ldc_w -16777216
    //   3299: iand
    //   3300: invokestatic combineMeasuredStates : (II)I
    //   3303: istore #5
    //   3305: fload_3
    //   3306: fload #4
    //   3308: fsub
    //   3309: fstore_3
    //   3310: iload #7
    //   3312: iload #17
    //   3314: isub
    //   3315: istore #7
    //   3317: goto -> 3320
    //   3320: iload #16
    //   3322: ifeq -> 3360
    //   3325: aload_0
    //   3326: getfield k : I
    //   3329: istore #13
    //   3331: aload_0
    //   3332: aload #26
    //   3334: invokevirtual getMeasuredWidth : ()I
    //   3337: aload #27
    //   3339: getfield leftMargin : I
    //   3342: iadd
    //   3343: aload #27
    //   3345: getfield rightMargin : I
    //   3348: iconst_0
    //   3349: iload #13
    //   3351: invokestatic a : (IIII)I
    //   3354: putfield k : I
    //   3357: goto -> 3397
    //   3360: aload_0
    //   3361: getfield k : I
    //   3364: istore #13
    //   3366: aload_0
    //   3367: iload #13
    //   3369: aload #26
    //   3371: invokevirtual getMeasuredWidth : ()I
    //   3374: iload #13
    //   3376: iadd
    //   3377: aload #27
    //   3379: getfield leftMargin : I
    //   3382: iadd
    //   3383: aload #27
    //   3385: getfield rightMargin : I
    //   3388: iadd
    //   3389: iconst_0
    //   3390: iadd
    //   3391: invokestatic max : (II)I
    //   3394: putfield k : I
    //   3397: iload #22
    //   3399: ldc_w 1073741824
    //   3402: if_icmpeq -> 3420
    //   3405: aload #27
    //   3407: getfield height : I
    //   3410: iconst_m1
    //   3411: if_icmpne -> 3420
    //   3414: iconst_1
    //   3415: istore #13
    //   3417: goto -> 3423
    //   3420: iconst_0
    //   3421: istore #13
    //   3423: aload #27
    //   3425: getfield topMargin : I
    //   3428: aload #27
    //   3430: getfield bottomMargin : I
    //   3433: iadd
    //   3434: istore #19
    //   3436: aload #26
    //   3438: invokevirtual getMeasuredHeight : ()I
    //   3441: iload #19
    //   3443: iadd
    //   3444: istore #18
    //   3446: iload #12
    //   3448: iload #18
    //   3450: invokestatic max : (II)I
    //   3453: istore #17
    //   3455: iload #13
    //   3457: ifeq -> 3467
    //   3460: iload #19
    //   3462: istore #12
    //   3464: goto -> 3471
    //   3467: iload #18
    //   3469: istore #12
    //   3471: iload #6
    //   3473: iload #12
    //   3475: invokestatic max : (II)I
    //   3478: istore #12
    //   3480: iload #8
    //   3482: ifeq -> 3500
    //   3485: aload #27
    //   3487: getfield height : I
    //   3490: iconst_m1
    //   3491: if_icmpne -> 3500
    //   3494: iconst_1
    //   3495: istore #6
    //   3497: goto -> 3503
    //   3500: iconst_0
    //   3501: istore #6
    //   3503: iload #25
    //   3505: ifeq -> 3590
    //   3508: aload #26
    //   3510: invokevirtual getBaseline : ()I
    //   3513: istore #19
    //   3515: iload #19
    //   3517: iconst_m1
    //   3518: if_icmpeq -> 3590
    //   3521: aload #27
    //   3523: getfield gravity : I
    //   3526: istore #13
    //   3528: iload #13
    //   3530: istore #8
    //   3532: iload #13
    //   3534: ifge -> 3543
    //   3537: aload_0
    //   3538: getfield j : I
    //   3541: istore #8
    //   3543: iload #8
    //   3545: bipush #112
    //   3547: iand
    //   3548: iconst_4
    //   3549: ishr
    //   3550: bipush #-2
    //   3552: iand
    //   3553: iconst_1
    //   3554: ishr
    //   3555: istore #8
    //   3557: aload #29
    //   3559: iload #8
    //   3561: aload #29
    //   3563: iload #8
    //   3565: iaload
    //   3566: iload #19
    //   3568: invokestatic max : (II)I
    //   3571: iastore
    //   3572: aload #30
    //   3574: iload #8
    //   3576: aload #30
    //   3578: iload #8
    //   3580: iaload
    //   3581: iload #18
    //   3583: iload #19
    //   3585: isub
    //   3586: invokestatic max : (II)I
    //   3589: iastore
    //   3590: iload #6
    //   3592: istore #8
    //   3594: iload #7
    //   3596: istore #6
    //   3598: iload #12
    //   3600: istore #7
    //   3602: iload #17
    //   3604: istore #12
    //   3606: goto -> 3621
    //   3609: iload #7
    //   3611: istore #13
    //   3613: iload #6
    //   3615: istore #7
    //   3617: iload #13
    //   3619: istore #6
    //   3621: iload #15
    //   3623: iconst_1
    //   3624: iadd
    //   3625: istore #15
    //   3627: iload #6
    //   3629: istore #13
    //   3631: iload #7
    //   3633: istore #6
    //   3635: iload #13
    //   3637: istore #7
    //   3639: goto -> 3097
    //   3642: aload_0
    //   3643: getfield k : I
    //   3646: istore #7
    //   3648: aload_0
    //   3649: invokevirtual getPaddingLeft : ()I
    //   3652: istore #13
    //   3654: aload_0
    //   3655: aload_0
    //   3656: invokevirtual getPaddingRight : ()I
    //   3659: iload #13
    //   3661: iadd
    //   3662: iload #7
    //   3664: iadd
    //   3665: putfield k : I
    //   3668: aload #29
    //   3670: iconst_1
    //   3671: iaload
    //   3672: iconst_m1
    //   3673: if_icmpne -> 3718
    //   3676: aload #29
    //   3678: iconst_0
    //   3679: iaload
    //   3680: iconst_m1
    //   3681: if_icmpne -> 3718
    //   3684: aload #29
    //   3686: iconst_2
    //   3687: iaload
    //   3688: iconst_m1
    //   3689: if_icmpne -> 3718
    //   3692: aload #29
    //   3694: iconst_3
    //   3695: iaload
    //   3696: iconst_m1
    //   3697: if_icmpeq -> 3703
    //   3700: goto -> 3718
    //   3703: iload #6
    //   3705: istore #7
    //   3707: iload #11
    //   3709: istore #6
    //   3711: iload #6
    //   3713: istore #11
    //   3715: goto -> 3784
    //   3718: aload #29
    //   3720: iconst_3
    //   3721: iaload
    //   3722: aload #29
    //   3724: iconst_0
    //   3725: iaload
    //   3726: aload #29
    //   3728: iconst_1
    //   3729: iaload
    //   3730: aload #29
    //   3732: iconst_2
    //   3733: iaload
    //   3734: invokestatic max : (II)I
    //   3737: invokestatic max : (II)I
    //   3740: invokestatic max : (II)I
    //   3743: istore #7
    //   3745: iload #12
    //   3747: aload #30
    //   3749: iconst_3
    //   3750: iaload
    //   3751: aload #30
    //   3753: iconst_0
    //   3754: iaload
    //   3755: aload #30
    //   3757: iconst_1
    //   3758: iaload
    //   3759: aload #30
    //   3761: iconst_2
    //   3762: iaload
    //   3763: invokestatic max : (II)I
    //   3766: invokestatic max : (II)I
    //   3769: invokestatic max : (II)I
    //   3772: iload #7
    //   3774: iadd
    //   3775: invokestatic max : (II)I
    //   3778: istore #12
    //   3780: iload #6
    //   3782: istore #7
    //   3784: iload #8
    //   3786: ifne -> 3800
    //   3789: iload #22
    //   3791: ldc_w 1073741824
    //   3794: if_icmpeq -> 3800
    //   3797: goto -> 3804
    //   3800: iload #12
    //   3802: istore #7
    //   3804: aload_0
    //   3805: invokevirtual getPaddingTop : ()I
    //   3808: istore #6
    //   3810: aload_0
    //   3811: ldc_w -16777216
    //   3814: iload #5
    //   3816: iand
    //   3817: iload #11
    //   3819: ior
    //   3820: aload_0
    //   3821: invokevirtual getPaddingBottom : ()I
    //   3824: iload #6
    //   3826: iadd
    //   3827: iload #7
    //   3829: iadd
    //   3830: aload_0
    //   3831: invokevirtual getSuggestedMinimumHeight : ()I
    //   3834: invokestatic max : (II)I
    //   3837: iload_2
    //   3838: iload #5
    //   3840: bipush #16
    //   3842: ishl
    //   3843: invokestatic resolveSizeAndState : (III)I
    //   3846: invokevirtual setMeasuredDimension : (II)V
    //   3849: iload #10
    //   3851: ifeq -> 3952
    //   3854: aload_0
    //   3855: invokevirtual getMeasuredHeight : ()I
    //   3858: ldc_w 1073741824
    //   3861: invokestatic makeMeasureSpec : (II)I
    //   3864: istore #5
    //   3866: iconst_0
    //   3867: istore_2
    //   3868: iload_2
    //   3869: iload #9
    //   3871: if_icmpge -> 3952
    //   3874: aload_0
    //   3875: iload_2
    //   3876: invokevirtual getChildAt : (I)Landroid/view/View;
    //   3879: astore #26
    //   3881: aload #26
    //   3883: invokevirtual getVisibility : ()I
    //   3886: bipush #8
    //   3888: if_icmpeq -> 3945
    //   3891: aload #26
    //   3893: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   3896: checkcast androidx/appcompat/widget/n0$a
    //   3899: astore #27
    //   3901: aload #27
    //   3903: getfield height : I
    //   3906: iconst_m1
    //   3907: if_icmpne -> 3945
    //   3910: aload #27
    //   3912: getfield width : I
    //   3915: istore #6
    //   3917: aload #27
    //   3919: aload #26
    //   3921: invokevirtual getMeasuredWidth : ()I
    //   3924: putfield width : I
    //   3927: aload_0
    //   3928: aload #26
    //   3930: iload_1
    //   3931: iconst_0
    //   3932: iload #5
    //   3934: iconst_0
    //   3935: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   3938: aload #27
    //   3940: iload #6
    //   3942: putfield width : I
    //   3945: iload_2
    //   3946: iconst_1
    //   3947: iadd
    //   3948: istore_2
    //   3949: goto -> 3868
    //   3952: return
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.g = paramInt;
      return;
    } 
    StringBuilder stringBuilder = android.support.v4.media.a.a("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.p)
      return; 
    this.p = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.q = paramDrawable.getIntrinsicWidth();
      this.r = paramDrawable.getIntrinsicHeight();
    } else {
      this.q = 0;
      this.r = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.t = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.j != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.j = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.j;
    if ((0x800007 & i) != paramInt) {
      this.j = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.i != paramInt) {
      this.i = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.s)
      requestLayout(); 
    this.s = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.j;
    if ((i & 0x70) != paramInt) {
      this.j = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.l = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class a extends LinearLayout.LayoutParams {
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */