package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.view.View;
import k.f;

public class y extends m0 {
  public y(z paramz, View paramView, z.d paramd) {
    super(paramView);
  }
  
  public f c() {
    return this.o;
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public boolean d() {
    if (!this.p.getInternalPopup().isShowing())
      this.p.b(); 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */