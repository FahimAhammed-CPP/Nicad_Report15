package androidx.appcompat.widget;

import android.os.Build;
import android.text.TextUtils;
import android.view.View;

public class h1 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    i1 i11;
    if (Build.VERSION.SDK_INT >= 26) {
      paramView.setTooltipText(paramCharSequence);
      return;
    } 
    i1 i12 = i1.o;
    if (i12 != null && i12.f == paramView)
      i1.c(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      i11 = i1.p;
      if (i11 != null && i11.f == paramView)
        i11.b(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new i1(paramView, (CharSequence)i11);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */