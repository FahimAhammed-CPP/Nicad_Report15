package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import e7.t0;
import g.a;
import java.util.concurrent.Future;
import k0.b;
import m0.t;
import q0.b;
import q0.g;
import q0.k;

public class e0 extends TextView implements t, k, b {
  public final f f;
  
  public final c0 g;
  
  public final a0 h;
  
  public n i;
  
  public boolean j = false;
  
  public Future<b> k;
  
  public e0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public e0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(a1.a(paramContext), paramAttributeSet, paramInt);
    y0.a((View)this, getContext());
    f f1 = new f((View)this);
    this.f = f1;
    f1.d(paramAttributeSet, paramInt);
    c0 c01 = new c0(this);
    this.g = c01;
    c01.e(paramAttributeSet, paramInt);
    c01.b();
    this.h = new a0(this);
    getEmojiTextViewHelper().a(paramAttributeSet, paramInt);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.i == null)
      this.i = new n(this); 
    return this.i;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.f;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.d)
      return super.getAutoSizeMaxTextSize(); 
    c0 c01 = this.g;
    return (c01 != null) ? Math.round(c01.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.d)
      return super.getAutoSizeMinTextSize(); 
    c0 c01 = this.g;
    return (c01 != null) ? Math.round(c01.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.d)
      return super.getAutoSizeStepGranularity(); 
    c0 c01 = this.g;
    return (c01 != null) ? Math.round(c01.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.d)
      return super.getAutoSizeTextAvailableSizes(); 
    c0 c01 = this.g;
    return (c01 != null) ? c01.i.f : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.d;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    c0 c01 = this.g;
    return (c01 != null) ? c01.i.a : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return g.g(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return getPaddingTop() - (getPaint().getFontMetricsInt()).top;
  }
  
  public int getLastBaselineToBottomHeight() {
    return getPaddingBottom() + (getPaint().getFontMetricsInt()).bottom;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.f;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.f;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    b1 b1 = this.g.h;
    return (b1 != null) ? b1.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    b1 b1 = this.g.h;
    return (b1 != null) ? b1.b : null;
  }
  
  public CharSequence getText() {
    Future<b> future = this.k;
    if (future != null)
      try {
        this.k = null;
        g.e(this, future.get());
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {} 
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      a0 a01 = this.h;
      if (a01 != null)
        return a01.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public b.a getTextMetricsParamsCompat() {
    return g.a(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.g.g(this, inputConnection, paramEditorInfo);
    t0.g(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    c0 c01 = this.g;
    if (c01 != null && !b.d)
      c01.i.a(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    Future<b> future = this.k;
    if (future != null)
      try {
        this.k = null;
        g.e(this, future.get());
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {} 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    c0 c01 = this.g;
    if (c01 != null && !b.d && c01.d())
      this.g.i.a(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.d) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    c0 c01 = this.g;
    if (c01 != null)
      c01.h(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.d) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    c0 c01 = this.g;
    if (c01 != null)
      c01.i(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.d) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    c0 c01 = this.g;
    if (c01 != null)
      c01.j(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.f;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.f;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(g.h(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters((getEmojiTextViewHelper()).b.a.a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    g.b(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    g.c(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    g.d(this, paramInt);
  }
  
  public void setPrecomputedText(b paramb) {
    g.e(this, paramb);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.f;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.f;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.g.k(paramColorStateList);
    this.g.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.g.l(paramMode);
    this.g.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.g;
    if (c01 != null)
      c01.f(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      a0 a01 = this.h;
      if (a01 != null) {
        a01.b = paramTextClassifier;
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future<b> paramFuture) {
    this.k = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(b.a parama) {
    int i = Build.VERSION.SDK_INT;
    TextDirectionHeuristic textDirectionHeuristic1 = parama.b;
    TextDirectionHeuristic textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
    byte b1 = 1;
    if (textDirectionHeuristic1 != textDirectionHeuristic2 && textDirectionHeuristic1 != TextDirectionHeuristics.FIRSTSTRONG_LTR)
      if (textDirectionHeuristic1 == TextDirectionHeuristics.ANYRTL_LTR) {
        b1 = 2;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LTR) {
        b1 = 3;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.RTL) {
        b1 = 4;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LOCALE) {
        b1 = 5;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
        b1 = 6;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
        b1 = 7;
      }  
    setTextDirection(b1);
    if (i < 23) {
      float f1 = parama.a.getTextScaleX();
      getPaint().set(parama.a);
      if (f1 == getTextScaleX())
        setTextScaleX(f1 / 2.0F + 1.0F); 
      setTextScaleX(f1);
      return;
    } 
    getPaint().set(parama.a);
    setBreakStrategy(parama.c);
    setHyphenationFrequency(parama.d);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = b.d;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    c0 c01 = this.g;
    if (c01 != null && !bool && !c01.d())
      c01.i.f(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Z
    //   4: ifeq -> 8
    //   7: return
    //   8: aconst_null
    //   9: astore #7
    //   11: aconst_null
    //   12: astore #6
    //   14: aload #7
    //   16: astore #5
    //   18: aload_1
    //   19: ifnull -> 157
    //   22: aload #7
    //   24: astore #5
    //   26: iload_2
    //   27: ifle -> 157
    //   30: aload_0
    //   31: invokevirtual getContext : ()Landroid/content/Context;
    //   34: astore #7
    //   36: getstatic e0/e.a : Le0/k;
    //   39: astore #5
    //   41: aload #7
    //   43: ifnull -> 146
    //   46: getstatic android/os/Build$VERSION.SDK_INT : I
    //   49: bipush #21
    //   51: if_icmpge -> 136
    //   54: getstatic e0/e.a : Le0/k;
    //   57: astore #8
    //   59: aload #8
    //   61: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   64: pop
    //   65: aload_1
    //   66: invokestatic f : (Landroid/graphics/Typeface;)J
    //   69: lstore_3
    //   70: lload_3
    //   71: lconst_0
    //   72: lcmp
    //   73: ifne -> 82
    //   76: aconst_null
    //   77: astore #5
    //   79: goto -> 99
    //   82: aload #8
    //   84: getfield a : Ljava/util/concurrent/ConcurrentHashMap;
    //   87: lload_3
    //   88: invokestatic valueOf : (J)Ljava/lang/Long;
    //   91: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   94: checkcast d0/e$b
    //   97: astore #5
    //   99: aload #5
    //   101: ifnonnull -> 111
    //   104: aload #6
    //   106: astore #5
    //   108: goto -> 128
    //   111: aload #8
    //   113: aload #7
    //   115: aload #5
    //   117: aload #7
    //   119: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   122: iload_2
    //   123: invokevirtual a : (Landroid/content/Context;Ld0/e$b;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    //   126: astore #5
    //   128: aload #5
    //   130: ifnull -> 136
    //   133: goto -> 157
    //   136: aload_1
    //   137: iload_2
    //   138: invokestatic create : (Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;
    //   141: astore #5
    //   143: goto -> 157
    //   146: new java/lang/IllegalArgumentException
    //   149: dup
    //   150: ldc_w 'Context cannot be null'
    //   153: invokespecial <init> : (Ljava/lang/String;)V
    //   156: athrow
    //   157: aload_0
    //   158: iconst_1
    //   159: putfield j : Z
    //   162: aload #5
    //   164: ifnull -> 170
    //   167: aload #5
    //   169: astore_1
    //   170: aload_0
    //   171: aload_1
    //   172: iload_2
    //   173: invokespecial setTypeface : (Landroid/graphics/Typeface;I)V
    //   176: aload_0
    //   177: iconst_0
    //   178: putfield j : Z
    //   181: return
    //   182: astore_1
    //   183: aload_0
    //   184: iconst_0
    //   185: putfield j : Z
    //   188: aload_1
    //   189: athrow
    // Exception table:
    //   from	to	target	type
    //   170	176	182	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */