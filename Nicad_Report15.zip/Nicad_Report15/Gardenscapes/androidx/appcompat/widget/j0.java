package androidx.appcompat.widget;

import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.ScaleDrawable;
import android.os.Build;
import f0.c;
import h.d;

public class j0 {
  public static final int[] a = new int[] { 16842912 };
  
  public static final int[] b = new int[0];
  
  static {
    new Rect();
  }
  
  public static boolean a(Drawable paramDrawable) {
    Drawable[] arrayOfDrawable;
    if (paramDrawable instanceof DrawableContainer) {
      Drawable.ConstantState constantState = paramDrawable.getConstantState();
      if (constantState instanceof DrawableContainer.DrawableContainerState) {
        arrayOfDrawable = ((DrawableContainer.DrawableContainerState)constantState).getChildren();
        int j = arrayOfDrawable.length;
        for (int i = 0; i < j; i++) {
          if (!a(arrayOfDrawable[i]))
            return false; 
        } 
      } 
    } else {
      if (arrayOfDrawable instanceof c)
        return a(((c)arrayOfDrawable).b()); 
      if (arrayOfDrawable instanceof d)
        return a(((d)arrayOfDrawable).f); 
      if (arrayOfDrawable instanceof ScaleDrawable)
        return a(((ScaleDrawable)arrayOfDrawable).getDrawable()); 
    } 
    return true;
  }
  
  public static void b(Drawable paramDrawable) {
    String str = paramDrawable.getClass().getName();
    int i = Build.VERSION.SDK_INT;
    if (i == 21 && "android.graphics.drawable.VectorDrawable".equals(str)) {
      c(paramDrawable);
      return;
    } 
    if (i >= 29 && i < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(str))
      c(paramDrawable); 
  }
  
  public static void c(Drawable paramDrawable) {
    int[] arrayOfInt = paramDrawable.getState();
    if (arrayOfInt == null || arrayOfInt.length == 0) {
      paramDrawable.setState(a);
    } else {
      paramDrawable.setState(b);
    } 
    paramDrawable.setState(arrayOfInt);
  }
  
  public static PorterDuff.Mode d(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */