package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.AlertController;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.t;
import m0.y;

public class z extends Spinner implements t {
  public static final int[] n = new int[] { 16843505 };
  
  public final f f;
  
  public final Context g;
  
  public m0 h;
  
  public SpinnerAdapter i;
  
  public final boolean j;
  
  public f k;
  
  public int l;
  
  public final Rect m;
  
  public z(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield m : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic e/i.v : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/f
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield f : Landroidx/appcompat/widget/f;
    //   50: aload #9
    //   52: iconst_4
    //   53: iconst_0
    //   54: invokevirtual getResourceId : (II)I
    //   57: istore #4
    //   59: iload #4
    //   61: ifeq -> 81
    //   64: aload_0
    //   65: new j/c
    //   68: dup
    //   69: aload_1
    //   70: iload #4
    //   72: invokespecial <init> : (Landroid/content/Context;I)V
    //   75: putfield g : Landroid/content/Context;
    //   78: goto -> 86
    //   81: aload_0
    //   82: aload_1
    //   83: putfield g : Landroid/content/Context;
    //   86: aconst_null
    //   87: astore #7
    //   89: iconst_m1
    //   90: istore #5
    //   92: aload_1
    //   93: aload_2
    //   94: getstatic androidx/appcompat/widget/z.n : [I
    //   97: iload_3
    //   98: iconst_0
    //   99: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   102: astore #6
    //   104: aload #6
    //   106: astore #7
    //   108: iload #5
    //   110: istore #4
    //   112: aload #6
    //   114: astore #8
    //   116: aload #6
    //   118: iconst_0
    //   119: invokevirtual hasValue : (I)Z
    //   122: ifeq -> 200
    //   125: aload #6
    //   127: astore #7
    //   129: aload #6
    //   131: iconst_0
    //   132: iconst_0
    //   133: invokevirtual getInt : (II)I
    //   136: istore #4
    //   138: aload #6
    //   140: astore #8
    //   142: goto -> 200
    //   145: astore_2
    //   146: aload #7
    //   148: astore_1
    //   149: goto -> 426
    //   152: astore #8
    //   154: goto -> 169
    //   157: astore_2
    //   158: aload #7
    //   160: astore_1
    //   161: goto -> 426
    //   164: astore #8
    //   166: aconst_null
    //   167: astore #6
    //   169: aload #6
    //   171: astore #7
    //   173: ldc 'AppCompatSpinner'
    //   175: ldc 'Could not read android:spinnerMode'
    //   177: aload #8
    //   179: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   182: pop
    //   183: iload #5
    //   185: istore #4
    //   187: aload #6
    //   189: ifnull -> 205
    //   192: aload #6
    //   194: astore #8
    //   196: iload #5
    //   198: istore #4
    //   200: aload #8
    //   202: invokevirtual recycle : ()V
    //   205: iload #4
    //   207: ifeq -> 323
    //   210: iload #4
    //   212: iconst_1
    //   213: if_icmpeq -> 219
    //   216: goto -> 350
    //   219: new androidx/appcompat/widget/z$d
    //   222: dup
    //   223: aload_0
    //   224: aload_0
    //   225: getfield g : Landroid/content/Context;
    //   228: aload_2
    //   229: iload_3
    //   230: invokespecial <init> : (Landroidx/appcompat/widget/z;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   233: astore #6
    //   235: aload_0
    //   236: getfield g : Landroid/content/Context;
    //   239: aload_2
    //   240: getstatic e/i.v : [I
    //   243: iload_3
    //   244: iconst_0
    //   245: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/d1;
    //   248: astore #7
    //   250: aload_0
    //   251: aload #7
    //   253: iconst_3
    //   254: bipush #-2
    //   256: invokevirtual k : (II)I
    //   259: putfield l : I
    //   262: aload #7
    //   264: iconst_1
    //   265: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   268: astore #8
    //   270: aload #6
    //   272: getfield D : Landroid/widget/PopupWindow;
    //   275: aload #8
    //   277: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   280: aload #6
    //   282: aload #9
    //   284: iconst_2
    //   285: invokevirtual getString : (I)Ljava/lang/String;
    //   288: putfield H : Ljava/lang/CharSequence;
    //   291: aload #7
    //   293: getfield b : Landroid/content/res/TypedArray;
    //   296: invokevirtual recycle : ()V
    //   299: aload_0
    //   300: aload #6
    //   302: putfield k : Landroidx/appcompat/widget/z$f;
    //   305: aload_0
    //   306: new androidx/appcompat/widget/y
    //   309: dup
    //   310: aload_0
    //   311: aload_0
    //   312: aload #6
    //   314: invokespecial <init> : (Landroidx/appcompat/widget/z;Landroid/view/View;Landroidx/appcompat/widget/z$d;)V
    //   317: putfield h : Landroidx/appcompat/widget/m0;
    //   320: goto -> 350
    //   323: new androidx/appcompat/widget/z$b
    //   326: dup
    //   327: aload_0
    //   328: invokespecial <init> : (Landroidx/appcompat/widget/z;)V
    //   331: astore #6
    //   333: aload_0
    //   334: aload #6
    //   336: putfield k : Landroidx/appcompat/widget/z$f;
    //   339: aload #6
    //   341: aload #9
    //   343: iconst_2
    //   344: invokevirtual getString : (I)Ljava/lang/String;
    //   347: invokevirtual g : (Ljava/lang/CharSequence;)V
    //   350: aload #9
    //   352: iconst_0
    //   353: invokevirtual getTextArray : (I)[Ljava/lang/CharSequence;
    //   356: astore #6
    //   358: aload #6
    //   360: ifnull -> 387
    //   363: new android/widget/ArrayAdapter
    //   366: dup
    //   367: aload_1
    //   368: ldc 17367048
    //   370: aload #6
    //   372: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   375: astore_1
    //   376: aload_1
    //   377: ldc 2131427452
    //   379: invokevirtual setDropDownViewResource : (I)V
    //   382: aload_0
    //   383: aload_1
    //   384: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   387: aload #9
    //   389: invokevirtual recycle : ()V
    //   392: aload_0
    //   393: iconst_1
    //   394: putfield j : Z
    //   397: aload_0
    //   398: getfield i : Landroid/widget/SpinnerAdapter;
    //   401: astore_1
    //   402: aload_1
    //   403: ifnull -> 416
    //   406: aload_0
    //   407: aload_1
    //   408: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   411: aload_0
    //   412: aconst_null
    //   413: putfield i : Landroid/widget/SpinnerAdapter;
    //   416: aload_0
    //   417: getfield f : Landroidx/appcompat/widget/f;
    //   420: aload_2
    //   421: iload_3
    //   422: invokevirtual d : (Landroid/util/AttributeSet;I)V
    //   425: return
    //   426: aload_1
    //   427: ifnull -> 434
    //   430: aload_1
    //   431: invokevirtual recycle : ()V
    //   434: aload_2
    //   435: athrow
    // Exception table:
    //   from	to	target	type
    //   92	104	164	java/lang/Exception
    //   92	104	157	finally
    //   116	125	152	java/lang/Exception
    //   116	125	145	finally
    //   129	138	152	java/lang/Exception
    //   129	138	145	finally
    //   173	183	145	finally
  }
  
  public int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.m);
      Rect rect = this.m;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  public void b() {
    this.k.l(getTextDirection(), getTextAlignment());
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.f;
    if (f1 != null)
      f1.a(); 
  }
  
  public int getDropDownHorizontalOffset() {
    f f1 = this.k;
    return (f1 != null) ? f1.a() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    f f1 = this.k;
    return (f1 != null) ? f1.m() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.k != null) ? this.l : super.getDropDownWidth();
  }
  
  public final f getInternalPopup() {
    return this.k;
  }
  
  public Drawable getPopupBackground() {
    f f1 = this.k;
    return (f1 != null) ? f1.e() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.g;
  }
  
  public CharSequence getPrompt() {
    f f1 = this.k;
    return (f1 != null) ? f1.n() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.f;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.f;
    return (f1 != null) ? f1.c() : null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    f f1 = this.k;
    if (f1 != null && f1.isShowing())
      this.k.dismiss(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.k != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    e e = (e)paramParcelable;
    super.onRestoreInstanceState(e.getSuperState());
    if (e.f) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new a(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    e e = new e(super.onSaveInstanceState());
    f f1 = this.k;
    if (f1 != null && f1.isShowing()) {
      bool = true;
    } else {
      bool = false;
    } 
    e.f = bool;
    return (Parcelable)e;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    m0 m01 = this.h;
    return (m01 != null && m01.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    f f1 = this.k;
    if (f1 != null) {
      if (!f1.isShowing())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.j) {
      this.i = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.k != null) {
      Context context2 = this.g;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.k.o(new c(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.f;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.f;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    f f1 = this.k;
    if (f1 != null) {
      f1.j(paramInt);
      this.k.k(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    f f1 = this.k;
    if (f1 != null) {
      f1.i(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.k != null) {
      this.l = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    f f1 = this.k;
    if (f1 != null) {
      f1.h(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(g.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    f f1 = this.k;
    if (f1 != null) {
      f1.g(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.f;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.f;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(z this$0) {}
    
    public void onGlobalLayout() {
      if (!this.f.getInternalPopup().isShowing())
        this.f.b(); 
      ViewTreeObserver viewTreeObserver = this.f.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeOnGlobalLayoutListener(this); 
    }
  }
  
  public class b implements f, DialogInterface.OnClickListener {
    public androidx.appcompat.app.b f;
    
    public ListAdapter g;
    
    public CharSequence h;
    
    public b(z this$0) {}
    
    public int a() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.b b1 = this.f;
      if (b1 != null) {
        b1.dismiss();
        this.f = null;
      } 
    }
    
    public Drawable e() {
      return null;
    }
    
    public void g(CharSequence param1CharSequence) {
      this.h = param1CharSequence;
    }
    
    public void h(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public void i(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public boolean isShowing() {
      androidx.appcompat.app.b b1 = this.f;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public void j(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int1, int param1Int2) {
      if (this.g == null)
        return; 
      androidx.appcompat.app.b.a a = new androidx.appcompat.app.b.a(this.i.getPopupContext());
      CharSequence charSequence = this.h;
      if (charSequence != null)
        a.a.d = charSequence; 
      ListAdapter listAdapter = this.g;
      int i = this.i.getSelectedItemPosition();
      AlertController.b b2 = a.a;
      b2.g = listAdapter;
      b2.h = this;
      b2.j = i;
      b2.i = true;
      androidx.appcompat.app.b b1 = a.a();
      this.f = b1;
      ListView listView = b1.h.g;
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      this.f.show();
    }
    
    public int m() {
      return 0;
    }
    
    public CharSequence n() {
      return this.h;
    }
    
    public void o(ListAdapter param1ListAdapter) {
      this.g = param1ListAdapter;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.i.setSelection(param1Int);
      if (this.i.getOnItemClickListener() != null)
        this.i.performItemClick(null, param1Int, this.g.getItemId(param1Int)); 
      androidx.appcompat.app.b b1 = this.f;
      if (b1 != null) {
        b1.dismiss();
        this.f = null;
      } 
    }
  }
  
  public static class c implements ListAdapter, SpinnerAdapter {
    public SpinnerAdapter f;
    
    public ListAdapter g;
    
    public c(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.f = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.g = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (themedSpinnerAdapter.getDropDownViewTheme() != param1Theme) {
            themedSpinnerAdapter.setDropDownViewTheme(param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof z0) {
          z0 z0 = (z0)themedSpinnerAdapter;
          if (z0.getDropDownViewTheme() == null)
            z0.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.g;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.g;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.f;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.f;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  public class d extends p0 implements f {
    public CharSequence H;
    
    public ListAdapter I;
    
    public final Rect J = new Rect();
    
    public int K;
    
    public d(z this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int, 0);
      this.t = (View)this$0;
      r(true);
      this.u = new a(this, this$0);
    }
    
    public void g(CharSequence param1CharSequence) {
      this.H = param1CharSequence;
    }
    
    public void j(int param1Int) {
      this.K = param1Int;
    }
    
    public void l(int param1Int1, int param1Int2) {
      boolean bool = isShowing();
      s();
      this.D.setInputMethodMode(2);
      c();
      k0 k0 = this.h;
      k0.setChoiceMode(1);
      k0.setTextDirection(param1Int1);
      k0.setTextAlignment(param1Int2);
      param1Int1 = this.L.getSelectedItemPosition();
      k0 = this.h;
      if (isShowing() && k0 != null) {
        k0.setListSelectionHidden(false);
        k0.setSelection(param1Int1);
        if (k0.getChoiceMode() != 0)
          k0.setItemChecked(param1Int1, true); 
      } 
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.L.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        c c = new c(this, b);
        this.D.setOnDismissListener(c);
      } 
    }
    
    public CharSequence n() {
      return this.H;
    }
    
    public void o(ListAdapter param1ListAdapter) {
      super.o(param1ListAdapter);
      this.I = param1ListAdapter;
    }
    
    public void s() {
      Drawable drawable = e();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.L.m);
        if (l1.b((View)this.L)) {
          i = this.L.m.right;
        } else {
          i = -this.L.m.left;
        } 
      } else {
        Rect rect = this.L.m;
        rect.right = 0;
        rect.left = 0;
      } 
      int k = this.L.getPaddingLeft();
      int m = this.L.getPaddingRight();
      int n = this.L.getWidth();
      z z1 = this.L;
      int j = z1.l;
      if (j == -2) {
        int i1 = z1.a((SpinnerAdapter)this.I, e());
        j = (this.L.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.L.m;
        int i2 = j - rect.left - rect.right;
        j = i1;
        if (i1 > i2)
          j = i2; 
        q(Math.max(j, n - k - m));
      } else if (j == -1) {
        q(n - k - m);
      } else {
        q(j);
      } 
      if (l1.b((View)this.L)) {
        i = n - m - this.j - this.K + i;
      } else {
        i = k + this.K + i;
      } 
      this.k = i;
    }
    
    public class a implements AdapterView.OnItemClickListener {
      public a(z.d this$0, z param2z) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.f.L.setSelection(param2Int);
        if (this.f.L.getOnItemClickListener() != null) {
          z.d d1 = this.f;
          d1.L.performItemClick(param2View, param2Int, d1.I.getItemId(param2Int));
        } 
        this.f.dismiss();
      }
    }
    
    public class b implements ViewTreeObserver.OnGlobalLayoutListener {
      public b(z.d this$0) {}
      
      public void onGlobalLayout() {
        boolean bool;
        z.d d1 = this.f;
        z z = d1.L;
        Objects.requireNonNull(d1);
        WeakHashMap weakHashMap = y.a;
        if (y.g.b((View)z) && z.getGlobalVisibleRect(d1.J)) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          this.f.dismiss();
          return;
        } 
        this.f.s();
        this.f.c();
      }
    }
    
    public class c implements PopupWindow.OnDismissListener {
      public c(z.d this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.g.L.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.f); 
      }
    }
  }
  
  public class a implements AdapterView.OnItemClickListener {
    public a(z this$0, z param1z) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.f.L.setSelection(param1Int);
      if (this.f.L.getOnItemClickListener() != null) {
        z.d d1 = this.f;
        d1.L.performItemClick(param1View, param1Int, d1.I.getItemId(param1Int));
      } 
      this.f.dismiss();
    }
  }
  
  public class b implements ViewTreeObserver.OnGlobalLayoutListener {
    public b(z this$0) {}
    
    public void onGlobalLayout() {
      boolean bool;
      z.d d1 = this.f;
      z z = d1.L;
      Objects.requireNonNull(d1);
      WeakHashMap weakHashMap = y.a;
      if (y.g.b((View)z) && z.getGlobalVisibleRect(d1.J)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        this.f.dismiss();
        return;
      } 
      this.f.s();
      this.f.c();
    }
  }
  
  public class c implements PopupWindow.OnDismissListener {
    public c(z this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.g.L.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.f); 
    }
  }
  
  public static class e extends View.BaseSavedState {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    public boolean f;
    
    public e(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = bool;
    }
    
    public e(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.f);
    }
    
    public class a implements Parcelable.Creator<e> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new z.e(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new z.e[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<e> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new z.e(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new z.e[param1Int];
    }
  }
  
  public static interface f {
    int a();
    
    void dismiss();
    
    Drawable e();
    
    void g(CharSequence param1CharSequence);
    
    void h(Drawable param1Drawable);
    
    void i(int param1Int);
    
    boolean isShowing();
    
    void j(int param1Int);
    
    void k(int param1Int);
    
    void l(int param1Int1, int param1Int2);
    
    int m();
    
    CharSequence n();
    
    void o(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */