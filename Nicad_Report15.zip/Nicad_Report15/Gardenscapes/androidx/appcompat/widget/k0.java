package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import h.d;
import java.lang.reflect.Field;
import q0.e;

public class k0 extends ListView {
  public final Rect f = new Rect();
  
  public int g = 0;
  
  public int h = 0;
  
  public int i = 0;
  
  public int j = 0;
  
  public int k;
  
  public Field l;
  
  public a m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public e q;
  
  public b r;
  
  public k0(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, 2130903386);
    this.o = paramBoolean;
    setCacheColorHint(0);
    try {
      Field field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.l = field;
      field.setAccessible(true);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
      return;
    } 
  }
  
  private void setSelectorEnabled(boolean paramBoolean) {
    a a1 = this.m;
    if (a1 != null)
      a1.g = paramBoolean; 
  }
  
  public int a(int paramInt1, int paramInt2, int paramInt3) {
    int i = getListPaddingTop();
    int j = getListPaddingBottom();
    int k = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    if (listAdapter == null)
      return i + j; 
    j = i + j;
    if (k <= 0 || drawable == null)
      k = 0; 
    int i1 = listAdapter.getCount();
    drawable = null;
    int m = 0;
    int n = 0;
    for (i = 0; m < i1; i = i3) {
      int i3 = listAdapter.getItemViewType(m);
      int i2 = n;
      if (i3 != n) {
        drawable = null;
        i2 = i3;
      } 
      View view2 = listAdapter.getView(m, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      n = layoutParams1.height;
      if (n > 0) {
        n = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
      } else {
        n = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, n);
      view2.forceLayout();
      n = j;
      if (m > 0)
        n = j + k; 
      j = n + view2.getMeasuredHeight();
      if (j >= paramInt2) {
        paramInt1 = paramInt2;
        if (paramInt3 >= 0) {
          paramInt1 = paramInt2;
          if (m > paramInt3) {
            paramInt1 = paramInt2;
            if (i > 0) {
              paramInt1 = paramInt2;
              if (j != paramInt2)
                paramInt1 = i; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i3 = i;
      if (paramInt3 >= 0) {
        i3 = i;
        if (m >= paramInt3)
          i3 = j; 
      } 
      m++;
      n = i2;
      View view1 = view2;
    } 
    return j;
  }
  
  public boolean b(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #8
    //   6: iconst_1
    //   7: istore #7
    //   9: iload #8
    //   11: iconst_1
    //   12: if_icmpeq -> 36
    //   15: iload #8
    //   17: iconst_2
    //   18: if_icmpeq -> 30
    //   21: iload #8
    //   23: iconst_3
    //   24: if_icmpeq -> 51
    //   27: goto -> 569
    //   30: iconst_1
    //   31: istore #11
    //   33: goto -> 39
    //   36: iconst_0
    //   37: istore #11
    //   39: aload_1
    //   40: iload_2
    //   41: invokevirtual findPointerIndex : (I)I
    //   44: istore #9
    //   46: iload #9
    //   48: ifge -> 57
    //   51: iconst_0
    //   52: istore #11
    //   54: goto -> 572
    //   57: aload_1
    //   58: iload #9
    //   60: invokevirtual getX : (I)F
    //   63: f2i
    //   64: istore_2
    //   65: aload_1
    //   66: iload #9
    //   68: invokevirtual getY : (I)F
    //   71: f2i
    //   72: istore #10
    //   74: aload_0
    //   75: iload_2
    //   76: iload #10
    //   78: invokevirtual pointToPosition : (II)I
    //   81: istore #9
    //   83: iload #9
    //   85: iconst_m1
    //   86: if_icmpne -> 95
    //   89: iload #7
    //   91: istore_2
    //   92: goto -> 574
    //   95: aload_0
    //   96: iload #9
    //   98: aload_0
    //   99: invokevirtual getFirstVisiblePosition : ()I
    //   102: isub
    //   103: invokevirtual getChildAt : (I)Landroid/view/View;
    //   106: astore #13
    //   108: iload_2
    //   109: i2f
    //   110: fstore_3
    //   111: iload #10
    //   113: i2f
    //   114: fstore #4
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield p : Z
    //   121: getstatic android/os/Build$VERSION.SDK_INT : I
    //   124: istore_2
    //   125: iload_2
    //   126: bipush #21
    //   128: if_icmplt -> 138
    //   131: aload_0
    //   132: fload_3
    //   133: fload #4
    //   135: invokevirtual drawableHotspotChanged : (FF)V
    //   138: aload_0
    //   139: invokevirtual isPressed : ()Z
    //   142: ifne -> 150
    //   145: aload_0
    //   146: iconst_1
    //   147: invokevirtual setPressed : (Z)V
    //   150: aload_0
    //   151: invokevirtual layoutChildren : ()V
    //   154: aload_0
    //   155: getfield k : I
    //   158: istore #7
    //   160: iload #7
    //   162: iconst_m1
    //   163: if_icmpeq -> 205
    //   166: aload_0
    //   167: iload #7
    //   169: aload_0
    //   170: invokevirtual getFirstVisiblePosition : ()I
    //   173: isub
    //   174: invokevirtual getChildAt : (I)Landroid/view/View;
    //   177: astore #14
    //   179: aload #14
    //   181: ifnull -> 205
    //   184: aload #14
    //   186: aload #13
    //   188: if_acmpeq -> 205
    //   191: aload #14
    //   193: invokevirtual isPressed : ()Z
    //   196: ifeq -> 205
    //   199: aload #14
    //   201: iconst_0
    //   202: invokevirtual setPressed : (Z)V
    //   205: aload_0
    //   206: iload #9
    //   208: putfield k : I
    //   211: aload #13
    //   213: invokevirtual getLeft : ()I
    //   216: i2f
    //   217: fstore #5
    //   219: aload #13
    //   221: invokevirtual getTop : ()I
    //   224: i2f
    //   225: fstore #6
    //   227: iload_2
    //   228: bipush #21
    //   230: if_icmplt -> 247
    //   233: aload #13
    //   235: fload_3
    //   236: fload #5
    //   238: fsub
    //   239: fload #4
    //   241: fload #6
    //   243: fsub
    //   244: invokevirtual drawableHotspotChanged : (FF)V
    //   247: aload #13
    //   249: invokevirtual isPressed : ()Z
    //   252: ifne -> 261
    //   255: aload #13
    //   257: iconst_1
    //   258: invokevirtual setPressed : (Z)V
    //   261: aload_0
    //   262: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   265: astore #14
    //   267: aload #14
    //   269: ifnull -> 283
    //   272: iload #9
    //   274: iconst_m1
    //   275: if_icmpeq -> 283
    //   278: iconst_1
    //   279: istore_2
    //   280: goto -> 285
    //   283: iconst_0
    //   284: istore_2
    //   285: iload_2
    //   286: ifeq -> 297
    //   289: aload #14
    //   291: iconst_0
    //   292: iconst_0
    //   293: invokevirtual setVisible : (ZZ)Z
    //   296: pop
    //   297: aload_0
    //   298: getfield f : Landroid/graphics/Rect;
    //   301: astore #15
    //   303: aload #15
    //   305: aload #13
    //   307: invokevirtual getLeft : ()I
    //   310: aload #13
    //   312: invokevirtual getTop : ()I
    //   315: aload #13
    //   317: invokevirtual getRight : ()I
    //   320: aload #13
    //   322: invokevirtual getBottom : ()I
    //   325: invokevirtual set : (IIII)V
    //   328: aload #15
    //   330: aload #15
    //   332: getfield left : I
    //   335: aload_0
    //   336: getfield g : I
    //   339: isub
    //   340: putfield left : I
    //   343: aload #15
    //   345: aload #15
    //   347: getfield top : I
    //   350: aload_0
    //   351: getfield h : I
    //   354: isub
    //   355: putfield top : I
    //   358: aload #15
    //   360: aload #15
    //   362: getfield right : I
    //   365: aload_0
    //   366: getfield i : I
    //   369: iadd
    //   370: putfield right : I
    //   373: aload #15
    //   375: aload #15
    //   377: getfield bottom : I
    //   380: aload_0
    //   381: getfield j : I
    //   384: iadd
    //   385: putfield bottom : I
    //   388: aload_0
    //   389: getfield l : Ljava/lang/reflect/Field;
    //   392: aload_0
    //   393: invokevirtual getBoolean : (Ljava/lang/Object;)Z
    //   396: istore #11
    //   398: aload #13
    //   400: invokevirtual isEnabled : ()Z
    //   403: iload #11
    //   405: if_icmpeq -> 456
    //   408: aload_0
    //   409: getfield l : Ljava/lang/reflect/Field;
    //   412: astore #15
    //   414: iload #11
    //   416: ifne -> 705
    //   419: iconst_1
    //   420: istore #11
    //   422: goto -> 425
    //   425: aload #15
    //   427: aload_0
    //   428: iload #11
    //   430: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   433: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   436: iload #9
    //   438: iconst_m1
    //   439: if_icmpeq -> 456
    //   442: aload_0
    //   443: invokevirtual refreshDrawableState : ()V
    //   446: goto -> 456
    //   449: astore #15
    //   451: aload #15
    //   453: invokevirtual printStackTrace : ()V
    //   456: iload_2
    //   457: ifeq -> 514
    //   460: aload_0
    //   461: getfield f : Landroid/graphics/Rect;
    //   464: astore #15
    //   466: aload #15
    //   468: invokevirtual exactCenterX : ()F
    //   471: fstore #5
    //   473: aload #15
    //   475: invokevirtual exactCenterY : ()F
    //   478: fstore #6
    //   480: aload_0
    //   481: invokevirtual getVisibility : ()I
    //   484: ifne -> 493
    //   487: iconst_1
    //   488: istore #11
    //   490: goto -> 496
    //   493: iconst_0
    //   494: istore #11
    //   496: aload #14
    //   498: iload #11
    //   500: iconst_0
    //   501: invokevirtual setVisible : (ZZ)Z
    //   504: pop
    //   505: aload #14
    //   507: fload #5
    //   509: fload #6
    //   511: invokestatic e : (Landroid/graphics/drawable/Drawable;FF)V
    //   514: aload_0
    //   515: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   518: astore #14
    //   520: aload #14
    //   522: ifnull -> 539
    //   525: iload #9
    //   527: iconst_m1
    //   528: if_icmpeq -> 539
    //   531: aload #14
    //   533: fload_3
    //   534: fload #4
    //   536: invokestatic e : (Landroid/graphics/drawable/Drawable;FF)V
    //   539: aload_0
    //   540: iconst_0
    //   541: invokespecial setSelectorEnabled : (Z)V
    //   544: aload_0
    //   545: invokevirtual refreshDrawableState : ()V
    //   548: iload #8
    //   550: iconst_1
    //   551: if_icmpne -> 569
    //   554: aload_0
    //   555: aload #13
    //   557: iload #9
    //   559: aload_0
    //   560: iload #9
    //   562: invokevirtual getItemIdAtPosition : (I)J
    //   565: invokevirtual performItemClick : (Landroid/view/View;IJ)Z
    //   568: pop
    //   569: iconst_1
    //   570: istore #11
    //   572: iconst_0
    //   573: istore_2
    //   574: iload #11
    //   576: ifeq -> 583
    //   579: iload_2
    //   580: ifeq -> 623
    //   583: aload_0
    //   584: iconst_0
    //   585: putfield p : Z
    //   588: aload_0
    //   589: iconst_0
    //   590: invokevirtual setPressed : (Z)V
    //   593: aload_0
    //   594: invokevirtual drawableStateChanged : ()V
    //   597: aload_0
    //   598: aload_0
    //   599: getfield k : I
    //   602: aload_0
    //   603: invokevirtual getFirstVisiblePosition : ()I
    //   606: isub
    //   607: invokevirtual getChildAt : (I)Landroid/view/View;
    //   610: astore #13
    //   612: aload #13
    //   614: ifnull -> 623
    //   617: aload #13
    //   619: iconst_0
    //   620: invokevirtual setPressed : (Z)V
    //   623: iload #11
    //   625: ifeq -> 677
    //   628: aload_0
    //   629: getfield q : Lq0/e;
    //   632: ifnonnull -> 647
    //   635: aload_0
    //   636: new q0/e
    //   639: dup
    //   640: aload_0
    //   641: invokespecial <init> : (Landroid/widget/ListView;)V
    //   644: putfield q : Lq0/e;
    //   647: aload_0
    //   648: getfield q : Lq0/e;
    //   651: astore #13
    //   653: aload #13
    //   655: getfield u : Z
    //   658: istore #12
    //   660: aload #13
    //   662: iconst_1
    //   663: putfield u : Z
    //   666: aload #13
    //   668: aload_0
    //   669: aload_1
    //   670: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   673: pop
    //   674: iload #11
    //   676: ireturn
    //   677: aload_0
    //   678: getfield q : Lq0/e;
    //   681: astore_1
    //   682: aload_1
    //   683: ifnull -> 702
    //   686: aload_1
    //   687: getfield u : Z
    //   690: ifeq -> 697
    //   693: aload_1
    //   694: invokevirtual e : ()V
    //   697: aload_1
    //   698: iconst_0
    //   699: putfield u : Z
    //   702: iload #11
    //   704: ireturn
    //   705: iconst_0
    //   706: istore #11
    //   708: goto -> 425
    // Exception table:
    //   from	to	target	type
    //   388	414	449	java/lang/IllegalAccessException
    //   425	436	449	java/lang/IllegalAccessException
    //   442	446	449	java/lang/IllegalAccessException
  }
  
  public final void c() {
    Drawable drawable = getSelector();
    if (drawable != null && this.p && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (!this.f.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.f);
        drawable.draw(paramCanvas);
      } 
    } 
    super.dispatchDraw(paramCanvas);
  }
  
  public void drawableStateChanged() {
    if (this.r != null)
      return; 
    super.drawableStateChanged();
    setSelectorEnabled(true);
    c();
  }
  
  public boolean hasFocus() {
    return (this.o || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.o || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.o || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.o && this.n) || super.isInTouchMode());
  }
  
  public void onDetachedFromWindow() {
    this.r = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int i = paramMotionEvent.getActionMasked();
    if (i == 10 && this.r == null) {
      b b1 = new b(this);
      this.r = b1;
      post(b1);
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (i == 9 || i == 7) {
      i = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (i != -1 && i != getSelectedItemPosition()) {
        View view = getChildAt(i - getFirstVisiblePosition());
        if (view.isEnabled())
          setSelectionFromTop(i, view.getTop() - getTop()); 
        c();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.k = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    b b1 = this.r;
    if (b1 != null) {
      k0 k01 = b1.f;
      k01.r = null;
      k01.removeCallbacks(b1);
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setListSelectionHidden(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    a a1;
    if (paramDrawable != null) {
      a1 = new a(paramDrawable);
    } else {
      a1 = null;
    } 
    this.m = a1;
    super.setSelector((Drawable)a1);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.g = rect.left;
    this.h = rect.top;
    this.i = rect.right;
    this.j = rect.bottom;
  }
  
  public static class a extends d {
    public boolean g = true;
    
    public a(Drawable param1Drawable) {
      super(param1Drawable);
    }
    
    public void draw(Canvas param1Canvas) {
      if (this.g)
        this.f.draw(param1Canvas); 
    }
    
    public void setHotspot(float param1Float1, float param1Float2) {
      if (this.g)
        f0.a.e(this.f, param1Float1, param1Float2); 
    }
    
    public void setHotspotBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.g)
        f0.a.f(this.f, param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public boolean setState(int[] param1ArrayOfint) {
      return this.g ? this.f.setState(param1ArrayOfint) : false;
    }
    
    public boolean setVisible(boolean param1Boolean1, boolean param1Boolean2) {
      return this.g ? super.setVisible(param1Boolean1, param1Boolean2) : false;
    }
  }
  
  public class b implements Runnable {
    public b(k0 this$0) {}
    
    public void run() {
      k0 k01 = this.f;
      k01.r = null;
      k01.drawableStateChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */