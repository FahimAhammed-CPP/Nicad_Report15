package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.l;
import java.util.ArrayList;
import java.util.Objects;

public class c extends a {
  public b A;
  
  public final f B = new f(this);
  
  public d n;
  
  public Drawable o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public boolean v;
  
  public final SparseBooleanArray w = new SparseBooleanArray();
  
  public e x;
  
  public a y;
  
  public c z;
  
  public c(Context paramContext) {
    super(paramContext, 2131427331, 2131427330);
  }
  
  public void a(androidx.appcompat.view.menu.e parame, boolean paramBoolean) {
    c();
    i.a a1 = this.j;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public void b(Context paramContext, androidx.appcompat.view.menu.e parame) {
    this.g = paramContext;
    LayoutInflater.from(paramContext);
    this.h = parame;
    Resources resources = paramContext.getResources();
    if (!this.r)
      this.q = true; 
    int j = (paramContext.getResources().getDisplayMetrics()).widthPixels;
    int i = 2;
    this.s = j / 2;
    Configuration configuration = paramContext.getResources().getConfiguration();
    j = configuration.screenWidthDp;
    int k = configuration.screenHeightDp;
    if (configuration.smallestScreenWidthDp > 600 || j > 600 || (j > 960 && k > 720) || (j > 720 && k > 960)) {
      i = 5;
    } else if (j >= 500 || (j > 640 && k > 480) || (j > 480 && k > 640)) {
      i = 4;
    } else if (j >= 360) {
      i = 3;
    } 
    this.u = i;
    i = this.s;
    if (this.q) {
      if (this.n == null) {
        d d1 = new d(this, this.f);
        this.n = d1;
        if (this.p) {
          d1.setImageDrawable(this.o);
          this.o = null;
          this.p = false;
        } 
        j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.n.measure(j, j);
      } 
      i -= this.n.getMeasuredWidth();
    } else {
      this.n = null;
    } 
    this.t = i;
    float f1 = (resources.getDisplayMetrics()).density;
  }
  
  public boolean c() {
    return k() | l();
  }
  
  public boolean d(l paraml) {
    boolean bool = paraml.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    l l1 = paraml;
    while (true) {
      View view;
      androidx.appcompat.view.menu.e e1 = l1.z;
      if (e1 != this.h) {
        l1 = (l)e1;
        continue;
      } 
      g g = l1.A;
      ViewGroup viewGroup = (ViewGroup)this.m;
      e1 = null;
      if (viewGroup == null) {
        androidx.appcompat.view.menu.e e2 = e1;
      } else {
        int m = viewGroup.getChildCount();
        int k = 0;
        while (true) {
          androidx.appcompat.view.menu.e e2 = e1;
          if (k < m) {
            view = viewGroup.getChildAt(k);
            if (view instanceof j.a && ((j.a)view).getItemData() == g)
              break; 
            k++;
            continue;
          } 
          break;
        } 
      } 
      if (view == null)
        return false; 
      Objects.requireNonNull(paraml.A);
      int j = paraml.size();
      int i = 0;
      while (true) {
        bool = bool1;
        if (i < j) {
          MenuItem menuItem = paraml.getItem(i);
          if (menuItem.isVisible() && menuItem.getIcon() != null) {
            bool = true;
            break;
          } 
          i++;
          continue;
        } 
        break;
      } 
      a a1 = new a(this, this.g, paraml, view);
      this.y = a1;
      a1.h = bool;
      k.d d1 = a1.j;
      if (d1 != null)
        d1.n(bool); 
      if (this.y.f()) {
        i.a a2 = this.j;
        if (a2 != null)
          a2.b((androidx.appcompat.view.menu.e)paraml); 
        return true;
      } 
      IllegalStateException illegalStateException = new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
      throw illegalStateException;
    } 
  }
  
  public void e(boolean paramBoolean) {
    ArrayList arrayList;
    ViewGroup viewGroup = (ViewGroup)this.m;
    androidx.appcompat.view.menu.e e2 = null;
    byte b1 = 0;
    if (viewGroup != null) {
      int j;
      androidx.appcompat.view.menu.e e4 = this.h;
      if (e4 != null) {
        e4.i();
        ArrayList<g> arrayList1 = this.h.l();
        int n = arrayList1.size();
        int m = 0;
        int k = 0;
        while (true) {
          j = k;
          if (m < n) {
            g g = arrayList1.get(m);
            j = k;
            if (g.g()) {
              View view1 = viewGroup.getChildAt(k);
              if (view1 instanceof j.a) {
                g g1 = ((j.a)view1).getItemData();
              } else {
                e4 = null;
              } 
              View view2 = f(g, view1, viewGroup);
              if (g != e4) {
                view2.setPressed(false);
                view2.jumpDrawablesToCurrentState();
              } 
              if (view2 != view1) {
                ViewGroup viewGroup1 = (ViewGroup)view2.getParent();
                if (viewGroup1 != null)
                  viewGroup1.removeView(view2); 
                ((ViewGroup)this.m).addView(view2, k);
              } 
              j = k + 1;
            } 
            m++;
            k = j;
            continue;
          } 
          break;
        } 
      } else {
        j = 0;
      } 
      while (j < viewGroup.getChildCount()) {
        boolean bool;
        if (viewGroup.getChildAt(j) == this.n) {
          bool = false;
        } else {
          viewGroup.removeViewAt(j);
          bool = true;
        } 
        if (!bool)
          j++; 
      } 
    } 
    ((View)this.m).requestLayout();
    androidx.appcompat.view.menu.e e1 = this.h;
    if (e1 != null) {
      e1.i();
      arrayList = e1.i;
      int k = arrayList.size();
      for (int j = 0; j < k; j++)
        m0.b b2 = ((g)arrayList.get(j)).A; 
    } 
    androidx.appcompat.view.menu.e e3 = this.h;
    e1 = e2;
    if (e3 != null) {
      e3.i();
      arrayList = e3.j;
    } 
    int i = b1;
    if (this.q) {
      i = b1;
      if (arrayList != null) {
        int j = arrayList.size();
        if (j == 1) {
          i = ((g)arrayList.get(0)).C ^ true;
        } else {
          i = b1;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.n == null)
        this.n = new d(this, this.f); 
      ViewGroup viewGroup1 = (ViewGroup)this.n.getParent();
      if (viewGroup1 != this.m) {
        if (viewGroup1 != null)
          viewGroup1.removeView((View)this.n); 
        viewGroup1 = (ActionMenuView)this.m;
        d d1 = this.n;
        ActionMenuView.c c1 = viewGroup1.l();
        c1.a = true;
        viewGroup1.addView((View)d1, (ViewGroup.LayoutParams)c1);
      } 
    } else {
      d d1 = this.n;
      if (d1 != null) {
        ViewParent viewParent = d1.getParent();
        j j = this.m;
        if (viewParent == j)
          ((ViewGroup)j).removeView((View)this.n); 
      } 
    } 
    ((ActionMenuView)this.m).setOverflowReserved(this.q);
  }
  
  public View f(g paramg, View paramView, ViewGroup paramViewGroup) {
    View view = paramg.getActionView();
    byte b1 = 0;
    if (view == null || paramg.f()) {
      j.a a1;
      if (paramView instanceof j.a) {
        a1 = (j.a)paramView;
      } else {
        a1 = (j.a)this.i.inflate(this.l, paramViewGroup, false);
      } 
      a1.d(paramg, 0);
      ActionMenuView actionMenuView1 = (ActionMenuView)this.m;
      ActionMenuItemView actionMenuItemView = (ActionMenuItemView)a1;
      actionMenuItemView.setItemInvoker(actionMenuView1);
      if (this.A == null)
        this.A = new b(this); 
      actionMenuItemView.setPopupCallback(this.A);
      view = (View)a1;
    } 
    if (paramg.C)
      b1 = 8; 
    view.setVisibility(b1);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.m(layoutParams)); 
    return view;
  }
  
  public boolean g() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Landroidx/appcompat/view/menu/e;
    //   4: astore #14
    //   6: aload #14
    //   8: ifnull -> 28
    //   11: aload #14
    //   13: invokevirtual l : ()Ljava/util/ArrayList;
    //   16: astore #14
    //   18: aload #14
    //   20: invokevirtual size : ()I
    //   23: istore #6
    //   25: goto -> 34
    //   28: aconst_null
    //   29: astore #14
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: getfield u : I
    //   38: istore_1
    //   39: aload_0
    //   40: getfield t : I
    //   43: istore #8
    //   45: iconst_0
    //   46: iconst_0
    //   47: invokestatic makeMeasureSpec : (II)I
    //   50: istore #9
    //   52: aload_0
    //   53: getfield m : Landroidx/appcompat/view/menu/j;
    //   56: checkcast android/view/ViewGroup
    //   59: astore #15
    //   61: iconst_0
    //   62: istore_3
    //   63: iconst_0
    //   64: istore #5
    //   66: iconst_0
    //   67: istore #4
    //   69: iconst_0
    //   70: istore_2
    //   71: iload_3
    //   72: iload #6
    //   74: if_icmpge -> 192
    //   77: aload #14
    //   79: iload_3
    //   80: invokevirtual get : (I)Ljava/lang/Object;
    //   83: checkcast androidx/appcompat/view/menu/g
    //   86: astore #16
    //   88: aload #16
    //   90: getfield y : I
    //   93: istore #10
    //   95: iload #10
    //   97: iconst_2
    //   98: iand
    //   99: iconst_2
    //   100: if_icmpne -> 109
    //   103: iconst_1
    //   104: istore #7
    //   106: goto -> 112
    //   109: iconst_0
    //   110: istore #7
    //   112: iload #7
    //   114: ifeq -> 124
    //   117: iload_2
    //   118: iconst_1
    //   119: iadd
    //   120: istore_2
    //   121: goto -> 158
    //   124: iload #10
    //   126: iconst_1
    //   127: iand
    //   128: iconst_1
    //   129: if_icmpne -> 138
    //   132: iconst_1
    //   133: istore #7
    //   135: goto -> 141
    //   138: iconst_0
    //   139: istore #7
    //   141: iload #7
    //   143: ifeq -> 155
    //   146: iload #4
    //   148: iconst_1
    //   149: iadd
    //   150: istore #4
    //   152: goto -> 158
    //   155: iconst_1
    //   156: istore #5
    //   158: iload_1
    //   159: istore #7
    //   161: aload_0
    //   162: getfield v : Z
    //   165: ifeq -> 182
    //   168: iload_1
    //   169: istore #7
    //   171: aload #16
    //   173: getfield C : Z
    //   176: ifeq -> 182
    //   179: iconst_0
    //   180: istore #7
    //   182: iload_3
    //   183: iconst_1
    //   184: iadd
    //   185: istore_3
    //   186: iload #7
    //   188: istore_1
    //   189: goto -> 71
    //   192: iload_1
    //   193: istore_3
    //   194: aload_0
    //   195: getfield q : Z
    //   198: ifeq -> 220
    //   201: iload #5
    //   203: ifne -> 216
    //   206: iload_1
    //   207: istore_3
    //   208: iload #4
    //   210: iload_2
    //   211: iadd
    //   212: iload_1
    //   213: if_icmple -> 220
    //   216: iload_1
    //   217: iconst_1
    //   218: isub
    //   219: istore_3
    //   220: iload_3
    //   221: iload_2
    //   222: isub
    //   223: istore_1
    //   224: aload_0
    //   225: getfield w : Landroid/util/SparseBooleanArray;
    //   228: astore #16
    //   230: aload #16
    //   232: invokevirtual clear : ()V
    //   235: iconst_0
    //   236: istore #7
    //   238: iconst_0
    //   239: istore_2
    //   240: iload #8
    //   242: istore_3
    //   243: iload #7
    //   245: iload #6
    //   247: if_icmpge -> 646
    //   250: aload #14
    //   252: iload #7
    //   254: invokevirtual get : (I)Ljava/lang/Object;
    //   257: checkcast androidx/appcompat/view/menu/g
    //   260: astore #17
    //   262: aload #17
    //   264: getfield y : I
    //   267: istore #5
    //   269: iload #5
    //   271: iconst_2
    //   272: iand
    //   273: iconst_2
    //   274: if_icmpne -> 283
    //   277: iconst_1
    //   278: istore #4
    //   280: goto -> 286
    //   283: iconst_0
    //   284: istore #4
    //   286: iload #4
    //   288: ifeq -> 359
    //   291: aload_0
    //   292: aload #17
    //   294: aconst_null
    //   295: aload #15
    //   297: invokevirtual f : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   300: astore #18
    //   302: aload #18
    //   304: iload #9
    //   306: iload #9
    //   308: invokevirtual measure : (II)V
    //   311: aload #18
    //   313: invokevirtual getMeasuredWidth : ()I
    //   316: istore #5
    //   318: iload_3
    //   319: iload #5
    //   321: isub
    //   322: istore #4
    //   324: iload_2
    //   325: istore_3
    //   326: iload_2
    //   327: ifne -> 333
    //   330: iload #5
    //   332: istore_3
    //   333: aload #17
    //   335: getfield b : I
    //   338: istore_2
    //   339: iload_2
    //   340: ifeq -> 350
    //   343: aload #16
    //   345: iload_2
    //   346: iconst_1
    //   347: invokevirtual put : (IZ)V
    //   350: aload #17
    //   352: iconst_1
    //   353: invokevirtual k : (Z)V
    //   356: goto -> 620
    //   359: iload #5
    //   361: iconst_1
    //   362: iand
    //   363: iconst_1
    //   364: if_icmpne -> 373
    //   367: iconst_1
    //   368: istore #4
    //   370: goto -> 376
    //   373: iconst_0
    //   374: istore #4
    //   376: iload #4
    //   378: ifeq -> 625
    //   381: aload #17
    //   383: getfield b : I
    //   386: istore #10
    //   388: aload #16
    //   390: iload #10
    //   392: invokevirtual get : (I)Z
    //   395: istore #13
    //   397: iload_1
    //   398: ifgt -> 406
    //   401: iload #13
    //   403: ifeq -> 416
    //   406: iload_3
    //   407: ifle -> 416
    //   410: iconst_1
    //   411: istore #11
    //   413: goto -> 419
    //   416: iconst_0
    //   417: istore #11
    //   419: iload_3
    //   420: istore #4
    //   422: iload_2
    //   423: istore #5
    //   425: iload #11
    //   427: istore #12
    //   429: iload #11
    //   431: ifeq -> 499
    //   434: aload_0
    //   435: aload #17
    //   437: aconst_null
    //   438: aload #15
    //   440: invokevirtual f : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   443: astore #18
    //   445: aload #18
    //   447: iload #9
    //   449: iload #9
    //   451: invokevirtual measure : (II)V
    //   454: aload #18
    //   456: invokevirtual getMeasuredWidth : ()I
    //   459: istore #8
    //   461: iload_3
    //   462: iload #8
    //   464: isub
    //   465: istore #4
    //   467: iload_2
    //   468: istore #5
    //   470: iload_2
    //   471: ifne -> 478
    //   474: iload #8
    //   476: istore #5
    //   478: iload #4
    //   480: iload #5
    //   482: iadd
    //   483: ifle -> 491
    //   486: iconst_1
    //   487: istore_2
    //   488: goto -> 493
    //   491: iconst_0
    //   492: istore_2
    //   493: iload #11
    //   495: iload_2
    //   496: iand
    //   497: istore #12
    //   499: iload #12
    //   501: ifeq -> 522
    //   504: iload #10
    //   506: ifeq -> 522
    //   509: aload #16
    //   511: iload #10
    //   513: iconst_1
    //   514: invokevirtual put : (IZ)V
    //   517: iload_1
    //   518: istore_2
    //   519: goto -> 599
    //   522: iload_1
    //   523: istore_2
    //   524: iload #13
    //   526: ifeq -> 599
    //   529: aload #16
    //   531: iload #10
    //   533: iconst_0
    //   534: invokevirtual put : (IZ)V
    //   537: iconst_0
    //   538: istore_3
    //   539: iload_1
    //   540: istore_2
    //   541: iload_3
    //   542: iload #7
    //   544: if_icmpge -> 599
    //   547: aload #14
    //   549: iload_3
    //   550: invokevirtual get : (I)Ljava/lang/Object;
    //   553: checkcast androidx/appcompat/view/menu/g
    //   556: astore #18
    //   558: iload_1
    //   559: istore_2
    //   560: aload #18
    //   562: getfield b : I
    //   565: iload #10
    //   567: if_icmpne -> 590
    //   570: iload_1
    //   571: istore_2
    //   572: aload #18
    //   574: invokevirtual g : ()Z
    //   577: ifeq -> 584
    //   580: iload_1
    //   581: iconst_1
    //   582: iadd
    //   583: istore_2
    //   584: aload #18
    //   586: iconst_0
    //   587: invokevirtual k : (Z)V
    //   590: iload_3
    //   591: iconst_1
    //   592: iadd
    //   593: istore_3
    //   594: iload_2
    //   595: istore_1
    //   596: goto -> 539
    //   599: iload_2
    //   600: istore_1
    //   601: iload #12
    //   603: ifeq -> 610
    //   606: iload_2
    //   607: iconst_1
    //   608: isub
    //   609: istore_1
    //   610: aload #17
    //   612: iload #12
    //   614: invokevirtual k : (Z)V
    //   617: iload #5
    //   619: istore_3
    //   620: iload_3
    //   621: istore_2
    //   622: goto -> 634
    //   625: aload #17
    //   627: iconst_0
    //   628: invokevirtual k : (Z)V
    //   631: iload_3
    //   632: istore #4
    //   634: iload #7
    //   636: iconst_1
    //   637: iadd
    //   638: istore #7
    //   640: iload #4
    //   642: istore_3
    //   643: goto -> 243
    //   646: iconst_1
    //   647: ireturn
  }
  
  public boolean k() {
    c c1 = this.z;
    if (c1 != null) {
      j j = this.m;
      if (j != null) {
        ((View)j).removeCallbacks(c1);
        this.z = null;
        return true;
      } 
    } 
    e e1 = this.x;
    if (e1 != null) {
      if (e1.b())
        e1.j.dismiss(); 
      return true;
    } 
    return false;
  }
  
  public boolean l() {
    a a1 = this.y;
    if (a1 != null) {
      if (a1.b())
        a1.j.dismiss(); 
      return true;
    } 
    return false;
  }
  
  public boolean m() {
    e e1 = this.x;
    return (e1 != null && e1.b());
  }
  
  public boolean n() {
    if (this.q && !m()) {
      androidx.appcompat.view.menu.e e1 = this.h;
      if (e1 != null && this.m != null && this.z == null) {
        e1.i();
        if (!e1.j.isEmpty()) {
          c c1 = new c(this, new e(this, this.g, this.h, (View)this.n, true));
          this.z = c1;
          ((View)this.m).post(c1);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public class a extends h {
    public a(c this$0, Context param1Context, l param1l, View param1View) {
      super(param1Context, (androidx.appcompat.view.menu.e)param1l, param1View, false, 2130903072, 0);
      if (!param1l.A.g()) {
        View view;
        c.d d2 = this$0.n;
        c.d d1 = d2;
        if (d2 == null)
          view = (View)this$0.m; 
        this.f = view;
      } 
      d(this$0.B);
    }
    
    public void c() {
      c c1 = this.m;
      c1.y = null;
      Objects.requireNonNull(c1);
      super.c();
    }
  }
  
  public class b extends ActionMenuItemView.b {
    public b(c this$0) {}
  }
  
  public class c implements Runnable {
    public c.e f;
    
    public c(c this$0, c.e param1e) {
      this.f = param1e;
    }
    
    public void run() {
      androidx.appcompat.view.menu.e e1 = this.g.h;
      if (e1 != null) {
        androidx.appcompat.view.menu.e.a a = e1.e;
        if (a != null)
          a.b(e1); 
      } 
      View view = (View)this.g.m;
      if (view != null && view.getWindowToken() != null && this.f.f())
        this.g.x = this.f; 
      this.g.z = null;
    }
  }
  
  public class d extends AppCompatImageView implements ActionMenuView.a {
    public d(c this$0, Context param1Context) {
      super(param1Context, null, 2130903071);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      h1.a((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean a() {
      return false;
    }
    
    public boolean c() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.f.n();
      return true;
    }
    
    public boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        f0.a.f(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    public class a extends m0 {
      public a(c.d this$0, View param2View, c param2c) {
        super(param2View);
      }
      
      public k.f c() {
        c.e e = this.o.f.x;
        return (k.f)((e == null) ? null : e.a());
      }
      
      public boolean d() {
        this.o.f.n();
        return true;
      }
      
      public boolean e() {
        c c = this.o.f;
        if (c.z != null)
          return false; 
        c.k();
        return true;
      }
    }
  }
  
  public class a extends m0 {
    public a(c this$0, View param1View, c param1c) {
      super(param1View);
    }
    
    public k.f c() {
      c.e e = this.o.f.x;
      return (k.f)((e == null) ? null : e.a());
    }
    
    public boolean d() {
      this.o.f.n();
      return true;
    }
    
    public boolean e() {
      c c = this.o.f;
      if (c.z != null)
        return false; 
      c.k();
      return true;
    }
  }
  
  public class e extends h {
    public e(c this$0, Context param1Context, androidx.appcompat.view.menu.e param1e, View param1View, boolean param1Boolean) {
      super(param1Context, param1e, param1View, param1Boolean, 2130903072, 0);
      this.g = 8388613;
      d(this$0.B);
    }
    
    public void c() {
      androidx.appcompat.view.menu.e e1 = this.m.h;
      if (e1 != null)
        e1.c(true); 
      this.m.x = null;
      super.c();
    }
  }
  
  public class f implements i.a {
    public f(c this$0) {}
    
    public void a(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (param1e instanceof l)
        param1e.k().c(false); 
      i.a a1 = this.f.j;
      if (a1 != null)
        a1.a(param1e, param1Boolean); 
    }
    
    public boolean b(androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.f.h;
      boolean bool = false;
      if (param1e == e1)
        return false; 
      Objects.requireNonNull(((l)param1e).A);
      i.a a1 = this.f.j;
      if (a1 != null)
        bool = a1.b(param1e); 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */