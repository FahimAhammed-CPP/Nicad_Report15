package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.CheckedTextView;
import f0.a;

public class i {
  public final CheckedTextView a;
  
  public ColorStateList b = null;
  
  public PorterDuff.Mode c = null;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public boolean f;
  
  public i(CheckedTextView paramCheckedTextView) {
    this.a = paramCheckedTextView;
  }
  
  public void a() {
    Drawable drawable = this.a.getCheckMarkDrawable();
    if (drawable != null && (this.d || this.e)) {
      drawable = a.k(drawable).mutate();
      if (this.d)
        a.i(drawable, this.b); 
      if (this.e)
        a.j(drawable, this.c); 
      if (drawable.isStateful())
        drawable.setState(this.a.getDrawableState()); 
      this.a.setCheckMarkDrawable(drawable);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */