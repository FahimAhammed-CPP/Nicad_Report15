package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import f0.a;
import q0.c;

public class j {
  public final CompoundButton a;
  
  public ColorStateList b = null;
  
  public PorterDuff.Mode c = null;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public boolean f;
  
  public j(CompoundButton paramCompoundButton) {
    this.a = paramCompoundButton;
  }
  
  public void a() {
    Drawable drawable = c.a(this.a);
    if (drawable != null && (this.d || this.e)) {
      drawable = a.k(drawable).mutate();
      if (this.d)
        a.i(drawable, this.b); 
      if (this.e)
        a.j(drawable, this.c); 
      if (drawable.isStateful())
        drawable.setState(this.a.getDrawableState()); 
      this.a.setButtonDrawable(drawable);
    } 
  }
  
  public void b(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/CompoundButton;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #4
    //   9: getstatic e/i.m : [I
    //   12: astore #5
    //   14: aload #4
    //   16: aload_1
    //   17: aload #5
    //   19: iload_2
    //   20: iconst_0
    //   21: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/d1;
    //   24: astore #4
    //   26: aload_0
    //   27: getfield a : Landroid/widget/CompoundButton;
    //   30: astore #6
    //   32: aload #6
    //   34: aload #6
    //   36: invokevirtual getContext : ()Landroid/content/Context;
    //   39: aload #5
    //   41: aload_1
    //   42: aload #4
    //   44: getfield b : Landroid/content/res/TypedArray;
    //   47: iload_2
    //   48: iconst_0
    //   49: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   52: iconst_1
    //   53: istore_2
    //   54: aload #4
    //   56: iconst_1
    //   57: invokevirtual o : (I)Z
    //   60: ifeq -> 95
    //   63: aload #4
    //   65: iconst_1
    //   66: iconst_0
    //   67: invokevirtual l : (II)I
    //   70: istore_3
    //   71: iload_3
    //   72: ifeq -> 95
    //   75: aload_0
    //   76: getfield a : Landroid/widget/CompoundButton;
    //   79: astore_1
    //   80: aload_1
    //   81: aload_1
    //   82: invokevirtual getContext : ()Landroid/content/Context;
    //   85: iload_3
    //   86: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   89: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   92: goto -> 97
    //   95: iconst_0
    //   96: istore_2
    //   97: iload_2
    //   98: ifne -> 139
    //   101: aload #4
    //   103: iconst_0
    //   104: invokevirtual o : (I)Z
    //   107: ifeq -> 139
    //   110: aload #4
    //   112: iconst_0
    //   113: iconst_0
    //   114: invokevirtual l : (II)I
    //   117: istore_2
    //   118: iload_2
    //   119: ifeq -> 139
    //   122: aload_0
    //   123: getfield a : Landroid/widget/CompoundButton;
    //   126: astore_1
    //   127: aload_1
    //   128: aload_1
    //   129: invokevirtual getContext : ()Landroid/content/Context;
    //   132: iload_2
    //   133: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   136: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   139: aload #4
    //   141: iconst_2
    //   142: invokevirtual o : (I)Z
    //   145: ifeq -> 161
    //   148: aload_0
    //   149: getfield a : Landroid/widget/CompoundButton;
    //   152: aload #4
    //   154: iconst_2
    //   155: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   158: invokestatic c : (Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    //   161: aload #4
    //   163: iconst_3
    //   164: invokevirtual o : (I)Z
    //   167: ifeq -> 230
    //   170: aload_0
    //   171: getfield a : Landroid/widget/CompoundButton;
    //   174: astore_1
    //   175: aload #4
    //   177: iconst_3
    //   178: iconst_m1
    //   179: invokevirtual j : (II)I
    //   182: aconst_null
    //   183: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   186: astore #5
    //   188: getstatic android/os/Build$VERSION.SDK_INT : I
    //   191: bipush #21
    //   193: if_icmplt -> 205
    //   196: aload_1
    //   197: aload #5
    //   199: invokevirtual setButtonTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   202: goto -> 230
    //   205: aload_1
    //   206: instanceof q0/j
    //   209: ifeq -> 230
    //   212: aload_1
    //   213: checkcast q0/j
    //   216: aload #5
    //   218: invokeinterface setSupportButtonTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   223: goto -> 230
    //   226: astore_1
    //   227: goto -> 239
    //   230: aload #4
    //   232: getfield b : Landroid/content/res/TypedArray;
    //   235: invokevirtual recycle : ()V
    //   238: return
    //   239: aload #4
    //   241: getfield b : Landroid/content/res/TypedArray;
    //   244: invokevirtual recycle : ()V
    //   247: aload_1
    //   248: athrow
    //   249: astore_1
    //   250: goto -> 95
    // Exception table:
    //   from	to	target	type
    //   54	71	226	finally
    //   75	92	249	android/content/res/Resources$NotFoundException
    //   75	92	226	finally
    //   101	118	226	finally
    //   122	139	226	finally
    //   139	161	226	finally
    //   161	202	226	finally
    //   205	223	226	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */