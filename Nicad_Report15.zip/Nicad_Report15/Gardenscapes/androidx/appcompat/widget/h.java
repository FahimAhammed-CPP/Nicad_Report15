package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import e7.t0;
import g.a;
import m0.t;
import q0.g;
import q0.i;

public class h extends CheckedTextView implements i, t {
  public final i f;
  
  public final f g;
  
  public final c0 h;
  
  public n i;
  
  public h(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokestatic a : (Landroid/content/Context;)Landroid/content/Context;
    //   5: aload_2
    //   6: ldc 2130903189
    //   8: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getContext : ()Landroid/content/Context;
    //   16: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   19: new androidx/appcompat/widget/c0
    //   22: dup
    //   23: aload_0
    //   24: invokespecial <init> : (Landroid/widget/TextView;)V
    //   27: astore_1
    //   28: aload_0
    //   29: aload_1
    //   30: putfield h : Landroidx/appcompat/widget/c0;
    //   33: aload_1
    //   34: aload_2
    //   35: ldc 2130903189
    //   37: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   40: aload_1
    //   41: invokevirtual b : ()V
    //   44: new androidx/appcompat/widget/f
    //   47: dup
    //   48: aload_0
    //   49: invokespecial <init> : (Landroid/view/View;)V
    //   52: astore_1
    //   53: aload_0
    //   54: aload_1
    //   55: putfield g : Landroidx/appcompat/widget/f;
    //   58: aload_1
    //   59: aload_2
    //   60: ldc 2130903189
    //   62: invokevirtual d : (Landroid/util/AttributeSet;I)V
    //   65: new androidx/appcompat/widget/i
    //   68: dup
    //   69: aload_0
    //   70: invokespecial <init> : (Landroid/widget/CheckedTextView;)V
    //   73: astore #5
    //   75: aload_0
    //   76: aload #5
    //   78: putfield f : Landroidx/appcompat/widget/i;
    //   81: aload_0
    //   82: invokevirtual getContext : ()Landroid/content/Context;
    //   85: astore_1
    //   86: getstatic e/i.l : [I
    //   89: astore #6
    //   91: aload_1
    //   92: aload_2
    //   93: aload #6
    //   95: ldc 2130903189
    //   97: iconst_0
    //   98: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/d1;
    //   101: astore_1
    //   102: aload_0
    //   103: aload_0
    //   104: invokevirtual getContext : ()Landroid/content/Context;
    //   107: aload #6
    //   109: aload_2
    //   110: aload_1
    //   111: getfield b : Landroid/content/res/TypedArray;
    //   114: ldc 2130903189
    //   116: iconst_0
    //   117: invokestatic z : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   120: iconst_1
    //   121: istore_3
    //   122: aload_1
    //   123: iconst_1
    //   124: invokevirtual o : (I)Z
    //   127: ifeq -> 159
    //   130: aload_1
    //   131: iconst_1
    //   132: iconst_0
    //   133: invokevirtual l : (II)I
    //   136: istore #4
    //   138: iload #4
    //   140: ifeq -> 159
    //   143: aload_0
    //   144: aload_0
    //   145: invokevirtual getContext : ()Landroid/content/Context;
    //   148: iload #4
    //   150: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   153: invokevirtual setCheckMarkDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   156: goto -> 161
    //   159: iconst_0
    //   160: istore_3
    //   161: iload_3
    //   162: ifne -> 205
    //   165: aload_1
    //   166: iconst_0
    //   167: invokevirtual o : (I)Z
    //   170: ifeq -> 205
    //   173: aload_1
    //   174: iconst_0
    //   175: iconst_0
    //   176: invokevirtual l : (II)I
    //   179: istore_3
    //   180: iload_3
    //   181: ifeq -> 205
    //   184: aload #5
    //   186: getfield a : Landroid/widget/CheckedTextView;
    //   189: astore #6
    //   191: aload #6
    //   193: aload #6
    //   195: invokevirtual getContext : ()Landroid/content/Context;
    //   198: iload_3
    //   199: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   202: invokevirtual setCheckMarkDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   205: aload_1
    //   206: iconst_2
    //   207: invokevirtual o : (I)Z
    //   210: ifeq -> 265
    //   213: aload #5
    //   215: getfield a : Landroid/widget/CheckedTextView;
    //   218: astore #6
    //   220: aload_1
    //   221: iconst_2
    //   222: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   225: astore #7
    //   227: getstatic android/os/Build$VERSION.SDK_INT : I
    //   230: bipush #21
    //   232: if_icmplt -> 245
    //   235: aload #6
    //   237: aload #7
    //   239: invokevirtual setCheckMarkTintList : (Landroid/content/res/ColorStateList;)V
    //   242: goto -> 265
    //   245: aload #6
    //   247: instanceof q0/i
    //   250: ifeq -> 265
    //   253: aload #6
    //   255: checkcast q0/i
    //   258: aload #7
    //   260: invokeinterface setSupportCheckMarkTintList : (Landroid/content/res/ColorStateList;)V
    //   265: aload_1
    //   266: iconst_3
    //   267: invokevirtual o : (I)Z
    //   270: ifeq -> 330
    //   273: aload #5
    //   275: getfield a : Landroid/widget/CheckedTextView;
    //   278: astore #5
    //   280: aload_1
    //   281: iconst_3
    //   282: iconst_m1
    //   283: invokevirtual j : (II)I
    //   286: aconst_null
    //   287: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   290: astore #6
    //   292: getstatic android/os/Build$VERSION.SDK_INT : I
    //   295: bipush #21
    //   297: if_icmplt -> 310
    //   300: aload #5
    //   302: aload #6
    //   304: invokevirtual setCheckMarkTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   307: goto -> 330
    //   310: aload #5
    //   312: instanceof q0/i
    //   315: ifeq -> 330
    //   318: aload #5
    //   320: checkcast q0/i
    //   323: aload #6
    //   325: invokeinterface setSupportCheckMarkTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   330: aload_1
    //   331: getfield b : Landroid/content/res/TypedArray;
    //   334: invokevirtual recycle : ()V
    //   337: aload_0
    //   338: invokespecial getEmojiTextViewHelper : ()Landroidx/appcompat/widget/n;
    //   341: aload_2
    //   342: ldc 2130903189
    //   344: invokevirtual a : (Landroid/util/AttributeSet;I)V
    //   347: return
    //   348: astore_2
    //   349: aload_1
    //   350: getfield b : Landroid/content/res/TypedArray;
    //   353: invokevirtual recycle : ()V
    //   356: aload_2
    //   357: athrow
    //   358: astore #6
    //   360: goto -> 159
    // Exception table:
    //   from	to	target	type
    //   122	138	348	finally
    //   143	156	358	android/content/res/Resources$NotFoundException
    //   143	156	348	finally
    //   165	180	348	finally
    //   184	205	348	finally
    //   205	242	348	finally
    //   245	265	348	finally
    //   265	307	348	finally
    //   310	330	348	finally
  }
  
  private n getEmojiTextViewHelper() {
    if (this.i == null)
      this.i = new n((TextView)this); 
    return this.i;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    c0 c01 = this.h;
    if (c01 != null)
      c01.b(); 
    f f1 = this.g;
    if (f1 != null)
      f1.a(); 
    i i1 = this.f;
    if (i1 != null)
      i1.a(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return g.g(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.g;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.g;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportCheckMarkTintList() {
    i i1 = this.f;
    return (i1 != null) ? i1.b : null;
  }
  
  public PorterDuff.Mode getSupportCheckMarkTintMode() {
    i i1 = this.f;
    return (i1 != null) ? i1.c : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    t0.g(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.g;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.g;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCheckMarkDrawable(Drawable paramDrawable) {
    super.setCheckMarkDrawable(paramDrawable);
    i i1 = this.f;
    if (i1 != null) {
      if (i1.f) {
        i1.f = false;
        return;
      } 
      i1.f = true;
      i1.a();
    } 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(g.h((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.g;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.g;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setSupportCheckMarkTintList(ColorStateList paramColorStateList) {
    i i1 = this.f;
    if (i1 != null) {
      i1.b = paramColorStateList;
      i1.d = true;
      i1.a();
    } 
  }
  
  public void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode) {
    i i1 = this.f;
    if (i1 != null) {
      i1.c = paramMode;
      i1.e = true;
      i1.a();
    } 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.h;
    if (c01 != null)
      c01.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */