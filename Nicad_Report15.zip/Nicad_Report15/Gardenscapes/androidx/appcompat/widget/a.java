package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.e;
import e.i;
import m0.c0;
import m0.d0;
import m0.y;

public abstract class a extends ViewGroup {
  public final a f = new a(this);
  
  public final Context g;
  
  public ActionMenuView h;
  
  public c i;
  
  public int j;
  
  public c0 k;
  
  public boolean l;
  
  public boolean m;
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(2130903042, typedValue, true) && typedValue.resourceId != 0) {
      this.g = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.g = paramContext;
  }
  
  public int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  public int d(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 = (paramInt3 - j) / 2 + paramInt2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public c0 e(int paramInt, long paramLong) {
    c0 c01 = this.k;
    if (c01 != null)
      c01.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      c01 = y.b((View)this);
      c01.a(1.0F);
      c01.c(paramLong);
      a a2 = this.f;
      a2.c.k = c01;
      a2.b = paramInt;
      View view1 = c01.a.get();
      if (view1 != null)
        c01.e(view1, a2); 
      return c01;
    } 
    c01 = y.b((View)this);
    c01.a(0.0F);
    c01.c(paramLong);
    a a1 = this.f;
    a1.c.k = c01;
    a1.b = paramInt;
    View view = c01.a.get();
    if (view != null)
      c01.e(view, a1); 
    return c01;
  }
  
  public int getAnimatedVisibility() {
    return (this.k != null) ? this.f.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.j;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, i.a, 2130903045, 0);
    setContentHeight(typedArray.getLayoutDimension(13, 0));
    typedArray.recycle();
    c c1 = this.i;
    if (c1 != null) {
      Configuration configuration = c1.g.getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      if (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) {
        i = 5;
      } else if (i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) {
        i = 4;
      } else if (i >= 360) {
        i = 3;
      } else {
        i = 2;
      } 
      c1.u = i;
      e e = c1.h;
      if (e != null)
        e.p(true); 
    } 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.m = false; 
    if (!this.m) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.m = true; 
    } 
    if (i == 10 || i == 3)
      this.m = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.l = false; 
    if (!this.l) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.l = true; 
    } 
    if (i == 1 || i == 3)
      this.l = false; 
    return true;
  }
  
  public abstract void setContentHeight(int paramInt);
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      c0 c01 = this.k;
      if (c01 != null)
        c01.b(); 
      super.setVisibility(paramInt);
    } 
  }
  
  public class a implements d0 {
    public boolean a = false;
    
    public int b;
    
    public a(a this$0) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      a a1 = this.c;
      a1.k = null;
      a.b(a1, this.b);
    }
    
    public void c(View param1View) {
      a.a(this.c, 0);
      this.a = false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */