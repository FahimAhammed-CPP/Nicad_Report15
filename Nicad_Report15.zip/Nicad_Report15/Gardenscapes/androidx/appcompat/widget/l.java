package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import e7.t0;
import java.util.Objects;
import m0.c;
import m0.r;
import m0.t;
import m0.y;
import p0.a;
import p0.b;
import p0.c;
import p0.d;
import p0.e;
import q0.g;
import q0.h;

public class l extends EditText implements t, r {
  private final m mAppCompatEmojiEditTextHelper;
  
  private final f mBackgroundTintHelper;
  
  private final h mDefaultOnReceiveContentListener;
  
  private final a0 mTextClassifierHelper;
  
  private final c0 mTextHelper;
  
  public l(Context paramContext) {
    this(paramContext, null);
  }
  
  public l(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903392);
  }
  
  public l(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(a1.a(paramContext), paramAttributeSet, paramInt);
    y0.a((View)this, getContext());
    f f1 = new f((View)this);
    this.mBackgroundTintHelper = f1;
    f1.d(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.mTextHelper = c01;
    c01.e(paramAttributeSet, paramInt);
    c01.b();
    this.mTextClassifierHelper = new a0((TextView)this);
    this.mDefaultOnReceiveContentListener = new h();
    m m1 = new m(this);
    this.mAppCompatEmojiEditTextHelper = m1;
    m1.b(paramAttributeSet, paramInt);
    initEmojiKeyListener(m1);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.b(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return g.g(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.c() : null;
  }
  
  public Editable getText() {
    return (Build.VERSION.SDK_INT >= 28) ? super.getText() : getEditableText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      a0 a01 = this.mTextClassifierHelper;
      if (a01 != null)
        return a01.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public void initEmojiKeyListener(m paramm) {
    KeyListener keyListener = getKeyListener();
    Objects.requireNonNull(paramm);
    if ((keyListener instanceof android.text.method.NumberKeyListener ^ true) != 0) {
      boolean bool = isFocusable();
      int i = getInputType();
      KeyListener keyListener1 = paramm.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool);
    } 
  }
  
  public boolean isEmojiCompatEnabled() {
    return this.mAppCompatEmojiEditTextHelper.b.a.b();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    c c;
    InputConnection inputConnection2 = super.onCreateInputConnection(paramEditorInfo);
    this.mTextHelper.g((TextView)this, inputConnection2, paramEditorInfo);
    t0.g(inputConnection2, paramEditorInfo, (View)this);
    InputConnection inputConnection1 = inputConnection2;
    if (inputConnection2 != null) {
      int i = Build.VERSION.SDK_INT;
      inputConnection1 = inputConnection2;
      if (i <= 30) {
        String[] arrayOfString = y.n((View)this);
        inputConnection1 = inputConnection2;
        if (arrayOfString != null) {
          if (i >= 25) {
            paramEditorInfo.contentMimeTypes = arrayOfString;
          } else {
            if (paramEditorInfo.extras == null)
              paramEditorInfo.extras = new Bundle(); 
            paramEditorInfo.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", arrayOfString);
            paramEditorInfo.extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", arrayOfString);
          } 
          d d = new d((View)this);
          if (i >= 25) {
            b b = new b(inputConnection2, false, (e)d);
          } else {
            String[] arrayOfString1;
            if (i >= 25) {
              arrayOfString1 = paramEditorInfo.contentMimeTypes;
              if (arrayOfString1 == null)
                arrayOfString1 = a.a; 
            } else {
              Bundle bundle = paramEditorInfo.extras;
              if (bundle == null) {
                arrayOfString1 = a.a;
              } else {
                arrayOfString = arrayOfString1.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
                arrayOfString1 = arrayOfString;
                if (arrayOfString == null)
                  arrayOfString1 = paramEditorInfo.extras.getStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"); 
                if (arrayOfString1 == null)
                  arrayOfString1 = a.a; 
              } 
            } 
            if (arrayOfString1.length == 0) {
              InputConnection inputConnection = inputConnection2;
            } else {
              c = new c(inputConnection2, false, (e)d);
            } 
          } 
        } 
      } 
    } 
    return this.mAppCompatEmojiEditTextHelper.c((InputConnection)c, paramEditorInfo);
  }
  
  public boolean onDragEvent(DragEvent paramDragEvent) {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i < 31) {
      bool1 = bool2;
      if (i >= 24) {
        bool1 = bool2;
        if (paramDragEvent.getLocalState() == null)
          if (y.n((View)this) == null) {
            bool1 = bool2;
          } else {
            StringBuilder stringBuilder;
            Context context = getContext();
            while (true) {
              if (context instanceof ContextWrapper) {
                Activity activity;
                if (context instanceof Activity) {
                  activity = (Activity)context;
                  break;
                } 
                Context context1 = ((ContextWrapper)activity).getBaseContext();
                continue;
              } 
              context = null;
              break;
            } 
            if (context == null) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Can't handle drop: no activity: view=");
              stringBuilder.append(this);
              Log.i("ReceiveContent", stringBuilder.toString());
              bool1 = bool2;
            } else if (paramDragEvent.getAction() == 1) {
              bool1 = bool2;
            } else {
              bool1 = bool2;
              if (paramDragEvent.getAction() == 3)
                bool1 = v.a(paramDragEvent, (TextView)this, (Activity)stringBuilder); 
            } 
          }  
      } 
    } 
    return bool1 ? true : super.onDragEvent(paramDragEvent);
  }
  
  public c onReceiveContent(c paramc) {
    return this.mDefaultOnReceiveContentListener.a((View)this, paramc);
  }
  
  public boolean onTextContextMenuItem(int paramInt) {
    int i = Build.VERSION.SDK_INT;
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = bool3;
    if (i < 31) {
      bool1 = bool3;
      if (y.n((View)this) != null)
        if (paramInt != 16908322 && paramInt != 16908337) {
          bool1 = bool3;
        } else {
          ClipData clipData;
          ClipboardManager clipboardManager = (ClipboardManager)getContext().getSystemService("clipboard");
          if (clipboardManager == null) {
            clipboardManager = null;
          } else {
            clipData = clipboardManager.getPrimaryClip();
          } 
          if (clipData != null && clipData.getItemCount() > 0) {
            c.a a;
            c.c c;
            if (i >= 31) {
              a = new c.a(clipData, 1);
            } else {
              c = new c.c((ClipData)a, 1);
            } 
            if (paramInt == 16908322) {
              bool1 = bool2;
            } else {
              bool1 = true;
            } 
            c.c(bool1);
            y.u((View)this, c.build());
          } 
          bool1 = true;
        }  
    } 
    return bool1 ? true : super.onTextContextMenuItem(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(g.h((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.mAppCompatEmojiEditTextHelper.b.a.d(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.mAppCompatEmojiEditTextHelper.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.mTextHelper;
    if (c01 != null)
      c01.f(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      a0 a01 = this.mTextClassifierHelper;
      if (a01 != null) {
        a01.b = paramTextClassifier;
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */