package androidx.appcompat.widget;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;
import r0.c;

public class x0 extends c implements View.OnClickListener {
  public int A = -1;
  
  public int B = -1;
  
  public int C = -1;
  
  public final SearchView q;
  
  public final SearchableInfo r;
  
  public final Context s;
  
  public final WeakHashMap<String, Drawable.ConstantState> t;
  
  public final int u;
  
  public int v = 1;
  
  public ColorStateList w;
  
  public int x = -1;
  
  public int y = -1;
  
  public int z = -1;
  
  public x0(Context paramContext, SearchView paramSearchView, SearchableInfo paramSearchableInfo, WeakHashMap<String, Drawable.ConstantState> paramWeakHashMap) {
    super(paramContext, paramSearchView.getSuggestionRowLayout(), null, true);
    this.q = paramSearchView;
    this.r = paramSearchableInfo;
    this.u = paramSearchView.getSuggestionCommitIconResId();
    this.s = paramContext;
    this.t = paramWeakHashMap;
  }
  
  public static String j(Cursor paramCursor, int paramInt) {
    if (paramInt == -1)
      return null; 
    try {
      return paramCursor.getString(paramInt);
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", exception);
      return null;
    } 
  }
  
  public void a(View paramView, Context paramContext, Cursor paramCursor) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getTag : ()Ljava/lang/Object;
    //   4: checkcast androidx/appcompat/widget/x0$a
    //   7: astore #6
    //   9: aload_0
    //   10: getfield C : I
    //   13: istore #4
    //   15: iload #4
    //   17: iconst_m1
    //   18: if_icmpeq -> 34
    //   21: aload_3
    //   22: iload #4
    //   24: invokeinterface getInt : (I)I
    //   29: istore #4
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #6
    //   39: getfield a : Landroid/widget/TextView;
    //   42: ifnull -> 86
    //   45: aload_3
    //   46: aload_0
    //   47: getfield x : I
    //   50: invokestatic j : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   53: astore_1
    //   54: aload #6
    //   56: getfield a : Landroid/widget/TextView;
    //   59: astore_2
    //   60: aload_2
    //   61: aload_1
    //   62: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   65: aload_1
    //   66: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   69: ifeq -> 81
    //   72: aload_2
    //   73: bipush #8
    //   75: invokevirtual setVisibility : (I)V
    //   78: goto -> 86
    //   81: aload_2
    //   82: iconst_0
    //   83: invokevirtual setVisibility : (I)V
    //   86: aload #6
    //   88: getfield b : Landroid/widget/TextView;
    //   91: ifnull -> 292
    //   94: aload_3
    //   95: aload_0
    //   96: getfield z : I
    //   99: invokestatic j : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   102: astore_2
    //   103: aload_2
    //   104: ifnull -> 193
    //   107: aload_0
    //   108: getfield w : Landroid/content/res/ColorStateList;
    //   111: ifnonnull -> 155
    //   114: new android/util/TypedValue
    //   117: dup
    //   118: invokespecial <init> : ()V
    //   121: astore_1
    //   122: aload_0
    //   123: getfield s : Landroid/content/Context;
    //   126: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   129: ldc 2130903972
    //   131: aload_1
    //   132: iconst_1
    //   133: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   136: pop
    //   137: aload_0
    //   138: aload_0
    //   139: getfield s : Landroid/content/Context;
    //   142: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   145: aload_1
    //   146: getfield resourceId : I
    //   149: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   152: putfield w : Landroid/content/res/ColorStateList;
    //   155: new android/text/SpannableString
    //   158: dup
    //   159: aload_2
    //   160: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   163: astore_1
    //   164: aload_1
    //   165: new android/text/style/TextAppearanceSpan
    //   168: dup
    //   169: aconst_null
    //   170: iconst_0
    //   171: iconst_0
    //   172: aload_0
    //   173: getfield w : Landroid/content/res/ColorStateList;
    //   176: aconst_null
    //   177: invokespecial <init> : (Ljava/lang/String;IILandroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;)V
    //   180: iconst_0
    //   181: aload_2
    //   182: invokevirtual length : ()I
    //   185: bipush #33
    //   187: invokevirtual setSpan : (Ljava/lang/Object;III)V
    //   190: goto -> 202
    //   193: aload_3
    //   194: aload_0
    //   195: getfield y : I
    //   198: invokestatic j : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   201: astore_1
    //   202: aload_1
    //   203: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   206: ifeq -> 236
    //   209: aload #6
    //   211: getfield a : Landroid/widget/TextView;
    //   214: astore_2
    //   215: aload_2
    //   216: ifnull -> 260
    //   219: aload_2
    //   220: iconst_0
    //   221: invokevirtual setSingleLine : (Z)V
    //   224: aload #6
    //   226: getfield a : Landroid/widget/TextView;
    //   229: iconst_2
    //   230: invokevirtual setMaxLines : (I)V
    //   233: goto -> 260
    //   236: aload #6
    //   238: getfield a : Landroid/widget/TextView;
    //   241: astore_2
    //   242: aload_2
    //   243: ifnull -> 260
    //   246: aload_2
    //   247: iconst_1
    //   248: invokevirtual setSingleLine : (Z)V
    //   251: aload #6
    //   253: getfield a : Landroid/widget/TextView;
    //   256: iconst_1
    //   257: invokevirtual setMaxLines : (I)V
    //   260: aload #6
    //   262: getfield b : Landroid/widget/TextView;
    //   265: astore_2
    //   266: aload_2
    //   267: aload_1
    //   268: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   271: aload_1
    //   272: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   275: ifeq -> 287
    //   278: aload_2
    //   279: bipush #8
    //   281: invokevirtual setVisibility : (I)V
    //   284: goto -> 292
    //   287: aload_2
    //   288: iconst_0
    //   289: invokevirtual setVisibility : (I)V
    //   292: aload #6
    //   294: getfield c : Landroid/widget/ImageView;
    //   297: astore #7
    //   299: aload #7
    //   301: ifnull -> 588
    //   304: aload_0
    //   305: getfield A : I
    //   308: istore #5
    //   310: iload #5
    //   312: iconst_m1
    //   313: if_icmpne -> 321
    //   316: aconst_null
    //   317: astore_1
    //   318: goto -> 549
    //   321: aload_0
    //   322: aload_3
    //   323: iload #5
    //   325: invokeinterface getString : (I)Ljava/lang/String;
    //   330: invokevirtual h : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   333: astore_1
    //   334: aload_1
    //   335: ifnull -> 341
    //   338: goto -> 549
    //   341: aload_0
    //   342: getfield r : Landroid/app/SearchableInfo;
    //   345: invokevirtual getSearchActivity : ()Landroid/content/ComponentName;
    //   348: astore #9
    //   350: aload #9
    //   352: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   355: astore #8
    //   357: aload_0
    //   358: getfield t : Ljava/util/WeakHashMap;
    //   361: aload #8
    //   363: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   366: ifeq -> 406
    //   369: aload_0
    //   370: getfield t : Ljava/util/WeakHashMap;
    //   373: aload #8
    //   375: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   378: checkcast android/graphics/drawable/Drawable$ConstantState
    //   381: astore_1
    //   382: aload_1
    //   383: ifnonnull -> 391
    //   386: aconst_null
    //   387: astore_1
    //   388: goto -> 531
    //   391: aload_1
    //   392: aload_0
    //   393: getfield s : Landroid/content/Context;
    //   396: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   399: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   402: astore_1
    //   403: goto -> 531
    //   406: aload_0
    //   407: getfield s : Landroid/content/Context;
    //   410: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   413: astore_1
    //   414: aload_1
    //   415: aload #9
    //   417: sipush #128
    //   420: invokevirtual getActivityInfo : (Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    //   423: astore_2
    //   424: aload_2
    //   425: invokevirtual getIconResource : ()I
    //   428: istore #5
    //   430: iload #5
    //   432: ifne -> 438
    //   435: goto -> 504
    //   438: aload_1
    //   439: aload #9
    //   441: invokevirtual getPackageName : ()Ljava/lang/String;
    //   444: iload #5
    //   446: aload_2
    //   447: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   450: invokevirtual getDrawable : (Ljava/lang/String;ILandroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;
    //   453: astore_2
    //   454: aload_2
    //   455: astore_1
    //   456: aload_2
    //   457: ifnonnull -> 506
    //   460: ldc 'Invalid icon resource '
    //   462: iload #5
    //   464: ldc ' for '
    //   466: invokestatic a : (Ljava/lang/String;ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   469: astore_1
    //   470: aload_1
    //   471: aload #9
    //   473: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: pop
    //   480: ldc 'SuggestionsAdapter'
    //   482: aload_1
    //   483: invokevirtual toString : ()Ljava/lang/String;
    //   486: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   489: pop
    //   490: goto -> 504
    //   493: astore_1
    //   494: ldc 'SuggestionsAdapter'
    //   496: aload_1
    //   497: invokevirtual toString : ()Ljava/lang/String;
    //   500: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   503: pop
    //   504: aconst_null
    //   505: astore_1
    //   506: aload_1
    //   507: ifnonnull -> 515
    //   510: aconst_null
    //   511: astore_2
    //   512: goto -> 520
    //   515: aload_1
    //   516: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   519: astore_2
    //   520: aload_0
    //   521: getfield t : Ljava/util/WeakHashMap;
    //   524: aload #8
    //   526: aload_2
    //   527: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   530: pop
    //   531: aload_1
    //   532: ifnull -> 538
    //   535: goto -> 549
    //   538: aload_0
    //   539: getfield s : Landroid/content/Context;
    //   542: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   545: invokevirtual getDefaultActivityIcon : ()Landroid/graphics/drawable/Drawable;
    //   548: astore_1
    //   549: aload #7
    //   551: aload_1
    //   552: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   555: aload_1
    //   556: ifnonnull -> 568
    //   559: aload #7
    //   561: iconst_4
    //   562: invokevirtual setVisibility : (I)V
    //   565: goto -> 588
    //   568: aload #7
    //   570: iconst_0
    //   571: invokevirtual setVisibility : (I)V
    //   574: aload_1
    //   575: iconst_0
    //   576: iconst_0
    //   577: invokevirtual setVisible : (ZZ)Z
    //   580: pop
    //   581: aload_1
    //   582: iconst_1
    //   583: iconst_0
    //   584: invokevirtual setVisible : (ZZ)Z
    //   587: pop
    //   588: aload #6
    //   590: getfield d : Landroid/widget/ImageView;
    //   593: astore_2
    //   594: aload_2
    //   595: ifnull -> 665
    //   598: aload_0
    //   599: getfield B : I
    //   602: istore #5
    //   604: iload #5
    //   606: iconst_m1
    //   607: if_icmpne -> 615
    //   610: aconst_null
    //   611: astore_1
    //   612: goto -> 628
    //   615: aload_0
    //   616: aload_3
    //   617: iload #5
    //   619: invokeinterface getString : (I)Ljava/lang/String;
    //   624: invokevirtual h : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   627: astore_1
    //   628: aload_2
    //   629: aload_1
    //   630: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   633: aload_1
    //   634: ifnonnull -> 646
    //   637: aload_2
    //   638: bipush #8
    //   640: invokevirtual setVisibility : (I)V
    //   643: goto -> 665
    //   646: aload_2
    //   647: iconst_0
    //   648: invokevirtual setVisibility : (I)V
    //   651: aload_1
    //   652: iconst_0
    //   653: iconst_0
    //   654: invokevirtual setVisible : (ZZ)Z
    //   657: pop
    //   658: aload_1
    //   659: iconst_1
    //   660: iconst_0
    //   661: invokevirtual setVisible : (ZZ)Z
    //   664: pop
    //   665: aload_0
    //   666: getfield v : I
    //   669: istore #5
    //   671: iload #5
    //   673: iconst_2
    //   674: if_icmpeq -> 704
    //   677: iload #5
    //   679: iconst_1
    //   680: if_icmpne -> 693
    //   683: iload #4
    //   685: iconst_1
    //   686: iand
    //   687: ifeq -> 693
    //   690: goto -> 704
    //   693: aload #6
    //   695: getfield e : Landroid/widget/ImageView;
    //   698: bipush #8
    //   700: invokevirtual setVisibility : (I)V
    //   703: return
    //   704: aload #6
    //   706: getfield e : Landroid/widget/ImageView;
    //   709: iconst_0
    //   710: invokevirtual setVisibility : (I)V
    //   713: aload #6
    //   715: getfield e : Landroid/widget/ImageView;
    //   718: aload #6
    //   720: getfield a : Landroid/widget/TextView;
    //   723: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   726: invokevirtual setTag : (Ljava/lang/Object;)V
    //   729: aload #6
    //   731: getfield e : Landroid/widget/ImageView;
    //   734: aload_0
    //   735: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   738: return
    // Exception table:
    //   from	to	target	type
    //   414	424	493	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public void c(Cursor paramCursor) {
    try {
      super.c(paramCursor);
      if (paramCursor != null) {
        this.x = paramCursor.getColumnIndex("suggest_text_1");
        this.y = paramCursor.getColumnIndex("suggest_text_2");
        this.z = paramCursor.getColumnIndex("suggest_text_2_url");
        this.A = paramCursor.getColumnIndex("suggest_icon_1");
        this.B = paramCursor.getColumnIndex("suggest_icon_2");
        this.C = paramCursor.getColumnIndex("suggest_flags");
        return;
      } 
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "error changing cursor and caching columns", exception);
    } 
  }
  
  public CharSequence d(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    String str = j(paramCursor, paramCursor.getColumnIndex("suggest_intent_query"));
    if (str != null)
      return str; 
    if (this.r.shouldRewriteQueryFromData()) {
      str = j(paramCursor, paramCursor.getColumnIndex("suggest_intent_data"));
      if (str != null)
        return str; 
    } 
    if (this.r.shouldRewriteQueryFromText()) {
      String str1 = j(paramCursor, paramCursor.getColumnIndex("suggest_text_1"));
      if (str1 != null)
        return str1; 
    } 
    return null;
  }
  
  public View e(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    View view = this.p.inflate(this.n, paramViewGroup, false);
    view.setTag(new a(view));
    ((ImageView)view.findViewById(2131230902)).setImageResource(this.u);
    return view;
  }
  
  public Drawable f(Uri paramUri) {
    String str = paramUri.getAuthority();
    if (!TextUtils.isEmpty(str))
      try {
        int i;
        Resources resources = this.s.getPackageManager().getResourcesForApplication(str);
        List<String> list = paramUri.getPathSegments();
        if (list != null) {
          StringBuilder stringBuilder2;
          i = list.size();
          if (i == 1)
            try {
              i = Integer.parseInt(list.get(0));
              if (i != 0)
                return resources.getDrawable(i); 
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("No resource found for: ");
              stringBuilder2.append(paramUri);
              throw new FileNotFoundException(stringBuilder2.toString());
            } catch (NumberFormatException numberFormatException) {
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("Single path segment is not a resource ID: ");
              stringBuilder2.append(paramUri);
              throw new FileNotFoundException(stringBuilder2.toString());
            }  
          if (i == 2) {
            i = resources.getIdentifier(list.get(1), list.get(0), (String)stringBuilder2);
          } else {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("More than two path segments: ");
            stringBuilder2.append(paramUri);
            throw new FileNotFoundException(stringBuilder2.toString());
          } 
        } else {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("No path: ");
          stringBuilder2.append(paramUri);
          throw new FileNotFoundException(stringBuilder2.toString());
        } 
        if (i != 0)
          return resources.getDrawable(i); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No resource found for: ");
        stringBuilder1.append(paramUri);
        throw new FileNotFoundException(stringBuilder1.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No package found for authority: ");
        stringBuilder1.append(paramUri);
        throw new FileNotFoundException(stringBuilder1.toString());
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No authority: ");
    stringBuilder.append(paramUri);
    throw new FileNotFoundException(stringBuilder.toString());
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getDropDownView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = this.p.inflate(this.o, paramViewGroup, false);
      if (view != null)
        ((a)view.getTag()).a.setText(runtimeException.toString()); 
      return view;
    } 
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = e(this.s, ((r0.a)this).h, paramViewGroup);
      ((a)view.getTag()).a.setText(runtimeException.toString());
      return view;
    } 
  }
  
  public final Drawable h(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #6
    //   6: aload #4
    //   8: astore #5
    //   10: aload_1
    //   11: ifnull -> 575
    //   14: aload #4
    //   16: astore #5
    //   18: aload_1
    //   19: invokevirtual isEmpty : ()Z
    //   22: ifne -> 575
    //   25: ldc_w '0'
    //   28: aload_1
    //   29: invokevirtual equals : (Ljava/lang/Object;)Z
    //   32: ifeq -> 37
    //   35: aconst_null
    //   36: areturn
    //   37: aload_1
    //   38: invokestatic parseInt : (Ljava/lang/String;)I
    //   41: istore_2
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore #4
    //   51: aload #4
    //   53: ldc_w 'android.resource://'
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #4
    //   62: aload_0
    //   63: getfield s : Landroid/content/Context;
    //   66: invokevirtual getPackageName : ()Ljava/lang/String;
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload #4
    //   75: ldc_w '/'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #4
    //   84: iload_2
    //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload #4
    //   91: invokevirtual toString : ()Ljava/lang/String;
    //   94: astore #5
    //   96: aload_0
    //   97: getfield t : Ljava/util/WeakHashMap;
    //   100: aload #5
    //   102: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   105: checkcast android/graphics/drawable/Drawable$ConstantState
    //   108: astore #4
    //   110: aload #4
    //   112: ifnonnull -> 121
    //   115: aconst_null
    //   116: astore #4
    //   118: goto -> 593
    //   121: aload #4
    //   123: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   126: astore #4
    //   128: goto -> 593
    //   131: aload_0
    //   132: getfield s : Landroid/content/Context;
    //   135: iload_2
    //   136: invokestatic c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   139: astore #4
    //   141: aload #4
    //   143: ifnull -> 161
    //   146: aload_0
    //   147: getfield t : Ljava/util/WeakHashMap;
    //   150: aload #5
    //   152: aload #4
    //   154: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   157: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   160: pop
    //   161: aload #4
    //   163: areturn
    //   164: new java/lang/StringBuilder
    //   167: dup
    //   168: invokespecial <init> : ()V
    //   171: astore #4
    //   173: aload #4
    //   175: ldc_w 'Icon resource not found: '
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: aload #4
    //   184: aload_1
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: ldc 'SuggestionsAdapter'
    //   191: aload #4
    //   193: invokevirtual toString : ()Ljava/lang/String;
    //   196: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   199: pop
    //   200: aconst_null
    //   201: areturn
    //   202: aload_0
    //   203: getfield t : Ljava/util/WeakHashMap;
    //   206: aload_1
    //   207: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   210: checkcast android/graphics/drawable/Drawable$ConstantState
    //   213: astore #4
    //   215: aload #4
    //   217: ifnonnull -> 226
    //   220: aconst_null
    //   221: astore #4
    //   223: goto -> 233
    //   226: aload #4
    //   228: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   231: astore #4
    //   233: aload #4
    //   235: ifnull -> 241
    //   238: aload #4
    //   240: areturn
    //   241: aload_1
    //   242: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   245: astore #5
    //   247: ldc_w 'android.resource'
    //   250: aload #5
    //   252: invokevirtual getScheme : ()Ljava/lang/String;
    //   255: invokevirtual equals : (Ljava/lang/Object;)Z
    //   258: istore_3
    //   259: iload_3
    //   260: ifeq -> 313
    //   263: aload_0
    //   264: aload #5
    //   266: invokevirtual f : (Landroid/net/Uri;)Landroid/graphics/drawable/Drawable;
    //   269: astore #4
    //   271: goto -> 548
    //   274: new java/lang/StringBuilder
    //   277: dup
    //   278: invokespecial <init> : ()V
    //   281: astore #4
    //   283: aload #4
    //   285: ldc_w 'Resource does not exist: '
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: pop
    //   292: aload #4
    //   294: aload #5
    //   296: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   299: pop
    //   300: new java/io/FileNotFoundException
    //   303: dup
    //   304: aload #4
    //   306: invokevirtual toString : ()Ljava/lang/String;
    //   309: invokespecial <init> : (Ljava/lang/String;)V
    //   312: athrow
    //   313: aload_0
    //   314: getfield s : Landroid/content/Context;
    //   317: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   320: aload #5
    //   322: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   325: astore #7
    //   327: aload #7
    //   329: ifnull -> 446
    //   332: aload #7
    //   334: aconst_null
    //   335: invokestatic createFromStream : (Ljava/io/InputStream;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   338: astore #4
    //   340: aload #7
    //   342: invokevirtual close : ()V
    //   345: goto -> 389
    //   348: astore #7
    //   350: new java/lang/StringBuilder
    //   353: dup
    //   354: invokespecial <init> : ()V
    //   357: astore #8
    //   359: aload #8
    //   361: ldc_w 'Error closing icon stream for '
    //   364: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: pop
    //   368: aload #8
    //   370: aload #5
    //   372: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   375: pop
    //   376: ldc 'SuggestionsAdapter'
    //   378: aload #8
    //   380: invokevirtual toString : ()Ljava/lang/String;
    //   383: aload #7
    //   385: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   388: pop
    //   389: goto -> 548
    //   392: astore #4
    //   394: aload #7
    //   396: invokevirtual close : ()V
    //   399: goto -> 443
    //   402: astore #7
    //   404: new java/lang/StringBuilder
    //   407: dup
    //   408: invokespecial <init> : ()V
    //   411: astore #8
    //   413: aload #8
    //   415: ldc_w 'Error closing icon stream for '
    //   418: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   421: pop
    //   422: aload #8
    //   424: aload #5
    //   426: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   429: pop
    //   430: ldc 'SuggestionsAdapter'
    //   432: aload #8
    //   434: invokevirtual toString : ()Ljava/lang/String;
    //   437: aload #7
    //   439: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   442: pop
    //   443: aload #4
    //   445: athrow
    //   446: new java/lang/StringBuilder
    //   449: dup
    //   450: invokespecial <init> : ()V
    //   453: astore #4
    //   455: aload #4
    //   457: ldc_w 'Failed to open '
    //   460: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   463: pop
    //   464: aload #4
    //   466: aload #5
    //   468: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   471: pop
    //   472: new java/io/FileNotFoundException
    //   475: dup
    //   476: aload #4
    //   478: invokevirtual toString : ()Ljava/lang/String;
    //   481: invokespecial <init> : (Ljava/lang/String;)V
    //   484: athrow
    //   485: astore #4
    //   487: new java/lang/StringBuilder
    //   490: dup
    //   491: invokespecial <init> : ()V
    //   494: astore #7
    //   496: aload #7
    //   498: ldc_w 'Icon not found: '
    //   501: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   504: pop
    //   505: aload #7
    //   507: aload #5
    //   509: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   512: pop
    //   513: aload #7
    //   515: ldc_w ', '
    //   518: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   521: pop
    //   522: aload #7
    //   524: aload #4
    //   526: invokevirtual getMessage : ()Ljava/lang/String;
    //   529: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   532: pop
    //   533: ldc 'SuggestionsAdapter'
    //   535: aload #7
    //   537: invokevirtual toString : ()Ljava/lang/String;
    //   540: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   543: pop
    //   544: aload #6
    //   546: astore #4
    //   548: aload #4
    //   550: astore #5
    //   552: aload #4
    //   554: ifnull -> 575
    //   557: aload_0
    //   558: getfield t : Ljava/util/WeakHashMap;
    //   561: aload_1
    //   562: aload #4
    //   564: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   567: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   570: pop
    //   571: aload #4
    //   573: astore #5
    //   575: aload #5
    //   577: areturn
    //   578: astore #4
    //   580: goto -> 202
    //   583: astore #4
    //   585: goto -> 164
    //   588: astore #4
    //   590: goto -> 274
    //   593: aload #4
    //   595: ifnull -> 131
    //   598: aload #4
    //   600: areturn
    // Exception table:
    //   from	to	target	type
    //   37	110	578	java/lang/NumberFormatException
    //   37	110	583	android/content/res/Resources$NotFoundException
    //   121	128	578	java/lang/NumberFormatException
    //   121	128	583	android/content/res/Resources$NotFoundException
    //   131	141	578	java/lang/NumberFormatException
    //   131	141	583	android/content/res/Resources$NotFoundException
    //   146	161	578	java/lang/NumberFormatException
    //   146	161	583	android/content/res/Resources$NotFoundException
    //   247	259	485	java/io/FileNotFoundException
    //   263	271	588	android/content/res/Resources$NotFoundException
    //   263	271	485	java/io/FileNotFoundException
    //   274	313	485	java/io/FileNotFoundException
    //   313	327	485	java/io/FileNotFoundException
    //   332	340	392	finally
    //   340	345	348	java/io/IOException
    //   350	389	485	java/io/FileNotFoundException
    //   394	399	402	java/io/IOException
    //   404	443	485	java/io/FileNotFoundException
    //   443	446	485	java/io/FileNotFoundException
    //   446	485	485	java/io/FileNotFoundException
  }
  
  public boolean hasStableIds() {
    return false;
  }
  
  public Cursor i(SearchableInfo paramSearchableInfo, String paramString, int paramInt) {
    SearchableInfo searchableInfo = null;
    if (paramSearchableInfo == null)
      return null; 
    String str1 = paramSearchableInfo.getSuggestAuthority();
    if (str1 == null)
      return null; 
    Uri.Builder builder = (new Uri.Builder()).scheme("content").authority(str1).query("").fragment("");
    String str2 = paramSearchableInfo.getSuggestPath();
    if (str2 != null)
      builder.appendEncodedPath(str2); 
    builder.appendPath("search_suggest_query");
    str2 = paramSearchableInfo.getSuggestSelection();
    if (str2 != null) {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramString;
    } else {
      builder.appendPath(paramString);
      paramSearchableInfo = searchableInfo;
    } 
    if (paramInt > 0)
      builder.appendQueryParameter("limit", String.valueOf(paramInt)); 
    Uri uri = builder.build();
    return this.s.getContentResolver().query(uri, null, str2, (String[])paramSearchableInfo, null);
  }
  
  public void notifyDataSetChanged() {
    super.notifyDataSetChanged();
    Cursor cursor = ((r0.a)this).h;
    if (cursor != null) {
      Bundle bundle = cursor.getExtras();
    } else {
      cursor = null;
    } 
    if (cursor != null)
      cursor.getBoolean("in_progress"); 
  }
  
  public void notifyDataSetInvalidated() {
    super.notifyDataSetInvalidated();
    Cursor cursor = ((r0.a)this).h;
    if (cursor != null) {
      Bundle bundle = cursor.getExtras();
    } else {
      cursor = null;
    } 
    if (cursor != null)
      cursor.getBoolean("in_progress"); 
  }
  
  public void onClick(View paramView) {
    Object object = paramView.getTag();
    if (object instanceof CharSequence)
      this.q.s((CharSequence)object); 
  }
  
  public static final class a {
    public final TextView a;
    
    public final TextView b;
    
    public final ImageView c;
    
    public final ImageView d;
    
    public final ImageView e;
    
    public a(View param1View) {
      this.a = (TextView)param1View.findViewById(16908308);
      this.b = (TextView)param1View.findViewById(16908309);
      this.c = (ImageView)param1View.findViewById(16908295);
      this.d = (ImageView)param1View.findViewById(16908296);
      this.e = (ImageView)param1View.findViewById(2131230902);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */