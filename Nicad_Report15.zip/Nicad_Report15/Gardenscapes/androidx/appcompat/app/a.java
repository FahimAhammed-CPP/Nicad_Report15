package androidx.appcompat.app;

import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;

public class a implements AdapterView.OnItemClickListener {
  public a(AlertController.b paramb, AlertController paramAlertController) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.g.h.onClick((DialogInterface)this.f.b, paramInt);
    if (!this.g.i)
      this.f.b.dismiss(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */