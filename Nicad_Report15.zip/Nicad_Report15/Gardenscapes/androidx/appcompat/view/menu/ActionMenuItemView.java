package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.c;
import androidx.appcompat.widget.e0;
import androidx.appcompat.widget.m0;
import e.i;
import k.d;
import k.f;

public class ActionMenuItemView extends e0 implements j.a, View.OnClickListener, ActionMenuView.a {
  public g l;
  
  public CharSequence m;
  
  public Drawable n;
  
  public e.b o;
  
  public m0 p;
  
  public b q;
  
  public boolean r;
  
  public boolean s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    Resources resources = paramContext.getResources();
    this.r = f();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, i.c, 0, 0);
    this.t = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
    this.v = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.u = -1;
    setSaveEnabled(false);
  }
  
  public boolean a() {
    return e();
  }
  
  public boolean c() {
    return (e() && this.l.getIcon() == null);
  }
  
  public void d(g paramg, int paramInt) {
    this.l = paramg;
    setIcon(paramg.getIcon());
    setTitle(paramg.getTitleCondensed());
    setId(paramg.a);
    if (paramg.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(paramg.isEnabled());
    if (paramg.hasSubMenu() && this.p == null)
      this.p = new a(this); 
  }
  
  public boolean e() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public final boolean f() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  public g getItemData() {
    return this.l;
  }
  
  public final void h() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield n : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 66
    //   19: aload_0
    //   20: getfield l : Landroidx/appcompat/view/menu/g;
    //   23: getfield y : I
    //   26: iconst_4
    //   27: iand
    //   28: iconst_4
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 64
    //   43: iload_2
    //   44: istore_1
    //   45: aload_0
    //   46: getfield r : Z
    //   49: ifne -> 66
    //   52: aload_0
    //   53: getfield s : Z
    //   56: ifeq -> 64
    //   59: iload_2
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_3
    //   67: iconst_1
    //   68: ixor
    //   69: iload_1
    //   70: iand
    //   71: istore_1
    //   72: aconst_null
    //   73: astore #5
    //   75: iload_1
    //   76: ifeq -> 88
    //   79: aload_0
    //   80: getfield m : Ljava/lang/CharSequence;
    //   83: astore #4
    //   85: goto -> 91
    //   88: aconst_null
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   97: aload_0
    //   98: getfield l : Landroidx/appcompat/view/menu/g;
    //   101: getfield q : Ljava/lang/CharSequence;
    //   104: astore #4
    //   106: aload #4
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifeq -> 142
    //   114: iload_1
    //   115: ifeq -> 124
    //   118: aconst_null
    //   119: astore #4
    //   121: goto -> 133
    //   124: aload_0
    //   125: getfield l : Landroidx/appcompat/view/menu/g;
    //   128: getfield e : Ljava/lang/CharSequence;
    //   131: astore #4
    //   133: aload_0
    //   134: aload #4
    //   136: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   139: goto -> 148
    //   142: aload_0
    //   143: aload #4
    //   145: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   148: aload_0
    //   149: getfield l : Landroidx/appcompat/view/menu/g;
    //   152: getfield r : Ljava/lang/CharSequence;
    //   155: astore #4
    //   157: aload #4
    //   159: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   162: ifeq -> 192
    //   165: iload_1
    //   166: ifeq -> 176
    //   169: aload #5
    //   171: astore #4
    //   173: goto -> 185
    //   176: aload_0
    //   177: getfield l : Landroidx/appcompat/view/menu/g;
    //   180: getfield e : Ljava/lang/CharSequence;
    //   183: astore #4
    //   185: aload_0
    //   186: aload #4
    //   188: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   191: return
    //   192: aload_0
    //   193: aload #4
    //   195: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   198: return
  }
  
  public void onClick(View paramView) {
    e.b b1 = this.o;
    if (b1 != null)
      b1.a(this.l); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.r = f();
    h();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = e();
    if (bool) {
      int k = this.u;
      if (k >= 0)
        super.setPadding(k, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.t);
    } else {
      paramInt1 = this.t;
    } 
    if (i != 1073741824 && this.t > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.n != null)
      super.setPadding((getMeasuredWidth() - this.n.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.l.hasSubMenu()) {
      m0 m01 = this.p;
      if (m01 != null && m01.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.s != paramBoolean) {
      this.s = paramBoolean;
      g g1 = this.l;
      if (g1 != null) {
        e e = g1.n;
        e.k = true;
        e.p(true);
      } 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.n = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.v;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    h();
  }
  
  public void setItemInvoker(e.b paramb) {
    this.o = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.u = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.q = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.m = paramCharSequence;
    h();
  }
  
  public class a extends m0 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public f c() {
      ActionMenuItemView.b b = this.o.q;
      d d2 = null;
      d d1 = d2;
      if (b != null) {
        c.a a1 = ((c.b)b).a.y;
        d1 = d2;
        if (a1 != null)
          d1 = a1.a(); 
      } 
      return (f)d1;
    }
    
    public boolean d() {
      ActionMenuItemView actionMenuItemView = this.o;
      e.b b = actionMenuItemView.o;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.l)) {
          f f = c();
          bool1 = bool2;
          if (f != null) {
            bool1 = bool2;
            if (f.isShowing())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */