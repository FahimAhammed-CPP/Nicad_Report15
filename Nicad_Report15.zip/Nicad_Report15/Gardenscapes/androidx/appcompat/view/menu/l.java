package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class l extends e implements SubMenu {
  public g A;
  
  public e z;
  
  public l(Context paramContext, e parame, g paramg) {
    super(paramContext);
    this.z = parame;
    this.A = paramg;
  }
  
  public boolean d(g paramg) {
    return this.z.d(paramg);
  }
  
  public boolean e(e parame, MenuItem paramMenuItem) {
    return (super.e(parame, paramMenuItem) || this.z.e(parame, paramMenuItem));
  }
  
  public boolean f(g paramg) {
    return this.z.f(paramg);
  }
  
  public MenuItem getItem() {
    return (MenuItem)this.A;
  }
  
  public String j() {
    boolean bool;
    g g1 = this.A;
    if (g1 != null) {
      bool = g1.a;
    } else {
      bool = false;
    } 
    if (!bool)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("android:menu:actionviewstates");
    stringBuilder.append(":");
    stringBuilder.append(bool);
    return stringBuilder.toString();
  }
  
  public e k() {
    return this.z.k();
  }
  
  public boolean m() {
    return this.z.m();
  }
  
  public boolean n() {
    return this.z.n();
  }
  
  public boolean o() {
    return this.z.o();
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.z.setGroupDividerEnabled(paramBoolean);
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    w(0, null, paramInt, null, null);
    return this;
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    w(0, null, 0, paramDrawable, null);
    return this;
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    w(paramInt, null, 0, null, null);
    return this;
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    w(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  public SubMenu setHeaderView(View paramView) {
    w(0, null, 0, null, paramView);
    return this;
  }
  
  public SubMenu setIcon(int paramInt) {
    this.A.setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    this.A.setIcon(paramDrawable);
    return this;
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.z.setQwertyMode(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */