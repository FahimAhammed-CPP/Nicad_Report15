package androidx.savedstate;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.text.TextUtils;
import h5.oa1;
import java.io.File;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import v5.o3;

public final class e {
  public static final String a(Reader paramReader) {
    StringWriter stringWriter = new StringWriter();
    char[] arrayOfChar = new char[8192];
    for (int i = paramReader.read(arrayOfChar); i >= 0; i = paramReader.read(arrayOfChar))
      stringWriter.write(arrayOfChar, 0, i); 
    String str = stringWriter.toString();
    oa1.e(str, "buffer.toString()");
    return str;
  }
  
  public static Set<String> b(SQLiteDatabase paramSQLiteDatabase, String paramString) {
    HashSet<? super String> hashSet = new HashSet();
    StringBuilder stringBuilder = new StringBuilder(d.a(paramString, 22));
    stringBuilder.append("SELECT * FROM ");
    stringBuilder.append(paramString);
    stringBuilder.append(" LIMIT 0");
    Cursor cursor = paramSQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    try {
      Collections.addAll(hashSet, cursor.getColumnNames());
      return (Set)hashSet;
    } finally {
      cursor.close();
    } 
  }
  
  public static void c(o3 paramo3, SQLiteDatabase paramSQLiteDatabase) {
    if (paramo3 != null) {
      File file = new File(paramSQLiteDatabase.getPath());
      if (!file.setReadable(false, false))
        paramo3.p.c("Failed to turn off database read permission"); 
      if (!file.setWritable(false, false))
        paramo3.p.c("Failed to turn off database write permission"); 
      if (!file.setReadable(true, true))
        paramo3.p.c("Failed to turn on database read permission for owner"); 
      if (!file.setWritable(true, true))
        paramo3.p.c("Failed to turn on database write permission for owner"); 
      return;
    } 
    throw new IllegalArgumentException("Monitor must not be null");
  }
  
  public static void d(o3 paramo3, SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    IllegalArgumentException illegalArgumentException;
    Set<String> set;
    byte b;
    if (paramo3 != null) {
      boolean bool;
      Cursor cursor2 = null;
      Cursor cursor1 = null;
      b = 0;
      try {
        Cursor cursor = paramSQLiteDatabase.query("SQLITE_MASTER", new String[] { "name" }, "name=?", new String[] { paramString1 }, null, null, null);
        cursor1 = cursor;
        cursor2 = cursor;
        bool = cursor.moveToFirst();
        cursor.close();
      } catch (SQLiteException sQLiteException1) {
        cursor1 = cursor2;
        paramo3.p.e("Error querying for table", paramString1, sQLiteException1);
        if (cursor2 != null)
          cursor2.close(); 
        bool = false;
      } finally {}
      if (!bool)
        paramSQLiteDatabase.execSQL(paramString2); 
      try {
        set = b(paramSQLiteDatabase, paramString1);
        String[] arrayOfString = paramString3.split(",");
        int j = arrayOfString.length;
        int i = 0;
        while (i < j) {
          paramString3 = arrayOfString[i];
          if (((HashSet)set).remove(paramString3)) {
            i++;
            continue;
          } 
          StringBuilder stringBuilder = new StringBuilder(paramString1.length() + 35 + String.valueOf(paramString3).length());
          stringBuilder.append("Table ");
          stringBuilder.append(paramString1);
          stringBuilder.append(" is missing required column: ");
          stringBuilder.append(paramString3);
          throw new SQLiteException(stringBuilder.toString());
        } 
      } catch (SQLiteException sQLiteException) {
        paramo3.m.d("Failed to verify columns on table that was just created", paramString1);
        throw sQLiteException;
      } 
    } else {
      illegalArgumentException = new IllegalArgumentException("Monitor must not be null");
      throw illegalArgumentException;
    } 
    if (paramArrayOfString != null) {
      int i;
      for (i = b;; i += 2) {
        if (i < paramArrayOfString.length) {
          paramString3 = paramArrayOfString[i];
          if (!((HashSet)set).remove(paramString3))
            sQLiteException.execSQL(paramArrayOfString[i + 1]); 
          continue;
        } 
        if (!((HashSet)set).isEmpty())
          ((o3)illegalArgumentException).p.e("Table has extra columns. table, columns", paramString1, TextUtils.join(", ", set)); 
        return;
      } 
    } 
    if (!((HashSet)set).isEmpty())
      ((o3)illegalArgumentException).p.e("Table has extra columns. table, columns", paramString1, TextUtils.join(", ", set)); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\savedstate\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */