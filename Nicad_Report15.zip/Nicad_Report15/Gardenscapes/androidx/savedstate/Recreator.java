package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import e.g;
import j.f;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@SuppressLint({"RestrictedApi"})
final class Recreator implements h {
  public final c f;
  
  public Recreator(c paramc) {
    this.f = paramc;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent == Lifecycle.Event.ON_CREATE) {
      k k = (k)paramj.getLifecycle();
      k.d("removeObserver");
      k.a.j(this);
      Bundle bundle = this.f.getSavedStateRegistry().a("androidx.savedstate.Restarter");
      if (bundle == null)
        return; 
      ArrayList arrayList = bundle.getStringArrayList("classes_to_restore");
      if (arrayList != null) {
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
          String str = iterator.next();
          try {
            Class<? extends a.a> clazz = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(a.a.class);
            try {
              Constructor<? extends a.a> constructor = clazz.getDeclaredConstructor(new Class[0]);
              constructor.setAccessible(true);
              try {
                a.a a = constructor.newInstance(new Object[0]);
                a.a(this.f);
              } catch (Exception exception) {
                throw new RuntimeException(f.a("Failed to instantiate ", str), exception);
              } 
            } catch (NoSuchMethodException noSuchMethodException) {
              StringBuilder stringBuilder = android.support.v4.media.a.a("Class");
              stringBuilder.append(exception.getSimpleName());
              stringBuilder.append(" must have default constructor in order to be automatically recreated");
              throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
            } 
          } catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException(g.a("Class ", noSuchMethodException, " wasn't found"), classNotFoundException);
          } 
        } 
        return;
      } 
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    } 
    AssertionError assertionError = new AssertionError("Next event must be ON_CREATE");
    throw assertionError;
  }
  
  public static final class a implements a.b {
    public final Set<String> a = new HashSet<String>();
    
    public a(a param1a) {
      param1a.b("androidx.savedstate.Restarter", this);
    }
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      bundle.putStringArrayList("classes_to_restore", new ArrayList<String>(this.a));
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */