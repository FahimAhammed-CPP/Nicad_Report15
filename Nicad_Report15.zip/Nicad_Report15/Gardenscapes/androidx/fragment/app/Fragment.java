package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.u;
import androidx.lifecycle.y;
import androidx.savedstate.c;
import b0.u;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, j, d0, c {
  public static final int ACTIVITY_CREATED = 4;
  
  public static final int ATTACHED = 0;
  
  public static final int AWAITING_ENTER_EFFECTS = 6;
  
  public static final int AWAITING_EXIT_EFFECTS = 3;
  
  public static final int CREATED = 1;
  
  public static final int INITIALIZING = -1;
  
  public static final int RESUMED = 7;
  
  public static final int STARTED = 5;
  
  public static final Object USE_DEFAULT_TRANSITION = new Object();
  
  public static final int VIEW_CREATED = 2;
  
  public boolean mAdded;
  
  public i mAnimationInfo;
  
  public Bundle mArguments;
  
  public int mBackStackNesting;
  
  private boolean mCalled;
  
  public FragmentManager mChildFragmentManager = new z();
  
  public ViewGroup mContainer;
  
  public int mContainerId;
  
  private int mContentLayoutId;
  
  public y mDefaultFactory;
  
  public boolean mDeferStart;
  
  public boolean mDetached;
  
  public int mFragmentId;
  
  public FragmentManager mFragmentManager;
  
  public boolean mFromLayout;
  
  public boolean mHasMenu;
  
  public boolean mHidden;
  
  public boolean mHiddenChanged;
  
  public w<?> mHost;
  
  public boolean mInLayout;
  
  public boolean mIsCreated;
  
  public boolean mIsNewlyAdded;
  
  private Boolean mIsPrimaryNavigationFragment = null;
  
  public LayoutInflater mLayoutInflater;
  
  public androidx.lifecycle.k mLifecycleRegistry;
  
  public Lifecycle.State mMaxState = Lifecycle.State.j;
  
  public boolean mMenuVisible = true;
  
  private final AtomicInteger mNextLocalRequestCode = new AtomicInteger();
  
  private final ArrayList<j> mOnPreAttachedListeners = new ArrayList<j>();
  
  public Fragment mParentFragment;
  
  public boolean mPerformedCreateView;
  
  public float mPostponedAlpha;
  
  public Runnable mPostponedDurationRunnable = new a(this);
  
  public boolean mRemoving;
  
  public boolean mRestored;
  
  public boolean mRetainInstance;
  
  public boolean mRetainInstanceChangedWhileDetached;
  
  public Bundle mSavedFragmentState;
  
  public androidx.savedstate.b mSavedStateRegistryController;
  
  public Boolean mSavedUserVisibleHint;
  
  public Bundle mSavedViewRegistryState;
  
  public SparseArray<Parcelable> mSavedViewState;
  
  public int mState = -1;
  
  public String mTag;
  
  public Fragment mTarget;
  
  public int mTargetRequestCode;
  
  public String mTargetWho = null;
  
  public boolean mUserVisibleHint = true;
  
  public View mView;
  
  public s0 mViewLifecycleOwner;
  
  public o<j> mViewLifecycleOwnerLiveData = new o();
  
  public String mWho = UUID.randomUUID().toString();
  
  public Fragment() {
    initLifecycle();
  }
  
  public Fragment(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private i ensureAnimationInfo() {
    if (this.mAnimationInfo == null)
      this.mAnimationInfo = new i(); 
    return this.mAnimationInfo;
  }
  
  private int getMinimumMaxLifecycleState() {
    Lifecycle.State state = this.mMaxState;
    return (state == Lifecycle.State.g || this.mParentFragment == null) ? state.ordinal() : Math.min(state.ordinal(), this.mParentFragment.getMinimumMaxLifecycleState());
  }
  
  private void initLifecycle() {
    this.mLifecycleRegistry = new androidx.lifecycle.k(this);
    this.mSavedStateRegistryController = new androidx.savedstate.b(this);
    this.mDefaultFactory = null;
  }
  
  @Deprecated
  public static Fragment instantiate(Context paramContext, String paramString) {
    return instantiate(paramContext, paramString, null);
  }
  
  @Deprecated
  public static Fragment instantiate(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Fragment fragment = v.c(paramContext.getClassLoader(), paramString).getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.setArguments(paramBundle);
      } 
      return fragment;
    } catch (InstantiationException instantiationException) {
      throw new InstantiationException(e.g.a("Unable to instantiate fragment ", paramString, ": make sure class name exists, is public, and has an empty constructor that is public"), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new InstantiationException(e.g.a("Unable to instantiate fragment ", paramString, ": make sure class name exists, is public, and has an empty constructor that is public"), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new InstantiationException(e.g.a("Unable to instantiate fragment ", paramString, ": could not find Fragment constructor"), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new InstantiationException(e.g.a("Unable to instantiate fragment ", paramString, ": calling Fragment constructor caused an exception"), invocationTargetException);
    } 
  }
  
  private <I, O> androidx.activity.result.c<I> prepareCallInternal(d.a<I, O> parama, n.a<Void, ActivityResultRegistry> parama1, androidx.activity.result.b<O> paramb) {
    if (this.mState <= 1) {
      AtomicReference atomicReference = new AtomicReference();
      registerOnPreAttachListener(new g(this, parama1, atomicReference, parama, paramb));
      return new h(this, atomicReference, parama);
    } 
    throw new IllegalStateException(m.a("Fragment ", this, " is attempting to registerForActivityResult after being created. Fragments must call registerForActivityResult() before they are created (i.e. initialization, onAttach(), or onCreate())."));
  }
  
  private void registerOnPreAttachListener(j paramj) {
    if (this.mState >= 0) {
      paramj.a();
      return;
    } 
    this.mOnPreAttachedListeners.add(paramj);
  }
  
  private void restoreViewState() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESTORE_VIEW_STATE: ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    if (this.mView != null)
      restoreViewState(this.mSavedFragmentState); 
    this.mSavedFragmentState = null;
  }
  
  public void callStartTransitionListener(boolean paramBoolean) {
    i i1 = this.mAnimationInfo;
    k k1 = null;
    if (i1 != null) {
      i1.u = false;
      k1 = i1.v;
      i1.v = null;
    } 
    if (k1 != null) {
      k1 = k1;
      int m = ((FragmentManager.o)k1).c - 1;
      ((FragmentManager.o)k1).c = m;
      if (m != 0)
        return; 
      ((FragmentManager.o)k1).b.q.d0();
      return;
    } 
    if (this.mView != null) {
      ViewGroup viewGroup = this.mContainer;
      if (viewGroup != null) {
        FragmentManager fragmentManager = this.mFragmentManager;
        if (fragmentManager != null) {
          SpecialEffectsController specialEffectsController = SpecialEffectsController.f(viewGroup, fragmentManager);
          specialEffectsController.h();
          if (paramBoolean) {
            this.mHost.h.post(new c(this, specialEffectsController));
            return;
          } 
          specialEffectsController.c();
        } 
      } 
    } 
  }
  
  public s createFragmentContainer() {
    return new d(this);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.mFragmentId));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.mContainerId));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.mTag);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.mState);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.mWho);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.mBackStackNesting);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.mAdded);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.mRemoving);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.mFromLayout);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.mInLayout);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.mHidden);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.mDetached);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.mMenuVisible);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.mHasMenu);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.mRetainInstance);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.mUserVisibleHint);
    if (this.mFragmentManager != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.mFragmentManager);
    } 
    if (this.mHost != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.mHost);
    } 
    if (this.mParentFragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.mParentFragment);
    } 
    if (this.mArguments != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.mArguments);
    } 
    if (this.mSavedFragmentState != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.mSavedFragmentState);
    } 
    if (this.mSavedViewState != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.mSavedViewState);
    } 
    if (this.mSavedViewRegistryState != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewRegistryState=");
      paramPrintWriter.println(this.mSavedViewRegistryState);
    } 
    Fragment fragment = getTargetFragment();
    if (fragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(fragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.mTargetRequestCode);
    } 
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mPopDirection=");
    paramPrintWriter.println(getPopDirection());
    if (getEnterAnim() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getEnterAnim=");
      paramPrintWriter.println(getEnterAnim());
    } 
    if (getExitAnim() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getExitAnim=");
      paramPrintWriter.println(getExitAnim());
    } 
    if (getPopEnterAnim() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopEnterAnim=");
      paramPrintWriter.println(getPopEnterAnim());
    } 
    if (getPopExitAnim() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopExitAnim=");
      paramPrintWriter.println(getPopExitAnim());
    } 
    if (this.mContainer != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.mContainer);
    } 
    if (this.mView != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.mView);
    } 
    if (getAnimatingAway() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(getAnimatingAway());
    } 
    if (getContext() != null)
      z0.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Child ");
    stringBuilder.append(this.mChildFragmentManager);
    stringBuilder.append(":");
    paramPrintWriter.println(stringBuilder.toString());
    this.mChildFragmentManager.y(j.f.a(paramString, "  "), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public Fragment findFragmentByWho(String paramString) {
    return paramString.equals(this.mWho) ? this : this.mChildFragmentManager.c.e(paramString);
  }
  
  public String generateActivityResultKey() {
    StringBuilder stringBuilder = android.support.v4.media.a.a("fragment_");
    stringBuilder.append(this.mWho);
    stringBuilder.append("_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return stringBuilder.toString();
  }
  
  public final n getActivity() {
    w<?> w1 = this.mHost;
    return (w1 == null) ? null : (n)w1.f;
  }
  
  public boolean getAllowEnterTransitionOverlap() {
    i i1 = this.mAnimationInfo;
    if (i1 != null) {
      Boolean bool = i1.r;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public boolean getAllowReturnTransitionOverlap() {
    i i1 = this.mAnimationInfo;
    if (i1 != null) {
      Boolean bool = i1.q;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public View getAnimatingAway() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.a;
  }
  
  public Animator getAnimator() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.b;
  }
  
  public final Bundle getArguments() {
    return this.mArguments;
  }
  
  public final FragmentManager getChildFragmentManager() {
    if (this.mHost != null)
      return this.mChildFragmentManager; 
    throw new IllegalStateException(m.a("Fragment ", this, " has not been attached yet."));
  }
  
  public Context getContext() {
    w<?> w1 = this.mHost;
    return (w1 == null) ? null : w1.g;
  }
  
  public y getDefaultViewModelProviderFactory() {
    if (this.mFragmentManager != null) {
      if (this.mDefaultFactory == null) {
        Application application1;
        Application application2 = null;
        Context context = requireContext().getApplicationContext();
        while (true) {
          application1 = application2;
          if (context instanceof ContextWrapper) {
            if (context instanceof Application) {
              application1 = (Application)context;
              break;
            } 
            context = ((ContextWrapper)context).getBaseContext();
            continue;
          } 
          break;
        } 
        if (application1 == null && FragmentManager.O(3)) {
          StringBuilder stringBuilder = android.support.v4.media.a.a("Could not find Application instance from Context ");
          stringBuilder.append(requireContext().getApplicationContext());
          stringBuilder.append(", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
          Log.d("FragmentManager", stringBuilder.toString());
        } 
        this.mDefaultFactory = (y)new u(application1, this, getArguments());
      } 
      return this.mDefaultFactory;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Can't access ViewModels from detached fragment");
    throw illegalStateException;
  }
  
  public int getEnterAnim() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 0 : i1.d;
  }
  
  public Object getEnterTransition() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.k;
  }
  
  public u getEnterTransitionCallback() {
    i i1 = this.mAnimationInfo;
    if (i1 == null)
      return null; 
    Objects.requireNonNull(i1);
    return null;
  }
  
  public int getExitAnim() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 0 : i1.e;
  }
  
  public Object getExitTransition() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.m;
  }
  
  public u getExitTransitionCallback() {
    i i1 = this.mAnimationInfo;
    if (i1 == null)
      return null; 
    Objects.requireNonNull(i1);
    return null;
  }
  
  public View getFocusedView() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.t;
  }
  
  @Deprecated
  public final FragmentManager getFragmentManager() {
    return this.mFragmentManager;
  }
  
  public final Object getHost() {
    w<?> w1 = this.mHost;
    return (w1 == null) ? null : w1.d();
  }
  
  public final int getId() {
    return this.mFragmentId;
  }
  
  public final LayoutInflater getLayoutInflater() {
    LayoutInflater layoutInflater2 = this.mLayoutInflater;
    LayoutInflater layoutInflater1 = layoutInflater2;
    if (layoutInflater2 == null)
      layoutInflater1 = performGetLayoutInflater(null); 
    return layoutInflater1;
  }
  
  @Deprecated
  public LayoutInflater getLayoutInflater(Bundle paramBundle) {
    w<?> w1 = this.mHost;
    if (w1 != null) {
      LayoutInflater layoutInflater = w1.e();
      m0.f.b(layoutInflater, this.mChildFragmentManager.f);
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)this.mLifecycleRegistry;
  }
  
  @Deprecated
  public z0.a getLoaderManager() {
    return z0.a.b(this);
  }
  
  public int getNextTransition() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 0 : i1.h;
  }
  
  public final Fragment getParentFragment() {
    return this.mParentFragment;
  }
  
  public final FragmentManager getParentFragmentManager() {
    FragmentManager fragmentManager = this.mFragmentManager;
    if (fragmentManager != null)
      return fragmentManager; 
    throw new IllegalStateException(m.a("Fragment ", this, " not associated with a fragment manager."));
  }
  
  public boolean getPopDirection() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? false : i1.c;
  }
  
  public int getPopEnterAnim() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 0 : i1.f;
  }
  
  public int getPopExitAnim() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 0 : i1.g;
  }
  
  public float getPostOnViewCreatedAlpha() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? 1.0F : i1.s;
  }
  
  public Object getReenterTransition() {
    i i1 = this.mAnimationInfo;
    if (i1 == null)
      return null; 
    Object object2 = i1.n;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getExitTransition(); 
    return object1;
  }
  
  public final Resources getResources() {
    return requireContext().getResources();
  }
  
  @Deprecated
  public final boolean getRetainInstance() {
    return this.mRetainInstance;
  }
  
  public Object getReturnTransition() {
    i i1 = this.mAnimationInfo;
    if (i1 == null)
      return null; 
    Object object2 = i1.l;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getEnterTransition(); 
    return object1;
  }
  
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b;
  }
  
  public Object getSharedElementEnterTransition() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? null : i1.o;
  }
  
  public Object getSharedElementReturnTransition() {
    i i1 = this.mAnimationInfo;
    if (i1 == null)
      return null; 
    Object object2 = i1.p;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getSharedElementEnterTransition(); 
    return object1;
  }
  
  public ArrayList<String> getSharedElementSourceNames() {
    i i1 = this.mAnimationInfo;
    if (i1 != null) {
      ArrayList<String> arrayList = i1.i;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  public ArrayList<String> getSharedElementTargetNames() {
    i i1 = this.mAnimationInfo;
    if (i1 != null) {
      ArrayList<String> arrayList = i1.j;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  public final String getString(int paramInt) {
    return getResources().getString(paramInt);
  }
  
  public final String getString(int paramInt, Object... paramVarArgs) {
    return getResources().getString(paramInt, paramVarArgs);
  }
  
  public final String getTag() {
    return this.mTag;
  }
  
  @Deprecated
  public final Fragment getTargetFragment() {
    Fragment fragment = this.mTarget;
    if (fragment != null)
      return fragment; 
    FragmentManager fragmentManager = this.mFragmentManager;
    if (fragmentManager != null) {
      String str = this.mTargetWho;
      if (str != null)
        return fragmentManager.G(str); 
    } 
    return null;
  }
  
  @Deprecated
  public final int getTargetRequestCode() {
    return this.mTargetRequestCode;
  }
  
  public final CharSequence getText(int paramInt) {
    return getResources().getText(paramInt);
  }
  
  @Deprecated
  public boolean getUserVisibleHint() {
    return this.mUserVisibleHint;
  }
  
  public View getView() {
    return this.mView;
  }
  
  public j getViewLifecycleOwner() {
    s0 s01 = this.mViewLifecycleOwner;
    if (s01 != null)
      return (j)s01; 
    throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
  }
  
  public LiveData<j> getViewLifecycleOwnerLiveData() {
    return (LiveData<j>)this.mViewLifecycleOwnerLiveData;
  }
  
  public c0 getViewModelStore() {
    if (this.mFragmentManager != null) {
      if (getMinimumMaxLifecycleState() != 1) {
        b0 b0 = this.mFragmentManager.K;
        c0 c02 = b0.e.get(this.mWho);
        c0 c01 = c02;
        if (c02 == null) {
          c01 = new c0();
          b0.e.put(this.mWho, c01);
        } 
        return c01;
      } 
      throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  @SuppressLint({"KotlinPropertyAccess"})
  public final boolean hasOptionsMenu() {
    return this.mHasMenu;
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public void initState() {
    initLifecycle();
    this.mWho = UUID.randomUUID().toString();
    this.mAdded = false;
    this.mRemoving = false;
    this.mFromLayout = false;
    this.mInLayout = false;
    this.mRestored = false;
    this.mBackStackNesting = 0;
    this.mFragmentManager = null;
    this.mChildFragmentManager = new z();
    this.mHost = null;
    this.mFragmentId = 0;
    this.mContainerId = 0;
    this.mTag = null;
    this.mHidden = false;
    this.mDetached = false;
  }
  
  public final boolean isAdded() {
    return (this.mHost != null && this.mAdded);
  }
  
  public final boolean isDetached() {
    return this.mDetached;
  }
  
  public final boolean isHidden() {
    return this.mHidden;
  }
  
  public boolean isHideReplaced() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? false : i1.w;
  }
  
  public final boolean isInBackStack() {
    return (this.mBackStackNesting > 0);
  }
  
  public final boolean isInLayout() {
    return this.mInLayout;
  }
  
  public final boolean isMenuVisible() {
    if (this.mMenuVisible) {
      FragmentManager fragmentManager = this.mFragmentManager;
      if (fragmentManager == null || fragmentManager.Q(this.mParentFragment))
        return true; 
    } 
    return false;
  }
  
  public boolean isPostponed() {
    i i1 = this.mAnimationInfo;
    return (i1 == null) ? false : i1.u;
  }
  
  public final boolean isRemoving() {
    return this.mRemoving;
  }
  
  public final boolean isRemovingParent() {
    Fragment fragment = getParentFragment();
    return (fragment != null && (fragment.isRemoving() || fragment.isRemovingParent()));
  }
  
  public final boolean isResumed() {
    return (this.mState >= 7);
  }
  
  public final boolean isStateSaved() {
    FragmentManager fragmentManager = this.mFragmentManager;
    return (fragmentManager == null) ? false : fragmentManager.S();
  }
  
  public final boolean isVisible() {
    if (isAdded() && !isHidden()) {
      View view = this.mView;
      if (view != null && view.getWindowToken() != null && this.mView.getVisibility() == 0)
        return true; 
    } 
    return false;
  }
  
  public void noteStateNotSaved() {
    this.mChildFragmentManager.V();
  }
  
  @Deprecated
  public void onActivityCreated(Bundle paramBundle) {
    this.mCalled = true;
  }
  
  @Deprecated
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" resultCode: ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" data: ");
      stringBuilder.append(paramIntent);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  @Deprecated
  public void onAttach(Activity paramActivity) {
    this.mCalled = true;
  }
  
  public void onAttach(Context paramContext) {
    Activity activity;
    this.mCalled = true;
    w<?> w1 = this.mHost;
    if (w1 == null) {
      w1 = null;
    } else {
      activity = w1.f;
    } 
    if (activity != null) {
      this.mCalled = false;
      onAttach(activity);
    } 
  }
  
  @Deprecated
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.mCalled = true;
  }
  
  public boolean onContextItemSelected(MenuItem paramMenuItem) {
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    boolean bool = true;
    this.mCalled = true;
    restoreChildFragmentState(paramBundle);
    FragmentManager fragmentManager = this.mChildFragmentManager;
    if (fragmentManager.q < 1)
      bool = false; 
    if (!bool)
      fragmentManager.m(); 
  }
  
  public Animation onCreateAnimation(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public Animator onCreateAnimator(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    requireActivity().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    int m = this.mContentLayoutId;
    return (m != 0) ? paramLayoutInflater.inflate(m, paramViewGroup, false) : null;
  }
  
  public void onDestroy() {
    this.mCalled = true;
  }
  
  public void onDestroyOptionsMenu() {}
  
  public void onDestroyView() {
    this.mCalled = true;
  }
  
  public void onDetach() {
    this.mCalled = true;
  }
  
  public LayoutInflater onGetLayoutInflater(Bundle paramBundle) {
    return getLayoutInflater(paramBundle);
  }
  
  public void onHiddenChanged(boolean paramBoolean) {}
  
  @Deprecated
  public void onInflate(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.mCalled = true;
  }
  
  public void onInflate(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.mCalled = true;
    w<?> w1 = this.mHost;
    if (w1 == null) {
      w1 = null;
    } else {
      activity = w1.f;
    } 
    if (activity != null) {
      this.mCalled = false;
      onInflate(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public void onLowMemory() {
    this.mCalled = true;
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {}
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    return false;
  }
  
  public void onOptionsMenuClosed(Menu paramMenu) {}
  
  public void onPause() {
    this.mCalled = true;
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {}
  
  public void onPrepareOptionsMenu(Menu paramMenu) {}
  
  public void onPrimaryNavigationFragmentChanged(boolean paramBoolean) {}
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public void onResume() {
    this.mCalled = true;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {}
  
  public void onStart() {
    this.mCalled = true;
  }
  
  public void onStop() {
    this.mCalled = true;
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {}
  
  public void onViewStateRestored(Bundle paramBundle) {
    this.mCalled = true;
  }
  
  public void performActivityCreated(Bundle paramBundle) {
    this.mChildFragmentManager.V();
    this.mState = 3;
    this.mCalled = false;
    onActivityCreated(paramBundle);
    if (this.mCalled) {
      restoreViewState();
      FragmentManager fragmentManager = this.mChildFragmentManager;
      fragmentManager.C = false;
      fragmentManager.D = false;
      fragmentManager.K.h = false;
      fragmentManager.w(4);
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onActivityCreated()"));
  }
  
  public void performAttach() {
    Iterator<j> iterator = this.mOnPreAttachedListeners.iterator();
    while (iterator.hasNext())
      ((j)iterator.next()).a(); 
    this.mOnPreAttachedListeners.clear();
    this.mChildFragmentManager.b(this.mHost, createFragmentContainer(), this);
    this.mState = 0;
    this.mCalled = false;
    onAttach(this.mHost.g);
    if (this.mCalled) {
      FragmentManager fragmentManager = this.mFragmentManager;
      Iterator<c0> iterator1 = fragmentManager.p.iterator();
      while (iterator1.hasNext())
        ((c0)iterator1.next()).a(fragmentManager, this); 
      fragmentManager = this.mChildFragmentManager;
      fragmentManager.C = false;
      fragmentManager.D = false;
      fragmentManager.K.h = false;
      fragmentManager.w(0);
      return;
    } 
    SuperNotCalledException superNotCalledException = new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onAttach()"));
    throw superNotCalledException;
  }
  
  public void performConfigurationChanged(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    this.mChildFragmentManager.k(paramConfiguration);
  }
  
  public boolean performContextItemSelected(MenuItem paramMenuItem) {
    return !this.mHidden ? (onContextItemSelected(paramMenuItem) ? true : this.mChildFragmentManager.l(paramMenuItem)) : false;
  }
  
  public void performCreate(Bundle paramBundle) {
    this.mChildFragmentManager.V();
    this.mState = 1;
    this.mCalled = false;
    this.mLifecycleRegistry.a((androidx.lifecycle.i)new androidx.lifecycle.h(this) {
          public void a(j param1j, Lifecycle.Event param1Event) {
            if (param1Event == Lifecycle.Event.ON_STOP) {
              View view = this.f.mView;
              if (view != null)
                view.cancelPendingInputEvents(); 
            } 
          }
        });
    this.mSavedStateRegistryController.a(paramBundle);
    onCreate(paramBundle);
    this.mIsCreated = true;
    if (this.mCalled) {
      this.mLifecycleRegistry.e(Lifecycle.Event.ON_CREATE);
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onCreate()"));
  }
  
  public boolean performCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool3 = this.mHidden;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.mHasMenu) {
        bool = bool1;
        if (this.mMenuVisible) {
          bool = true;
          onCreateOptionsMenu(paramMenu, paramMenuInflater);
        } 
      } 
      bool2 = bool | this.mChildFragmentManager.n(paramMenu, paramMenuInflater);
    } 
    return bool2;
  }
  
  public void performCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.mChildFragmentManager.V();
    boolean bool = true;
    this.mPerformedCreateView = true;
    this.mViewLifecycleOwner = new s0(this, getViewModelStore());
    View view = onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
    this.mView = view;
    if (view != null) {
      this.mViewLifecycleOwner.b();
      this.mView.setTag(2131231215, this.mViewLifecycleOwner);
      this.mView.setTag(2131231217, this.mViewLifecycleOwner);
      this.mView.setTag(2131231216, this.mViewLifecycleOwner);
      this.mViewLifecycleOwnerLiveData.i(this.mViewLifecycleOwner);
      return;
    } 
    if (this.mViewLifecycleOwner.g == null)
      bool = false; 
    if (!bool) {
      this.mViewLifecycleOwner = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  public void performDestroy() {
    this.mChildFragmentManager.o();
    this.mLifecycleRegistry.e(Lifecycle.Event.ON_DESTROY);
    this.mState = 0;
    this.mCalled = false;
    this.mIsCreated = false;
    onDestroy();
    if (this.mCalled)
      return; 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onDestroy()"));
  }
  
  public void performDestroyView() {
    this.mChildFragmentManager.w(1);
    if (this.mView != null) {
      boolean bool;
      s0 s01 = this.mViewLifecycleOwner;
      s01.b();
      if (s01.g.b.compareTo(Lifecycle.State.h) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        this.mViewLifecycleOwner.a(Lifecycle.Event.ON_DESTROY); 
    } 
    this.mState = 1;
    this.mCalled = false;
    onDestroyView();
    if (this.mCalled) {
      z0.b.c c1 = ((z0.b)z0.a.b(this)).b;
      int n = c1.c.g();
      for (int m = 0; m < n; m++)
        ((z0.b.a)c1.c.h(m)).l(); 
      this.mPerformedCreateView = false;
      return;
    } 
    SuperNotCalledException superNotCalledException = new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onDestroyView()"));
    throw superNotCalledException;
  }
  
  public void performDetach() {
    this.mState = -1;
    this.mCalled = false;
    onDetach();
    this.mLayoutInflater = null;
    if (this.mCalled) {
      FragmentManager fragmentManager = this.mChildFragmentManager;
      if (!fragmentManager.E) {
        fragmentManager.o();
        this.mChildFragmentManager = new z();
      } 
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onDetach()"));
  }
  
  public LayoutInflater performGetLayoutInflater(Bundle paramBundle) {
    LayoutInflater layoutInflater = onGetLayoutInflater(paramBundle);
    this.mLayoutInflater = layoutInflater;
    return layoutInflater;
  }
  
  public void performLowMemory() {
    onLowMemory();
    this.mChildFragmentManager.p();
  }
  
  public void performMultiWindowModeChanged(boolean paramBoolean) {
    onMultiWindowModeChanged(paramBoolean);
    this.mChildFragmentManager.q(paramBoolean);
  }
  
  public boolean performOptionsItemSelected(MenuItem paramMenuItem) {
    return !this.mHidden ? ((this.mHasMenu && this.mMenuVisible && onOptionsItemSelected(paramMenuItem)) ? true : this.mChildFragmentManager.r(paramMenuItem)) : false;
  }
  
  public void performOptionsMenuClosed(Menu paramMenu) {
    if (!this.mHidden) {
      if (this.mHasMenu && this.mMenuVisible)
        onOptionsMenuClosed(paramMenu); 
      this.mChildFragmentManager.s(paramMenu);
    } 
  }
  
  public void performPause() {
    this.mChildFragmentManager.w(5);
    if (this.mView != null)
      this.mViewLifecycleOwner.a(Lifecycle.Event.ON_PAUSE); 
    this.mLifecycleRegistry.e(Lifecycle.Event.ON_PAUSE);
    this.mState = 6;
    this.mCalled = false;
    onPause();
    if (this.mCalled)
      return; 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onPause()"));
  }
  
  public void performPictureInPictureModeChanged(boolean paramBoolean) {
    onPictureInPictureModeChanged(paramBoolean);
    this.mChildFragmentManager.u(paramBoolean);
  }
  
  public boolean performPrepareOptionsMenu(Menu paramMenu) {
    boolean bool3 = this.mHidden;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.mHasMenu) {
        bool = bool1;
        if (this.mMenuVisible) {
          bool = true;
          onPrepareOptionsMenu(paramMenu);
        } 
      } 
      bool2 = bool | this.mChildFragmentManager.v(paramMenu);
    } 
    return bool2;
  }
  
  public void performPrimaryNavigationFragmentChanged() {
    boolean bool = this.mFragmentManager.R(this);
    Boolean bool1 = this.mIsPrimaryNavigationFragment;
    if (bool1 == null || bool1.booleanValue() != bool) {
      this.mIsPrimaryNavigationFragment = Boolean.valueOf(bool);
      onPrimaryNavigationFragmentChanged(bool);
      FragmentManager fragmentManager = this.mChildFragmentManager;
      fragmentManager.k0();
      fragmentManager.t(fragmentManager.u);
    } 
  }
  
  public void performResume() {
    this.mChildFragmentManager.V();
    this.mChildFragmentManager.C(true);
    this.mState = 7;
    this.mCalled = false;
    onResume();
    if (this.mCalled) {
      androidx.lifecycle.k k1 = this.mLifecycleRegistry;
      Lifecycle.Event event = Lifecycle.Event.ON_RESUME;
      k1.e(event);
      if (this.mView != null) {
        k1 = this.mViewLifecycleOwner.g;
        k1.d("handleLifecycleEvent");
        k1.g(event.b());
      } 
      FragmentManager fragmentManager = this.mChildFragmentManager;
      fragmentManager.C = false;
      fragmentManager.D = false;
      fragmentManager.K.h = false;
      fragmentManager.w(7);
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onResume()"));
  }
  
  public void performSaveInstanceState(Bundle paramBundle) {
    onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.b(paramBundle);
    Parcelable parcelable = this.mChildFragmentManager.c0();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  public void performStart() {
    this.mChildFragmentManager.V();
    this.mChildFragmentManager.C(true);
    this.mState = 5;
    this.mCalled = false;
    onStart();
    if (this.mCalled) {
      androidx.lifecycle.k k1 = this.mLifecycleRegistry;
      Lifecycle.Event event = Lifecycle.Event.ON_START;
      k1.e(event);
      if (this.mView != null) {
        k1 = this.mViewLifecycleOwner.g;
        k1.d("handleLifecycleEvent");
        k1.g(event.b());
      } 
      FragmentManager fragmentManager = this.mChildFragmentManager;
      fragmentManager.C = false;
      fragmentManager.D = false;
      fragmentManager.K.h = false;
      fragmentManager.w(5);
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onStart()"));
  }
  
  public void performStop() {
    FragmentManager fragmentManager = this.mChildFragmentManager;
    fragmentManager.D = true;
    fragmentManager.K.h = true;
    fragmentManager.w(4);
    if (this.mView != null)
      this.mViewLifecycleOwner.a(Lifecycle.Event.ON_STOP); 
    this.mLifecycleRegistry.e(Lifecycle.Event.ON_STOP);
    this.mState = 4;
    this.mCalled = false;
    onStop();
    if (this.mCalled)
      return; 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onStop()"));
  }
  
  public void performViewCreated() {
    onViewCreated(this.mView, this.mSavedFragmentState);
    this.mChildFragmentManager.w(2);
  }
  
  public void postponeEnterTransition() {
    (ensureAnimationInfo()).u = true;
  }
  
  public final void postponeEnterTransition(long paramLong, TimeUnit paramTimeUnit) {
    Handler handler;
    (ensureAnimationInfo()).u = true;
    FragmentManager fragmentManager = this.mFragmentManager;
    if (fragmentManager != null) {
      handler = fragmentManager.r.h;
    } else {
      handler = new Handler(Looper.getMainLooper());
    } 
    handler.removeCallbacks(this.mPostponedDurationRunnable);
    handler.postDelayed(this.mPostponedDurationRunnable, paramTimeUnit.toMillis(paramLong));
  }
  
  public final <I, O> androidx.activity.result.c<I> registerForActivityResult(d.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, androidx.activity.result.b<O> paramb) {
    return prepareCallInternal(parama, new f(this, paramActivityResultRegistry), paramb);
  }
  
  public final <I, O> androidx.activity.result.c<I> registerForActivityResult(d.a<I, O> parama, androidx.activity.result.b<O> paramb) {
    return prepareCallInternal(parama, new e(this), paramb);
  }
  
  public void registerForContextMenu(View paramView) {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  @Deprecated
  public final void requestPermissions(String[] paramArrayOfString, int paramInt) {
    if (this.mHost != null) {
      FragmentManager fragmentManager = getParentFragmentManager();
      if (fragmentManager.z != null) {
        FragmentManager.k k1 = new FragmentManager.k(this.mWho, paramInt);
        fragmentManager.A.addLast(k1);
        fragmentManager.z.b(paramArrayOfString, null);
        return;
      } 
      Objects.requireNonNull(fragmentManager.r);
      return;
    } 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to Activity"));
  }
  
  public final n requireActivity() {
    n n = getActivity();
    if (n != null)
      return n; 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to an activity."));
  }
  
  public final Bundle requireArguments() {
    Bundle bundle = getArguments();
    if (bundle != null)
      return bundle; 
    throw new IllegalStateException(m.a("Fragment ", this, " does not have any arguments."));
  }
  
  public final Context requireContext() {
    Context context = getContext();
    if (context != null)
      return context; 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to a context."));
  }
  
  @Deprecated
  public final FragmentManager requireFragmentManager() {
    return getParentFragmentManager();
  }
  
  public final Object requireHost() {
    Object object = getHost();
    if (object != null)
      return object; 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to a host."));
  }
  
  public final Fragment requireParentFragment() {
    StringBuilder stringBuilder;
    Fragment fragment = getParentFragment();
    if (fragment == null) {
      if (getContext() == null)
        throw new IllegalStateException(m.a("Fragment ", this, " is not attached to any Fragment or host")); 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" is not a child Fragment, it is directly attached to ");
      stringBuilder.append(getContext());
      throw new IllegalStateException(stringBuilder.toString());
    } 
    return (Fragment)stringBuilder;
  }
  
  public final View requireView() {
    View view = getView();
    if (view != null)
      return view; 
    throw new IllegalStateException(m.a("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
  }
  
  public void restoreChildFragmentState(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.mChildFragmentManager.b0(parcelable);
        this.mChildFragmentManager.m();
      } 
    } 
  }
  
  public final void restoreViewState(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.mSavedViewState;
    if (sparseArray != null) {
      this.mView.restoreHierarchyState(sparseArray);
      this.mSavedViewState = null;
    } 
    if (this.mView != null) {
      s0 s01 = this.mViewLifecycleOwner;
      Bundle bundle = this.mSavedViewRegistryState;
      s01.h.a(bundle);
      this.mSavedViewRegistryState = null;
    } 
    this.mCalled = false;
    onViewStateRestored(paramBundle);
    if (this.mCalled) {
      if (this.mView != null)
        this.mViewLifecycleOwner.a(Lifecycle.Event.ON_CREATE); 
      return;
    } 
    throw new SuperNotCalledException(m.a("Fragment ", this, " did not call through to super.onViewStateRestored()"));
  }
  
  public void setAllowEnterTransitionOverlap(boolean paramBoolean) {
    (ensureAnimationInfo()).r = Boolean.valueOf(paramBoolean);
  }
  
  public void setAllowReturnTransitionOverlap(boolean paramBoolean) {
    (ensureAnimationInfo()).q = Boolean.valueOf(paramBoolean);
  }
  
  public void setAnimatingAway(View paramView) {
    (ensureAnimationInfo()).a = paramView;
  }
  
  public void setAnimations(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mAnimationInfo == null && paramInt1 == 0 && paramInt2 == 0 && paramInt3 == 0 && paramInt4 == 0)
      return; 
    (ensureAnimationInfo()).d = paramInt1;
    (ensureAnimationInfo()).e = paramInt2;
    (ensureAnimationInfo()).f = paramInt3;
    (ensureAnimationInfo()).g = paramInt4;
  }
  
  public void setAnimator(Animator paramAnimator) {
    (ensureAnimationInfo()).b = paramAnimator;
  }
  
  public void setArguments(Bundle paramBundle) {
    if (this.mFragmentManager == null || !isStateSaved()) {
      this.mArguments = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already added and state has been saved");
  }
  
  public void setEnterSharedElementCallback(u paramu) {
    Objects.requireNonNull(ensureAnimationInfo());
  }
  
  public void setEnterTransition(Object paramObject) {
    (ensureAnimationInfo()).k = paramObject;
  }
  
  public void setExitSharedElementCallback(u paramu) {
    Objects.requireNonNull(ensureAnimationInfo());
  }
  
  public void setExitTransition(Object paramObject) {
    (ensureAnimationInfo()).m = paramObject;
  }
  
  public void setFocusedView(View paramView) {
    (ensureAnimationInfo()).t = paramView;
  }
  
  public void setHasOptionsMenu(boolean paramBoolean) {
    if (this.mHasMenu != paramBoolean) {
      this.mHasMenu = paramBoolean;
      if (isAdded() && !isHidden())
        this.mHost.h(); 
    } 
  }
  
  public void setHideReplaced(boolean paramBoolean) {
    (ensureAnimationInfo()).w = paramBoolean;
  }
  
  public void setInitialSavedState(l paraml) {
    if (this.mFragmentManager == null) {
      if (paraml != null) {
        Bundle bundle = paraml.f;
        if (bundle != null) {
          this.mSavedFragmentState = bundle;
          return;
        } 
      } 
      paraml = null;
    } else {
      throw new IllegalStateException("Fragment already added");
    } 
    this.mSavedFragmentState = (Bundle)paraml;
  }
  
  public void setMenuVisibility(boolean paramBoolean) {
    if (this.mMenuVisible != paramBoolean) {
      this.mMenuVisible = paramBoolean;
      if (this.mHasMenu && isAdded() && !isHidden())
        this.mHost.h(); 
    } 
  }
  
  public void setNextTransition(int paramInt) {
    if (this.mAnimationInfo == null && paramInt == 0)
      return; 
    ensureAnimationInfo();
    this.mAnimationInfo.h = paramInt;
  }
  
  public void setOnStartEnterTransitionListener(k paramk) {
    ensureAnimationInfo();
    i i1 = this.mAnimationInfo;
    k k1 = i1.v;
    if (paramk == k1)
      return; 
    if (paramk == null || k1 == null) {
      if (i1.u)
        i1.v = paramk; 
      if (paramk != null) {
        paramk = paramk;
        ((FragmentManager.o)paramk).c++;
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setPopDirection(boolean paramBoolean) {
    if (this.mAnimationInfo == null)
      return; 
    (ensureAnimationInfo()).c = paramBoolean;
  }
  
  public void setPostOnViewCreatedAlpha(float paramFloat) {
    (ensureAnimationInfo()).s = paramFloat;
  }
  
  public void setReenterTransition(Object paramObject) {
    (ensureAnimationInfo()).n = paramObject;
  }
  
  @Deprecated
  public void setRetainInstance(boolean paramBoolean) {
    this.mRetainInstance = paramBoolean;
    FragmentManager fragmentManager = this.mFragmentManager;
    if (fragmentManager != null) {
      if (paramBoolean) {
        fragmentManager.K.c(this);
        return;
      } 
      fragmentManager.K.d(this);
      return;
    } 
    this.mRetainInstanceChangedWhileDetached = true;
  }
  
  public void setReturnTransition(Object paramObject) {
    (ensureAnimationInfo()).l = paramObject;
  }
  
  public void setSharedElementEnterTransition(Object paramObject) {
    (ensureAnimationInfo()).o = paramObject;
  }
  
  public void setSharedElementNames(ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2) {
    ensureAnimationInfo();
    i i1 = this.mAnimationInfo;
    i1.i = paramArrayList1;
    i1.j = paramArrayList2;
  }
  
  public void setSharedElementReturnTransition(Object paramObject) {
    (ensureAnimationInfo()).p = paramObject;
  }
  
  @Deprecated
  public void setTargetFragment(Fragment paramFragment, int paramInt) {
    FragmentManager fragmentManager1;
    FragmentManager fragmentManager2 = this.mFragmentManager;
    if (paramFragment != null) {
      fragmentManager1 = paramFragment.mFragmentManager;
    } else {
      fragmentManager1 = null;
    } 
    if (fragmentManager2 == null || fragmentManager1 == null || fragmentManager2 == fragmentManager1) {
      Fragment fragment = paramFragment;
      while (fragment != null) {
        if (!fragment.equals(this)) {
          fragment = fragment.getTargetFragment();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Setting ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" as the target of ");
        stringBuilder.append(this);
        stringBuilder.append(" would create a target cycle");
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (paramFragment == null) {
        this.mTargetWho = null;
        this.mTarget = null;
      } else if (this.mFragmentManager != null && paramFragment.mFragmentManager != null) {
        this.mTargetWho = paramFragment.mWho;
        this.mTarget = null;
      } else {
        this.mTargetWho = null;
        this.mTarget = paramFragment;
      } 
      this.mTargetRequestCode = paramInt;
      return;
    } 
    throw new IllegalArgumentException(m.a("Fragment ", paramFragment, " must share the same FragmentManager to be set as a target fragment"));
  }
  
  @Deprecated
  public void setUserVisibleHint(boolean paramBoolean) {
    boolean bool;
    if (!this.mUserVisibleHint && paramBoolean && this.mState < 5 && this.mFragmentManager != null && isAdded() && this.mIsCreated) {
      FragmentManager fragmentManager = this.mFragmentManager;
      fragmentManager.W(fragmentManager.h(this));
    } 
    this.mUserVisibleHint = paramBoolean;
    if (this.mState < 5 && !paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mDeferStart = bool;
    if (this.mSavedFragmentState != null)
      this.mSavedUserVisibleHint = Boolean.valueOf(paramBoolean); 
  }
  
  public boolean shouldShowRequestPermissionRationale(String paramString) {
    w<?> w1 = this.mHost;
    return (w1 != null) ? w1.g(paramString) : false;
  }
  
  public void startActivity(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    startActivity(paramIntent, null);
  }
  
  public void startActivity(@SuppressLint({"UnknownNullness"}) Intent paramIntent, Bundle paramBundle) {
    w<?> w1 = this.mHost;
    if (w1 != null) {
      Context context = w1.g;
      Object object = c0.a.a;
      c0.a.a.b(context, paramIntent, paramBundle);
      return;
    } 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to Activity"));
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    startActivityForResult(paramIntent, paramInt, null);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (this.mHost != null) {
      FragmentManager fragmentManager = getParentFragmentManager();
      if (fragmentManager.x != null) {
        FragmentManager.k k1 = new FragmentManager.k(this.mWho, paramInt);
        fragmentManager.A.addLast(k1);
        if (paramIntent != null && paramBundle != null)
          paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
        fragmentManager.x.b(paramIntent, null);
        return;
      } 
      w<?> w1 = fragmentManager.r;
      Objects.requireNonNull(w1);
      if (paramInt == -1) {
        Context context = w1.g;
        Object object = c0.a.a;
        c0.a.a.b(context, paramIntent, paramBundle);
        return;
      } 
      throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
    } 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to Activity"));
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    Intent intent = paramIntent;
    if (this.mHost != null) {
      androidx.activity.result.f f;
      StringBuilder stringBuilder;
      if (FragmentManager.O(2)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Fragment ");
        stringBuilder1.append(this);
        stringBuilder1.append(" received the following in startIntentSenderForResult() requestCode: ");
        stringBuilder1.append(paramInt1);
        stringBuilder1.append(" IntentSender: ");
        stringBuilder1.append(paramIntentSender);
        stringBuilder1.append(" fillInIntent: ");
        stringBuilder1.append(paramIntent);
        stringBuilder1.append(" options: ");
        stringBuilder1.append(paramBundle);
        Log.v("FragmentManager", stringBuilder1.toString());
      } 
      FragmentManager fragmentManager = getParentFragmentManager();
      if (fragmentManager.y != null) {
        paramIntent = intent;
        if (paramBundle != null) {
          paramIntent = intent;
          if (intent == null) {
            paramIntent = new Intent();
            paramIntent.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
          } 
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("ActivityOptions ");
            stringBuilder1.append(paramBundle);
            stringBuilder1.append(" were added to fillInIntent ");
            stringBuilder1.append(paramIntent);
            stringBuilder1.append(" for fragment ");
            stringBuilder1.append(this);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle);
        } 
        f = new androidx.activity.result.f(paramIntentSender, paramIntent, paramInt2, paramInt3);
        FragmentManager.k k1 = new FragmentManager.k(this.mWho, paramInt1);
        fragmentManager.A.addLast(k1);
        if (FragmentManager.O(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment ");
          stringBuilder.append(this);
          stringBuilder.append("is launching an IntentSender for result ");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        fragmentManager.y.b(f, null);
        return;
      } 
      w<?> w1 = fragmentManager.r;
      Objects.requireNonNull(w1);
      if (paramInt1 == -1) {
        Activity activity = w1.f;
        int m = b0.a.c;
        activity.startIntentSenderForResult((IntentSender)f, paramInt1, (Intent)stringBuilder, paramInt2, paramInt3, paramInt4, paramBundle);
        return;
      } 
      throw new IllegalStateException("Starting intent sender with a requestCode requires a FragmentActivity host");
    } 
    throw new IllegalStateException(m.a("Fragment ", this, " not attached to Activity"));
  }
  
  public void startPostponedEnterTransition() {
    if (this.mAnimationInfo != null) {
      if (!(ensureAnimationInfo()).u)
        return; 
      if (this.mHost == null) {
        (ensureAnimationInfo()).u = false;
        return;
      } 
      if (Looper.myLooper() != this.mHost.h.getLooper()) {
        this.mHost.h.postAtFrontOfQueue(new b(this));
        return;
      } 
      callStartTransitionListener(true);
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("}");
    stringBuilder.append(" (");
    stringBuilder.append(this.mWho);
    if (this.mFragmentId != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.mFragmentId));
    } 
    if (this.mTag != null) {
      stringBuilder.append(" tag=");
      stringBuilder.append(this.mTag);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void unregisterForContextMenu(View paramView) {
    paramView.setOnCreateContextMenuListener(null);
  }
  
  public static class InstantiationException extends RuntimeException {
    public InstantiationException(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  public class a implements Runnable {
    public a(Fragment this$0) {}
    
    public void run() {
      this.f.startPostponedEnterTransition();
    }
  }
  
  public class b implements Runnable {
    public b(Fragment this$0) {}
    
    public void run() {
      this.f.callStartTransitionListener(false);
    }
  }
  
  public class c implements Runnable {
    public c(Fragment this$0, SpecialEffectsController param1SpecialEffectsController) {}
    
    public void run() {
      this.f.c();
    }
  }
  
  public class d extends s {
    public d(Fragment this$0) {}
    
    public View b(int param1Int) {
      View view = this.a.mView;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = android.support.v4.media.a.a("Fragment ");
      stringBuilder.append(this.a);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean c() {
      return (this.a.mView != null);
    }
  }
  
  public class e implements n.a<Void, ActivityResultRegistry> {
    public e(Fragment this$0) {}
    
    public Object apply(Object param1Object) {
      param1Object = this.a;
      w<?> w = ((Fragment)param1Object).mHost;
      return (w instanceof androidx.activity.result.e) ? ((androidx.activity.result.e)w).getActivityResultRegistry() : param1Object.requireActivity().getActivityResultRegistry();
    }
  }
  
  public class f implements n.a<Void, ActivityResultRegistry> {
    public f(Fragment this$0, ActivityResultRegistry param1ActivityResultRegistry) {}
    
    public Object apply(Object param1Object) {
      return this.a;
    }
  }
  
  public class g extends j {
    public g(Fragment this$0, n.a param1a, AtomicReference param1AtomicReference, d.a param1a1, androidx.activity.result.b param1b) {
      super(null);
    }
    
    public void a() {
      String str = this.e.generateActivityResultKey();
      ActivityResultRegistry activityResultRegistry = (ActivityResultRegistry)this.a.apply(null);
      this.b.set(activityResultRegistry.c(str, this.e, this.c, this.d));
    }
  }
  
  public class h extends androidx.activity.result.c<I> {
    public h(Fragment this$0, AtomicReference param1AtomicReference, d.a param1a) {}
    
    public d.a<I, ?> a() {
      return this.b;
    }
    
    public void b(I param1I, b0.c param1c) {
      androidx.activity.result.c c1 = this.a.get();
      if (c1 != null) {
        c1.b(param1I, param1c);
        return;
      } 
      throw new IllegalStateException("Operation cannot be started before fragment is in created state");
    }
    
    public void c() {
      androidx.activity.result.c c1 = this.a.getAndSet(null);
      if (c1 != null)
        c1.c(); 
    }
  }
  
  public static class i {
    public View a;
    
    public Animator b;
    
    public boolean c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h;
    
    public ArrayList<String> i;
    
    public ArrayList<String> j;
    
    public Object k = null;
    
    public Object l;
    
    public Object m;
    
    public Object n;
    
    public Object o;
    
    public Object p;
    
    public Boolean q;
    
    public Boolean r;
    
    public float s;
    
    public View t;
    
    public boolean u;
    
    public Fragment.k v;
    
    public boolean w;
    
    public i() {
      Object object = Fragment.USE_DEFAULT_TRANSITION;
      this.l = object;
      this.m = null;
      this.n = object;
      this.o = null;
      this.p = object;
      this.s = 1.0F;
      this.t = null;
    }
  }
  
  public static abstract class j {
    public j() {}
    
    public j(Fragment.a param1a) {}
    
    public abstract void a();
  }
  
  public static interface k {}
  
  @SuppressLint({"BanParcelableUsage, ParcelClassLoader"})
  public static class l implements Parcelable {
    public static final Parcelable.Creator<l> CREATOR = (Parcelable.Creator<l>)new a();
    
    public final Bundle f;
    
    public l(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      Bundle bundle = param1Parcel.readBundle();
      this.f = bundle;
      if (param1ClassLoader != null && bundle != null)
        bundle.setClassLoader(param1ClassLoader); 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeBundle(this.f);
    }
    
    public class a implements Parcelable.ClassLoaderCreator<l> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new Fragment.l(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Fragment.l(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new Fragment.l[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<l> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new Fragment.l(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Fragment.l(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new Fragment.l[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */