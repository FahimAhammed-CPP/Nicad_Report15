package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.w0;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.c0;
import java.util.Iterator;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class e0 {
  public final y a;
  
  public final f0 b;
  
  public final Fragment c;
  
  public boolean d = false;
  
  public int e = -1;
  
  public e0(y paramy, f0 paramf0, Fragment paramFragment) {
    this.a = paramy;
    this.b = paramf0;
    this.c = paramFragment;
  }
  
  public e0(y paramy, f0 paramf0, Fragment paramFragment, d0 paramd0) {
    this.a = paramy;
    this.b = paramf0;
    this.c = paramFragment;
    paramFragment.mSavedViewState = null;
    paramFragment.mSavedViewRegistryState = null;
    paramFragment.mBackStackNesting = 0;
    paramFragment.mInLayout = false;
    paramFragment.mAdded = false;
    Fragment fragment = paramFragment.mTarget;
    if (fragment != null) {
      String str = fragment.mWho;
    } else {
      fragment = null;
    } 
    paramFragment.mTargetWho = (String)fragment;
    paramFragment.mTarget = null;
    Bundle bundle = paramd0.r;
    if (bundle != null) {
      paramFragment.mSavedFragmentState = bundle;
      return;
    } 
    paramFragment.mSavedFragmentState = new Bundle();
  }
  
  public e0(y paramy, f0 paramf0, ClassLoader paramClassLoader, v paramv, d0 paramd0) {
    this.a = paramy;
    this.b = paramf0;
    Fragment fragment = paramv.a(paramClassLoader, paramd0.f);
    this.c = fragment;
    Bundle bundle = paramd0.o;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    fragment.setArguments(paramd0.o);
    fragment.mWho = paramd0.g;
    fragment.mFromLayout = paramd0.h;
    fragment.mRestored = true;
    fragment.mFragmentId = paramd0.i;
    fragment.mContainerId = paramd0.j;
    fragment.mTag = paramd0.k;
    fragment.mRetainInstance = paramd0.l;
    fragment.mRemoving = paramd0.m;
    fragment.mDetached = paramd0.n;
    fragment.mHidden = paramd0.p;
    fragment.mMaxState = Lifecycle.State.values()[paramd0.q];
    bundle = paramd0.r;
    if (bundle != null) {
      fragment.mSavedFragmentState = bundle;
    } else {
      fragment.mSavedFragmentState = new Bundle();
    } 
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void a() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    fragment1.performActivityCreated(fragment1.mSavedFragmentState);
    y y1 = this.a;
    Fragment fragment2 = this.c;
    y1.a(fragment2, fragment2.mSavedFragmentState, false);
  }
  
  public void b() {
    int i;
    f0 f01 = this.b;
    Fragment fragment2 = this.c;
    Objects.requireNonNull(f01);
    ViewGroup viewGroup = fragment2.mContainer;
    byte b = -1;
    if (viewGroup == null) {
      i = b;
    } else {
      int k = f01.g.indexOf(fragment2);
      int j = k - 1;
      while (true) {
        i = k;
        if (j >= 0) {
          fragment2 = f01.g.get(j);
          if (fragment2.mContainer == viewGroup) {
            View view = fragment2.mView;
            if (view != null) {
              i = viewGroup.indexOfChild(view) + 1;
              break;
            } 
          } 
          j--;
          continue;
        } 
        while (true) {
          j = i + 1;
          i = b;
          if (j < f01.g.size()) {
            fragment2 = f01.g.get(j);
            i = j;
            if (fragment2.mContainer == viewGroup) {
              View view = fragment2.mView;
              i = j;
              if (view != null) {
                i = viewGroup.indexOfChild(view);
                break;
              } 
            } 
            continue;
          } 
          break;
        } 
        break;
      } 
    } 
    Fragment fragment1 = this.c;
    fragment1.mContainer.addView(fragment1.mView, i);
  }
  
  public void c() {
    StringBuilder stringBuilder;
    if (FragmentManager.O(3)) {
      stringBuilder = android.support.v4.media.a.a("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    Fragment fragment3 = fragment2.mTarget;
    e0 e01 = null;
    if (fragment3 != null) {
      e01 = this.b.h(fragment3.mWho);
      if (e01 != null) {
        fragment2 = this.c;
        fragment2.mTargetWho = fragment2.mTarget.mWho;
        fragment2.mTarget = null;
      } else {
        stringBuilder = android.support.v4.media.a.a("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.mTarget);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = fragment2.mTargetWho;
      if (str != null) {
        e01 = this.b.h(str);
        if (e01 == null) {
          stringBuilder = android.support.v4.media.a.a("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          throw new IllegalStateException(v.a.a(stringBuilder, this.c.mTargetWho, " that does not belong to this FragmentManager!"));
        } 
      } 
    } 
    if (stringBuilder != null)
      stringBuilder.k(); 
    Fragment fragment1 = this.c;
    FragmentManager fragmentManager = fragment1.mFragmentManager;
    fragment1.mHost = fragmentManager.r;
    fragment1.mParentFragment = fragmentManager.t;
    this.a.g(fragment1, false);
    this.c.performAttach();
    this.a.b(this.c, false);
  }
  
  public int d() {
    int i;
    SpecialEffectsController.Operation.LifecycleImpact lifecycleImpact;
    Fragment fragment2 = this.c;
    if (fragment2.mFragmentManager == null)
      return fragment2.mState; 
    int j = this.e;
    int k = fragment2.mMaxState.ordinal();
    if (k != 1) {
      if (k != 2) {
        if (k != 3) {
          i = j;
          if (k != 4)
            i = Math.min(j, -1); 
        } else {
          i = Math.min(j, 5);
        } 
      } else {
        i = Math.min(j, 1);
      } 
    } else {
      i = Math.min(j, 0);
    } 
    fragment2 = this.c;
    j = i;
    if (fragment2.mFromLayout) {
      View view;
      if (fragment2.mInLayout) {
        i = Math.max(this.e, 2);
        view = this.c.mView;
        j = i;
        if (view != null) {
          j = i;
          if (view.getParent() == null)
            j = Math.min(i, 2); 
        } 
      } else if (this.e < 4) {
        j = Math.min(i, ((Fragment)view).mState);
      } else {
        j = Math.min(i, 1);
      } 
    } 
    k = j;
    if (!this.c.mAdded)
      k = Math.min(j, 1); 
    Fragment fragment3 = this.c;
    ViewGroup viewGroup = fragment3.mContainer;
    fragment2 = null;
    SpecialEffectsController specialEffectsController = null;
    if (viewGroup != null) {
      SpecialEffectsController.Operation operation2;
      SpecialEffectsController specialEffectsController1 = SpecialEffectsController.f(viewGroup, fragment3.getParentFragmentManager());
      Objects.requireNonNull(specialEffectsController1);
      SpecialEffectsController.Operation operation1 = specialEffectsController1.d(this.c);
      if (operation1 != null) {
        lifecycleImpact = operation1.b;
      } else {
        operation1 = null;
      } 
      Fragment fragment = this.c;
      Iterator<SpecialEffectsController.Operation> iterator = specialEffectsController1.c.iterator();
      while (true) {
        specialEffectsController1 = specialEffectsController;
        if (iterator.hasNext()) {
          operation2 = iterator.next();
          if (operation2.c.equals(fragment) && !operation2.f)
            break; 
          continue;
        } 
        break;
      } 
      if (operation2 != null && (operation1 == null || operation1 == SpecialEffectsController.Operation.LifecycleImpact.f))
        lifecycleImpact = operation2.b; 
    } 
    if (lifecycleImpact == SpecialEffectsController.Operation.LifecycleImpact.g) {
      i = Math.min(k, 6);
    } else if (lifecycleImpact == SpecialEffectsController.Operation.LifecycleImpact.h) {
      i = Math.max(k, 3);
    } else {
      Fragment fragment = this.c;
      i = k;
      if (fragment.mRemoving)
        if (fragment.isInBackStack()) {
          i = Math.min(k, 1);
        } else {
          i = Math.min(k, -1);
        }  
    } 
    Fragment fragment1 = this.c;
    j = i;
    if (fragment1.mDeferStart) {
      j = i;
      if (fragment1.mState < 5)
        j = Math.min(i, 4); 
    } 
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = w0.a("computeExpectedState() of ", j, " for ");
      stringBuilder.append(this.c);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    return j;
  }
  
  public void e() {
    y y1;
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    if (!fragment.mIsCreated) {
      this.a.h(fragment, fragment.mSavedFragmentState, false);
      fragment = this.c;
      fragment.performCreate(fragment.mSavedFragmentState);
      y1 = this.a;
      Fragment fragment1 = this.c;
      y1.c(fragment1, fragment1.mSavedFragmentState, false);
      return;
    } 
    y1.restoreChildFragmentState(((Fragment)y1).mSavedFragmentState);
    this.c.mState = 1;
  }
  
  public void f() {
    StringBuilder stringBuilder;
    if (this.c.mFromLayout)
      return; 
    if (FragmentManager.O(3)) {
      stringBuilder = android.support.v4.media.a.a("moveto CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    LayoutInflater layoutInflater = fragment1.performGetLayoutInflater(fragment1.mSavedFragmentState);
    fragment1 = null;
    Fragment fragment3 = this.c;
    ViewGroup viewGroup = fragment3.mContainer;
    if (viewGroup != null) {
      ViewGroup viewGroup1 = viewGroup;
    } else {
      int i = fragment3.mContainerId;
      if (i != 0)
        if (i != -1) {
          viewGroup = (ViewGroup)fragment3.mFragmentManager.s.b(i);
          ViewGroup viewGroup1 = viewGroup;
          if (viewGroup == null) {
            ViewGroup viewGroup2;
            Fragment fragment = this.c;
            if (fragment.mRestored) {
              viewGroup2 = viewGroup;
            } else {
              String str;
              try {
                str = viewGroup2.getResources().getResourceName(this.c.mContainerId);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              StringBuilder stringBuilder1 = android.support.v4.media.a.a("No view found for id 0x");
              stringBuilder1.append(Integer.toHexString(this.c.mContainerId));
              stringBuilder1.append(" (");
              stringBuilder1.append(str);
              stringBuilder1.append(") for fragment ");
              stringBuilder1.append(this.c);
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
          } 
        } else {
          stringBuilder = android.support.v4.media.a.a("Cannot create fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
    } 
    Fragment fragment2 = this.c;
    fragment2.mContainer = (ViewGroup)stringBuilder;
    fragment2.performCreateView(layoutInflater, (ViewGroup)stringBuilder, fragment2.mSavedFragmentState);
    View view = this.c.mView;
    if (view != null) {
      view.setSaveFromParentEnabled(false);
      Fragment fragment7 = this.c;
      fragment7.mView.setTag(2131230923, fragment7);
      if (stringBuilder != null)
        b(); 
      Fragment fragment5 = this.c;
      if (fragment5.mHidden)
        fragment5.mView.setVisibility(8); 
      View view1 = this.c.mView;
      WeakHashMap weakHashMap = y.a;
      if (y.g.b(view1)) {
        y.y(this.c.mView);
      } else {
        view1 = this.c.mView;
        view1.addOnAttachStateChangeListener(new a(this, view1));
      } 
      this.c.performViewCreated();
      y y1 = this.a;
      Fragment fragment6 = this.c;
      y1.m(fragment6, fragment6.mView, fragment6.mSavedFragmentState, false);
      int i = this.c.mView.getVisibility();
      float f = this.c.mView.getAlpha();
      this.c.setPostOnViewCreatedAlpha(f);
      Fragment fragment4 = this.c;
      if (fragment4.mContainer != null && i == 0) {
        View view2 = fragment4.mView.findFocus();
        if (view2 != null) {
          this.c.setFocusedView(view2);
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("requestFocus: Saved focused view ");
            stringBuilder1.append(view2);
            stringBuilder1.append(" for Fragment ");
            stringBuilder1.append(this.c);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
        } 
        this.c.mView.setAlpha(0.0F);
      } 
    } 
    this.c.mState = 2;
  }
  
  public void g() {
    boolean bool1;
    boolean bool2;
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    boolean bool4 = fragment.mRemoving;
    boolean bool3 = true;
    if (bool4 && !fragment.isInBackStack()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 || ((b0)this.b.i).e(this.c)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      int i;
      w<?> w = this.c.mHost;
      if (w instanceof androidx.lifecycle.d0) {
        bool3 = ((b0)this.b.i).g;
      } else {
        Context context = w.g;
        if (context instanceof Activity)
          i = true ^ ((Activity)context).isChangingConfigurations(); 
      } 
      if (bool1 || i != 0) {
        b0 b01 = (b0)this.b.i;
        Fragment fragment2 = this.c;
        Objects.requireNonNull(b01);
        if (FragmentManager.O(3)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Clearing non-config state for ");
          stringBuilder.append(fragment2);
          Log.d("FragmentManager", stringBuilder.toString());
        } 
        b0 b02 = b01.d.get(fragment2.mWho);
        if (b02 != null) {
          b02.a();
          b01.d.remove(fragment2.mWho);
        } 
        c0 c0 = b01.e.get(fragment2.mWho);
        if (c0 != null) {
          c0.a();
          b01.e.remove(fragment2.mWho);
        } 
      } 
      this.c.performDestroy();
      this.a.d(this.c, false);
      for (e0 e01 : this.b.f()) {
        if (e01 != null) {
          Fragment fragment2 = e01.c;
          if (this.c.mWho.equals(fragment2.mTargetWho)) {
            fragment2.mTarget = this.c;
            fragment2.mTargetWho = null;
          } 
        } 
      } 
      Fragment fragment1 = this.c;
      String str1 = fragment1.mTargetWho;
      if (str1 != null)
        fragment1.mTarget = this.b.d(str1); 
      this.b.p(this);
      return;
    } 
    String str = this.c.mTargetWho;
    if (str != null) {
      Fragment fragment1 = this.b.d(str);
      if (fragment1 != null && fragment1.mRetainInstance)
        this.c.mTarget = fragment1; 
    } 
    this.c.mState = 0;
  }
  
  public void h() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    ViewGroup viewGroup = fragment2.mContainer;
    if (viewGroup != null) {
      View view = fragment2.mView;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.performDestroyView();
    this.a.n(this.c, false);
    Fragment fragment1 = this.c;
    fragment1.mContainer = null;
    fragment1.mView = null;
    fragment1.mViewLifecycleOwner = null;
    fragment1.mViewLifecycleOwnerLiveData.i(null);
    this.c.mInLayout = false;
  }
  
  public void i() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performDetach();
    y y1 = this.a;
    Fragment fragment2 = this.c;
    boolean bool2 = false;
    y1.e(fragment2, false);
    Fragment fragment1 = this.c;
    fragment1.mState = -1;
    fragment1.mHost = null;
    fragment1.mParentFragment = null;
    fragment1.mFragmentManager = null;
    boolean bool1 = bool2;
    if (fragment1.mRemoving) {
      bool1 = bool2;
      if (!fragment1.isInBackStack())
        bool1 = true; 
    } 
    if (bool1 || ((b0)this.b.i).e(this.c)) {
      if (FragmentManager.O(3)) {
        StringBuilder stringBuilder = android.support.v4.media.a.a("initState called for fragment: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.initState();
    } 
  }
  
  public void j() {
    Fragment fragment = this.c;
    if (fragment.mFromLayout && fragment.mInLayout && !fragment.mPerformedCreateView) {
      if (FragmentManager.O(3)) {
        StringBuilder stringBuilder = android.support.v4.media.a.a("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      fragment = this.c;
      fragment.performCreateView(fragment.performGetLayoutInflater(fragment.mSavedFragmentState), null, this.c.mSavedFragmentState);
      View view = this.c.mView;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        Fragment fragment1 = this.c;
        fragment1.mView.setTag(2131230923, fragment1);
        fragment1 = this.c;
        if (fragment1.mHidden)
          fragment1.mView.setVisibility(8); 
        this.c.performViewCreated();
        y y1 = this.a;
        Fragment fragment2 = this.c;
        y1.m(fragment2, fragment2.mView, fragment2.mSavedFragmentState, false);
        this.c.mState = 2;
      } 
    } 
  }
  
  public void k() {
    SpecialEffectsController.Operation.LifecycleImpact lifecycleImpact = SpecialEffectsController.Operation.LifecycleImpact.f;
    if (this.d) {
      if (FragmentManager.O(2)) {
        null = android.support.v4.media.a.a("Ignoring re-entrant call to moveToExpectedState() for ");
        null.append(this.c);
        Log.v("FragmentManager", null.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      while (true) {
        SpecialEffectsController specialEffectsController2;
        FragmentManager fragmentManager;
        Fragment fragment1;
        SpecialEffectsController specialEffectsController1;
        int i = d();
        Fragment fragment2 = this.c;
        int j = fragment2.mState;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                n();
                continue;
              case 6:
                fragment2.mState = 6;
                continue;
              case 5:
                p();
                continue;
              case 4:
                if (fragment2.mView != null) {
                  ViewGroup viewGroup = fragment2.mContainer;
                  if (viewGroup != null) {
                    specialEffectsController2 = SpecialEffectsController.f(viewGroup, fragment2.getParentFragmentManager());
                    SpecialEffectsController.Operation.State state = SpecialEffectsController.Operation.State.e(this.c.mView.getVisibility());
                    Objects.requireNonNull(specialEffectsController2);
                    if (FragmentManager.O(2)) {
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
                      stringBuilder.append(this.c);
                      Log.v("FragmentManager", stringBuilder.toString());
                    } 
                    specialEffectsController2.a(state, SpecialEffectsController.Operation.LifecycleImpact.g, this);
                  } 
                } 
                this.c.mState = 4;
                continue;
              case 3:
                a();
                continue;
              case 2:
                j();
                f();
                continue;
              case 1:
                e();
                continue;
              case 0:
                c();
                continue;
            } 
            continue;
          } 
        } else {
          if (((Fragment)specialEffectsController2).mHiddenChanged) {
            if (((Fragment)specialEffectsController2).mView != null) {
              ViewGroup viewGroup = ((Fragment)specialEffectsController2).mContainer;
              if (viewGroup != null) {
                specialEffectsController2 = SpecialEffectsController.f(viewGroup, specialEffectsController2.getParentFragmentManager());
                if (this.c.mHidden) {
                  Objects.requireNonNull(specialEffectsController2);
                  if (FragmentManager.O(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
                    stringBuilder.append(this.c);
                    Log.v("FragmentManager", stringBuilder.toString());
                  } 
                  specialEffectsController2.a(SpecialEffectsController.Operation.State.h, (SpecialEffectsController.Operation.LifecycleImpact)null, this);
                } else {
                  Objects.requireNonNull(specialEffectsController2);
                  if (FragmentManager.O(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
                    stringBuilder.append(this.c);
                    Log.v("FragmentManager", stringBuilder.toString());
                  } 
                  specialEffectsController2.a(SpecialEffectsController.Operation.State.g, (SpecialEffectsController.Operation.LifecycleImpact)null, this);
                } 
              } 
            } 
            Fragment fragment = this.c;
            fragmentManager = fragment.mFragmentManager;
            if (fragmentManager != null && fragment.mAdded && fragmentManager.P(fragment))
              fragmentManager.B = true; 
            fragment = this.c;
            fragment.mHiddenChanged = false;
            fragment.onHiddenChanged(fragment.mHidden);
          } 
          return;
        } 
        switch (j - 1) {
          case 6:
            l();
          case 5:
            ((Fragment)fragmentManager).mState = 5;
          case 4:
            q();
          case 3:
            if (FragmentManager.O(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(this.c);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            fragment1 = this.c;
            if (fragment1.mView != null && fragment1.mSavedViewState == null)
              o(); 
            fragment1 = this.c;
            if (fragment1.mView != null) {
              ViewGroup viewGroup = fragment1.mContainer;
              if (viewGroup != null) {
                specialEffectsController1 = SpecialEffectsController.f(viewGroup, fragment1.getParentFragmentManager());
                Objects.requireNonNull(specialEffectsController1);
                if (FragmentManager.O(2)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
                  stringBuilder.append(this.c);
                  Log.v("FragmentManager", stringBuilder.toString());
                } 
                specialEffectsController1.a(SpecialEffectsController.Operation.State.f, SpecialEffectsController.Operation.LifecycleImpact.h, this);
              } 
            } 
            this.c.mState = 3;
          case 2:
            ((Fragment)specialEffectsController1).mInLayout = false;
            ((Fragment)specialEffectsController1).mState = 2;
          case 1:
            h();
            this.c.mState = 1;
          case 0:
            g();
          case -1:
            i();
        } 
      } 
    } finally {
      this.d = false;
    } 
  }
  
  public void l() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performPause();
    this.a.f(this.c, false);
  }
  
  public void m(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.mSavedFragmentState;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    Fragment fragment = this.c;
    fragment.mSavedViewState = fragment.mSavedFragmentState.getSparseParcelableArray("android:view_state");
    fragment = this.c;
    fragment.mSavedViewRegistryState = fragment.mSavedFragmentState.getBundle("android:view_registry_state");
    fragment = this.c;
    fragment.mTargetWho = fragment.mSavedFragmentState.getString("android:target_state");
    fragment = this.c;
    if (fragment.mTargetWho != null)
      fragment.mTargetRequestCode = fragment.mSavedFragmentState.getInt("android:target_req_state", 0); 
    fragment = this.c;
    Boolean bool = fragment.mSavedUserVisibleHint;
    if (bool != null) {
      fragment.mUserVisibleHint = bool.booleanValue();
      this.c.mSavedUserVisibleHint = null;
    } else {
      fragment.mUserVisibleHint = fragment.mSavedFragmentState.getBoolean("android:user_visible_hint", true);
    } 
    fragment = this.c;
    if (!fragment.mUserVisibleHint)
      fragment.mDeferStart = true; 
  }
  
  public void n() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("moveto RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = this.c.getFocusedView();
    if (view != null) {
      View view1 = this.c.mView;
      boolean bool = true;
      if (view != view1) {
        ViewParent viewParent = view.getParent();
        while (true) {
          if (viewParent != null) {
            if (viewParent == this.c.mView)
              break; 
            viewParent = viewParent.getParent();
            continue;
          } 
          bool = false;
          break;
        } 
      } 
      if (bool) {
        boolean bool1 = view.requestFocus();
        if (FragmentManager.O(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("requestFocus: Restoring focused view ");
          stringBuilder.append(view);
          stringBuilder.append(" ");
          if (bool1) {
            str = "succeeded";
          } else {
            str = "failed";
          } 
          stringBuilder.append(str);
          stringBuilder.append(" on Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" resulting in focused view ");
          stringBuilder.append(this.c.mView.findFocus());
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
    this.c.setFocusedView(null);
    this.c.performResume();
    this.a.i(this.c, false);
    Fragment fragment = this.c;
    fragment.mSavedFragmentState = null;
    fragment.mSavedViewState = null;
    fragment.mSavedViewRegistryState = null;
  }
  
  public void o() {
    if (this.c.mView == null)
      return; 
    SparseArray<Parcelable> sparseArray = new SparseArray();
    this.c.mView.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.mSavedViewState = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.mViewLifecycleOwner.h.b(bundle);
    if (!bundle.isEmpty())
      this.c.mSavedViewRegistryState = bundle; 
  }
  
  public void p() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performStart();
    this.a.k(this.c, false);
  }
  
  public void q() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performStop();
    this.a.l(this.c, false);
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public a(e0 this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.f.removeOnAttachStateChangeListener(this);
      y.y(this.f);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */