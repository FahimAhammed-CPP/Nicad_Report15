package androidx.fragment.app;

import a6.c;
import a6.g;
import a6.h;
import android.accounts.Account;
import android.content.Context;
import android.os.Parcelable;
import android.support.v4.media.a;
import android.util.Log;
import com.amplitude.core.platform.c;
import com.google.ads.mediation.customevent.CustomEventAdapter;
import com.google.android.gms.ads.mediation.customevent.CustomEventAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.cloudmessaging.a;
import com.google.android.gms.common.api.b;
import com.google.android.gms.common.internal.e;
import com.google.android.gms.games.internal.zzj;
import com.google.android.gms.games.internal.zzl;
import com.google.android.gms.games.zzl;
import com.google.android.gms.games.zzn;
import com.google.android.gms.internal.games_v2.a;
import com.google.android.gms.internal.games_v2.zzbi;
import com.google.android.gms.internal.games_v2.zzfd;
import f3.d;
import g3.b;
import g4.g;
import h4.d;
import io.sentry.n1;
import io.sentry.protocol.o;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import q1.a;
import q5.h1;
import q5.r1;
import q5.t;
import q5.u;
import q5.w0;
import q5.y;
import u2.b0;

public class f0 implements b, d, c {
  public ArrayList<Fragment> g;
  
  public HashMap<String, e0> h;
  
  public Object i;
  
  public f0(int paramInt) {
    this.i = new ArrayList();
  }
  
  public f0(CustomEventAdapter paramCustomEventAdapter1, CustomEventAdapter paramCustomEventAdapter2, d paramd) {
    this.g = (ArrayList<Fragment>)paramCustomEventAdapter2;
    this.h = (HashMap<String, e0>)paramd;
  }
  
  public f0(CustomEventAdapter paramCustomEventAdapter1, CustomEventAdapter paramCustomEventAdapter2, g paramg) {
    this.g = (ArrayList<Fragment>)paramCustomEventAdapter2;
    this.h = (HashMap<String, e0>)paramg;
  }
  
  public f0(o paramo, n1 paramn1, Boolean paramBoolean) {
    this.g = (ArrayList<Fragment>)paramo;
    this.h = (HashMap<String, e0>)paramn1;
    this.i = paramBoolean;
  }
  
  public f0(Class paramClass, String paramString, Class[] paramArrayOfClass) {
    this.g = (ArrayList<Fragment>)paramClass;
    this.h = (HashMap<String, e0>)paramString;
    this.i = paramArrayOfClass;
  }
  
  public void a(Fragment paramFragment) {
    if (!this.g.contains(paramFragment))
      synchronized (this.g) {
        this.g.add(paramFragment);
        paramFragment.mAdded = true;
        return;
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment already added: ");
    stringBuilder.append(paramFragment);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b() {
    this.h.values().removeAll(Collections.singleton(null));
  }
  
  public boolean c(String paramString) {
    return (this.h.get(paramString) != null);
  }
  
  public Fragment d(String paramString) {
    e0 e0 = this.h.get(paramString);
    return (e0 != null) ? e0.c : null;
  }
  
  public Fragment e(String paramString) {
    for (e0 e0 : this.h.values()) {
      if (e0 != null) {
        Fragment fragment = e0.c.findFragmentByWho(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public List<e0> f() {
    ArrayList<e0> arrayList = new ArrayList();
    for (e0 e0 : this.h.values()) {
      if (e0 != null)
        arrayList.add(e0); 
    } 
    return arrayList;
  }
  
  public List<Fragment> g() {
    ArrayList<Fragment> arrayList = new ArrayList();
    for (e0 e0 : this.h.values()) {
      if (e0 != null) {
        arrayList.add(e0.c);
        continue;
      } 
      arrayList.add(null);
    } 
    return arrayList;
  }
  
  public e0 h(String paramString) {
    return this.h.get(paramString);
  }
  
  public List<Fragment> i() {
    if (this.g.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.g) {
      return new ArrayList<Fragment>(this.g);
    } 
  }
  
  public Method j(Class<?> paramClass) {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Ljava/lang/Object;
    //   4: checkcast java/lang/String
    //   7: astore #4
    //   9: aconst_null
    //   10: astore_3
    //   11: aload #4
    //   13: ifnull -> 82
    //   16: aload_0
    //   17: getfield i : Ljava/lang/Object;
    //   20: checkcast [Ljava/lang/Class;
    //   23: astore_3
    //   24: aload_1
    //   25: aload #4
    //   27: aload_3
    //   28: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   31: astore_1
    //   32: aload_1
    //   33: invokevirtual getModifiers : ()I
    //   36: istore_2
    //   37: iload_2
    //   38: iconst_1
    //   39: iand
    //   40: ifne -> 51
    //   43: goto -> 49
    //   46: goto -> 51
    //   49: aconst_null
    //   50: astore_1
    //   51: aload_1
    //   52: ifnull -> 80
    //   55: aload_0
    //   56: getfield g : Ljava/lang/Object;
    //   59: checkcast java/lang/Class
    //   62: astore_3
    //   63: aload_3
    //   64: ifnull -> 80
    //   67: aload_3
    //   68: aload_1
    //   69: invokevirtual getReturnType : ()Ljava/lang/Class;
    //   72: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   75: ifne -> 80
    //   78: aconst_null
    //   79: areturn
    //   80: aload_1
    //   81: astore_3
    //   82: aload_3
    //   83: areturn
    //   84: astore_1
    //   85: goto -> 49
    //   88: astore_3
    //   89: goto -> 46
    // Exception table:
    //   from	to	target	type
    //   24	32	84	java/lang/NoSuchMethodException
    //   32	37	88	java/lang/NoSuchMethodException
  }
  
  public String k() {
    Object object = this.i;
    if ((Boolean)object != null) {
      o o = (o)this.g;
      n1 n1 = (n1)this.h;
      if (((Boolean)object).booleanValue()) {
        object = "1";
      } else {
        object = "0";
      } 
      return String.format("%s-%s-%s", new Object[] { o, n1, object });
    } 
    return String.format("%s-%s", new Object[] { this.g, this.h });
  }
  
  public Object l(T paramT, Object... paramVarArgs) {
    Method method = j(paramT.getClass());
    if (method != null)
      try {
        return method.invoke(paramT, paramVarArgs);
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unexpectedly could not call: ");
        stringBuilder1.append(method);
        AssertionError assertionError = new AssertionError(stringBuilder1.toString());
        assertionError.initCause(illegalAccessException);
        throw assertionError;
      }  
    StringBuilder stringBuilder = a.a("Method ");
    stringBuilder.append((String)this.h);
    stringBuilder.append(" not supported for object ");
    stringBuilder.append(illegalAccessException);
    throw new AssertionError(stringBuilder.toString());
  }
  
  public Object m(T paramT, Object... paramVarArgs) {
    try {
      Method method = j(paramT.getClass());
      if (method == null)
        return null; 
      try {
        return method.invoke(paramT, paramVarArgs);
      } catch (IllegalAccessException illegalAccessException) {
        return null;
      } 
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable instanceof RuntimeException)
        throw (RuntimeException)throwable; 
      AssertionError assertionError = new AssertionError("Unexpected exception");
      assertionError.initCause(throwable);
      throw assertionError;
    } 
  }
  
  public Object n(T paramT, Object... paramVarArgs) {
    try {
      return l(paramT, paramVarArgs);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable instanceof RuntimeException)
        throw (RuntimeException)throwable; 
      AssertionError assertionError = new AssertionError("Unexpected exception");
      assertionError.initCause(throwable);
      throw assertionError;
    } 
  }
  
  public void o(e0 parame0) {
    Fragment fragment = parame0.c;
    if (c(fragment.mWho))
      return; 
    this.h.put(fragment.mWho, parame0);
    if (fragment.mRetainInstanceChangedWhileDetached) {
      if (fragment.mRetainInstance) {
        ((b0)this.i).c(fragment);
      } else {
        ((b0)this.i).d(fragment);
      } 
      fragment.mRetainInstanceChangedWhileDetached = false;
    } 
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void onComplete(g paramg) {
    String str2;
    String str3;
    ScheduledFuture scheduledFuture;
    switch (this.f) {
      case 5:
        null = (a)this.g;
        str3 = (String)this.h;
        scheduledFuture = (ScheduledFuture)this.i;
        synchronized (null.a) {
          null.a.remove(str3);
          scheduledFuture.cancel(false);
          return;
        } 
    } 
    u u = (u)this.g;
    h h = (h)this.h;
    r1 r1 = (r1)this.i;
    Objects.requireNonNull(u);
    if (!paramg.p()) {
      Exception exception = paramg.k();
      a.a(exception);
      b0 b0 = h1.a;
      String str = h1.g("GamesApiManager");
      if (b0.b(3)) {
        String str4 = (String)b0.g;
        str2 = "Authentication task failed";
        if (str4 != null)
          str2 = str4.concat("Authentication task failed"); 
        Log.d(str, str2, exception);
      } 
      u.f(h, r1.f, null, false, r1.zzd() ^ true);
      return;
    } 
    y y = (y)str2.l();
    if (!y.b.k0()) {
      h1.a("GamesApiManager", "Failed to authenticate: ".concat(String.valueOf(y)));
      u.f(h, r1.f, y.b.i, true, r1.zzd() ^ true);
      return;
    } 
    String str1 = y.a;
    if (str1 == null) {
      h1.e("GamesApiManager", "Unexpected state: game run token absent");
      u.f(h, r1.f, null, false, r1.zzd() ^ true);
      return;
    } 
    h1.a("GamesApiManager", "Successfully authenticated");
    e.e("Must be called on the main thread.");
    zzl zzl = zzn.zzb();
    zzl.zzd(2101523);
    Parcelable.Creator creator = GoogleSignInAccount.CREATOR;
    Account account = new Account("<<default account>>", "com.google");
    HashSet hashSet = new HashSet();
    zzl.zzc(GoogleSignInAccount.l0(null, null, account.name, null, null, null, null, Long.valueOf(0L), account.name, hashSet));
    zzl.zza(str1);
    zzj zzj = zzl.zza();
    zzj.zzb(true);
    zzj.zzc(true);
    zzj.zza(true);
    zzl.zzb(zzj.zzd());
    zzn zzn = zzl.zze();
    w0 w0 = new w0((Context)u.f, zzn);
    u.e.set(w0);
    u.a.set(zzbi.h);
    h.b(Boolean.TRUE);
    Iterator<t> iterator = u.c.iterator();
    while (iterator.hasNext()) {
      t t = iterator.next();
      t.b.f((b)w0).c((Executor)zzfd.f, (c)new a(t));
      iterator.remove();
    } 
  }
  
  public void p(e0 parame0) {
    Fragment fragment = parame0.c;
    if (fragment.mRetainInstance)
      ((b0)this.i).d(fragment); 
    if ((e0)this.h.put(fragment.mWho, null) == null)
      return; 
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void q(Fragment paramFragment) {
    synchronized (this.g) {
      this.g.remove(paramFragment);
      paramFragment.mAdded = false;
      return;
    } 
  }
  
  public void r(String paramString) {
    this.h = (HashMap<String, e0>)paramString;
    Iterator<c> iterator = ((List)this.i).iterator();
    while (iterator.hasNext())
      ((c)iterator.next()).h(paramString); 
  }
  
  public void s(String paramString) {
    this.g = (ArrayList<Fragment>)paramString;
    Iterator<c> iterator = ((List)this.i).iterator();
    while (iterator.hasNext())
      ((c)iterator.next()).i(paramString); 
  }
  
  public f0 t(String paramString, double paramDouble1, double paramDouble2) {
    int i = 0;
    while (i < this.g.size()) {
      double d1 = ((Double)((List<Double>)this.i).get(i)).doubleValue();
      double d2 = ((Double)((List)this.h).get(i)).doubleValue();
      if (paramDouble1 >= d1 && (d1 != paramDouble1 || paramDouble2 >= d2))
        i++; 
    } 
    this.g.add(i, paramString);
    ((List<Double>)this.i).add(i, Double.valueOf(paramDouble1));
    ((List)this.h).add(i, Double.valueOf(paramDouble2));
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */