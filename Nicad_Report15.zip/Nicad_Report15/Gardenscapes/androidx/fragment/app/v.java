package androidx.fragment.app;

import e.g;
import s.h;

public class v {
  public static final h<ClassLoader, h<String, Class<?>>> a = new h();
  
  public static Class<?> b(ClassLoader paramClassLoader, String paramString) {
    h<ClassLoader, h<String, Class<?>>> h3 = a;
    h h2 = (h)h3.getOrDefault(paramClassLoader, null);
    h h1 = h2;
    if (h2 == null) {
      h1 = new h();
      h3.put(paramClassLoader, h1);
    } 
    Class<?> clazz2 = (Class)h1.getOrDefault(paramString, null);
    Class<?> clazz1 = clazz2;
    if (clazz2 == null) {
      clazz1 = Class.forName(paramString, false, paramClassLoader);
      h1.put(paramString, clazz1);
    } 
    return clazz1;
  }
  
  public static Class<? extends Fragment> c(ClassLoader paramClassLoader, String paramString) {
    try {
      return (Class)b(paramClassLoader, paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new Fragment.InstantiationException(g.a("Unable to instantiate fragment ", paramString, ": make sure class name exists"), classNotFoundException);
    } catch (ClassCastException classCastException) {
      throw new Fragment.InstantiationException(g.a("Unable to instantiate fragment ", paramString, ": make sure class is a valid subclass of Fragment"), classCastException);
    } 
  }
  
  public Fragment a(ClassLoader paramClassLoader, String paramString) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */