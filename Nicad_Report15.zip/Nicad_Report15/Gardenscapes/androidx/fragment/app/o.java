package androidx.fragment.app;

import android.view.View;
import i0.b;

public class o implements b.a {
  public o(Fragment paramFragment) {}
  
  public void onCancel() {
    if (this.a.getAnimatingAway() != null) {
      View view = this.a.getAnimatingAway();
      this.a.setAnimatingAway(null);
      view.clearAnimation();
    } 
    this.a.setAnimator(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */