package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import s.a;

public class l0 implements Runnable {
  public l0(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, a parama, View paramView, p0 paramp0, Rect paramRect) {}
  
  public void run() {
    n0.c(this.f, this.g, this.h, this.i, false);
    View view = this.j;
    if (view != null)
      this.k.j(view, this.l); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */