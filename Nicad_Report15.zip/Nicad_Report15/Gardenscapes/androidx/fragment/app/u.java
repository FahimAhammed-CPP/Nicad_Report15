package androidx.fragment.app;

public class u {
  public final w<?> a;
  
  public u(w<?> paramw) {
    this.a = paramw;
  }
  
  public void a() {
    this.a.i.V();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\ap\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */