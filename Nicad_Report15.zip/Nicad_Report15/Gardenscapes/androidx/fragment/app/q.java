package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import i0.b;

public class q extends AnimatorListenerAdapter {
  public q(ViewGroup paramViewGroup, View paramView, Fragment paramFragment, n0.a parama, b paramb) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.a.endViewTransition(this.b);
    paramAnimator = this.c.getAnimator();
    this.c.setAnimator(null);
    if (paramAnimator != null && this.a.indexOfChild(this.b) < 0) {
      n0.a a1 = this.d;
      Fragment fragment = this.c;
      b b1 = this.e;
      ((FragmentManager.d)a1).a(fragment, b1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */