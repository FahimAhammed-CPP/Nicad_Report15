package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public final class a extends g0 implements FragmentManager.m {
  public final FragmentManager q;
  
  public boolean r;
  
  public int s = -1;
  
  public a(FragmentManager paramFragmentManager) {
    super(v, (ClassLoader)w);
    this.q = paramFragmentManager;
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.g) {
      FragmentManager fragmentManager = this.q;
      if (fragmentManager.d == null)
        fragmentManager.d = new ArrayList<a>(); 
      fragmentManager.d.add(this);
    } 
    return true;
  }
  
  public int c() {
    return g(false);
  }
  
  public void d(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      if (paramString != null) {
        String str = paramFragment.mTag;
        if (str == null || paramString.equals(str)) {
          paramFragment.mTag = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          throw new IllegalStateException(a0.a.a(stringBuilder2, paramFragment.mTag, " now ", paramString));
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramFragment.mFragmentId;
          if (i == 0 || i == paramInt1) {
            paramFragment.mFragmentId = paramInt1;
            paramFragment.mContainerId = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.mFragmentId);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      b(new g0.a(paramInt2, paramFragment));
      paramFragment.mFragmentManager = this.q;
      return;
    } 
    StringBuilder stringBuilder1 = android.support.v4.media.a.a("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public void e(int paramInt) {
    if (!this.g)
      return; 
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      g0.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.mBackStackNesting += paramInt;
        if (FragmentManager.O(2)) {
          StringBuilder stringBuilder = android.support.v4.media.a.a("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.mBackStackNesting);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public int f() {
    return g(true);
  }
  
  public int g(boolean paramBoolean) {
    if (!this.r) {
      if (FragmentManager.O(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter(new t0("FragmentManager"));
        i("  ", printWriter, true);
        printWriter.close();
      } 
      this.r = true;
      if (this.g) {
        this.s = this.q.i.getAndIncrement();
      } else {
        this.s = -1;
      } 
      this.q.A(this, paramBoolean);
      return this.s;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void h() {
    if (!this.g) {
      this.h = false;
      this.q.D(this, false);
      return;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void i(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.i);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.s);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.r);
      if (this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
      } 
      if (this.b != 0 || this.c != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.b));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.c));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.j != 0 || this.k != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.j));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.k);
      } 
      if (this.l != 0 || this.m != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.l));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.m);
      } 
    } 
    if (!this.a.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int j = this.a.size();
      int i;
      for (i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        g0.a a1 = this.a.get(i);
        switch (a1.a) {
          default:
            stringBuilder = android.support.v4.media.a.a("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  public void j() {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      g0.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.setPopDirection(false);
        fragment.setNextTransition(this.f);
        fragment.setSharedElementNames(this.n, this.o);
      } 
      switch (a1.a) {
        default:
          stringBuilder = android.support.v4.media.a.a("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.q.f0((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.q.g0(null);
          break;
        case 8:
          this.q.g0((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, false);
          this.q.c((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.j((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, false);
          this.q.i0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.N((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.Z((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, false);
          this.q.a((Fragment)stringBuilder);
          break;
      } 
      if (!this.p)
        int k = a1.a; 
    } 
  }
  
  public void k(boolean paramBoolean) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      g0.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.setPopDirection(true);
        int j = this.f;
        char c = ' ';
        if (j != 4097)
          if (j != 4099) {
            if (j != 8194) {
              c = Character.MIN_VALUE;
            } else {
              c = 'ခ';
            } 
          } else {
            c = 'ဃ';
          }  
        fragment.setNextTransition(c);
        fragment.setSharedElementNames(this.o, this.n);
      } 
      switch (a1.a) {
        default:
          stringBuilder = android.support.v4.media.a.a("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.q.f0((Fragment)stringBuilder, a1.g);
          break;
        case 9:
          this.q.g0((Fragment)stringBuilder);
          break;
        case 8:
          this.q.g0(null);
          break;
        case 7:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, true);
          this.q.j((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.c((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, true);
          this.q.N((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.i0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.a((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.setAnimations(a1.c, a1.d, a1.e, a1.f);
          this.q.e0((Fragment)stringBuilder, true);
          this.q.Z((Fragment)stringBuilder);
          break;
      } 
      if (!this.p)
        int j = a1.a; 
    } 
  }
  
  public boolean l(int paramInt) {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      int k;
      Fragment fragment = ((g0.a)this.a.get(i)).b;
      if (fragment != null) {
        k = fragment.mContainerId;
      } else {
        k = 0;
      } 
      if (k && k == paramInt)
        return true; 
    } 
    return false;
  }
  
  public boolean m(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int k = this.a.size();
    int j = -1;
    int i = 0;
    while (i < k) {
      int n;
      Fragment fragment = ((g0.a)this.a.get(i)).b;
      if (fragment != null) {
        n = fragment.mContainerId;
      } else {
        n = 0;
      } 
      int i1 = j;
      if (n) {
        i1 = j;
        if (n != j) {
          for (j = paramInt1; j < paramInt2; j++) {
            a a1 = paramArrayList.get(j);
            int i2 = a1.a.size();
            for (i1 = 0; i1 < i2; i1++) {
              int i3;
              Fragment fragment1 = ((g0.a)a1.a.get(i1)).b;
              if (fragment1 != null) {
                i3 = fragment1.mContainerId;
              } else {
                i3 = 0;
              } 
              if (i3 == n)
                return true; 
            } 
          } 
          i1 = n;
        } 
      } 
      i++;
      j = i1;
    } 
    return false;
  }
  
  public g0 n(Fragment paramFragment) {
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    if (fragmentManager == null || fragmentManager == this.q) {
      b(new g0.a(3, paramFragment));
      return this;
    } 
    StringBuilder stringBuilder = android.support.v4.media.a.a("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.s >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.s);
    } 
    if (this.i != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.i);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */