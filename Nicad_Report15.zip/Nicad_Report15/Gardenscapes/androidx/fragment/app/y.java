package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class y {
  public final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<a>();
  
  public final FragmentManager b;
  
  public y(FragmentManager paramFragmentManager) {
    this.b = paramFragmentManager;
  }
  
  public void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.a(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        Objects.requireNonNull(a.a); 
    } 
  }
  
  public void b(Fragment paramFragment, boolean paramBoolean) {
    FragmentManager fragmentManager = this.b;
    Context context = fragmentManager.r.g;
    Fragment fragment = fragmentManager.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.b(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.a(this.b, paramFragment, context); 
    } 
  }
  
  public void c(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.c(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.b(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void d(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.d(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.c(this.b, paramFragment); 
    } 
  }
  
  public void e(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.e(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.d(this.b, paramFragment); 
    } 
  }
  
  public void f(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.f(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.e(this.b, paramFragment); 
    } 
  }
  
  public void g(Fragment paramFragment, boolean paramBoolean) {
    Objects.requireNonNull(this.b.r);
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.g(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        Objects.requireNonNull(a.a); 
    } 
  }
  
  public void h(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.h(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        Objects.requireNonNull(a.a); 
    } 
  }
  
  public void i(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.i(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.f(this.b, paramFragment); 
    } 
  }
  
  public void j(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.j(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.g(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void k(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.k(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.h(this.b, paramFragment); 
    } 
  }
  
  public void l(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.l(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.i(this.b, paramFragment); 
    } 
  }
  
  public void m(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.m(paramFragment, paramView, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.j(this.b, paramFragment, paramView, paramBundle); 
    } 
  }
  
  public void n(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.t;
    if (fragment != null)
      (fragment.getParentFragmentManager()).o.n(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.k(this.b, paramFragment); 
    } 
  }
  
  public static final class a {
    public final FragmentManager.FragmentLifecycleCallbacks a;
    
    public final boolean b;
    
    public a(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.a = param1FragmentLifecycleCallbacks;
      this.b = param1Boolean;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */