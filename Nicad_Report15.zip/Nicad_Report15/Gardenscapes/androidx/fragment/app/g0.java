package androidx.fragment.app;

import androidx.lifecycle.Lifecycle;
import java.util.ArrayList;

public abstract class g0 {
  public ArrayList<a> a = new ArrayList<a>();
  
  public int b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public int f;
  
  public boolean g;
  
  public boolean h = true;
  
  public String i;
  
  public int j;
  
  public CharSequence k;
  
  public int l;
  
  public CharSequence m;
  
  public ArrayList<String> n;
  
  public ArrayList<String> o;
  
  public boolean p = false;
  
  public g0(v paramv, ClassLoader paramClassLoader) {}
  
  public void b(a parama) {
    this.a.add(parama);
    parama.c = this.b;
    parama.d = this.c;
    parama.e = this.d;
    parama.f = this.e;
  }
  
  public abstract int c();
  
  public abstract void d(int paramInt1, Fragment paramFragment, String paramString, int paramInt2);
  
  public static final class a {
    public int a;
    
    public Fragment b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public Lifecycle.State g;
    
    public Lifecycle.State h;
    
    public a() {}
    
    public a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      Lifecycle.State state = Lifecycle.State.j;
      this.g = state;
      this.h = state;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */