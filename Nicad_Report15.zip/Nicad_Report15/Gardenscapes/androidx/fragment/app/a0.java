package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class a0 implements Parcelable {
  public static final Parcelable.Creator<a0> CREATOR = new a();
  
  public ArrayList<d0> f;
  
  public ArrayList<String> g;
  
  public b[] h;
  
  public int i;
  
  public String j = null;
  
  public ArrayList<String> k = new ArrayList<String>();
  
  public ArrayList<Bundle> l = new ArrayList<Bundle>();
  
  public ArrayList<FragmentManager.k> m;
  
  public a0() {}
  
  public a0(Parcel paramParcel) {
    this.f = paramParcel.createTypedArrayList(d0.CREATOR);
    this.g = paramParcel.createStringArrayList();
    this.h = (b[])paramParcel.createTypedArray(b.CREATOR);
    this.i = paramParcel.readInt();
    this.j = paramParcel.readString();
    this.k = paramParcel.createStringArrayList();
    this.l = paramParcel.createTypedArrayList(Bundle.CREATOR);
    this.m = paramParcel.createTypedArrayList(FragmentManager.k.CREATOR);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.f);
    paramParcel.writeStringList(this.g);
    paramParcel.writeTypedArray((Parcelable[])this.h, paramInt);
    paramParcel.writeInt(this.i);
    paramParcel.writeString(this.j);
    paramParcel.writeStringList(this.k);
    paramParcel.writeTypedList(this.l);
    paramParcel.writeTypedList(this.m);
  }
  
  public class a implements Parcelable.Creator<a0> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new a0(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new a0[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */