package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import i0.b;

public class g implements b.a {
  public g(c paramc, View paramView, ViewGroup paramViewGroup, c.b paramb) {}
  
  public void onCancel() {
    this.a.clearAnimation();
    this.b.endViewTransition(this.a);
    this.c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */