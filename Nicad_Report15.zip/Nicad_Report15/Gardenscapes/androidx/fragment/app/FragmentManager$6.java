package androidx.fragment.app;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;

class FragmentManager$6 implements h {
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent != Lifecycle.Event.ON_START) {
      if (paramEvent != Lifecycle.Event.ON_DESTROY)
        return; 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\FragmentManager$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */