package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class b implements Parcelable {
  public static final Parcelable.Creator<b> CREATOR = new a();
  
  public final int[] f;
  
  public final ArrayList<String> g;
  
  public final int[] h;
  
  public final int[] i;
  
  public final int j;
  
  public final String k;
  
  public final int l;
  
  public final int m;
  
  public final CharSequence n;
  
  public final int o;
  
  public final CharSequence p;
  
  public final ArrayList<String> q;
  
  public final ArrayList<String> r;
  
  public final boolean s;
  
  public b(Parcel paramParcel) {
    boolean bool;
    this.f = paramParcel.createIntArray();
    this.g = paramParcel.createStringArrayList();
    this.h = paramParcel.createIntArray();
    this.i = paramParcel.createIntArray();
    this.j = paramParcel.readInt();
    this.k = paramParcel.readString();
    this.l = paramParcel.readInt();
    this.m = paramParcel.readInt();
    this.n = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.o = paramParcel.readInt();
    this.p = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.q = paramParcel.createStringArrayList();
    this.r = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.s = bool;
  }
  
  public b(a parama) {
    int i = parama.a.size();
    this.f = new int[i * 5];
    if (parama.g) {
      this.g = new ArrayList<String>(i);
      this.h = new int[i];
      this.i = new int[i];
      int j = 0;
      for (int k = 0; j < i; k++) {
        g0.a a1 = parama.a.get(j);
        int[] arrayOfInt2 = this.f;
        int m = k + 1;
        arrayOfInt2[k] = a1.a;
        ArrayList<String> arrayList = this.g;
        Fragment fragment = a1.b;
        if (fragment != null) {
          String str = fragment.mWho;
        } else {
          fragment = null;
        } 
        arrayList.add(fragment);
        int[] arrayOfInt1 = this.f;
        k = m + 1;
        arrayOfInt1[m] = a1.c;
        m = k + 1;
        arrayOfInt1[k] = a1.d;
        k = m + 1;
        arrayOfInt1[m] = a1.e;
        arrayOfInt1[k] = a1.f;
        this.h[j] = a1.g.ordinal();
        this.i[j] = a1.h.ordinal();
        j++;
      } 
      this.j = parama.f;
      this.k = parama.i;
      this.l = parama.s;
      this.m = parama.j;
      this.n = parama.k;
      this.o = parama.l;
      this.p = parama.m;
      this.q = parama.n;
      this.r = parama.o;
      this.s = parama.p;
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Not on back stack");
    throw illegalStateException;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public class a implements Parcelable.Creator<b> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new b(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new b[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */