package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import m0.s;

public class r {
  public static a a(Context paramContext, Fragment paramFragment, boolean paramBoolean1, boolean paramBoolean2) {
    int j;
    int k = paramFragment.getNextTransition();
    if (paramBoolean2) {
      if (paramBoolean1) {
        j = paramFragment.getPopEnterAnim();
      } else {
        j = paramFragment.getPopExitAnim();
      } 
    } else if (paramBoolean1) {
      j = paramFragment.getEnterAnim();
    } else {
      j = paramFragment.getExitAnim();
    } 
    boolean bool = false;
    paramFragment.setAnimations(0, 0, 0, 0);
    ViewGroup viewGroup = paramFragment.mContainer;
    if (viewGroup != null && viewGroup.getTag(2131231219) != null)
      paramFragment.mContainer.setTag(2131231219, null); 
    viewGroup = paramFragment.mContainer;
    if (viewGroup != null && viewGroup.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.onCreateAnimation(k, paramBoolean1, j);
    if (animation != null)
      return new a(animation); 
    Animator animator = paramFragment.onCreateAnimator(k, paramBoolean1, j);
    if (animator != null)
      return new a(animator); 
    int i = j;
    if (j == 0) {
      i = j;
      if (k != 0)
        if (k != 4097) {
          if (k != 4099) {
            if (k != 8194) {
              i = -1;
            } else if (paramBoolean1) {
              i = 2130837507;
            } else {
              i = 2130837508;
            } 
          } else if (paramBoolean1) {
            i = 2130837509;
          } else {
            i = 2130837510;
          } 
        } else if (paramBoolean1) {
          i = 2130837511;
        } else {
          i = 2130837512;
        }  
    } 
    if (i != 0) {
      paramBoolean1 = "anim".equals(paramContext.getResources().getResourceTypeName(i));
      j = bool;
      if (paramBoolean1)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(paramContext, i);
          if (animation1 != null)
            return new a(animation1); 
          j = 1;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          j = bool;
        }  
      if (j == 0)
        try {
          animator = AnimatorInflater.loadAnimator((Context)notFoundException, i);
          if (animator != null)
            return new a(animator); 
        } catch (RuntimeException runtimeException) {
          if (!paramBoolean1) {
            Animation animation1 = AnimationUtils.loadAnimation((Context)notFoundException, i);
            if (animation1 != null)
              return new a(animation1); 
          } else {
            throw runtimeException;
          } 
        }  
    } 
    return null;
  }
  
  public static class a {
    public final Animation a = null;
    
    public final Animator b;
    
    public a(Animator param1Animator) {
      this.b = param1Animator;
    }
    
    public a(Animation param1Animation) {
      this.b = null;
    }
  }
  
  public static class b extends AnimationSet implements Runnable {
    public final ViewGroup f;
    
    public final View g;
    
    public boolean h;
    
    public boolean i;
    
    public boolean j = true;
    
    public b(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.f = param1ViewGroup;
      this.g = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.j = true;
      if (this.h)
        return this.i ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.h = true;
        s.a((View)this.f, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.j = true;
      if (this.h)
        return this.i ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.h = true;
        s.a((View)this.f, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.h && this.j) {
        this.j = false;
        this.f.post(this);
        return;
      } 
      this.f.endViewTransition(this.g);
      this.i = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */