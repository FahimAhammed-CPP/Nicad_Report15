package androidx.fragment.app;

import i0.b;

public class h0 implements Runnable {
  public h0(n0.a parama, Fragment paramFragment, b paramb) {}
  
  public void run() {
    n0.a a1 = this.f;
    Fragment fragment = this.g;
    b b1 = this.h;
    ((FragmentManager.d)a1).a(fragment, b1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */