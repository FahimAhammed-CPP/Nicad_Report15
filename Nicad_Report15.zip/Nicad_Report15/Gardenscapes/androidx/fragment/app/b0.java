package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.c0;
import androidx.lifecycle.w;
import androidx.lifecycle.y;
import java.util.HashMap;
import java.util.Iterator;

public final class b0 extends w {
  public static final y i = new a();
  
  public final HashMap<String, Fragment> c = new HashMap<String, Fragment>();
  
  public final HashMap<String, b0> d = new HashMap<String, b0>();
  
  public final HashMap<String, c0> e = new HashMap<String, c0>();
  
  public final boolean f;
  
  public boolean g = false;
  
  public boolean h = false;
  
  public b0(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void a() {
    if (FragmentManager.O(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.g = true;
  }
  
  public void c(Fragment paramFragment) {
    if (this.h) {
      if (FragmentManager.O(2))
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.containsKey(paramFragment.mWho))
      return; 
    this.c.put(paramFragment.mWho, paramFragment);
    if (FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void d(Fragment paramFragment) {
    boolean bool;
    if (this.h) {
      if (FragmentManager.O(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.remove(paramFragment.mWho) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && FragmentManager.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public boolean e(Fragment paramFragment) {
    return !this.c.containsKey(paramFragment.mWho) ? true : (this.f ? this.g : true);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (b0.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.c.equals(((b0)paramObject).c) && this.d.equals(((b0)paramObject).d) && this.e.equals(((b0)paramObject).e));
    } 
    return false;
  }
  
  public int hashCode() {
    int i = this.c.hashCode();
    int j = this.d.hashCode();
    return this.e.hashCode() + (j + i * 31) * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.c.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.d.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.e.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public class a implements y {
    public <T extends w> T a(Class<T> param1Class) {
      return (T)new b0(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */