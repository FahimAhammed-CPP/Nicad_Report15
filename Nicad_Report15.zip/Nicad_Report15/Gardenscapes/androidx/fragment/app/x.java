package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import e.g;
import s.h;
import w0.d;

public class x implements LayoutInflater.Factory2 {
  public final FragmentManager f;
  
  public x(FragmentManager paramFragmentManager) {
    this.f = paramFragmentManager;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (t.class.getName().equals(paramString))
      return (View)new t(paramContext, paramAttributeSet, this.f); 
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.a);
    int i = 0;
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    String str3 = typedArray.getString(2);
    typedArray.recycle();
    if (str2 != null) {
      e0 e0;
      ClassLoader classLoader = paramContext.getClassLoader();
      h<ClassLoader, h<String, Class<?>>> h = v.a;
      try {
        bool = Fragment.class.isAssignableFrom(v.b(classLoader, str2));
      } catch (ClassNotFoundException classNotFoundException) {
        bool = false;
      } 
      if (!bool)
        return null; 
      if (paramView != null)
        i = paramView.getId(); 
      if (i != -1 || j != -1 || str3 != null) {
        StringBuilder stringBuilder1;
        Fragment fragment2;
        if (j != -1)
          fragment1 = this.f.H(j); 
        Fragment fragment3 = fragment1;
        if (fragment1 == null) {
          fragment3 = fragment1;
          if (str3 != null)
            fragment3 = this.f.I(str3); 
        } 
        Fragment fragment1 = fragment3;
        if (fragment3 == null) {
          fragment1 = fragment3;
          if (i != -1)
            fragment1 = this.f.H(i); 
        } 
        if (fragment1 == null) {
          int k;
          fragment1 = this.f.L().a(paramContext.getClassLoader(), str2);
          fragment1.mFromLayout = true;
          if (j != 0) {
            k = j;
          } else {
            k = i;
          } 
          fragment1.mFragmentId = k;
          fragment1.mContainerId = i;
          fragment1.mTag = str3;
          fragment1.mInLayout = true;
          FragmentManager fragmentManager = this.f;
          fragment1.mFragmentManager = fragmentManager;
          w<?> w = fragmentManager.r;
          fragment1.mHost = w;
          fragment1.onInflate(w.g, paramAttributeSet, fragment1.mSavedFragmentState);
          e0 e01 = this.f.a(fragment1);
          fragment2 = fragment1;
          e0 = e01;
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Fragment ");
            stringBuilder2.append(fragment1);
            stringBuilder2.append(" has been inflated via the <fragment> tag: id=0x");
            stringBuilder2.append(Integer.toHexString(j));
            Log.v("FragmentManager", stringBuilder2.toString());
            Fragment fragment = fragment1;
            e0 = e01;
          } 
        } else if (!fragment1.mInLayout) {
          fragment1.mInLayout = true;
          FragmentManager fragmentManager = this.f;
          fragment1.mFragmentManager = fragmentManager;
          w<?> w = fragmentManager.r;
          fragment1.mHost = w;
          fragment1.onInflate(w.g, (AttributeSet)e0, fragment1.mSavedFragmentState);
          e0 e01 = this.f.h(fragment1);
          fragment2 = fragment1;
          e0 = e01;
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Retained Fragment ");
            stringBuilder2.append(fragment1);
            stringBuilder2.append(" has been re-attached via the <fragment> tag: id=0x");
            stringBuilder2.append(Integer.toHexString(j));
            Log.v("FragmentManager", stringBuilder2.toString());
            e0 = e01;
            fragment2 = fragment1;
          } 
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(e0.getPositionDescription());
          stringBuilder1.append(": Duplicate id 0x");
          stringBuilder1.append(Integer.toHexString(j));
          stringBuilder1.append(", tag ");
          stringBuilder1.append(str3);
          stringBuilder1.append(", or parent id 0x");
          stringBuilder1.append(Integer.toHexString(i));
          stringBuilder1.append(" with another fragment for ");
          stringBuilder1.append(str2);
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        fragment2.mContainer = (ViewGroup)stringBuilder1;
        e0.k();
        e0.j();
        View view = fragment2.mView;
        if (view != null) {
          if (j != 0)
            view.setId(j); 
          if (fragment2.mView.getTag() == null)
            fragment2.mView.setTag(str3); 
          fragment2.mView.addOnAttachStateChangeListener(new a(this, e0));
          return fragment2.mView;
        } 
        throw new IllegalStateException(g.a("Fragment ", str2, " did not create a view."));
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(e0.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str2);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public a(x this$0, e0 param1e0) {}
    
    public void onViewAttachedToWindow(View param1View) {
      e0 e01 = this.f;
      Fragment fragment = e01.c;
      e01.k();
      SpecialEffectsController.f((ViewGroup)fragment.mView.getParent(), this.g.f).e();
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */