package androidx.fragment.app;

import android.animation.Animator;
import i0.b;

public class e implements b.a {
  public e(c paramc, Animator paramAnimator) {}
  
  public void onCancel() {
    this.a.end();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */