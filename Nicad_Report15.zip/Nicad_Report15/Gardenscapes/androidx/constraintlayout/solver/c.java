package androidx.constraintlayout.solver;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import h5.mt;
import java.util.Arrays;
import java.util.Objects;

public class c {
  public static int o = 1000;
  
  public static boolean p = true;
  
  public static long q;
  
  public static long r;
  
  public int a = 0;
  
  public a b;
  
  public int c = 32;
  
  public int d = 32;
  
  public b[] e = null;
  
  public boolean f = false;
  
  public boolean[] g = new boolean[32];
  
  public int h = 1;
  
  public int i = 0;
  
  public int j = 32;
  
  public final mt k;
  
  public SolverVariable[] l = new SolverVariable[o];
  
  public int m = 0;
  
  public a n;
  
  public c() {
    this.e = new b[32];
    s();
    mt mt1 = new mt(1);
    this.k = mt1;
    this.b = new d(mt1);
    if (p) {
      this.n = new b(this, mt1);
      return;
    } 
    this.n = new b(mt1);
  }
  
  public final SolverVariable a(SolverVariable.Type paramType, String paramString) {
    SolverVariable solverVariable1;
    SolverVariable solverVariable2 = (SolverVariable)((u.a)this.k.i).a();
    if (solverVariable2 == null) {
      solverVariable2 = new SolverVariable(paramType);
      solverVariable2.i = paramType;
      solverVariable1 = solverVariable2;
    } else {
      solverVariable2.c();
      solverVariable2.i = (SolverVariable.Type)solverVariable1;
      solverVariable1 = solverVariable2;
    } 
    int i = this.m;
    int j = o;
    if (i >= j) {
      i = j * 2;
      o = i;
      this.l = Arrays.<SolverVariable>copyOf(this.l, i);
    } 
    SolverVariable[] arrayOfSolverVariable = this.l;
    i = this.m;
    this.m = i + 1;
    arrayOfSolverVariable[i] = solverVariable1;
    return solverVariable1;
  }
  
  public void b(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, float paramFloat, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, int paramInt2, int paramInt3) {
    b b1 = m();
    if (paramSolverVariable2 == paramSolverVariable3) {
      b1.d.g(paramSolverVariable1, 1.0F);
      b1.d.g(paramSolverVariable4, 1.0F);
      b1.d.g(paramSolverVariable2, -2.0F);
    } else if (paramFloat == 0.5F) {
      b1.d.g(paramSolverVariable1, 1.0F);
      b1.d.g(paramSolverVariable2, -1.0F);
      b1.d.g(paramSolverVariable3, -1.0F);
      b1.d.g(paramSolverVariable4, 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0)
        b1.b = (-paramInt1 + paramInt2); 
    } else if (paramFloat <= 0.0F) {
      b1.d.g(paramSolverVariable1, -1.0F);
      b1.d.g(paramSolverVariable2, 1.0F);
      b1.b = paramInt1;
    } else if (paramFloat >= 1.0F) {
      b1.d.g(paramSolverVariable4, -1.0F);
      b1.d.g(paramSolverVariable3, 1.0F);
      b1.b = -paramInt2;
    } else {
      b.a a1 = b1.d;
      float f = 1.0F - paramFloat;
      a1.g(paramSolverVariable1, f * 1.0F);
      b1.d.g(paramSolverVariable2, f * -1.0F);
      b1.d.g(paramSolverVariable3, -1.0F * paramFloat);
      b1.d.g(paramSolverVariable4, 1.0F * paramFloat);
      if (paramInt1 > 0 || paramInt2 > 0) {
        float f1 = -paramInt1;
        b1.b = paramInt2 * paramFloat + f1 * f;
      } 
    } 
    if (paramInt3 != 8)
      b1.c(this, paramInt3); 
    c(b1);
  }
  
  public void c(b paramb) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/SolverVariable$Type.f : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   3: astore #20
    //   5: aload_0
    //   6: getfield i : I
    //   9: istore #7
    //   11: iconst_1
    //   12: istore #9
    //   14: iload #7
    //   16: iconst_1
    //   17: iadd
    //   18: aload_0
    //   19: getfield j : I
    //   22: if_icmpge -> 38
    //   25: aload_0
    //   26: getfield h : I
    //   29: iconst_1
    //   30: iadd
    //   31: aload_0
    //   32: getfield d : I
    //   35: if_icmplt -> 42
    //   38: aload_0
    //   39: invokevirtual p : ()V
    //   42: aload_1
    //   43: getfield e : Z
    //   46: ifne -> 1112
    //   49: aload_0
    //   50: getfield e : [Landroidx/constraintlayout/solver/b;
    //   53: arraylength
    //   54: ifne -> 60
    //   57: goto -> 231
    //   60: iconst_0
    //   61: istore #7
    //   63: iload #7
    //   65: ifne -> 231
    //   68: aload_1
    //   69: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   72: invokeinterface e : ()I
    //   77: istore #10
    //   79: iconst_0
    //   80: istore #8
    //   82: iload #8
    //   84: iload #10
    //   86: if_icmpge -> 138
    //   89: aload_1
    //   90: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   93: iload #8
    //   95: invokeinterface i : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   100: astore #15
    //   102: aload #15
    //   104: getfield c : I
    //   107: iconst_m1
    //   108: if_icmpne -> 119
    //   111: aload #15
    //   113: getfield f : Z
    //   116: ifeq -> 129
    //   119: aload_1
    //   120: getfield c : Ljava/util/ArrayList;
    //   123: aload #15
    //   125: invokevirtual add : (Ljava/lang/Object;)Z
    //   128: pop
    //   129: iload #8
    //   131: iconst_1
    //   132: iadd
    //   133: istore #8
    //   135: goto -> 82
    //   138: aload_1
    //   139: getfield c : Ljava/util/ArrayList;
    //   142: invokevirtual size : ()I
    //   145: ifle -> 225
    //   148: aload_1
    //   149: getfield c : Ljava/util/ArrayList;
    //   152: invokevirtual iterator : ()Ljava/util/Iterator;
    //   155: astore #15
    //   157: aload #15
    //   159: invokeinterface hasNext : ()Z
    //   164: ifeq -> 215
    //   167: aload #15
    //   169: invokeinterface next : ()Ljava/lang/Object;
    //   174: checkcast androidx/constraintlayout/solver/SolverVariable
    //   177: astore #16
    //   179: aload #16
    //   181: getfield f : Z
    //   184: ifeq -> 197
    //   187: aload_1
    //   188: aload #16
    //   190: iconst_1
    //   191: invokevirtual k : (Landroidx/constraintlayout/solver/SolverVariable;Z)V
    //   194: goto -> 157
    //   197: aload_1
    //   198: aload_0
    //   199: getfield e : [Landroidx/constraintlayout/solver/b;
    //   202: aload #16
    //   204: getfield c : I
    //   207: aaload
    //   208: iconst_1
    //   209: invokevirtual l : (Landroidx/constraintlayout/solver/b;Z)V
    //   212: goto -> 157
    //   215: aload_1
    //   216: getfield c : Ljava/util/ArrayList;
    //   219: invokevirtual clear : ()V
    //   222: goto -> 63
    //   225: iconst_1
    //   226: istore #7
    //   228: goto -> 63
    //   231: aload_1
    //   232: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   235: ifnonnull -> 265
    //   238: aload_1
    //   239: getfield b : F
    //   242: fconst_0
    //   243: fcmpl
    //   244: ifne -> 265
    //   247: aload_1
    //   248: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   251: invokeinterface e : ()I
    //   256: ifne -> 265
    //   259: iconst_1
    //   260: istore #7
    //   262: goto -> 268
    //   265: iconst_0
    //   266: istore #7
    //   268: iload #7
    //   270: ifeq -> 274
    //   273: return
    //   274: aload_1
    //   275: getfield b : F
    //   278: fstore_2
    //   279: fload_2
    //   280: fconst_0
    //   281: fcmpg
    //   282: ifge -> 302
    //   285: aload_1
    //   286: fload_2
    //   287: ldc -1.0
    //   289: fmul
    //   290: putfield b : F
    //   293: aload_1
    //   294: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   297: invokeinterface k : ()V
    //   302: aload_1
    //   303: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   306: invokeinterface e : ()I
    //   311: istore #8
    //   313: iconst_0
    //   314: istore #7
    //   316: aconst_null
    //   317: astore #17
    //   319: aconst_null
    //   320: astore #16
    //   322: fconst_0
    //   323: fstore #6
    //   325: iconst_0
    //   326: istore #14
    //   328: fconst_0
    //   329: fstore #5
    //   331: iconst_0
    //   332: istore #13
    //   334: iload #7
    //   336: iload #8
    //   338: if_icmpge -> 744
    //   341: aload_1
    //   342: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   345: iload #7
    //   347: invokeinterface a : (I)F
    //   352: fstore_2
    //   353: aload_1
    //   354: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   357: iload #7
    //   359: invokeinterface i : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   364: astore #15
    //   366: aload #15
    //   368: getfield i : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   371: aload #20
    //   373: if_acmpne -> 515
    //   376: aload #17
    //   378: ifnonnull -> 392
    //   381: aload_1
    //   382: aload #15
    //   384: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   387: istore #11
    //   389: goto -> 410
    //   392: fload #6
    //   394: fload_2
    //   395: fcmpl
    //   396: ifle -> 431
    //   399: aload_1
    //   400: aload #15
    //   402: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   405: istore #11
    //   407: goto -> 389
    //   410: aload #15
    //   412: astore #18
    //   414: aload #16
    //   416: astore #19
    //   418: fload_2
    //   419: fstore_3
    //   420: fload #5
    //   422: fstore #4
    //   424: iload #13
    //   426: istore #12
    //   428: goto -> 712
    //   431: aload #17
    //   433: astore #18
    //   435: aload #16
    //   437: astore #19
    //   439: fload #6
    //   441: fstore_3
    //   442: iload #14
    //   444: istore #11
    //   446: fload #5
    //   448: fstore #4
    //   450: iload #13
    //   452: istore #12
    //   454: iload #14
    //   456: ifne -> 712
    //   459: aload #17
    //   461: astore #18
    //   463: aload #16
    //   465: astore #19
    //   467: fload #6
    //   469: fstore_3
    //   470: iload #14
    //   472: istore #11
    //   474: fload #5
    //   476: fstore #4
    //   478: iload #13
    //   480: istore #12
    //   482: aload_1
    //   483: aload #15
    //   485: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   488: ifeq -> 712
    //   491: iconst_1
    //   492: istore #11
    //   494: aload #15
    //   496: astore #18
    //   498: aload #16
    //   500: astore #19
    //   502: fload_2
    //   503: fstore_3
    //   504: fload #5
    //   506: fstore #4
    //   508: iload #13
    //   510: istore #12
    //   512: goto -> 712
    //   515: aload #17
    //   517: astore #18
    //   519: aload #16
    //   521: astore #19
    //   523: fload #6
    //   525: fstore_3
    //   526: iload #14
    //   528: istore #11
    //   530: fload #5
    //   532: fstore #4
    //   534: iload #13
    //   536: istore #12
    //   538: aload #17
    //   540: ifnonnull -> 712
    //   543: aload #17
    //   545: astore #18
    //   547: aload #16
    //   549: astore #19
    //   551: fload #6
    //   553: fstore_3
    //   554: iload #14
    //   556: istore #11
    //   558: fload #5
    //   560: fstore #4
    //   562: iload #13
    //   564: istore #12
    //   566: fload_2
    //   567: fconst_0
    //   568: fcmpg
    //   569: ifge -> 712
    //   572: aload #16
    //   574: ifnonnull -> 592
    //   577: aload_1
    //   578: aload #15
    //   580: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   583: istore #11
    //   585: iload #11
    //   587: istore #12
    //   589: goto -> 610
    //   592: fload #5
    //   594: fload_2
    //   595: fcmpl
    //   596: ifle -> 631
    //   599: aload_1
    //   600: aload #15
    //   602: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   605: istore #11
    //   607: goto -> 585
    //   610: aload #17
    //   612: astore #18
    //   614: aload #15
    //   616: astore #19
    //   618: fload #6
    //   620: fstore_3
    //   621: iload #14
    //   623: istore #11
    //   625: fload_2
    //   626: fstore #4
    //   628: goto -> 712
    //   631: aload #17
    //   633: astore #18
    //   635: aload #16
    //   637: astore #19
    //   639: fload #6
    //   641: fstore_3
    //   642: iload #14
    //   644: istore #11
    //   646: fload #5
    //   648: fstore #4
    //   650: iload #13
    //   652: istore #12
    //   654: iload #13
    //   656: ifne -> 712
    //   659: aload #17
    //   661: astore #18
    //   663: aload #16
    //   665: astore #19
    //   667: fload #6
    //   669: fstore_3
    //   670: iload #14
    //   672: istore #11
    //   674: fload #5
    //   676: fstore #4
    //   678: iload #13
    //   680: istore #12
    //   682: aload_1
    //   683: aload #15
    //   685: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;)Z
    //   688: ifeq -> 712
    //   691: iconst_1
    //   692: istore #12
    //   694: fload_2
    //   695: fstore #4
    //   697: iload #14
    //   699: istore #11
    //   701: fload #6
    //   703: fstore_3
    //   704: aload #15
    //   706: astore #19
    //   708: aload #17
    //   710: astore #18
    //   712: iload #7
    //   714: iconst_1
    //   715: iadd
    //   716: istore #7
    //   718: aload #18
    //   720: astore #17
    //   722: aload #19
    //   724: astore #16
    //   726: fload_3
    //   727: fstore #6
    //   729: iload #11
    //   731: istore #14
    //   733: fload #4
    //   735: fstore #5
    //   737: iload #12
    //   739: istore #13
    //   741: goto -> 334
    //   744: aload #17
    //   746: ifnull -> 756
    //   749: aload #17
    //   751: astore #16
    //   753: goto -> 756
    //   756: aload #16
    //   758: ifnonnull -> 767
    //   761: iconst_1
    //   762: istore #7
    //   764: goto -> 776
    //   767: aload_1
    //   768: aload #16
    //   770: invokevirtual j : (Landroidx/constraintlayout/solver/SolverVariable;)V
    //   773: iconst_0
    //   774: istore #7
    //   776: aload_1
    //   777: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   780: invokeinterface e : ()I
    //   785: ifne -> 793
    //   788: aload_1
    //   789: iconst_1
    //   790: putfield e : Z
    //   793: iload #7
    //   795: ifeq -> 1056
    //   798: aload_0
    //   799: getfield h : I
    //   802: iconst_1
    //   803: iadd
    //   804: aload_0
    //   805: getfield d : I
    //   808: if_icmplt -> 815
    //   811: aload_0
    //   812: invokevirtual p : ()V
    //   815: aload_0
    //   816: getstatic androidx/constraintlayout/solver/SolverVariable$Type.g : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   819: aconst_null
    //   820: invokevirtual a : (Landroidx/constraintlayout/solver/SolverVariable$Type;Ljava/lang/String;)Landroidx/constraintlayout/solver/SolverVariable;
    //   823: astore #15
    //   825: aload_0
    //   826: getfield a : I
    //   829: iconst_1
    //   830: iadd
    //   831: istore #7
    //   833: aload_0
    //   834: iload #7
    //   836: putfield a : I
    //   839: aload_0
    //   840: aload_0
    //   841: getfield h : I
    //   844: iconst_1
    //   845: iadd
    //   846: putfield h : I
    //   849: aload #15
    //   851: iload #7
    //   853: putfield b : I
    //   856: aload_0
    //   857: getfield k : Lh5/mt;
    //   860: getfield j : Ljava/lang/Object;
    //   863: checkcast [Landroidx/constraintlayout/solver/SolverVariable;
    //   866: iload #7
    //   868: aload #15
    //   870: aastore
    //   871: aload_1
    //   872: aload #15
    //   874: putfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   877: aload_0
    //   878: aload_1
    //   879: invokevirtual i : (Landroidx/constraintlayout/solver/b;)V
    //   882: aload_0
    //   883: getfield n : Landroidx/constraintlayout/solver/c$a;
    //   886: checkcast androidx/constraintlayout/solver/b
    //   889: astore #16
    //   891: aload #16
    //   893: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   896: pop
    //   897: aload #16
    //   899: aconst_null
    //   900: putfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   903: aload #16
    //   905: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   908: invokeinterface clear : ()V
    //   913: iconst_0
    //   914: istore #7
    //   916: iload #7
    //   918: aload_1
    //   919: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   922: invokeinterface e : ()I
    //   927: if_icmpge -> 978
    //   930: aload_1
    //   931: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   934: iload #7
    //   936: invokeinterface i : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   941: astore #17
    //   943: aload_1
    //   944: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   947: iload #7
    //   949: invokeinterface a : (I)F
    //   954: fstore_2
    //   955: aload #16
    //   957: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   960: aload #17
    //   962: fload_2
    //   963: iconst_1
    //   964: invokeinterface b : (Landroidx/constraintlayout/solver/SolverVariable;FZ)V
    //   969: iload #7
    //   971: iconst_1
    //   972: iadd
    //   973: istore #7
    //   975: goto -> 916
    //   978: aload_0
    //   979: aload_0
    //   980: getfield n : Landroidx/constraintlayout/solver/c$a;
    //   983: invokevirtual r : (Landroidx/constraintlayout/solver/c$a;)I
    //   986: pop
    //   987: aload #15
    //   989: getfield c : I
    //   992: iconst_m1
    //   993: if_icmpne -> 1050
    //   996: aload_1
    //   997: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   1000: aload #15
    //   1002: if_acmpne -> 1025
    //   1005: aload_1
    //   1006: aconst_null
    //   1007: aload #15
    //   1009: invokevirtual i : ([ZLandroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1012: astore #15
    //   1014: aload #15
    //   1016: ifnull -> 1025
    //   1019: aload_1
    //   1020: aload #15
    //   1022: invokevirtual j : (Landroidx/constraintlayout/solver/SolverVariable;)V
    //   1025: aload_1
    //   1026: getfield e : Z
    //   1029: ifne -> 1040
    //   1032: aload_1
    //   1033: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   1036: aload_1
    //   1037: invokevirtual e : (Landroidx/constraintlayout/solver/b;)V
    //   1040: aload_0
    //   1041: aload_0
    //   1042: getfield i : I
    //   1045: iconst_1
    //   1046: isub
    //   1047: putfield i : I
    //   1050: iconst_1
    //   1051: istore #7
    //   1053: goto -> 1059
    //   1056: iconst_0
    //   1057: istore #7
    //   1059: aload_1
    //   1060: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   1063: astore #15
    //   1065: aload #15
    //   1067: ifnull -> 1100
    //   1070: iload #9
    //   1072: istore #8
    //   1074: aload #15
    //   1076: getfield i : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   1079: aload #20
    //   1081: if_acmpeq -> 1103
    //   1084: aload_1
    //   1085: getfield b : F
    //   1088: fconst_0
    //   1089: fcmpg
    //   1090: iflt -> 1100
    //   1093: iload #9
    //   1095: istore #8
    //   1097: goto -> 1103
    //   1100: iconst_0
    //   1101: istore #8
    //   1103: iload #8
    //   1105: ifne -> 1109
    //   1108: return
    //   1109: goto -> 1115
    //   1112: iconst_0
    //   1113: istore #7
    //   1115: iload #7
    //   1117: ifne -> 1125
    //   1120: aload_0
    //   1121: aload_1
    //   1122: invokevirtual i : (Landroidx/constraintlayout/solver/b;)V
    //   1125: return
  }
  
  public b d(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, int paramInt2) {
    if (paramInt2 == 8 && paramSolverVariable2.f && paramSolverVariable1.c == -1) {
      paramSolverVariable1.d(this, paramSolverVariable2.e + paramInt1);
      return null;
    } 
    b b1 = m();
    int i = 0;
    int j = 0;
    if (paramInt1 != 0) {
      i = j;
      j = paramInt1;
      if (paramInt1 < 0) {
        j = paramInt1 * -1;
        i = 1;
      } 
      b1.b = j;
    } 
    if (i == 0) {
      b1.d.g(paramSolverVariable1, -1.0F);
      b1.d.g(paramSolverVariable2, 1.0F);
    } else {
      b1.d.g(paramSolverVariable1, 1.0F);
      b1.d.g(paramSolverVariable2, -1.0F);
    } 
    if (paramInt2 != 8)
      b1.c(this, paramInt2); 
    c(b1);
    return b1;
  }
  
  public void e(SolverVariable paramSolverVariable, int paramInt) {
    int i = paramSolverVariable.c;
    if (i == -1) {
      paramSolverVariable.d(this, paramInt);
      return;
    } 
    if (i != -1) {
      b b2 = this.e[i];
      if (b2.e) {
        b2.b = paramInt;
        return;
      } 
      if (b2.d.e() == 0) {
        b2.e = true;
        b2.b = paramInt;
        return;
      } 
      b2 = m();
      if (paramInt < 0) {
        b2.b = (paramInt * -1);
        b2.d.g(paramSolverVariable, 1.0F);
      } else {
        b2.b = paramInt;
        b2.d.g(paramSolverVariable, -1.0F);
      } 
      c(b2);
      return;
    } 
    b b1 = m();
    b1.a = paramSolverVariable;
    float f = paramInt;
    paramSolverVariable.e = f;
    b1.b = f;
    b1.e = true;
    c(b1);
  }
  
  public void f(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, int paramInt2) {
    b b1 = m();
    SolverVariable solverVariable = n();
    solverVariable.d = 0;
    b1.e(paramSolverVariable1, paramSolverVariable2, solverVariable, paramInt1);
    if (paramInt2 != 8) {
      paramInt1 = (int)(b1.d.c(solverVariable) * -1.0F);
      paramSolverVariable1 = k(paramInt2, null);
      b1.d.g(paramSolverVariable1, paramInt1);
    } 
    c(b1);
  }
  
  public void g(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, int paramInt2) {
    b b1 = m();
    SolverVariable solverVariable = n();
    solverVariable.d = 0;
    b1.f(paramSolverVariable1, paramSolverVariable2, solverVariable, paramInt1);
    if (paramInt2 != 8) {
      paramInt1 = (int)(b1.d.c(solverVariable) * -1.0F);
      paramSolverVariable1 = k(paramInt2, null);
      b1.d.g(paramSolverVariable1, paramInt1);
    } 
    c(b1);
  }
  
  public void h(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat, int paramInt) {
    b b1 = m();
    b1.d(paramSolverVariable1, paramSolverVariable2, paramSolverVariable3, paramSolverVariable4, paramFloat);
    if (paramInt != 8)
      b1.c(this, paramInt); 
    c(b1);
  }
  
  public final void i(b paramb) {
    if (p) {
      b[] arrayOfB1 = this.e;
      int j = this.i;
      if (arrayOfB1[j] != null)
        ((u.a)this.k.g).c(arrayOfB1[j]); 
    } else {
      b[] arrayOfB1 = this.e;
      int j = this.i;
      if (arrayOfB1[j] != null)
        ((u.a)this.k.h).c(arrayOfB1[j]); 
    } 
    b[] arrayOfB = this.e;
    int i = this.i;
    arrayOfB[i] = paramb;
    SolverVariable solverVariable = paramb.a;
    solverVariable.c = i;
    this.i = i + 1;
    solverVariable.e(paramb);
  }
  
  public final void j() {
    for (int i = 0; i < this.i; i++) {
      b b1 = this.e[i];
      b1.a.e = b1.b;
    } 
  }
  
  public SolverVariable k(int paramInt, String paramString) {
    if (this.h + 1 >= this.d)
      p(); 
    SolverVariable solverVariable = a(SolverVariable.Type.h, paramString);
    int i = this.a + 1;
    this.a = i;
    this.h++;
    solverVariable.b = i;
    solverVariable.d = paramInt;
    ((SolverVariable[])this.k.j)[i] = solverVariable;
    this.b.a(solverVariable);
    return solverVariable;
  }
  
  public SolverVariable l(Object paramObject) {
    SolverVariable solverVariable = null;
    if (paramObject == null)
      return null; 
    if (this.h + 1 >= this.d)
      p(); 
    if (paramObject instanceof ConstraintAnchor) {
      ConstraintAnchor constraintAnchor = (ConstraintAnchor)paramObject;
      solverVariable = constraintAnchor.g;
      paramObject = solverVariable;
      if (solverVariable == null) {
        constraintAnchor.f();
        paramObject = constraintAnchor.g;
      } 
      i = ((SolverVariable)paramObject).b;
      if (i != -1 && i <= this.a) {
        Object object = paramObject;
        if (((SolverVariable[])this.k.j)[i] == null) {
          if (i != -1)
            paramObject.c(); 
          i = this.a + 1;
          this.a = i;
          this.h++;
          ((SolverVariable)paramObject).b = i;
          ((SolverVariable)paramObject).i = SolverVariable.Type.f;
          ((SolverVariable[])this.k.j)[i] = (SolverVariable)paramObject;
          return (SolverVariable)paramObject;
        } 
        return (SolverVariable)object;
      } 
    } else {
      return solverVariable;
    } 
    if (i != -1)
      paramObject.c(); 
    int i = this.a + 1;
    this.a = i;
    this.h++;
    ((SolverVariable)paramObject).b = i;
    ((SolverVariable)paramObject).i = SolverVariable.Type.f;
    ((SolverVariable[])this.k.j)[i] = (SolverVariable)paramObject;
    return (SolverVariable)paramObject;
  }
  
  public b m() {
    b b1;
    if (p) {
      b1 = (b)((u.a)this.k.g).a();
      if (b1 == null) {
        b1 = new b(this, this.k);
        r++;
      } else {
        b1.a = null;
        b1.d.clear();
        b1.b = 0.0F;
        b1.e = false;
      } 
    } else {
      b1 = (b)((u.a)this.k.h).a();
      if (b1 == null) {
        b1 = new b(this.k);
        q++;
      } else {
        b1.a = null;
        b1.d.clear();
        b1.b = 0.0F;
        b1.e = false;
      } 
    } 
    SolverVariable.m++;
    return b1;
  }
  
  public SolverVariable n() {
    if (this.h + 1 >= this.d)
      p(); 
    SolverVariable solverVariable = a(SolverVariable.Type.g, null);
    int i = this.a + 1;
    this.a = i;
    this.h++;
    solverVariable.b = i;
    ((SolverVariable[])this.k.j)[i] = solverVariable;
    return solverVariable;
  }
  
  public int o(Object paramObject) {
    paramObject = ((ConstraintAnchor)paramObject).g;
    return (paramObject != null) ? (int)(((SolverVariable)paramObject).e + 0.5F) : 0;
  }
  
  public final void p() {
    int i = this.c * 2;
    this.c = i;
    this.e = Arrays.<b>copyOf(this.e, i);
    mt mt1 = this.k;
    mt1.j = Arrays.<SolverVariable>copyOf((SolverVariable[])mt1.j, this.c);
    i = this.c;
    this.g = new boolean[i];
    this.d = i;
    this.j = i;
  }
  
  public void q(a parama) {
    SolverVariable.Type type = SolverVariable.Type.f;
    int i = 0;
    while (true) {
      if (i < this.i) {
        b[] arrayOfB = this.e;
        if ((arrayOfB[i]).a.i != type && (arrayOfB[i]).b < 0.0F) {
          i = 1;
          break;
        } 
        i++;
        continue;
      } 
      i = 0;
      break;
    } 
    if (i != 0) {
      boolean bool = false;
      for (i = 0; !bool; i = n) {
        int n = i + 1;
        float f = Float.MAX_VALUE;
        int m = 0;
        i = -1;
        int j = -1;
        int k;
        for (k = 0; m < this.i; k = i3) {
          float f1;
          int i1;
          int i2;
          int i3;
          b b1 = this.e[m];
          if (b1.a.i == type) {
            f1 = f;
            i1 = i;
            i2 = j;
            i3 = k;
          } else if (b1.e) {
            f1 = f;
            i1 = i;
            i2 = j;
            i3 = k;
          } else {
            f1 = f;
            i1 = i;
            i2 = j;
            i3 = k;
            if (b1.b < 0.0F) {
              Object object;
              int i4 = 1;
              while (true) {
                f1 = f;
                i1 = i;
                i2 = j;
                Object object1 = object;
                if (i4 < this.h) {
                  int i5;
                  SolverVariable solverVariable = ((SolverVariable[])this.k.j)[i4];
                  float f2 = b1.d.c(solverVariable);
                  if (f2 <= 0.0F) {
                    f1 = f;
                    i2 = i;
                    int i6 = j;
                    Object object2 = object;
                    continue;
                  } 
                  i2 = 0;
                  i1 = i;
                  i = i2;
                  while (true) {
                    f1 = f;
                    i2 = i1;
                    i3 = j;
                    int i6 = i5;
                    i++;
                    i5 = i2;
                  } 
                  continue;
                } 
                break;
                i4++;
                f = f1;
                i = i2;
                j = i3;
                object = SYNTHETIC_LOCAL_VARIABLE_14;
              } 
            } 
          } 
          m++;
          f = f1;
          i = i1;
          j = i2;
        } 
        if (i != -1) {
          b b1 = this.e[i];
          b1.a.c = -1;
          b1.j(((SolverVariable[])this.k.j)[j]);
          SolverVariable solverVariable = b1.a;
          solverVariable.c = i;
          solverVariable.e(b1);
        } else {
          bool = true;
        } 
        if (n > this.h / 2)
          bool = true; 
      } 
    } 
    r(parama);
    j();
  }
  
  public final int r(a parama) {
    int i;
    for (i = 0; i < this.h; i++)
      this.g[i] = false; 
    boolean bool = false;
    for (i = 0; !bool; i = j) {
      int j = i + 1;
      if (j >= this.h * 2)
        return j; 
      SolverVariable solverVariable = ((b)parama).a;
      if (solverVariable != null)
        this.g[solverVariable.b] = true; 
      solverVariable = parama.b(this, this.g);
      if (solverVariable != null) {
        boolean[] arrayOfBoolean = this.g;
        i = solverVariable.b;
        if (arrayOfBoolean[i])
          return j; 
        arrayOfBoolean[i] = true;
      } 
      if (solverVariable != null) {
        float f = Float.MAX_VALUE;
        i = 0;
        int k;
        for (k = -1; i < this.i; k = m) {
          float f1;
          int m;
          b b1 = this.e[i];
          if (b1.a.i == SolverVariable.Type.f) {
            f1 = f;
            m = k;
          } else if (b1.e) {
            f1 = f;
            m = k;
          } else {
            f1 = f;
            m = k;
            if (b1.d.d(solverVariable)) {
              float f2 = b1.d.c(solverVariable);
              f1 = f;
              m = k;
              if (f2 < 0.0F) {
                f2 = -b1.b / f2;
                f1 = f;
                m = k;
                if (f2 < f) {
                  m = i;
                  f1 = f2;
                } 
              } 
            } 
          } 
          i++;
          f = f1;
        } 
        i = j;
        if (k > -1) {
          b b1 = this.e[k];
          b1.a.c = -1;
          b1.j(solverVariable);
          solverVariable = b1.a;
          solverVariable.c = k;
          solverVariable.e(b1);
          i = j;
        } 
        continue;
      } 
      bool = true;
    } 
    return i;
  }
  
  public final void s() {
    boolean bool = p;
    int i = 0;
    byte b1 = 0;
    if (bool) {
      i = b1;
      while (true) {
        b[] arrayOfB = this.e;
        if (i < arrayOfB.length) {
          b b2 = arrayOfB[i];
          if (b2 != null)
            ((u.a)this.k.g).c(b2); 
          this.e[i] = null;
          i++;
          continue;
        } 
        break;
      } 
    } else {
      while (true) {
        b[] arrayOfB = this.e;
        if (i < arrayOfB.length) {
          b b2 = arrayOfB[i];
          if (b2 != null)
            ((u.a)this.k.h).c(b2); 
          this.e[i] = null;
          i++;
          continue;
        } 
        break;
      } 
    } 
  }
  
  public void t() {
    int i = 0;
    while (true) {
      SolverVariable solverVariable;
      mt mt1 = this.k;
      Object object = mt1.j;
      if (i < ((SolverVariable[])object).length) {
        solverVariable = ((SolverVariable[])object)[i];
        if (solverVariable != null)
          solverVariable.c(); 
        i++;
        continue;
      } 
      u.a a1 = (u.a)((mt)solverVariable).i;
      object = this.l;
      int j = this.m;
      Objects.requireNonNull(a1);
      i = j;
      if (j > object.length)
        i = object.length; 
      for (j = 0; j < i; j++) {
        Object object1 = object[j];
        int k = a1.c;
        Object[] arrayOfObject = a1.b;
        if (k < arrayOfObject.length) {
          arrayOfObject[k] = object1;
          a1.c = k + 1;
        } 
      } 
      this.m = 0;
      Arrays.fill((Object[])this.k.j, (Object)null);
      this.a = 0;
      this.b.clear();
      this.h = 1;
      for (i = 0; i < this.i; i++)
        Objects.requireNonNull(this.e[i]); 
      s();
      this.i = 0;
      if (p) {
        this.n = new b(this, this.k);
        return;
      } 
      this.n = new b(this.k);
      return;
    } 
  }
  
  public static interface a {
    void a(SolverVariable param1SolverVariable);
    
    SolverVariable b(c param1c, boolean[] param1ArrayOfboolean);
    
    void clear();
  }
  
  public class b extends b {
    public b(c this$0, mt param1mt) {
      this.d = new e(this, param1mt);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */