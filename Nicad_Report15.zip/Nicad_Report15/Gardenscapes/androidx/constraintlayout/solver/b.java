package androidx.constraintlayout.solver;

import h5.mt;
import java.util.ArrayList;

public class b implements c.a {
  public SolverVariable a = null;
  
  public float b = 0.0F;
  
  public ArrayList<SolverVariable> c = new ArrayList<SolverVariable>();
  
  public a d;
  
  public boolean e = false;
  
  public b() {}
  
  public b(mt parammt) {
    this.d = new a(this, parammt);
  }
  
  public void a(SolverVariable paramSolverVariable) {
    // Byte code:
    //   0: aload_1
    //   1: getfield d : I
    //   4: istore_3
    //   5: iload_3
    //   6: iconst_1
    //   7: if_icmpne -> 13
    //   10: goto -> 57
    //   13: iload_3
    //   14: iconst_2
    //   15: if_icmpne -> 24
    //   18: ldc 1000.0
    //   20: fstore_2
    //   21: goto -> 59
    //   24: iload_3
    //   25: iconst_3
    //   26: if_icmpne -> 35
    //   29: ldc 1000000.0
    //   31: fstore_2
    //   32: goto -> 59
    //   35: iload_3
    //   36: iconst_4
    //   37: if_icmpne -> 46
    //   40: ldc 1.0E9
    //   42: fstore_2
    //   43: goto -> 59
    //   46: iload_3
    //   47: iconst_5
    //   48: if_icmpne -> 57
    //   51: ldc 1.0E12
    //   53: fstore_2
    //   54: goto -> 59
    //   57: fconst_1
    //   58: fstore_2
    //   59: aload_0
    //   60: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   63: aload_1
    //   64: fload_2
    //   65: invokeinterface g : (Landroidx/constraintlayout/solver/SolverVariable;F)V
    //   70: return
  }
  
  public SolverVariable b(c paramc, boolean[] paramArrayOfboolean) {
    return i(paramArrayOfboolean, null);
  }
  
  public b c(c paramc, int paramInt) {
    this.d.g(paramc.k(paramInt, "ep"), 1.0F);
    this.d.g(paramc.k(paramInt, "em"), -1.0F);
    return this;
  }
  
  public void clear() {
    this.d.clear();
    this.a = null;
    this.b = 0.0F;
  }
  
  public b d(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.d.g(paramSolverVariable1, -1.0F);
    this.d.g(paramSolverVariable2, 1.0F);
    this.d.g(paramSolverVariable3, paramFloat);
    this.d.g(paramSolverVariable4, -paramFloat);
    return this;
  }
  
  public b e(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.b = j;
    } 
    if (i == 0) {
      this.d.g(paramSolverVariable1, -1.0F);
      this.d.g(paramSolverVariable2, 1.0F);
      this.d.g(paramSolverVariable3, 1.0F);
      return this;
    } 
    this.d.g(paramSolverVariable1, 1.0F);
    this.d.g(paramSolverVariable2, -1.0F);
    this.d.g(paramSolverVariable3, -1.0F);
    return this;
  }
  
  public b f(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.b = j;
    } 
    if (i == 0) {
      this.d.g(paramSolverVariable1, -1.0F);
      this.d.g(paramSolverVariable2, 1.0F);
      this.d.g(paramSolverVariable3, -1.0F);
      return this;
    } 
    this.d.g(paramSolverVariable1, 1.0F);
    this.d.g(paramSolverVariable2, -1.0F);
    this.d.g(paramSolverVariable3, 1.0F);
    return this;
  }
  
  public b g(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.d.g(paramSolverVariable3, 0.5F);
    this.d.g(paramSolverVariable4, 0.5F);
    this.d.g(paramSolverVariable1, -0.5F);
    this.d.g(paramSolverVariable2, -0.5F);
    this.b = -paramFloat;
    return this;
  }
  
  public final boolean h(SolverVariable paramSolverVariable) {
    return (paramSolverVariable.l <= 1);
  }
  
  public final SolverVariable i(boolean[] paramArrayOfboolean, SolverVariable paramSolverVariable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   4: invokeinterface e : ()I
    //   9: istore #7
    //   11: aconst_null
    //   12: astore #8
    //   14: iconst_0
    //   15: istore #6
    //   17: fconst_0
    //   18: fstore_3
    //   19: iload #6
    //   21: iload #7
    //   23: if_icmpge -> 168
    //   26: aload_0
    //   27: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   30: iload #6
    //   32: invokeinterface a : (I)F
    //   37: fstore #5
    //   39: aload #8
    //   41: astore #9
    //   43: fload_3
    //   44: fstore #4
    //   46: fload #5
    //   48: fconst_0
    //   49: fcmpg
    //   50: ifge -> 152
    //   53: aload_0
    //   54: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   57: iload #6
    //   59: invokeinterface i : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   64: astore #10
    //   66: aload_1
    //   67: ifnull -> 87
    //   70: aload #8
    //   72: astore #9
    //   74: fload_3
    //   75: fstore #4
    //   77: aload_1
    //   78: aload #10
    //   80: getfield b : I
    //   83: baload
    //   84: ifne -> 152
    //   87: aload #8
    //   89: astore #9
    //   91: fload_3
    //   92: fstore #4
    //   94: aload #10
    //   96: aload_2
    //   97: if_acmpeq -> 152
    //   100: aload #10
    //   102: getfield i : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   105: astore #11
    //   107: aload #11
    //   109: getstatic androidx/constraintlayout/solver/SolverVariable$Type.g : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   112: if_acmpeq -> 130
    //   115: aload #8
    //   117: astore #9
    //   119: fload_3
    //   120: fstore #4
    //   122: aload #11
    //   124: getstatic androidx/constraintlayout/solver/SolverVariable$Type.h : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   127: if_acmpne -> 152
    //   130: aload #8
    //   132: astore #9
    //   134: fload_3
    //   135: fstore #4
    //   137: fload #5
    //   139: fload_3
    //   140: fcmpg
    //   141: ifge -> 152
    //   144: fload #5
    //   146: fstore #4
    //   148: aload #10
    //   150: astore #9
    //   152: iload #6
    //   154: iconst_1
    //   155: iadd
    //   156: istore #6
    //   158: aload #9
    //   160: astore #8
    //   162: fload #4
    //   164: fstore_3
    //   165: goto -> 19
    //   168: aload #8
    //   170: areturn
  }
  
  public void j(SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.a;
    if (solverVariable != null) {
      this.d.g(solverVariable, -1.0F);
      this.a = null;
    } 
    float f = this.d.h(paramSolverVariable, true) * -1.0F;
    this.a = paramSolverVariable;
    if (f == 1.0F)
      return; 
    this.b /= f;
    this.d.j(f);
  }
  
  public void k(SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (!paramSolverVariable.f)
      return; 
    float f1 = this.d.c(paramSolverVariable);
    float f2 = this.b;
    this.b = paramSolverVariable.e * f1 + f2;
    this.d.h(paramSolverVariable, paramBoolean);
    if (paramBoolean)
      paramSolverVariable.b(this); 
  }
  
  public void l(b paramb, boolean paramBoolean) {
    float f1 = this.d.f(paramb, paramBoolean);
    float f2 = this.b;
    this.b = paramb.b * f1 + f2;
    if (paramBoolean)
      paramb.a.b(this); 
  }
  
  public String toString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   4: ifnonnull -> 14
    //   7: ldc '0'
    //   9: astore #6
    //   11: goto -> 38
    //   14: ldc ''
    //   16: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: astore #6
    //   21: aload #6
    //   23: aload_0
    //   24: getfield a : Landroidx/constraintlayout/solver/SolverVariable;
    //   27: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   30: pop
    //   31: aload #6
    //   33: invokevirtual toString : ()Ljava/lang/String;
    //   36: astore #6
    //   38: aload #6
    //   40: ldc ' = '
    //   42: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   45: astore #6
    //   47: aload_0
    //   48: getfield b : F
    //   51: fstore_1
    //   52: iconst_0
    //   53: istore #4
    //   55: fload_1
    //   56: fconst_0
    //   57: fcmpl
    //   58: ifeq -> 90
    //   61: aload #6
    //   63: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: astore #6
    //   68: aload #6
    //   70: aload_0
    //   71: getfield b : F
    //   74: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #6
    //   80: invokevirtual toString : ()Ljava/lang/String;
    //   83: astore #6
    //   85: iconst_1
    //   86: istore_3
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_3
    //   92: aload_0
    //   93: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   96: invokeinterface e : ()I
    //   101: istore #5
    //   103: iload #4
    //   105: iload #5
    //   107: if_icmpge -> 297
    //   110: aload_0
    //   111: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   114: iload #4
    //   116: invokeinterface i : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   121: astore #7
    //   123: aload #7
    //   125: ifnonnull -> 131
    //   128: goto -> 288
    //   131: aload_0
    //   132: getfield d : Landroidx/constraintlayout/solver/b$a;
    //   135: iload #4
    //   137: invokeinterface a : (I)F
    //   142: fstore_2
    //   143: fload_2
    //   144: fconst_0
    //   145: fcmpl
    //   146: ifne -> 152
    //   149: goto -> 288
    //   152: aload #7
    //   154: invokevirtual toString : ()Ljava/lang/String;
    //   157: astore #8
    //   159: iload_3
    //   160: ifne -> 187
    //   163: aload #6
    //   165: astore #7
    //   167: fload_2
    //   168: fstore_1
    //   169: fload_2
    //   170: fconst_0
    //   171: fcmpg
    //   172: ifge -> 221
    //   175: aload #6
    //   177: ldc '- '
    //   179: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   182: astore #7
    //   184: goto -> 216
    //   187: fload_2
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 207
    //   193: aload #6
    //   195: ldc ' + '
    //   197: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   200: astore #7
    //   202: fload_2
    //   203: fstore_1
    //   204: goto -> 221
    //   207: aload #6
    //   209: ldc ' - '
    //   211: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   214: astore #7
    //   216: fload_2
    //   217: ldc -1.0
    //   219: fmul
    //   220: fstore_1
    //   221: fload_1
    //   222: fconst_1
    //   223: fcmpl
    //   224: ifne -> 239
    //   227: aload #7
    //   229: aload #8
    //   231: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   234: astore #6
    //   236: goto -> 286
    //   239: new java/lang/StringBuilder
    //   242: dup
    //   243: invokespecial <init> : ()V
    //   246: astore #6
    //   248: aload #6
    //   250: aload #7
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: pop
    //   256: aload #6
    //   258: fload_1
    //   259: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   262: pop
    //   263: aload #6
    //   265: ldc ' '
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: pop
    //   271: aload #6
    //   273: aload #8
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: aload #6
    //   281: invokevirtual toString : ()Ljava/lang/String;
    //   284: astore #6
    //   286: iconst_1
    //   287: istore_3
    //   288: iload #4
    //   290: iconst_1
    //   291: iadd
    //   292: istore #4
    //   294: goto -> 103
    //   297: aload #6
    //   299: astore #7
    //   301: iload_3
    //   302: ifne -> 314
    //   305: aload #6
    //   307: ldc '0.0'
    //   309: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   312: astore #7
    //   314: aload #7
    //   316: areturn
  }
  
  public static interface a {
    float a(int param1Int);
    
    void b(SolverVariable param1SolverVariable, float param1Float, boolean param1Boolean);
    
    float c(SolverVariable param1SolverVariable);
    
    void clear();
    
    boolean d(SolverVariable param1SolverVariable);
    
    int e();
    
    float f(b param1b, boolean param1Boolean);
    
    void g(SolverVariable param1SolverVariable, float param1Float);
    
    float h(SolverVariable param1SolverVariable, boolean param1Boolean);
    
    SolverVariable i(int param1Int);
    
    void j(float param1Float);
    
    void k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */