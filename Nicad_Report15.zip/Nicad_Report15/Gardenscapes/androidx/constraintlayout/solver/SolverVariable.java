package androidx.constraintlayout.solver;

import android.support.v4.media.a;
import java.util.Arrays;

public class SolverVariable {
  public static int m = 1;
  
  public boolean a;
  
  public int b = -1;
  
  public int c = -1;
  
  public int d = 0;
  
  public float e;
  
  public boolean f = false;
  
  public float[] g = new float[9];
  
  public float[] h = new float[9];
  
  public Type i;
  
  public b[] j = new b[16];
  
  public int k = 0;
  
  public int l = 0;
  
  public SolverVariable(Type paramType) {
    this.i = paramType;
  }
  
  public final void a(b paramb) {
    int i = 0;
    while (true) {
      int j = this.k;
      if (i < j) {
        if (this.j[i] == paramb)
          return; 
        i++;
        continue;
      } 
      b[] arrayOfB = this.j;
      if (j >= arrayOfB.length)
        this.j = Arrays.<b>copyOf(arrayOfB, arrayOfB.length * 2); 
      arrayOfB = this.j;
      i = this.k;
      arrayOfB[i] = paramb;
      this.k = i + 1;
      return;
    } 
  }
  
  public final void b(b paramb) {
    int j = this.k;
    for (int i = 0; i < j; i++) {
      if (this.j[i] == paramb) {
        while (i < j - 1) {
          b[] arrayOfB = this.j;
          int k = i + 1;
          arrayOfB[i] = arrayOfB[k];
          i = k;
        } 
        this.k--;
        return;
      } 
    } 
  }
  
  public void c() {
    this.i = Type.i;
    this.d = 0;
    this.b = -1;
    this.c = -1;
    this.e = 0.0F;
    this.f = false;
    int j = this.k;
    for (int i = 0; i < j; i++)
      this.j[i] = null; 
    this.k = 0;
    this.l = 0;
    this.a = false;
    Arrays.fill(this.h, 0.0F);
  }
  
  public void d(c paramc, float paramFloat) {
    this.e = paramFloat;
    this.f = true;
    int j = this.k;
    for (int i = 0; i < j; i++)
      this.j[i].k(this, false); 
    this.k = 0;
  }
  
  public final void e(b paramb) {
    int j = this.k;
    for (int i = 0; i < j; i++)
      this.j[i].l(paramb, false); 
    this.k = 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = a.a("");
    stringBuilder.append(this.b);
    return stringBuilder.toString();
  }
  
  public enum Type {
    f, g, h, i;
    
    static {
      Type type1 = new Type("UNRESTRICTED", 0);
      f = type1;
      Type type2 = new Type("CONSTANT", 1);
      Type type3 = new Type("SLACK", 2);
      g = type3;
      Type type4 = new Type("ERROR", 3);
      h = type4;
      Type type5 = new Type("UNKNOWN", 4);
      i = type5;
      j = new Type[] { type1, type2, type3, type4, type5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\SolverVariable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */