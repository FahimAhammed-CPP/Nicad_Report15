package androidx.constraintlayout.solver;

import h5.mt;
import java.util.Arrays;
import java.util.Comparator;

public class d extends b {
  public SolverVariable[] f = new SolverVariable[128];
  
  public SolverVariable[] g = new SolverVariable[128];
  
  public int h = 0;
  
  public b i = new b(this, this);
  
  public d(mt parammt) {
    super(parammt);
  }
  
  public void a(SolverVariable paramSolverVariable) {
    this.i.f = paramSolverVariable;
    Arrays.fill(paramSolverVariable.h, 0.0F);
    paramSolverVariable.h[paramSolverVariable.d] = 1.0F;
    m(paramSolverVariable);
  }
  
  public SolverVariable b(c paramc, boolean[] paramArrayOfboolean) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_m1
    //   4: istore #6
    //   6: iload #5
    //   8: aload_0
    //   9: getfield h : I
    //   12: if_icmpge -> 210
    //   15: aload_0
    //   16: getfield f : [Landroidx/constraintlayout/solver/SolverVariable;
    //   19: astore #10
    //   21: aload #10
    //   23: iload #5
    //   25: aaload
    //   26: astore #11
    //   28: aload_2
    //   29: aload #11
    //   31: getfield b : I
    //   34: baload
    //   35: ifeq -> 41
    //   38: goto -> 201
    //   41: aload_0
    //   42: getfield i : Landroidx/constraintlayout/solver/d$b;
    //   45: astore_1
    //   46: aload_1
    //   47: aload #11
    //   49: putfield f : Landroidx/constraintlayout/solver/SolverVariable;
    //   52: bipush #8
    //   54: istore #7
    //   56: iconst_1
    //   57: istore #9
    //   59: iconst_1
    //   60: istore #8
    //   62: iload #6
    //   64: iconst_m1
    //   65: if_icmpne -> 126
    //   68: iload #7
    //   70: iflt -> 115
    //   73: aload_1
    //   74: getfield f : Landroidx/constraintlayout/solver/SolverVariable;
    //   77: getfield h : [F
    //   80: iload #7
    //   82: faload
    //   83: fstore_3
    //   84: fload_3
    //   85: fconst_0
    //   86: fcmpl
    //   87: ifle -> 93
    //   90: goto -> 115
    //   93: fload_3
    //   94: fconst_0
    //   95: fcmpg
    //   96: ifge -> 106
    //   99: iload #8
    //   101: istore #7
    //   103: goto -> 118
    //   106: iload #7
    //   108: iconst_1
    //   109: isub
    //   110: istore #7
    //   112: goto -> 68
    //   115: iconst_0
    //   116: istore #7
    //   118: iload #7
    //   120: ifeq -> 201
    //   123: goto -> 197
    //   126: aload #10
    //   128: iload #6
    //   130: aaload
    //   131: astore #10
    //   133: iload #7
    //   135: iflt -> 189
    //   138: aload #10
    //   140: getfield h : [F
    //   143: iload #7
    //   145: faload
    //   146: fstore_3
    //   147: aload_1
    //   148: getfield f : Landroidx/constraintlayout/solver/SolverVariable;
    //   151: getfield h : [F
    //   154: iload #7
    //   156: faload
    //   157: fstore #4
    //   159: fload #4
    //   161: fload_3
    //   162: fcmpl
    //   163: ifne -> 175
    //   166: iload #7
    //   168: iconst_1
    //   169: isub
    //   170: istore #7
    //   172: goto -> 133
    //   175: fload #4
    //   177: fload_3
    //   178: fcmpg
    //   179: ifge -> 189
    //   182: iload #9
    //   184: istore #7
    //   186: goto -> 192
    //   189: iconst_0
    //   190: istore #7
    //   192: iload #7
    //   194: ifeq -> 201
    //   197: iload #5
    //   199: istore #6
    //   201: iload #5
    //   203: iconst_1
    //   204: iadd
    //   205: istore #5
    //   207: goto -> 6
    //   210: iload #6
    //   212: iconst_m1
    //   213: if_icmpne -> 218
    //   216: aconst_null
    //   217: areturn
    //   218: aload_0
    //   219: getfield f : [Landroidx/constraintlayout/solver/SolverVariable;
    //   222: iload #6
    //   224: aaload
    //   225: areturn
  }
  
  public void clear() {
    this.h = 0;
    this.b = 0.0F;
  }
  
  public void l(b paramb, boolean paramBoolean) {
    SolverVariable solverVariable = paramb.a;
    if (solverVariable == null)
      return; 
    b.a a = paramb.d;
    int j = a.e();
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable1 = a.i(i);
      float f2 = a.a(i);
      b b1 = this.i;
      b1.f = solverVariable1;
      paramBoolean = solverVariable1.a;
      boolean bool2 = true;
      boolean bool1 = true;
      if (paramBoolean) {
        int k;
        for (k = 0; k < 9; k++) {
          float[] arrayOfFloat = b1.f.h;
          float f = arrayOfFloat[k];
          arrayOfFloat[k] = solverVariable.h[k] * f2 + f;
          if (Math.abs(arrayOfFloat[k]) < 1.0E-4F) {
            b1.f.h[k] = 0.0F;
          } else {
            bool1 = false;
          } 
        } 
        if (bool1)
          b1.g.n(b1.f); 
        bool1 = false;
      } else {
        int k = 0;
        while (true) {
          bool1 = bool2;
          if (k < 9) {
            float f = solverVariable.h[k];
            if (f != 0.0F) {
              float f3 = f * f2;
              f = f3;
              if (Math.abs(f3) < 1.0E-4F)
                f = 0.0F; 
              b1.f.h[k] = f;
            } else {
              b1.f.h[k] = 0.0F;
            } 
            k++;
            continue;
          } 
          break;
        } 
      } 
      if (bool1)
        m(solverVariable1); 
      float f1 = this.b;
      this.b = paramb.b * f2 + f1;
    } 
    n(solverVariable);
  }
  
  public final void m(SolverVariable paramSolverVariable) {
    int i = this.h;
    SolverVariable[] arrayOfSolverVariable = this.f;
    if (i + 1 > arrayOfSolverVariable.length) {
      arrayOfSolverVariable = Arrays.<SolverVariable>copyOf(arrayOfSolverVariable, arrayOfSolverVariable.length * 2);
      this.f = arrayOfSolverVariable;
      this.g = Arrays.<SolverVariable>copyOf(arrayOfSolverVariable, arrayOfSolverVariable.length * 2);
    } 
    arrayOfSolverVariable = this.f;
    i = this.h;
    arrayOfSolverVariable[i] = paramSolverVariable;
    this.h = ++i;
    if (i > 1 && (arrayOfSolverVariable[i - 1]).b > paramSolverVariable.b) {
      boolean bool = false;
      i = 0;
      while (true) {
        int j = this.h;
        if (i < j) {
          this.g[i] = this.f[i];
          i++;
          continue;
        } 
        Arrays.sort(this.g, 0, j, new a(this));
        for (i = bool; i < this.h; i++)
          this.f[i] = this.g[i]; 
        break;
      } 
    } 
    paramSolverVariable.a = true;
    paramSolverVariable.a(this);
  }
  
  public final void n(SolverVariable paramSolverVariable) {
    for (int i = 0; i < this.h; i++) {
      if (this.f[i] == paramSolverVariable)
        while (true) {
          int j = this.h;
          if (i < j - 1) {
            SolverVariable[] arrayOfSolverVariable = this.f;
            j = i + 1;
            arrayOfSolverVariable[i] = arrayOfSolverVariable[j];
            i = j;
            continue;
          } 
          this.h = j - 1;
          paramSolverVariable.a = false;
          return;
        }  
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = u.b.a("", " goal -> (");
    stringBuilder.append(this.b);
    stringBuilder.append(") : ");
    String str = stringBuilder.toString();
    for (int i = 0; i < this.h; i++) {
      SolverVariable solverVariable = this.f[i];
      this.i.f = solverVariable;
      StringBuilder stringBuilder1 = android.support.v4.media.a.a(str);
      stringBuilder1.append(this.i);
      stringBuilder1.append(" ");
      str = stringBuilder1.toString();
    } 
    return str;
  }
  
  public class a implements Comparator<SolverVariable> {
    public a(d this$0) {}
    
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      return ((SolverVariable)param1Object1).b - ((SolverVariable)param1Object2).b;
    }
  }
  
  public class b implements Comparable {
    public SolverVariable f;
    
    public b(d this$0, d param1d1) {}
    
    public int compareTo(Object param1Object) {
      param1Object = param1Object;
      return this.f.b - ((SolverVariable)param1Object).b;
    }
    
    public String toString() {
      SolverVariable solverVariable = this.f;
      String str1 = "[ ";
      String str2 = str1;
      if (solverVariable != null) {
        int i = 0;
        while (true) {
          str2 = str1;
          if (i < 9) {
            StringBuilder stringBuilder1 = android.support.v4.media.a.a(str1);
            stringBuilder1.append(this.f.h[i]);
            stringBuilder1.append(" ");
            String str = stringBuilder1.toString();
            i++;
            continue;
          } 
          break;
        } 
      } 
      StringBuilder stringBuilder = u.b.a(str2, "] ");
      stringBuilder.append(this.f);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */