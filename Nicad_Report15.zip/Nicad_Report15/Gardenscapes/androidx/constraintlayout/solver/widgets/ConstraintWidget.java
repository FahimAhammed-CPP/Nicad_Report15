package androidx.constraintlayout.solver.widgets;

import android.support.v4.media.a;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.c;
import androidx.constraintlayout.solver.widgets.analyzer.c;
import androidx.constraintlayout.solver.widgets.analyzer.d;
import h5.mt;
import java.util.ArrayList;
import v.a;
import w.c;

public class ConstraintWidget {
  public ConstraintAnchor A;
  
  public ConstraintAnchor B;
  
  public ConstraintAnchor C;
  
  public ConstraintAnchor D;
  
  public ConstraintAnchor E;
  
  public ConstraintAnchor F;
  
  public ConstraintAnchor[] G;
  
  public ArrayList<ConstraintAnchor> H;
  
  public boolean[] I;
  
  public DimensionBehaviour[] J;
  
  public ConstraintWidget K;
  
  public int L;
  
  public int M;
  
  public float N;
  
  public int O;
  
  public int P;
  
  public int Q;
  
  public int R;
  
  public int S;
  
  public int T;
  
  public float U;
  
  public float V;
  
  public Object W;
  
  public int X;
  
  public String Y;
  
  public int Z;
  
  public boolean a = false;
  
  public int a0;
  
  public c b;
  
  public float[] b0;
  
  public c c;
  
  public ConstraintWidget[] c0;
  
  public c d = new c(this);
  
  public ConstraintWidget[] d0;
  
  public d e = new d(this);
  
  public boolean[] f = new boolean[] { true, true };
  
  public int[] g = new int[] { 0, 0, 0, 0 };
  
  public int h = -1;
  
  public int i = -1;
  
  public int j = 0;
  
  public int k = 0;
  
  public int[] l = new int[2];
  
  public int m = 0;
  
  public int n = 0;
  
  public float o = 1.0F;
  
  public int p = 0;
  
  public int q = 0;
  
  public float r = 1.0F;
  
  public int s = -1;
  
  public float t = 1.0F;
  
  public int[] u = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  public float v = 0.0F;
  
  public boolean w = false;
  
  public boolean x;
  
  public ConstraintAnchor y;
  
  public ConstraintAnchor z;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor1 = new ConstraintAnchor(this, ConstraintAnchor.Type.f);
    this.y = constraintAnchor1;
    ConstraintAnchor constraintAnchor2 = new ConstraintAnchor(this, ConstraintAnchor.Type.g);
    this.z = constraintAnchor2;
    ConstraintAnchor constraintAnchor3 = new ConstraintAnchor(this, ConstraintAnchor.Type.h);
    this.A = constraintAnchor3;
    ConstraintAnchor constraintAnchor4 = new ConstraintAnchor(this, ConstraintAnchor.Type.i);
    this.B = constraintAnchor4;
    ConstraintAnchor constraintAnchor5 = new ConstraintAnchor(this, ConstraintAnchor.Type.j);
    this.C = constraintAnchor5;
    this.D = new ConstraintAnchor(this, ConstraintAnchor.Type.l);
    this.E = new ConstraintAnchor(this, ConstraintAnchor.Type.m);
    ConstraintAnchor constraintAnchor6 = new ConstraintAnchor(this, ConstraintAnchor.Type.k);
    this.F = constraintAnchor6;
    this.G = new ConstraintAnchor[] { constraintAnchor1, constraintAnchor3, constraintAnchor2, constraintAnchor4, constraintAnchor5, constraintAnchor6 };
    ArrayList<ConstraintAnchor> arrayList = new ArrayList();
    this.H = arrayList;
    this.I = new boolean[2];
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.f;
    this.J = new DimensionBehaviour[] { dimensionBehaviour, dimensionBehaviour };
    this.K = null;
    this.L = 0;
    this.M = 0;
    this.N = 0.0F;
    this.O = -1;
    this.P = 0;
    this.Q = 0;
    this.R = 0;
    this.U = 0.5F;
    this.V = 0.5F;
    this.X = 0;
    this.Y = null;
    this.Z = 0;
    this.a0 = 0;
    this.b0 = new float[] { -1.0F, -1.0F };
    this.c0 = new ConstraintWidget[] { null, null };
    this.d0 = new ConstraintWidget[] { null, null };
    arrayList.add(this.y);
    this.H.add(this.z);
    this.H.add(this.A);
    this.H.add(this.B);
    this.H.add(this.D);
    this.H.add(this.E);
    this.H.add(this.F);
    this.H.add(this.C);
  }
  
  public void A(DimensionBehaviour paramDimensionBehaviour) {
    this.J[1] = paramDimensionBehaviour;
  }
  
  public void B(int paramInt) {
    this.L = paramInt;
    int i = this.S;
    if (paramInt < i)
      this.L = i; 
  }
  
  public void C(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.f : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   3: astore #10
    //   5: aload_0
    //   6: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   9: astore #11
    //   11: iload_1
    //   12: aload #11
    //   14: getfield g : Z
    //   17: iand
    //   18: istore #9
    //   20: aload_0
    //   21: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   24: astore #12
    //   26: iload_2
    //   27: aload #12
    //   29: getfield g : Z
    //   32: iand
    //   33: istore #8
    //   35: aload #11
    //   37: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   40: getfield g : I
    //   43: istore_3
    //   44: aload #12
    //   46: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   49: getfield g : I
    //   52: istore #4
    //   54: aload #11
    //   56: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   59: getfield g : I
    //   62: istore #6
    //   64: aload #12
    //   66: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   69: getfield g : I
    //   72: istore #7
    //   74: iload #6
    //   76: iload_3
    //   77: isub
    //   78: iflt -> 147
    //   81: iload #7
    //   83: iload #4
    //   85: isub
    //   86: iflt -> 147
    //   89: iload_3
    //   90: ldc -2147483648
    //   92: if_icmpeq -> 147
    //   95: iload_3
    //   96: ldc 2147483647
    //   98: if_icmpeq -> 147
    //   101: iload #4
    //   103: ldc -2147483648
    //   105: if_icmpeq -> 147
    //   108: iload #4
    //   110: ldc 2147483647
    //   112: if_icmpeq -> 147
    //   115: iload #6
    //   117: ldc -2147483648
    //   119: if_icmpeq -> 147
    //   122: iload #6
    //   124: ldc 2147483647
    //   126: if_icmpeq -> 147
    //   129: iload #7
    //   131: ldc -2147483648
    //   133: if_icmpeq -> 147
    //   136: iload #7
    //   138: istore #5
    //   140: iload #7
    //   142: ldc 2147483647
    //   144: if_icmpne -> 158
    //   147: iconst_0
    //   148: istore #6
    //   150: iconst_0
    //   151: istore #5
    //   153: iconst_0
    //   154: istore_3
    //   155: iconst_0
    //   156: istore #4
    //   158: iload #6
    //   160: iload_3
    //   161: isub
    //   162: istore #6
    //   164: iload #5
    //   166: iload #4
    //   168: isub
    //   169: istore #5
    //   171: iload #9
    //   173: ifeq -> 181
    //   176: aload_0
    //   177: iload_3
    //   178: putfield P : I
    //   181: iload #8
    //   183: ifeq -> 192
    //   186: aload_0
    //   187: iload #4
    //   189: putfield Q : I
    //   192: aload_0
    //   193: getfield X : I
    //   196: bipush #8
    //   198: if_icmpne -> 212
    //   201: aload_0
    //   202: iconst_0
    //   203: putfield L : I
    //   206: aload_0
    //   207: iconst_0
    //   208: putfield M : I
    //   211: return
    //   212: iload #9
    //   214: ifeq -> 273
    //   217: iload #6
    //   219: istore_3
    //   220: aload_0
    //   221: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   224: iconst_0
    //   225: aaload
    //   226: aload #10
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield L : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield L : I
    //   255: aload_0
    //   256: getfield S : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield L : I
    //   273: iload #8
    //   275: ifeq -> 334
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: aload #10
    //   289: if_acmpne -> 311
    //   292: aload_0
    //   293: getfield M : I
    //   296: istore #4
    //   298: iload #5
    //   300: istore_3
    //   301: iload #5
    //   303: iload #4
    //   305: if_icmpge -> 311
    //   308: iload #4
    //   310: istore_3
    //   311: aload_0
    //   312: iload_3
    //   313: putfield M : I
    //   316: aload_0
    //   317: getfield T : I
    //   320: istore #4
    //   322: iload_3
    //   323: iload #4
    //   325: if_icmpge -> 334
    //   328: aload_0
    //   329: iload #4
    //   331: putfield M : I
    //   334: return
  }
  
  public void D(c paramc) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual o : (Ljava/lang/Object;)I
    //   8: istore_3
    //   9: aload_1
    //   10: aload_0
    //   11: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual o : (Ljava/lang/Object;)I
    //   17: istore #6
    //   19: aload_1
    //   20: aload_0
    //   21: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   24: invokevirtual o : (Ljava/lang/Object;)I
    //   27: istore #5
    //   29: aload_1
    //   30: aload_0
    //   31: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   34: invokevirtual o : (Ljava/lang/Object;)I
    //   37: istore #7
    //   39: aload_0
    //   40: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   43: astore #8
    //   45: aload #8
    //   47: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   50: astore_1
    //   51: iload_3
    //   52: istore #4
    //   54: iload #5
    //   56: istore_2
    //   57: aload_1
    //   58: getfield j : Z
    //   61: ifeq -> 97
    //   64: aload #8
    //   66: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   69: astore #8
    //   71: iload_3
    //   72: istore #4
    //   74: iload #5
    //   76: istore_2
    //   77: aload #8
    //   79: getfield j : Z
    //   82: ifeq -> 97
    //   85: aload_1
    //   86: getfield g : I
    //   89: istore #4
    //   91: aload #8
    //   93: getfield g : I
    //   96: istore_2
    //   97: aload_0
    //   98: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   101: astore #8
    //   103: aload #8
    //   105: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   108: astore_1
    //   109: iload #6
    //   111: istore #5
    //   113: iload #7
    //   115: istore_3
    //   116: aload_1
    //   117: getfield j : Z
    //   120: ifeq -> 157
    //   123: aload #8
    //   125: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   128: astore #8
    //   130: iload #6
    //   132: istore #5
    //   134: iload #7
    //   136: istore_3
    //   137: aload #8
    //   139: getfield j : Z
    //   142: ifeq -> 157
    //   145: aload_1
    //   146: getfield g : I
    //   149: istore #5
    //   151: aload #8
    //   153: getfield g : I
    //   156: istore_3
    //   157: iload_2
    //   158: iload #4
    //   160: isub
    //   161: iflt -> 228
    //   164: iload_3
    //   165: iload #5
    //   167: isub
    //   168: iflt -> 228
    //   171: iload #4
    //   173: ldc -2147483648
    //   175: if_icmpeq -> 228
    //   178: iload #4
    //   180: ldc 2147483647
    //   182: if_icmpeq -> 228
    //   185: iload #5
    //   187: ldc -2147483648
    //   189: if_icmpeq -> 228
    //   192: iload #5
    //   194: ldc 2147483647
    //   196: if_icmpeq -> 228
    //   199: iload_2
    //   200: ldc -2147483648
    //   202: if_icmpeq -> 228
    //   205: iload_2
    //   206: ldc 2147483647
    //   208: if_icmpeq -> 228
    //   211: iload_3
    //   212: ldc -2147483648
    //   214: if_icmpeq -> 228
    //   217: iload_2
    //   218: istore #6
    //   220: iload_3
    //   221: istore_2
    //   222: iload_3
    //   223: ldc 2147483647
    //   225: if_icmpne -> 239
    //   228: iconst_0
    //   229: istore_2
    //   230: iconst_0
    //   231: istore #4
    //   233: iconst_0
    //   234: istore #5
    //   236: iconst_0
    //   237: istore #6
    //   239: iload #6
    //   241: iload #4
    //   243: isub
    //   244: istore_3
    //   245: iload_2
    //   246: iload #5
    //   248: isub
    //   249: istore #6
    //   251: aload_0
    //   252: iload #4
    //   254: putfield P : I
    //   257: aload_0
    //   258: iload #5
    //   260: putfield Q : I
    //   263: aload_0
    //   264: getfield X : I
    //   267: bipush #8
    //   269: if_icmpne -> 283
    //   272: aload_0
    //   273: iconst_0
    //   274: putfield L : I
    //   277: aload_0
    //   278: iconst_0
    //   279: putfield M : I
    //   282: return
    //   283: aload_0
    //   284: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   287: astore_1
    //   288: aload_1
    //   289: iconst_0
    //   290: aaload
    //   291: astore #8
    //   293: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.f : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   296: astore #9
    //   298: iload_3
    //   299: istore_2
    //   300: aload #8
    //   302: aload #9
    //   304: if_acmpne -> 324
    //   307: aload_0
    //   308: getfield L : I
    //   311: istore #4
    //   313: iload_3
    //   314: istore_2
    //   315: iload_3
    //   316: iload #4
    //   318: if_icmpge -> 324
    //   321: iload #4
    //   323: istore_2
    //   324: iload #6
    //   326: istore_3
    //   327: aload_1
    //   328: iconst_1
    //   329: aaload
    //   330: aload #9
    //   332: if_acmpne -> 354
    //   335: aload_0
    //   336: getfield M : I
    //   339: istore #4
    //   341: iload #6
    //   343: istore_3
    //   344: iload #6
    //   346: iload #4
    //   348: if_icmpge -> 354
    //   351: iload #4
    //   353: istore_3
    //   354: aload_0
    //   355: iload_2
    //   356: putfield L : I
    //   359: aload_0
    //   360: iload_3
    //   361: putfield M : I
    //   364: aload_0
    //   365: getfield T : I
    //   368: istore #4
    //   370: iload_3
    //   371: iload #4
    //   373: if_icmpge -> 382
    //   376: aload_0
    //   377: iload #4
    //   379: putfield M : I
    //   382: aload_0
    //   383: getfield S : I
    //   386: istore_3
    //   387: iload_2
    //   388: iload_3
    //   389: if_icmpge -> 397
    //   392: aload_0
    //   393: iload_3
    //   394: putfield L : I
    //   397: return
  }
  
  public void b(c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: astore #34
    //   3: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.g : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   6: astore #37
    //   8: aload_1
    //   9: aload #34
    //   11: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   17: astore #36
    //   19: aload_1
    //   20: aload #34
    //   22: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   25: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   28: astore #28
    //   30: aload_1
    //   31: aload #34
    //   33: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   36: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   39: astore #35
    //   41: aload_1
    //   42: aload #34
    //   44: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   47: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   50: astore #32
    //   52: aload_1
    //   53: aload #34
    //   55: getfield C : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   58: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   61: astore #33
    //   63: aload #34
    //   65: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   68: astore #30
    //   70: aload #30
    //   72: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   75: astore #29
    //   77: aload #29
    //   79: getfield j : Z
    //   82: ifeq -> 355
    //   85: aload #30
    //   87: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   90: getfield j : Z
    //   93: ifeq -> 355
    //   96: aload #34
    //   98: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   101: astore #30
    //   103: aload #30
    //   105: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   108: getfield j : Z
    //   111: ifeq -> 355
    //   114: aload #30
    //   116: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   119: getfield j : Z
    //   122: ifeq -> 355
    //   125: aload_1
    //   126: aload #36
    //   128: aload #29
    //   130: getfield g : I
    //   133: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   136: aload_1
    //   137: aload #28
    //   139: aload #34
    //   141: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   144: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   147: getfield g : I
    //   150: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   153: aload_1
    //   154: aload #35
    //   156: aload #34
    //   158: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   161: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   164: getfield g : I
    //   167: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   170: aload_1
    //   171: aload #32
    //   173: aload #34
    //   175: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   178: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   181: getfield g : I
    //   184: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   187: aload_1
    //   188: aload #33
    //   190: aload #34
    //   192: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   195: getfield k : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   198: getfield g : I
    //   201: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   204: aload #34
    //   206: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   209: astore #29
    //   211: aload #29
    //   213: ifnull -> 354
    //   216: aload #29
    //   218: ifnull -> 239
    //   221: aload #29
    //   223: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   226: iconst_0
    //   227: aaload
    //   228: aload #37
    //   230: if_acmpne -> 239
    //   233: iconst_1
    //   234: istore #9
    //   236: goto -> 242
    //   239: iconst_0
    //   240: istore #9
    //   242: aload #29
    //   244: ifnull -> 265
    //   247: aload #29
    //   249: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   252: iconst_1
    //   253: aaload
    //   254: aload #37
    //   256: if_acmpne -> 265
    //   259: iconst_1
    //   260: istore #10
    //   262: goto -> 268
    //   265: iconst_0
    //   266: istore #10
    //   268: iload #9
    //   270: ifeq -> 311
    //   273: aload #34
    //   275: getfield f : [Z
    //   278: iconst_0
    //   279: baload
    //   280: ifeq -> 311
    //   283: aload_0
    //   284: invokevirtual s : ()Z
    //   287: ifne -> 311
    //   290: aload_1
    //   291: aload_1
    //   292: aload #34
    //   294: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   297: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   300: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   303: aload #28
    //   305: iconst_0
    //   306: bipush #8
    //   308: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   311: iload #10
    //   313: ifeq -> 354
    //   316: aload #34
    //   318: getfield f : [Z
    //   321: iconst_1
    //   322: baload
    //   323: ifeq -> 354
    //   326: aload_0
    //   327: invokevirtual t : ()Z
    //   330: ifne -> 354
    //   333: aload_1
    //   334: aload_1
    //   335: aload #34
    //   337: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   340: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   343: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   346: aload #32
    //   348: iconst_0
    //   349: bipush #8
    //   351: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   354: return
    //   355: aload #34
    //   357: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   360: astore #29
    //   362: aload #29
    //   364: ifnull -> 648
    //   367: aload #29
    //   369: ifnull -> 390
    //   372: aload #29
    //   374: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   377: iconst_0
    //   378: aaload
    //   379: aload #37
    //   381: if_acmpne -> 390
    //   384: iconst_1
    //   385: istore #19
    //   387: goto -> 393
    //   390: iconst_0
    //   391: istore #19
    //   393: aload #29
    //   395: ifnull -> 416
    //   398: aload #29
    //   400: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   403: iconst_1
    //   404: aaload
    //   405: aload #37
    //   407: if_acmpne -> 416
    //   410: iconst_1
    //   411: istore #20
    //   413: goto -> 419
    //   416: iconst_0
    //   417: istore #20
    //   419: aload #34
    //   421: iconst_0
    //   422: invokevirtual r : (I)Z
    //   425: ifeq -> 448
    //   428: aload #34
    //   430: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   433: checkcast androidx/constraintlayout/solver/widgets/d
    //   436: aload #34
    //   438: iconst_0
    //   439: invokevirtual F : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   442: iconst_1
    //   443: istore #21
    //   445: goto -> 454
    //   448: aload_0
    //   449: invokevirtual s : ()Z
    //   452: istore #21
    //   454: aload #34
    //   456: iconst_1
    //   457: invokevirtual r : (I)Z
    //   460: ifeq -> 483
    //   463: aload #34
    //   465: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   468: checkcast androidx/constraintlayout/solver/widgets/d
    //   471: aload #34
    //   473: iconst_1
    //   474: invokevirtual F : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   477: iconst_1
    //   478: istore #22
    //   480: goto -> 489
    //   483: aload_0
    //   484: invokevirtual t : ()Z
    //   487: istore #22
    //   489: iload #21
    //   491: ifne -> 551
    //   494: iload #19
    //   496: ifeq -> 551
    //   499: aload #34
    //   501: getfield X : I
    //   504: bipush #8
    //   506: if_icmpeq -> 551
    //   509: aload #34
    //   511: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   514: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   517: ifnonnull -> 551
    //   520: aload #34
    //   522: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   525: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   528: ifnonnull -> 551
    //   531: aload_1
    //   532: aload_1
    //   533: aload #34
    //   535: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   538: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   541: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   544: aload #28
    //   546: iconst_0
    //   547: iconst_1
    //   548: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   551: iload #22
    //   553: ifne -> 621
    //   556: iload #20
    //   558: ifeq -> 621
    //   561: aload #34
    //   563: getfield X : I
    //   566: bipush #8
    //   568: if_icmpeq -> 621
    //   571: aload #34
    //   573: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   576: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   579: ifnonnull -> 621
    //   582: aload #34
    //   584: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   587: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   590: ifnonnull -> 621
    //   593: aload #34
    //   595: getfield C : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   598: ifnonnull -> 621
    //   601: aload_1
    //   602: aload_1
    //   603: aload #34
    //   605: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   608: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   611: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   614: aload #32
    //   616: iconst_0
    //   617: iconst_1
    //   618: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   621: iload #19
    //   623: istore #24
    //   625: iload #21
    //   627: istore #23
    //   629: iload #22
    //   631: istore #21
    //   633: iload #20
    //   635: istore #19
    //   637: iload #24
    //   639: istore #20
    //   641: iload #23
    //   643: istore #22
    //   645: goto -> 660
    //   648: iconst_0
    //   649: istore #19
    //   651: iconst_0
    //   652: istore #20
    //   654: iconst_0
    //   655: istore #21
    //   657: iconst_0
    //   658: istore #22
    //   660: aload #34
    //   662: getfield L : I
    //   665: istore #16
    //   667: aload #34
    //   669: getfield S : I
    //   672: istore #9
    //   674: iload #16
    //   676: iload #9
    //   678: if_icmpge -> 684
    //   681: goto -> 688
    //   684: iload #16
    //   686: istore #9
    //   688: aload #34
    //   690: getfield M : I
    //   693: istore #17
    //   695: aload #34
    //   697: getfield T : I
    //   700: istore #10
    //   702: iload #17
    //   704: iload #10
    //   706: if_icmpge -> 712
    //   709: goto -> 716
    //   712: iload #17
    //   714: istore #10
    //   716: aload #34
    //   718: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   721: astore #30
    //   723: aload #30
    //   725: iconst_0
    //   726: aaload
    //   727: astore #31
    //   729: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.h : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   732: astore #29
    //   734: aload #31
    //   736: aload #29
    //   738: if_acmpeq -> 747
    //   741: iconst_1
    //   742: istore #13
    //   744: goto -> 750
    //   747: iconst_0
    //   748: istore #13
    //   750: aload #30
    //   752: iconst_1
    //   753: aaload
    //   754: aload #29
    //   756: if_acmpeq -> 765
    //   759: iconst_1
    //   760: istore #14
    //   762: goto -> 768
    //   765: iconst_0
    //   766: istore #14
    //   768: aload #34
    //   770: getfield O : I
    //   773: istore #18
    //   775: aload #34
    //   777: iload #18
    //   779: putfield s : I
    //   782: aload #34
    //   784: getfield N : F
    //   787: fstore #8
    //   789: aload #34
    //   791: fload #8
    //   793: putfield t : F
    //   796: aload #34
    //   798: getfield j : I
    //   801: istore #15
    //   803: aload #34
    //   805: getfield k : I
    //   808: istore #12
    //   810: fload #8
    //   812: fconst_0
    //   813: fcmpl
    //   814: ifle -> 1423
    //   817: aload #34
    //   819: getfield X : I
    //   822: bipush #8
    //   824: if_icmpeq -> 1423
    //   827: iload #15
    //   829: istore #11
    //   831: aload #30
    //   833: iconst_0
    //   834: aaload
    //   835: aload #29
    //   837: if_acmpne -> 852
    //   840: iload #15
    //   842: istore #11
    //   844: iload #15
    //   846: ifne -> 852
    //   849: iconst_3
    //   850: istore #11
    //   852: aload #30
    //   854: iconst_1
    //   855: aaload
    //   856: aload #29
    //   858: if_acmpne -> 872
    //   861: iload #12
    //   863: ifne -> 872
    //   866: iconst_3
    //   867: istore #12
    //   869: goto -> 872
    //   872: aload #30
    //   874: iconst_0
    //   875: aaload
    //   876: aload #29
    //   878: if_acmpne -> 1230
    //   881: aload #30
    //   883: iconst_1
    //   884: aaload
    //   885: aload #29
    //   887: if_acmpne -> 1230
    //   890: iload #11
    //   892: iconst_3
    //   893: if_icmpne -> 1230
    //   896: iload #12
    //   898: iconst_3
    //   899: if_icmpne -> 1230
    //   902: iload #18
    //   904: iconst_m1
    //   905: if_icmpne -> 958
    //   908: iload #13
    //   910: ifeq -> 927
    //   913: iload #14
    //   915: ifne -> 927
    //   918: aload #34
    //   920: iconst_0
    //   921: putfield s : I
    //   924: goto -> 958
    //   927: iload #13
    //   929: ifne -> 958
    //   932: iload #14
    //   934: ifeq -> 958
    //   937: aload #34
    //   939: iconst_1
    //   940: putfield s : I
    //   943: iload #18
    //   945: iconst_m1
    //   946: if_icmpne -> 958
    //   949: aload #34
    //   951: fconst_1
    //   952: fload #8
    //   954: fdiv
    //   955: putfield t : F
    //   958: aload #34
    //   960: getfield s : I
    //   963: ifne -> 997
    //   966: aload #34
    //   968: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   971: invokevirtual d : ()Z
    //   974: ifeq -> 988
    //   977: aload #34
    //   979: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   982: invokevirtual d : ()Z
    //   985: ifne -> 997
    //   988: aload #34
    //   990: iconst_1
    //   991: putfield s : I
    //   994: goto -> 1034
    //   997: aload #34
    //   999: getfield s : I
    //   1002: iconst_1
    //   1003: if_icmpne -> 1034
    //   1006: aload #34
    //   1008: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1011: invokevirtual d : ()Z
    //   1014: ifeq -> 1028
    //   1017: aload #34
    //   1019: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1022: invokevirtual d : ()Z
    //   1025: ifne -> 1034
    //   1028: aload #34
    //   1030: iconst_0
    //   1031: putfield s : I
    //   1034: aload #34
    //   1036: getfield s : I
    //   1039: iconst_m1
    //   1040: if_icmpne -> 1158
    //   1043: aload #34
    //   1045: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1048: invokevirtual d : ()Z
    //   1051: ifeq -> 1087
    //   1054: aload #34
    //   1056: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1059: invokevirtual d : ()Z
    //   1062: ifeq -> 1087
    //   1065: aload #34
    //   1067: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1070: invokevirtual d : ()Z
    //   1073: ifeq -> 1087
    //   1076: aload #34
    //   1078: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1081: invokevirtual d : ()Z
    //   1084: ifne -> 1158
    //   1087: aload #34
    //   1089: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1092: invokevirtual d : ()Z
    //   1095: ifeq -> 1118
    //   1098: aload #34
    //   1100: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1103: invokevirtual d : ()Z
    //   1106: ifeq -> 1118
    //   1109: aload #34
    //   1111: iconst_0
    //   1112: putfield s : I
    //   1115: goto -> 1158
    //   1118: aload #34
    //   1120: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1123: invokevirtual d : ()Z
    //   1126: ifeq -> 1158
    //   1129: aload #34
    //   1131: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1134: invokevirtual d : ()Z
    //   1137: ifeq -> 1158
    //   1140: aload #34
    //   1142: fconst_1
    //   1143: aload #34
    //   1145: getfield t : F
    //   1148: fdiv
    //   1149: putfield t : F
    //   1152: aload #34
    //   1154: iconst_1
    //   1155: putfield s : I
    //   1158: aload #34
    //   1160: getfield s : I
    //   1163: iconst_m1
    //   1164: if_icmpne -> 1397
    //   1167: aload #34
    //   1169: getfield m : I
    //   1172: istore #13
    //   1174: iload #13
    //   1176: ifle -> 1196
    //   1179: aload #34
    //   1181: getfield p : I
    //   1184: ifne -> 1196
    //   1187: aload #34
    //   1189: iconst_0
    //   1190: putfield s : I
    //   1193: goto -> 1397
    //   1196: iload #13
    //   1198: ifne -> 1397
    //   1201: aload #34
    //   1203: getfield p : I
    //   1206: ifle -> 1397
    //   1209: aload #34
    //   1211: fconst_1
    //   1212: aload #34
    //   1214: getfield t : F
    //   1217: fdiv
    //   1218: putfield t : F
    //   1221: aload #34
    //   1223: iconst_1
    //   1224: putfield s : I
    //   1227: goto -> 1397
    //   1230: aload #30
    //   1232: iconst_0
    //   1233: aaload
    //   1234: aload #29
    //   1236: if_acmpne -> 1300
    //   1239: iload #11
    //   1241: iconst_3
    //   1242: if_icmpne -> 1300
    //   1245: aload #34
    //   1247: iconst_0
    //   1248: putfield s : I
    //   1251: fload #8
    //   1253: iload #17
    //   1255: i2f
    //   1256: fmul
    //   1257: f2i
    //   1258: istore #14
    //   1260: aload #30
    //   1262: iconst_1
    //   1263: aaload
    //   1264: aload #29
    //   1266: if_acmpeq -> 1278
    //   1269: iconst_0
    //   1270: istore #11
    //   1272: iconst_4
    //   1273: istore #13
    //   1275: goto -> 1289
    //   1278: iconst_1
    //   1279: istore #9
    //   1281: iload #11
    //   1283: istore #13
    //   1285: iload #9
    //   1287: istore #11
    //   1289: iload #10
    //   1291: istore #9
    //   1293: iload #14
    //   1295: istore #10
    //   1297: goto -> 1442
    //   1300: aload #30
    //   1302: iconst_1
    //   1303: aaload
    //   1304: aload #29
    //   1306: if_acmpne -> 1397
    //   1309: iload #12
    //   1311: iconst_3
    //   1312: if_icmpne -> 1397
    //   1315: aload #34
    //   1317: iconst_1
    //   1318: putfield s : I
    //   1321: iload #18
    //   1323: iconst_m1
    //   1324: if_icmpne -> 1336
    //   1327: aload #34
    //   1329: fconst_1
    //   1330: fload #8
    //   1332: fdiv
    //   1333: putfield t : F
    //   1336: aload #34
    //   1338: getfield t : F
    //   1341: iload #16
    //   1343: i2f
    //   1344: fmul
    //   1345: f2i
    //   1346: istore #10
    //   1348: aload #30
    //   1350: iconst_0
    //   1351: aaload
    //   1352: astore #30
    //   1354: iload #11
    //   1356: istore #13
    //   1358: aload #30
    //   1360: aload #29
    //   1362: if_acmpeq -> 1390
    //   1365: iload #10
    //   1367: istore #12
    //   1369: iconst_0
    //   1370: istore #11
    //   1372: iconst_4
    //   1373: istore #14
    //   1375: iload #9
    //   1377: istore #10
    //   1379: iload #12
    //   1381: istore #9
    //   1383: iload #14
    //   1385: istore #12
    //   1387: goto -> 1442
    //   1390: iload #10
    //   1392: istore #13
    //   1394: goto -> 1401
    //   1397: iload #10
    //   1399: istore #13
    //   1401: iload #11
    //   1403: istore #14
    //   1405: iconst_1
    //   1406: istore #11
    //   1408: iload #9
    //   1410: istore #10
    //   1412: iload #13
    //   1414: istore #9
    //   1416: iload #14
    //   1418: istore #13
    //   1420: goto -> 1442
    //   1423: iload #15
    //   1425: istore #13
    //   1427: iload #9
    //   1429: istore #14
    //   1431: iload #10
    //   1433: istore #9
    //   1435: iconst_0
    //   1436: istore #11
    //   1438: iload #14
    //   1440: istore #10
    //   1442: aload #34
    //   1444: getfield l : [I
    //   1447: astore #29
    //   1449: aload #29
    //   1451: iconst_0
    //   1452: iload #13
    //   1454: iastore
    //   1455: aload #29
    //   1457: iconst_1
    //   1458: iload #12
    //   1460: iastore
    //   1461: iload #11
    //   1463: ifeq -> 1490
    //   1466: aload #34
    //   1468: getfield s : I
    //   1471: istore #14
    //   1473: iload #14
    //   1475: ifeq -> 1484
    //   1478: iload #14
    //   1480: iconst_m1
    //   1481: if_icmpne -> 1490
    //   1484: iconst_1
    //   1485: istore #23
    //   1487: goto -> 1493
    //   1490: iconst_0
    //   1491: istore #23
    //   1493: aload #34
    //   1495: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1498: iconst_0
    //   1499: aaload
    //   1500: aload #37
    //   1502: if_acmpne -> 1519
    //   1505: aload #34
    //   1507: instanceof androidx/constraintlayout/solver/widgets/d
    //   1510: ifeq -> 1519
    //   1513: iconst_1
    //   1514: istore #24
    //   1516: goto -> 1522
    //   1519: iconst_0
    //   1520: istore #24
    //   1522: iload #24
    //   1524: ifeq -> 1533
    //   1527: iconst_0
    //   1528: istore #10
    //   1530: goto -> 1533
    //   1533: aload #34
    //   1535: getfield F : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1538: invokevirtual d : ()Z
    //   1541: iconst_1
    //   1542: ixor
    //   1543: istore #25
    //   1545: aload #34
    //   1547: getfield I : [Z
    //   1550: astore #29
    //   1552: aload #29
    //   1554: iconst_0
    //   1555: baload
    //   1556: istore #27
    //   1558: aload #29
    //   1560: iconst_1
    //   1561: baload
    //   1562: istore #26
    //   1564: aload #34
    //   1566: getfield h : I
    //   1569: istore #14
    //   1571: aconst_null
    //   1572: astore #31
    //   1574: iload #14
    //   1576: iconst_2
    //   1577: if_icmpeq -> 1852
    //   1580: aload #34
    //   1582: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   1585: astore #29
    //   1587: aload #29
    //   1589: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1592: astore #30
    //   1594: aload #30
    //   1596: getfield j : Z
    //   1599: ifeq -> 1698
    //   1602: aload #29
    //   1604: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1607: getfield j : Z
    //   1610: ifne -> 1616
    //   1613: goto -> 1698
    //   1616: aload_1
    //   1617: aload #36
    //   1619: aload #30
    //   1621: getfield g : I
    //   1624: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1627: aload_1
    //   1628: aload #28
    //   1630: aload #34
    //   1632: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   1635: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1638: getfield g : I
    //   1641: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1644: aload #34
    //   1646: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1649: ifnull -> 1695
    //   1652: iload #20
    //   1654: ifeq -> 1695
    //   1657: aload #34
    //   1659: getfield f : [Z
    //   1662: iconst_0
    //   1663: baload
    //   1664: ifeq -> 1695
    //   1667: aload_0
    //   1668: invokevirtual s : ()Z
    //   1671: ifne -> 1695
    //   1674: aload_1
    //   1675: aload_1
    //   1676: aload #34
    //   1678: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1681: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1684: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1687: aload #28
    //   1689: iconst_0
    //   1690: bipush #8
    //   1692: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1695: goto -> 1852
    //   1698: aload #34
    //   1700: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1703: astore #29
    //   1705: aload #29
    //   1707: ifnull -> 1724
    //   1710: aload_1
    //   1711: aload #29
    //   1713: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1716: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1719: astore #29
    //   1721: goto -> 1727
    //   1724: aconst_null
    //   1725: astore #29
    //   1727: aload #34
    //   1729: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1732: astore #30
    //   1734: aload #30
    //   1736: ifnull -> 1753
    //   1739: aload_1
    //   1740: aload #30
    //   1742: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1745: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1748: astore #30
    //   1750: goto -> 1756
    //   1753: aconst_null
    //   1754: astore #30
    //   1756: aload_0
    //   1757: aload_1
    //   1758: iconst_1
    //   1759: iload #20
    //   1761: iload #19
    //   1763: aload #34
    //   1765: getfield f : [Z
    //   1768: iconst_0
    //   1769: baload
    //   1770: aload #30
    //   1772: aload #29
    //   1774: aload #34
    //   1776: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1779: iconst_0
    //   1780: aaload
    //   1781: iload #24
    //   1783: aload #34
    //   1785: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1788: aload #34
    //   1790: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1793: aload #34
    //   1795: getfield P : I
    //   1798: iload #10
    //   1800: aload #34
    //   1802: getfield S : I
    //   1805: aload #34
    //   1807: getfield u : [I
    //   1810: iconst_0
    //   1811: iaload
    //   1812: aload #34
    //   1814: getfield U : F
    //   1817: iload #23
    //   1819: iload #22
    //   1821: iload #21
    //   1823: iload #27
    //   1825: iload #13
    //   1827: iload #12
    //   1829: aload #34
    //   1831: getfield m : I
    //   1834: aload #34
    //   1836: getfield n : I
    //   1839: aload #34
    //   1841: getfield o : F
    //   1844: iload #25
    //   1846: invokevirtual d : (Landroidx/constraintlayout/solver/c;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZIIIIFZ)V
    //   1849: goto -> 1852
    //   1852: aload #36
    //   1854: astore #34
    //   1856: aload #28
    //   1858: astore #36
    //   1860: aload #35
    //   1862: astore #29
    //   1864: aload #32
    //   1866: astore #28
    //   1868: aload #33
    //   1870: astore #30
    //   1872: aload_0
    //   1873: astore #32
    //   1875: aload #32
    //   1877: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   1880: astore #33
    //   1882: aload #33
    //   1884: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1887: astore #35
    //   1889: aload #35
    //   1891: getfield j : Z
    //   1894: ifeq -> 2035
    //   1897: aload #33
    //   1899: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1902: getfield j : Z
    //   1905: ifeq -> 2035
    //   1908: aload #35
    //   1910: getfield g : I
    //   1913: istore #10
    //   1915: aload_1
    //   1916: astore #33
    //   1918: aload #33
    //   1920: aload #29
    //   1922: iload #10
    //   1924: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1927: aload #32
    //   1929: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   1932: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1935: getfield g : I
    //   1938: istore #10
    //   1940: aload #28
    //   1942: astore #35
    //   1944: aload #33
    //   1946: aload #35
    //   1948: iload #10
    //   1950: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1953: aload #33
    //   1955: aload #30
    //   1957: aload #32
    //   1959: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   1962: getfield k : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1965: getfield g : I
    //   1968: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1971: aload #32
    //   1973: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1976: astore #38
    //   1978: aload #38
    //   1980: ifnull -> 2029
    //   1983: iload #21
    //   1985: ifne -> 2029
    //   1988: iload #19
    //   1990: ifeq -> 2029
    //   1993: aload #32
    //   1995: getfield f : [Z
    //   1998: iconst_1
    //   1999: baload
    //   2000: ifeq -> 2026
    //   2003: aload #33
    //   2005: aload #33
    //   2007: aload #38
    //   2009: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2012: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2015: aload #35
    //   2017: iconst_0
    //   2018: bipush #8
    //   2020: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2023: goto -> 2029
    //   2026: goto -> 2029
    //   2029: iconst_0
    //   2030: istore #10
    //   2032: goto -> 2038
    //   2035: iconst_1
    //   2036: istore #10
    //   2038: aload_1
    //   2039: astore #33
    //   2041: aload #30
    //   2043: astore #35
    //   2045: aload #32
    //   2047: getfield i : I
    //   2050: iconst_2
    //   2051: if_icmpne -> 2060
    //   2054: iconst_0
    //   2055: istore #10
    //   2057: goto -> 2060
    //   2060: iload #10
    //   2062: ifeq -> 2407
    //   2065: aload #32
    //   2067: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2070: iconst_1
    //   2071: aaload
    //   2072: aload #37
    //   2074: if_acmpne -> 2091
    //   2077: aload #32
    //   2079: instanceof androidx/constraintlayout/solver/widgets/d
    //   2082: ifeq -> 2091
    //   2085: iconst_1
    //   2086: istore #23
    //   2088: goto -> 2094
    //   2091: iconst_0
    //   2092: istore #23
    //   2094: iload #23
    //   2096: ifeq -> 2102
    //   2099: iconst_0
    //   2100: istore #9
    //   2102: iload #11
    //   2104: ifeq -> 2132
    //   2107: aload #32
    //   2109: getfield s : I
    //   2112: istore #10
    //   2114: iload #10
    //   2116: iconst_1
    //   2117: if_icmpeq -> 2126
    //   2120: iload #10
    //   2122: iconst_m1
    //   2123: if_icmpne -> 2132
    //   2126: iconst_1
    //   2127: istore #24
    //   2129: goto -> 2135
    //   2132: iconst_0
    //   2133: istore #24
    //   2135: aload #32
    //   2137: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2140: astore #30
    //   2142: aload #30
    //   2144: ifnull -> 2162
    //   2147: aload #33
    //   2149: aload #30
    //   2151: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2154: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2157: astore #30
    //   2159: goto -> 2165
    //   2162: aconst_null
    //   2163: astore #30
    //   2165: aload #32
    //   2167: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2170: astore #37
    //   2172: aload #37
    //   2174: ifnull -> 2189
    //   2177: aload #33
    //   2179: aload #37
    //   2181: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2184: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2187: astore #31
    //   2189: aload #32
    //   2191: getfield R : I
    //   2194: istore #10
    //   2196: iload #10
    //   2198: ifgt -> 2211
    //   2201: aload #32
    //   2203: getfield X : I
    //   2206: bipush #8
    //   2208: if_icmpne -> 2311
    //   2211: aload #33
    //   2213: aload #35
    //   2215: aload #29
    //   2217: iload #10
    //   2219: bipush #8
    //   2221: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   2224: pop
    //   2225: aload #32
    //   2227: getfield C : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2230: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2233: astore #37
    //   2235: aload #37
    //   2237: ifnull -> 2288
    //   2240: aload #33
    //   2242: aload #35
    //   2244: aload #33
    //   2246: aload #37
    //   2248: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2251: iconst_0
    //   2252: bipush #8
    //   2254: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   2257: pop
    //   2258: iload #19
    //   2260: ifeq -> 2282
    //   2263: aload #33
    //   2265: aload #30
    //   2267: aload #33
    //   2269: aload #32
    //   2271: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2274: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2277: iconst_0
    //   2278: iconst_5
    //   2279: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2282: iconst_0
    //   2283: istore #25
    //   2285: goto -> 2311
    //   2288: aload #32
    //   2290: getfield X : I
    //   2293: bipush #8
    //   2295: if_icmpne -> 2311
    //   2298: aload #33
    //   2300: aload #35
    //   2302: aload #29
    //   2304: iconst_0
    //   2305: bipush #8
    //   2307: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   2310: pop
    //   2311: aload_0
    //   2312: aload_1
    //   2313: iconst_0
    //   2314: iload #19
    //   2316: iload #20
    //   2318: aload #32
    //   2320: getfield f : [Z
    //   2323: iconst_1
    //   2324: baload
    //   2325: aload #31
    //   2327: aload #30
    //   2329: aload #32
    //   2331: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2334: iconst_1
    //   2335: aaload
    //   2336: iload #23
    //   2338: aload #32
    //   2340: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2343: aload #32
    //   2345: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2348: aload #32
    //   2350: getfield Q : I
    //   2353: iload #9
    //   2355: aload #32
    //   2357: getfield T : I
    //   2360: aload #32
    //   2362: getfield u : [I
    //   2365: iconst_1
    //   2366: iaload
    //   2367: aload #32
    //   2369: getfield V : F
    //   2372: iload #24
    //   2374: iload #21
    //   2376: iload #22
    //   2378: iload #26
    //   2380: iload #12
    //   2382: iload #13
    //   2384: aload #32
    //   2386: getfield p : I
    //   2389: aload #32
    //   2391: getfield q : I
    //   2394: aload #32
    //   2396: getfield r : F
    //   2399: iload #25
    //   2401: invokevirtual d : (Landroidx/constraintlayout/solver/c;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZIIIIFZ)V
    //   2404: goto -> 2407
    //   2407: iload #11
    //   2409: ifeq -> 2468
    //   2412: aload_0
    //   2413: astore #30
    //   2415: aload #30
    //   2417: getfield s : I
    //   2420: iconst_1
    //   2421: if_icmpne -> 2446
    //   2424: aload_1
    //   2425: aload #28
    //   2427: aload #29
    //   2429: aload #36
    //   2431: aload #34
    //   2433: aload #30
    //   2435: getfield t : F
    //   2438: bipush #8
    //   2440: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2443: goto -> 2468
    //   2446: aload_1
    //   2447: aload #36
    //   2449: aload #34
    //   2451: aload #28
    //   2453: aload #29
    //   2455: aload #30
    //   2457: getfield t : F
    //   2460: bipush #8
    //   2462: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2465: goto -> 2468
    //   2468: aload_0
    //   2469: astore #28
    //   2471: aload #28
    //   2473: getfield F : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2476: invokevirtual d : ()Z
    //   2479: ifeq -> 2750
    //   2482: aload #28
    //   2484: getfield F : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2487: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2490: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2493: astore #33
    //   2495: aload #28
    //   2497: getfield v : F
    //   2500: ldc_w 90.0
    //   2503: fadd
    //   2504: f2d
    //   2505: invokestatic toRadians : (D)D
    //   2508: d2f
    //   2509: fstore #8
    //   2511: aload #28
    //   2513: getfield F : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2516: invokevirtual b : ()I
    //   2519: istore #9
    //   2521: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.f : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   2524: astore #32
    //   2526: aload_1
    //   2527: aload #28
    //   2529: aload #32
    //   2531: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2534: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2537: astore #29
    //   2539: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.g : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   2542: astore #36
    //   2544: aload_1
    //   2545: aload #28
    //   2547: aload #36
    //   2549: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2552: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2555: astore #31
    //   2557: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.h : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   2560: astore #35
    //   2562: aload_1
    //   2563: aload #28
    //   2565: aload #35
    //   2567: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2570: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2573: astore #30
    //   2575: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.i : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   2578: astore #34
    //   2580: aload_1
    //   2581: aload #28
    //   2583: aload #34
    //   2585: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2588: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2591: astore #28
    //   2593: aload_1
    //   2594: aload #33
    //   2596: aload #32
    //   2598: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2601: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2604: astore #32
    //   2606: aload_1
    //   2607: aload #33
    //   2609: aload #36
    //   2611: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2614: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2617: astore #36
    //   2619: aload_1
    //   2620: aload #33
    //   2622: aload #35
    //   2624: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2627: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2630: astore #35
    //   2632: aload_1
    //   2633: aload #33
    //   2635: aload #34
    //   2637: invokevirtual f : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2640: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2643: astore #33
    //   2645: aload_1
    //   2646: invokevirtual m : ()Landroidx/constraintlayout/solver/b;
    //   2649: astore #34
    //   2651: fload #8
    //   2653: f2d
    //   2654: dstore #4
    //   2656: dload #4
    //   2658: invokestatic sin : (D)D
    //   2661: dstore #6
    //   2663: iload #9
    //   2665: i2d
    //   2666: dstore_2
    //   2667: dload_2
    //   2668: invokestatic isNaN : (D)Z
    //   2671: pop
    //   2672: dload_2
    //   2673: invokestatic isNaN : (D)Z
    //   2676: pop
    //   2677: aload #34
    //   2679: aload #31
    //   2681: aload #28
    //   2683: aload #36
    //   2685: aload #33
    //   2687: dload #6
    //   2689: dload_2
    //   2690: dmul
    //   2691: d2f
    //   2692: invokevirtual g : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;F)Landroidx/constraintlayout/solver/b;
    //   2695: pop
    //   2696: aload_1
    //   2697: aload #34
    //   2699: invokevirtual c : (Landroidx/constraintlayout/solver/b;)V
    //   2702: aload_1
    //   2703: invokevirtual m : ()Landroidx/constraintlayout/solver/b;
    //   2706: astore #28
    //   2708: dload #4
    //   2710: invokestatic cos : (D)D
    //   2713: dstore #4
    //   2715: dload_2
    //   2716: invokestatic isNaN : (D)Z
    //   2719: pop
    //   2720: dload_2
    //   2721: invokestatic isNaN : (D)Z
    //   2724: pop
    //   2725: aload #28
    //   2727: aload #29
    //   2729: aload #30
    //   2731: aload #32
    //   2733: aload #35
    //   2735: dload #4
    //   2737: dload_2
    //   2738: dmul
    //   2739: d2f
    //   2740: invokevirtual g : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;F)Landroidx/constraintlayout/solver/b;
    //   2743: pop
    //   2744: aload_1
    //   2745: aload #28
    //   2747: invokevirtual c : (Landroidx/constraintlayout/solver/b;)V
    //   2750: return
  }
  
  public boolean c() {
    return (this.X != 8);
  }
  
  public final void d(c paramc, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean10) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void e(c paramc) {
    paramc.l(this.y);
    paramc.l(this.z);
    paramc.l(this.A);
    paramc.l(this.B);
    if (this.R > 0)
      paramc.l(this.C); 
  }
  
  public ConstraintAnchor f(ConstraintAnchor.Type paramType) {
    switch (paramType.ordinal()) {
      default:
        throw new AssertionError(paramType.name());
      case 0:
        return null;
      case 8:
        return this.E;
      case 7:
        return this.D;
      case 6:
        return this.F;
      case 5:
        return this.C;
      case 4:
        return this.B;
      case 3:
        return this.A;
      case 2:
        return this.z;
      case 1:
        break;
    } 
    return this.y;
  }
  
  public int g() {
    return q() + this.M;
  }
  
  public DimensionBehaviour h(int paramInt) {
    return (paramInt == 0) ? j() : ((paramInt == 1) ? n() : null);
  }
  
  public int i() {
    return (this.X == 8) ? 0 : this.M;
  }
  
  public DimensionBehaviour j() {
    return this.J[0];
  }
  
  public ConstraintWidget k(int paramInt) {
    if (paramInt == 0) {
      ConstraintAnchor constraintAnchor1 = this.A;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 != null && constraintAnchor2.d == constraintAnchor1)
        return constraintAnchor2.b; 
    } else if (paramInt == 1) {
      ConstraintAnchor constraintAnchor1 = this.B;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 != null && constraintAnchor2.d == constraintAnchor1)
        return constraintAnchor2.b; 
    } 
    return null;
  }
  
  public ConstraintWidget l(int paramInt) {
    if (paramInt == 0) {
      ConstraintAnchor constraintAnchor1 = this.y;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 != null && constraintAnchor2.d == constraintAnchor1)
        return constraintAnchor2.b; 
    } else if (paramInt == 1) {
      ConstraintAnchor constraintAnchor1 = this.z;
      ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 != null && constraintAnchor2.d == constraintAnchor1)
        return constraintAnchor2.b; 
    } 
    return null;
  }
  
  public int m() {
    return p() + this.L;
  }
  
  public DimensionBehaviour n() {
    return this.J[1];
  }
  
  public int o() {
    return (this.X == 8) ? 0 : this.L;
  }
  
  public int p() {
    ConstraintWidget constraintWidget = this.K;
    return (constraintWidget != null && constraintWidget instanceof d) ? (((d)constraintWidget).k0 + this.P) : this.P;
  }
  
  public int q() {
    ConstraintWidget constraintWidget = this.K;
    return (constraintWidget != null && constraintWidget instanceof d) ? (((d)constraintWidget).l0 + this.Q) : this.Q;
  }
  
  public final boolean r(int paramInt) {
    paramInt *= 2;
    ConstraintAnchor[] arrayOfConstraintAnchor = this.G;
    if ((arrayOfConstraintAnchor[paramInt]).d != null && (arrayOfConstraintAnchor[paramInt]).d.d != arrayOfConstraintAnchor[paramInt])
      if ((arrayOfConstraintAnchor[++paramInt]).d != null && (arrayOfConstraintAnchor[paramInt]).d.d == arrayOfConstraintAnchor[paramInt])
        return true;  
    return false;
  }
  
  public boolean s() {
    ConstraintAnchor constraintAnchor1 = this.y;
    ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
    if (constraintAnchor2 == null || constraintAnchor2.d != constraintAnchor1) {
      constraintAnchor1 = this.A;
      constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 == null || constraintAnchor2.d != constraintAnchor1)
        return false; 
    } 
    return true;
  }
  
  public boolean t() {
    ConstraintAnchor constraintAnchor1 = this.z;
    ConstraintAnchor constraintAnchor2 = constraintAnchor1.d;
    if (constraintAnchor2 == null || constraintAnchor2.d != constraintAnchor1) {
      constraintAnchor1 = this.B;
      constraintAnchor2 = constraintAnchor1.d;
      if (constraintAnchor2 == null || constraintAnchor2.d != constraintAnchor1)
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    String str = "";
    StringBuilder stringBuilder = a.a("");
    if (this.Y != null)
      str = a.a(a.a("id: "), this.Y, " "); 
    stringBuilder.append(str);
    stringBuilder.append("(");
    stringBuilder.append(this.P);
    stringBuilder.append(", ");
    stringBuilder.append(this.Q);
    stringBuilder.append(") - (");
    stringBuilder.append(this.L);
    stringBuilder.append(" x ");
    stringBuilder.append(this.M);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void u() {
    this.y.e();
    this.z.e();
    this.A.e();
    this.B.e();
    this.C.e();
    this.D.e();
    this.E.e();
    this.F.e();
    this.K = null;
    this.v = 0.0F;
    this.L = 0;
    this.M = 0;
    this.N = 0.0F;
    this.O = -1;
    this.P = 0;
    this.Q = 0;
    this.R = 0;
    this.S = 0;
    this.T = 0;
    this.U = 0.5F;
    this.V = 0.5F;
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.J;
    DimensionBehaviour dimensionBehaviour = DimensionBehaviour.f;
    arrayOfDimensionBehaviour[0] = dimensionBehaviour;
    arrayOfDimensionBehaviour[1] = dimensionBehaviour;
    this.W = null;
    this.X = 0;
    this.Z = 0;
    this.a0 = 0;
    float[] arrayOfFloat = this.b0;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.h = -1;
    this.i = -1;
    int[] arrayOfInt = this.u;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.j = 0;
    this.k = 0;
    this.o = 1.0F;
    this.r = 1.0F;
    this.n = Integer.MAX_VALUE;
    this.q = Integer.MAX_VALUE;
    this.m = 0;
    this.p = 0;
    this.s = -1;
    this.t = 1.0F;
    boolean[] arrayOfBoolean = this.f;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    arrayOfBoolean = this.I;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
  }
  
  public void v(mt parammt) {
    this.y.f();
    this.z.f();
    this.A.f();
    this.B.f();
    this.C.f();
    this.F.f();
    this.D.f();
    this.E.f();
  }
  
  public void w(int paramInt) {
    this.M = paramInt;
    int i = this.T;
    if (paramInt < i)
      this.M = i; 
  }
  
  public void x(DimensionBehaviour paramDimensionBehaviour) {
    this.J[0] = paramDimensionBehaviour;
  }
  
  public void y(int paramInt) {
    if (paramInt < 0) {
      this.T = 0;
      return;
    } 
    this.T = paramInt;
  }
  
  public void z(int paramInt) {
    if (paramInt < 0) {
      this.S = 0;
      return;
    } 
    this.S = paramInt;
  }
  
  public enum DimensionBehaviour {
    f, g, h, i;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      f = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      g = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      h = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      i = dimensionBehaviour4;
      j = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */