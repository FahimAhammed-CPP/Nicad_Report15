package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class Guideline extends View {
  public Guideline(Context paramContext) {
    super(paramContext);
    super.setVisibility(8);
  }
  
  public Guideline(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    super.setVisibility(8);
  }
  
  public void draw(Canvas paramCanvas) {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void setGuidelineBegin(int paramInt) {
    ConstraintLayout.a a = (ConstraintLayout.a)getLayoutParams();
    a.a = paramInt;
    setLayoutParams((ViewGroup.LayoutParams)a);
  }
  
  public void setGuidelineEnd(int paramInt) {
    ConstraintLayout.a a = (ConstraintLayout.a)getLayoutParams();
    a.b = paramInt;
    setLayoutParams((ViewGroup.LayoutParams)a);
  }
  
  public void setGuidelinePercent(float paramFloat) {
    ConstraintLayout.a a = (ConstraintLayout.a)getLayoutParams();
    a.c = paramFloat;
    setLayoutParams((ViewGroup.LayoutParams)a);
  }
  
  public void setVisibility(int paramInt) {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\Guideline.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */