package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.a;
import v.b;
import x.d;

public class Barrier extends a {
  public int l;
  
  public int m;
  
  public a n;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  public void e(AttributeSet paramAttributeSet) {
    super.e(paramAttributeSet);
    this.n = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.b);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 15) {
          setType(typedArray.getInt(k, 0));
        } else if (k == 14) {
          this.n.h0 = typedArray.getBoolean(k, true);
        } else if (k == 16) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.n.i0 = k;
        } 
      } 
    } 
    this.i = (b)this.n;
    g();
  }
  
  public void f(ConstraintWidget paramConstraintWidget, boolean paramBoolean) {
    int i = this.l;
    this.m = i;
    if (paramBoolean) {
      if (i == 5) {
        this.m = 1;
      } else if (i == 6) {
        this.m = 0;
      } 
    } else if (i == 5) {
      this.m = 0;
    } else if (i == 6) {
      this.m = 1;
    } 
    if (paramConstraintWidget instanceof a)
      ((a)paramConstraintWidget).g0 = this.m; 
  }
  
  public int getMargin() {
    return this.n.i0;
  }
  
  public int getType() {
    return this.l;
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.n.h0 = paramBoolean;
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.n.i0 = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.n.i0 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.l = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */