package androidx.lifecycle;

import androidx.savedstate.c;
import java.util.HashSet;
import java.util.Objects;

final class SavedStateHandleController implements h {
  public final String f;
  
  public boolean g = false;
  
  public final t h;
  
  public SavedStateHandleController(String paramString, t paramt) {
    this.f = paramString;
    this.h = paramt;
  }
  
  public static void b(w paramw, androidx.savedstate.a parama, Lifecycle paramLifecycle) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/Map;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 14
    //   9: aconst_null
    //   10: astore_0
    //   11: goto -> 30
    //   14: aload_3
    //   15: monitorenter
    //   16: aload_0
    //   17: getfield a : Ljava/util/Map;
    //   20: ldc 'androidx.lifecycle.savedstate.vm.tag'
    //   22: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   27: astore_0
    //   28: aload_3
    //   29: monitorexit
    //   30: aload_0
    //   31: checkcast androidx/lifecycle/SavedStateHandleController
    //   34: astore_0
    //   35: aload_0
    //   36: ifnull -> 57
    //   39: aload_0
    //   40: getfield g : Z
    //   43: ifne -> 57
    //   46: aload_0
    //   47: aload_1
    //   48: aload_2
    //   49: invokevirtual c : (Landroidx/savedstate/a;Landroidx/lifecycle/Lifecycle;)V
    //   52: aload_1
    //   53: aload_2
    //   54: invokestatic d : (Landroidx/savedstate/a;Landroidx/lifecycle/Lifecycle;)V
    //   57: return
    //   58: astore_0
    //   59: aload_3
    //   60: monitorexit
    //   61: aload_0
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   16	30	58	finally
    //   59	61	58	finally
  }
  
  public static void d(androidx.savedstate.a parama, Lifecycle paramLifecycle) {
    Lifecycle.State state = ((k)paramLifecycle).b;
    if (state != Lifecycle.State.g) {
      boolean bool;
      if (state.compareTo(Lifecycle.State.i) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        paramLifecycle.a(new h(paramLifecycle, parama) {
              public void a(j param1j, Lifecycle.Event param1Event) {
                if (param1Event == Lifecycle.Event.ON_START) {
                  k k = (k)this.f;
                  k.d("removeObserver");
                  k.a.j(this);
                  this.g.c(SavedStateHandleController.a.class);
                } 
              }
            });
        return;
      } 
    } 
    parama.c(a.class);
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent == Lifecycle.Event.ON_DESTROY) {
      this.g = false;
      k k = (k)paramj.getLifecycle();
      k.d("removeObserver");
      k.a.j(this);
    } 
  }
  
  public void c(androidx.savedstate.a parama, Lifecycle paramLifecycle) {
    if (!this.g) {
      this.g = true;
      paramLifecycle.a(this);
      parama.b(this.f, this.h.d);
      return;
    } 
    throw new IllegalStateException("Already attached to lifecycleOwner");
  }
  
  public static final class a implements androidx.savedstate.a.a {
    public void a(c param1c) {
      if (param1c instanceof d0) {
        c0 c0 = ((d0)param1c).getViewModelStore();
        androidx.savedstate.a a1 = param1c.getSavedStateRegistry();
        Objects.requireNonNull(c0);
        for (String str : new HashSet(c0.a.keySet()))
          SavedStateHandleController.b(c0.a.get(str), a1, param1c.getLifecycle()); 
        if (!(new HashSet(c0.a.keySet())).isEmpty())
          a1.c(a.class); 
        return;
      } 
      IllegalStateException illegalStateException = new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
      throw illegalStateException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */