package androidx.lifecycle;

import android.os.Handler;

public class v {
  public final k a;
  
  public final Handler b;
  
  public a c;
  
  public v(j paramj) {
    this.a = new k(paramj);
    this.b = new Handler();
  }
  
  public final void a(Lifecycle.Event paramEvent) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramEvent);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public static class a implements Runnable {
    public final k f;
    
    public final Lifecycle.Event g;
    
    public boolean h = false;
    
    public a(k param1k, Lifecycle.Event param1Event) {
      this.f = param1k;
      this.g = param1Event;
    }
    
    public void run() {
      if (!this.h) {
        this.f.e(this.g);
        this.h = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */