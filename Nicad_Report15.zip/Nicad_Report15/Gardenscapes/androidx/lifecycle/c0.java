package androidx.lifecycle;

import java.util.HashMap;

public class c0 {
  public final HashMap<String, w> a = new HashMap<String, w>();
  
  public final void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/HashMap;
    //   4: invokevirtual values : ()Ljava/util/Collection;
    //   7: invokeinterface iterator : ()Ljava/util/Iterator;
    //   12: astore_3
    //   13: aload_3
    //   14: invokeinterface hasNext : ()Z
    //   19: ifeq -> 138
    //   22: aload_3
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: checkcast androidx/lifecycle/w
    //   31: astore #4
    //   33: aload #4
    //   35: iconst_1
    //   36: putfield b : Z
    //   39: aload #4
    //   41: getfield a : Ljava/util/Map;
    //   44: astore_2
    //   45: aload_2
    //   46: ifnull -> 130
    //   49: aload_2
    //   50: monitorenter
    //   51: aload #4
    //   53: getfield a : Ljava/util/Map;
    //   56: invokeinterface values : ()Ljava/util/Collection;
    //   61: invokeinterface iterator : ()Ljava/util/Iterator;
    //   66: astore #5
    //   68: aload #5
    //   70: invokeinterface hasNext : ()Z
    //   75: ifeq -> 120
    //   78: aload #5
    //   80: invokeinterface next : ()Ljava/lang/Object;
    //   85: astore #6
    //   87: aload #6
    //   89: instanceof java/io/Closeable
    //   92: istore_1
    //   93: iload_1
    //   94: ifeq -> 68
    //   97: aload #6
    //   99: checkcast java/io/Closeable
    //   102: invokeinterface close : ()V
    //   107: goto -> 68
    //   110: astore_3
    //   111: new java/lang/RuntimeException
    //   114: dup
    //   115: aload_3
    //   116: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   119: athrow
    //   120: aload_2
    //   121: monitorexit
    //   122: goto -> 130
    //   125: astore_3
    //   126: aload_2
    //   127: monitorexit
    //   128: aload_3
    //   129: athrow
    //   130: aload #4
    //   132: invokevirtual a : ()V
    //   135: goto -> 13
    //   138: aload_0
    //   139: getfield a : Ljava/util/HashMap;
    //   142: invokevirtual clear : ()V
    //   145: return
    // Exception table:
    //   from	to	target	type
    //   51	68	125	finally
    //   68	93	125	finally
    //   97	107	110	java/io/IOException
    //   97	107	125	finally
    //   111	120	125	finally
    //   120	122	125	finally
    //   126	128	125	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */