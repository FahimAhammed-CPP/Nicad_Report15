package androidx.lifecycle;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public abstract class w {
  public final Map<String, Object> a = new HashMap<String, Object>();
  
  public volatile boolean b = false;
  
  public void a() {}
  
  public <T> T b(String paramString, T paramT) {
    synchronized (this.a) {
      Object object2 = this.a.get(paramString);
      if (object2 == null)
        this.a.put(paramString, paramT); 
      if (object2 == null) {
        object1 = paramT;
      } else {
        object1 = object2;
      } 
      if (this.b && object1 instanceof Closeable)
        try {
          ((Closeable)object1).close();
          return (T)object1;
        } catch (IOException object1) {
          throw new RuntimeException(object1);
        }  
      return (T)object1;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */