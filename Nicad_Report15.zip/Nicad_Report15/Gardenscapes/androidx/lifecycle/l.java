package androidx.lifecycle;

@Deprecated
public interface l extends j {
  k getLifecycle();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */