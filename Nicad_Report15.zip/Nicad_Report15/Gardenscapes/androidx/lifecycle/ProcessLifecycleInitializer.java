package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import k1.b;

public final class ProcessLifecycleInitializer implements b<j> {
  public List<Class<? extends b<?>>> a() {
    return Collections.emptyList();
  }
  
  public Object b(Context paramContext) {
    if (!g.a.getAndSet(true))
      ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new g.a()); 
    ProcessLifecycleOwner processLifecycleOwner = ProcessLifecycleOwner.n;
    Objects.requireNonNull(processLifecycleOwner);
    processLifecycleOwner.j = new Handler();
    processLifecycleOwner.k.e(Lifecycle.Event.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new r(processLifecycleOwner));
    return processLifecycleOwner;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */