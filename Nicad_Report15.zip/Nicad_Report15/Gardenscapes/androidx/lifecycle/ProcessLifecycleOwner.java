package androidx.lifecycle;

import android.os.Handler;

public class ProcessLifecycleOwner implements j {
  public static final ProcessLifecycleOwner n = new ProcessLifecycleOwner();
  
  public int f = 0;
  
  public int g = 0;
  
  public boolean h = true;
  
  public boolean i = true;
  
  public Handler j;
  
  public final k k = new k(this);
  
  public Runnable l = new a(this);
  
  public s.a m = new b(this);
  
  public void a() {
    int i = this.g + 1;
    this.g = i;
    if (i == 1) {
      if (this.h) {
        this.k.e(Lifecycle.Event.ON_RESUME);
        this.h = false;
        return;
      } 
      this.j.removeCallbacks(this.l);
    } 
  }
  
  public void b() {
    int i = this.f + 1;
    this.f = i;
    if (i == 1 && this.i) {
      this.k.e(Lifecycle.Event.ON_START);
      this.i = false;
    } 
  }
  
  public Lifecycle getLifecycle() {
    return this.k;
  }
  
  public class a implements Runnable {
    public a(ProcessLifecycleOwner this$0) {}
    
    public void run() {
      ProcessLifecycleOwner processLifecycleOwner = this.f;
      if (processLifecycleOwner.g == 0) {
        processLifecycleOwner.h = true;
        processLifecycleOwner.k.e(Lifecycle.Event.ON_PAUSE);
      } 
      processLifecycleOwner = this.f;
      if (processLifecycleOwner.f == 0 && processLifecycleOwner.h) {
        processLifecycleOwner.k.e(Lifecycle.Event.ON_STOP);
        processLifecycleOwner.i = true;
      } 
    }
  }
  
  public class b implements s.a {
    public b(ProcessLifecycleOwner this$0) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */