package androidx.lifecycle;

public interface y {
  <T extends w> T a(Class<T> paramClass);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */