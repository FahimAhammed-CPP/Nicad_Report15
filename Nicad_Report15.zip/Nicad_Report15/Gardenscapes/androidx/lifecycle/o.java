package androidx.lifecycle;

import l.a;

public class o<T> extends LiveData<T> {
  public void i(T paramT) {
    LiveData.a("setValue");
    this.g++;
    this.e = paramT;
    c(null);
  }
  
  public void j(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == LiveData.k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      a a = a.d();
      null = this.j;
      a.a.c((Runnable)null);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */