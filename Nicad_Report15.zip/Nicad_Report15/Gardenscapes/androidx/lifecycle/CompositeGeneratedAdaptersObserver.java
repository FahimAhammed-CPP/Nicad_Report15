package androidx.lifecycle;

import f.r;

class CompositeGeneratedAdaptersObserver implements h {
  public final f[] f;
  
  public CompositeGeneratedAdaptersObserver(f[] paramArrayOff) {
    this.f = paramArrayOff;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    r r = new r(1);
    f[] arrayOfF = this.f;
    int k = arrayOfF.length;
    boolean bool = false;
    int i;
    for (i = 0; i < k; i++)
      arrayOfF[i].a(paramj, paramEvent, false, r); 
    arrayOfF = this.f;
    k = arrayOfF.length;
    for (i = bool; i < k; i++)
      arrayOfF[i].a(paramj, paramEvent, true, r); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */