package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements h {
  public final f f;
  
  public SingleGeneratedAdapterObserver(f paramf) {
    this.f = paramf;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    this.f.a(paramj, paramEvent, false, null);
    this.f.a(paramj, paramEvent, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */