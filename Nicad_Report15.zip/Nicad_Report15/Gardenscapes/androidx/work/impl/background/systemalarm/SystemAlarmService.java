package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.lifecycle.m;
import java.util.HashMap;
import java.util.WeakHashMap;
import p1.i;
import z1.m;

public class SystemAlarmService extends m implements d.c {
  public static final String i = i.e("SystemAlarmService");
  
  public d g;
  
  public boolean h;
  
  public final void a() {
    d d1 = new d((Context)this);
    this.g = d1;
    if (d1.o != null) {
      i.c().b(d.p, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    d1.o = this;
  }
  
  public void b() {
    this.h = true;
    i.c().a(i, "All commands completed in dispatcher", new Throwable[0]);
    String str = m.a;
    null = new HashMap<Object, Object>();
    synchronized (m.b) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String str1 = String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          i.c().f(m.a, str1, new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    a();
    this.h = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.h = true;
    this.g.d();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.h) {
      i.c().d(i, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.g.d();
      a();
      this.h = false;
    } 
    if (paramIntent != null)
      this.g.b(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */