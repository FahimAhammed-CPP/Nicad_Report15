package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Objects;
import p1.i;
import q1.k;

public class RescheduleReceiver extends BroadcastReceiver {
  public static final String a = i.e("RescheduleReceiver");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    i.c().a(a, String.format("Received intent %s", new Object[] { paramIntent }), new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 23)
      try {
        null = k.b(paramContext);
        BroadcastReceiver.PendingResult pendingResult = goAsync();
        Objects.requireNonNull(null);
        synchronized (k.l) {
          null.i = pendingResult;
          if (null.h) {
            pendingResult.finish();
            null.i = null;
          } 
          return;
        } 
      } catch (IllegalStateException illegalStateException) {
        i.c().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", new Throwable[] { illegalStateException });
        return;
      }  
    String str = a.i;
    Intent intent = new Intent((Context)illegalStateException, SystemAlarmService.class);
    intent.setAction("ACTION_RESCHEDULE");
    illegalStateException.startService(intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\RescheduleReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */