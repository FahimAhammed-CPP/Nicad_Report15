package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import java.util.Collections;
import java.util.List;
import p1.i;
import q1.b;
import u1.c;
import u1.d;
import y1.p;
import y1.q;
import y1.r;
import z1.m;
import z1.r;

public class c implements c, b, r.b {
  public static final String o = i.e("DelayMetCommandHandler");
  
  public final Context f;
  
  public final int g;
  
  public final String h;
  
  public final d i;
  
  public final d j;
  
  public final Object k;
  
  public int l;
  
  public PowerManager.WakeLock m;
  
  public boolean n;
  
  public c(Context paramContext, int paramInt, String paramString, d paramd) {
    this.f = paramContext;
    this.g = paramInt;
    this.i = paramd;
    this.h = paramString;
    this.j = new d(paramContext, paramd.g, this);
    this.n = false;
    this.l = 0;
    this.k = new Object();
  }
  
  public void a(String paramString, boolean paramBoolean) {
    i.c().a(o, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    e();
    if (paramBoolean) {
      Intent intent = a.d(this.f, this.h);
      d d1 = this.i;
      d.b b1 = new d.b(d1, intent, this.g);
      d1.l.post(b1);
    } 
    if (this.n) {
      Intent intent = a.b(this.f);
      d d1 = this.i;
      d.b b1 = new d.b(d1, intent, this.g);
      d1.l.post(b1);
    } 
  }
  
  public void b(String paramString) {
    i.c().a(o, String.format("Exceeded time limits on execution for %s", new Object[] { paramString }), new Throwable[0]);
    g();
  }
  
  public void c(List<String> paramList) {
    g();
  }
  
  public void d(List<String> paramList) {
    if (!paramList.contains(this.h))
      return; 
    synchronized (this.k) {
      if (this.l == 0) {
        this.l = 1;
        i.c().a(o, String.format("onAllConstraintsMet for %s", new Object[] { this.h }), new Throwable[0]);
        if (this.i.i.g(this.h, null)) {
          this.i.h.a(this.h, 600000L, this);
        } else {
          e();
        } 
      } else {
        i.c().a(o, String.format("Already started work for %s", new Object[] { this.h }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public final void e() {
    synchronized (this.k) {
      this.j.c();
      this.i.h.b(this.h);
      PowerManager.WakeLock wakeLock = this.m;
      if (wakeLock != null && wakeLock.isHeld()) {
        i.c().a(o, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.m, this.h }), new Throwable[0]);
        this.m.release();
      } 
      return;
    } 
  }
  
  public void f() {
    this.m = m.a(this.f, String.format("%s (%s)", new Object[] { this.h, Integer.valueOf(this.g) }));
    i i = i.c();
    String str1 = o;
    i.a(str1, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.m, this.h }), new Throwable[0]);
    this.m.acquire();
    q q = this.i.j.c.q();
    String str2 = this.h;
    p p = ((r)q).i(str2);
    if (p == null) {
      g();
      return;
    } 
    boolean bool = p.b();
    this.n = bool;
    if (!bool) {
      i.c().a(str1, String.format("No constraints for %s", new Object[] { this.h }), new Throwable[0]);
      d(Collections.singletonList(this.h));
      return;
    } 
    this.j.b(Collections.singletonList(p));
  }
  
  public final void g() {
    synchronized (this.k) {
      if (this.l < 2) {
        d d1;
        this.l = 2;
        i i = i.c();
        String str1 = o;
        i.a(str1, String.format("Stopping work for WorkSpec %s", new Object[] { this.h }), new Throwable[0]);
        Context context = this.f;
        String str2 = this.h;
        Intent intent = new Intent(context, SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str2);
        d d2 = this.i;
        d.b b1 = new d.b(d2, intent, this.g);
        d2.l.post(b1);
        if (this.i.i.d(this.h)) {
          i.c().a(str1, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.h }), new Throwable[0]);
          Intent intent1 = a.d(this.f, this.h);
          d1 = this.i;
          d.b b2 = new d.b(d1, intent1, this.g);
          d1.l.post(b2);
        } else {
          i.c().a((String)d1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.h }), new Throwable[0]);
        } 
      } else {
        i.c().a(o, String.format("Already stopped work for %s", new Object[] { this.h }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */