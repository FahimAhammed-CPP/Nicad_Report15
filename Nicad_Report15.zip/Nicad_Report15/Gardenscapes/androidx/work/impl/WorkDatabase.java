package androidx.work.impl;

import androidx.room.RoomDatabase;
import java.util.concurrent.TimeUnit;
import y1.b;
import y1.e;
import y1.h;
import y1.k;
import y1.n;
import y1.q;
import y1.t;

public abstract class WorkDatabase extends RoomDatabase {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public abstract b l();
  
  public abstract e m();
  
  public abstract h n();
  
  public abstract k o();
  
  public abstract n p();
  
  public abstract q q();
  
  public abstract t r();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */