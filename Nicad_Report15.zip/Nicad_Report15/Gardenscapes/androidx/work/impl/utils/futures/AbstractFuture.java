package androidx.work.impl.utils.futures;

import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import m7.a;

public abstract class AbstractFuture<V> implements a<V> {
  public static final boolean i = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
  
  public static final Logger j = Logger.getLogger(AbstractFuture.class.getName());
  
  public static final b k;
  
  public static final Object l = new Object();
  
  public volatile Object f;
  
  public volatile d g;
  
  public volatile h h;
  
  public static void d(AbstractFuture<?> paramAbstractFuture) {
    AbstractFuture abstractFuture1 = null;
    AbstractFuture<?> abstractFuture = paramAbstractFuture;
    paramAbstractFuture = abstractFuture1;
    label34: while (true) {
      h h1 = abstractFuture.h;
      if (k.c(abstractFuture, h1, h.c)) {
        while (h1 != null) {
          Thread thread = h1.a;
          if (thread != null) {
            h1.a = null;
            LockSupport.unpark(thread);
          } 
          h1 = h1.b;
        } 
        while (true) {
          d d1 = abstractFuture.g;
          if (k.a(abstractFuture, d1, d.d)) {
            d d2 = d1;
            while (true) {
              d1 = d2;
              AbstractFuture<?> abstractFuture2 = paramAbstractFuture;
              if (d1 != null) {
                d2 = d1.c;
                d1.c = (d)paramAbstractFuture;
                d d3 = d1;
                continue;
              } 
              break;
            } 
            while (d2 != null) {
              AbstractFuture<V> abstractFuture2;
              d d3 = d2.c;
              Runnable runnable = d2.a;
              if (runnable instanceof f) {
                runnable = runnable;
                abstractFuture2 = ((f)runnable).f;
                if (abstractFuture2.f == runnable) {
                  Object object = g(((f)runnable).g);
                  if (k.b(abstractFuture2, runnable, object))
                    continue label34; 
                } 
              } else {
                e(runnable, ((d)abstractFuture2).b);
              } 
              d d4 = d3;
            } 
            return;
          } 
        } 
        continue;
      } 
    } 
  }
  
  public static void e(Runnable paramRunnable, Executor paramExecutor) {
    try {
      paramExecutor.execute(paramRunnable);
      return;
    } catch (RuntimeException runtimeException) {
      Logger logger = j;
      Level level = Level.SEVERE;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RuntimeException while executing runnable ");
      stringBuilder.append(paramRunnable);
      stringBuilder.append(" with executor ");
      stringBuilder.append(paramExecutor);
      logger.log(level, stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  public static Object g(a<?> parama) {
    if (parama instanceof AbstractFuture) {
      Object object1 = ((AbstractFuture)parama).f;
      object = object1;
      if (object1 instanceof c) {
        c c = (c)object1;
        object = object1;
        if (c.a) {
          if (c.b != null)
            return new c(false, c.b); 
          object = c.d;
        } 
      } 
      return object;
    } 
    boolean bool = ((AbstractFuture)object).f instanceof c;
    if (((i ^ true) & bool) != 0)
      return c.d; 
    try {
      Object object2 = h((Future<Object>)object);
      Object object1 = object2;
      return object1;
    } catch (ExecutionException object) {
      return new Failure(object.getCause());
    } catch (CancellationException cancellationException) {
      return new c(false, cancellationException);
    } finally {
      object = null;
    } 
  }
  
  public static <V> V h(Future<V> paramFuture) {
    boolean bool = false;
    while (true) {
      try {
        return (V)((AbstractFuture)paramFuture).get();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  public final void a(StringBuilder paramStringBuilder) {
    try {
      String str;
      AbstractFuture abstractFuture = (AbstractFuture)h((Future<Object>)this);
      paramStringBuilder.append("SUCCESS, result=[");
      if (abstractFuture == this) {
        str = "this future";
      } else {
        str = String.valueOf(str);
      } 
      paramStringBuilder.append(str);
      paramStringBuilder.append("]");
      return;
    } catch (ExecutionException executionException) {
      paramStringBuilder.append("FAILURE, cause=[");
      paramStringBuilder.append(executionException.getCause());
      paramStringBuilder.append("]");
      return;
    } catch (CancellationException cancellationException) {
      paramStringBuilder.append("CANCELLED");
      return;
    } catch (RuntimeException runtimeException) {
      paramStringBuilder.append("UNKNOWN, cause=[");
      paramStringBuilder.append(runtimeException.getClass());
      paramStringBuilder.append(" thrown from get()]");
      return;
    } 
  }
  
  public final void c(Runnable paramRunnable, Executor paramExecutor) {
    Objects.requireNonNull(paramExecutor);
    d d1 = this.g;
    if (d1 != d.d) {
      d d2;
      d d3 = new d(paramRunnable, paramExecutor);
      do {
        d3.c = d1;
        if (k.a(this, d1, d3))
          return; 
        d2 = this.g;
        d1 = d2;
      } while (d2 != d.d);
    } 
    e(paramRunnable, paramExecutor);
  }
  
  public final boolean cancel(boolean paramBoolean) {
    boolean bool;
    boolean bool1;
    Object object = this.f;
    boolean bool2 = true;
    if (object == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool | object instanceof f) {
      c c;
      if (i) {
        c = new c(paramBoolean, new CancellationException("Future.cancel() was called."));
      } else if (paramBoolean) {
        c = c.c;
      } else {
        c = c.d;
      } 
      bool1 = false;
      AbstractFuture<?> abstractFuture = this;
      while (true) {
        while (k.b(abstractFuture, object, c)) {
          d(abstractFuture);
          bool1 = bool2;
          if (object instanceof f) {
            object = ((f)object).g;
            if (object instanceof AbstractFuture) {
              abstractFuture = (AbstractFuture)object;
              object = abstractFuture.f;
              if (object == null) {
                bool = true;
              } else {
                bool = false;
              } 
              bool1 = bool2;
              if (bool | object instanceof f) {
                bool1 = true;
                continue;
              } 
            } else {
              ((AbstractFuture)object).cancel(paramBoolean);
              return true;
            } 
          } 
          return bool1;
        } 
        Object object1 = abstractFuture.f;
        object = object1;
        if (!(object1 instanceof f))
          return bool1; 
      } 
    } else {
      bool1 = false;
    } 
    return bool1;
  }
  
  public final V f(Object paramObject) {
    if (!(paramObject instanceof c)) {
      if (!(paramObject instanceof Failure)) {
        Object object = paramObject;
        if (paramObject == l)
          object = null; 
        return (V)object;
      } 
      throw new ExecutionException(((Failure)paramObject).a);
    } 
    paramObject = ((c)paramObject).b;
    CancellationException cancellationException = new CancellationException("Task was cancelled.");
    cancellationException.initCause((Throwable)paramObject);
    throw cancellationException;
  }
  
  public final V get() {
    if (!Thread.interrupted()) {
      boolean bool;
      Object object = this.f;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof f ^ true)) != 0)
        return f(object); 
      object = this.h;
      if (object != h.c) {
        h h1;
        h h2 = new h();
        do {
          b b1 = k;
          b1.d(h2, (h)object);
          if (b1.c(this, (h)object, h2))
            while (true) {
              LockSupport.park(this);
              if (!Thread.interrupted()) {
                object = this.f;
                if (object != null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if ((bool & (object instanceof f ^ true)) != 0)
                  return f(object); 
                continue;
              } 
              j(h2);
              throw new InterruptedException();
            }  
          h1 = this.h;
          object = h1;
        } while (h1 != h.c);
      } 
      return f(this.f);
    } 
    InterruptedException interruptedException = new InterruptedException();
    throw interruptedException;
  }
  
  public final V get(long paramLong, TimeUnit paramTimeUnit) {
    long l = paramTimeUnit.toNanos(paramLong);
    if (!Thread.interrupted()) {
      boolean bool;
      long l2;
      Object object = this.f;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof f ^ true)) != 0)
        return f(object); 
      if (l > 0L) {
        l2 = System.nanoTime() + l;
      } else {
        l2 = 0L;
      } 
      long l1 = l;
      if (l >= 1000L) {
        object = this.h;
        if (object != h.c) {
          h h1 = new h();
          label78: while (true) {
            b b1 = k;
            b1.d(h1, (h)object);
            if (b1.c(this, (h)object, h1))
              while (true) {
                LockSupport.parkNanos(this, l);
                if (!Thread.interrupted()) {
                  object = this.f;
                  if (object != null) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  if ((bool & (object instanceof f ^ true)) != 0)
                    return f(object); 
                  l1 = l2 - System.nanoTime();
                  l = l1;
                  if (l1 < 1000L) {
                    j(h1);
                    break;
                  } 
                  continue;
                } 
                j(h1);
                throw new InterruptedException();
              }  
            h h2 = this.h;
            object = h2;
            if (h2 == h.c)
              break label78; 
          } 
        } else {
          return f(this.f);
        } 
      } 
      while (l1 > 0L) {
        object = this.f;
        if (object != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool & (object instanceof f ^ true)) != 0)
          return f(object); 
        if (!Thread.interrupted()) {
          l1 = l2 - System.nanoTime();
          continue;
        } 
        throw new InterruptedException();
      } 
      String str3 = toString();
      String str2 = paramTimeUnit.toString();
      object = Locale.ROOT;
      String str4 = str2.toLowerCase((Locale)object);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Waited ");
      stringBuilder.append(paramLong);
      stringBuilder.append(" ");
      stringBuilder.append(paramTimeUnit.toString().toLowerCase((Locale)object));
      String str1 = stringBuilder.toString();
      object = str1;
      if (l1 + 1000L < 0L) {
        object = j.f.a(str1, " (plus ");
        l1 = -l1;
        paramLong = paramTimeUnit.convert(l1, TimeUnit.NANOSECONDS);
        l1 -= paramTimeUnit.toNanos(paramLong);
        if (paramLong == 0L || l1 > 1000L) {
          bool = true;
        } else {
          bool = false;
        } 
        Object object1 = object;
        if (paramLong > 0L) {
          object1 = new StringBuilder();
          object1.append((String)object);
          object1.append(paramLong);
          object1.append(" ");
          object1.append(str4);
          object = object1.toString();
          object1 = object;
          if (bool)
            object1 = j.f.a((String)object, ","); 
          object1 = j.f.a((String)object1, " ");
        } 
        object = object1;
        if (bool) {
          object = new StringBuilder();
          object.append((String)object1);
          object.append(l1);
          object.append(" nanoseconds ");
          object = object.toString();
        } 
        object = j.f.a((String)object, "delay)");
      } 
      if (isDone())
        throw new TimeoutException(j.f.a(object, " but future completed as timeout expired")); 
      throw new TimeoutException(e.g.a(object, " for ", str3));
    } 
    InterruptedException interruptedException = new InterruptedException();
    throw interruptedException;
  }
  
  public String i() {
    Object object = this.f;
    if (object instanceof f) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("setFuture=[");
      object = ((f)object).g;
      if (object == this) {
        object = "this future";
      } else {
        object = String.valueOf(object);
      } 
      return v.a.a(stringBuilder, (String)object, "]");
    } 
    if (this instanceof ScheduledFuture) {
      object = android.support.v4.media.a.a("remaining delay=[");
      object.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
      object.append(" ms]");
      return object.toString();
    } 
    return null;
  }
  
  public final boolean isCancelled() {
    return this.f instanceof c;
  }
  
  public final boolean isDone() {
    boolean bool;
    Object object = this.f;
    if (object != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (object instanceof f ^ true) & bool;
  }
  
  public final void j(h paramh) {
    paramh.a = null;
    label24: while (true) {
      paramh = this.h;
      if (paramh == h.c)
        return; 
      for (Object object = null; paramh != null; object = object1) {
        Object object1;
        h h1 = paramh.b;
        if (paramh.a != null) {
          object1 = paramh;
        } else if (object != null) {
          ((h)object).b = h1;
          object1 = object;
          if (((h)object).a == null)
            continue label24; 
        } else {
          object1 = object;
          if (!k.c(this, paramh, h1))
            continue label24; 
        } 
        paramh = h1;
      } 
      break;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("[status=");
    if (this.f instanceof c) {
      stringBuilder.append("CANCELLED");
    } else if (isDone()) {
      a(stringBuilder);
    } else {
      String str;
      try {
        str = i();
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder1 = android.support.v4.media.a.a("Exception thrown from implementation: ");
        stringBuilder1.append(runtimeException.getClass());
        str = stringBuilder1.toString();
      } 
      if (str != null && !str.isEmpty()) {
        stringBuilder.append("PENDING, info=[");
        stringBuilder.append(str);
        stringBuilder.append("]");
      } else if (isDone()) {
        a(stringBuilder);
      } else {
        stringBuilder.append("PENDING");
      } 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static {
    Exception exception;
    g g;
  }
  
  static {
    try {
      e e = new e(AtomicReferenceFieldUpdater.newUpdater(h.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(h.class, h.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, h.class, "h"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, d.class, "g"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Object.class, "f"));
    } finally {
      exception = null;
    } 
    k = g;
    if (exception != null)
      j.log(Level.SEVERE, "SafeAtomicHelper is broken!", exception); 
  }
  
  public static final class Failure {
    public static final Failure b = new Failure(new Throwable("Failure occurred while trying to finish a future.") {
          public Throwable fillInStackTrace() {
            /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/work/impl/utils/futures/AbstractFuture}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure;}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure$1;}} */
            /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/work/impl/utils/futures/AbstractFuture}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure;}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure$1;}} */
            return this;
          }
        });
    
    public final Throwable a;
    
    public Failure(Throwable param1Throwable) {
      boolean bool = AbstractFuture.i;
      Objects.requireNonNull(param1Throwable);
      this.a = param1Throwable;
    }
  }
  
  public class null extends Throwable {
    public null(AbstractFuture this$0) {
      super((String)this$0);
    }
    
    public Throwable fillInStackTrace() {
      /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/work/impl/utils/futures/AbstractFuture}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure;}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure$1;}} */
      /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/work/impl/utils/futures/AbstractFuture}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure;}.Landroidx/work/impl/utils/futures/AbstractFuture$Failure$1;}} */
      return this;
    }
  }
  
  public static abstract class b {
    public b(AbstractFuture.a param1a) {}
    
    public abstract boolean a(AbstractFuture<?> param1AbstractFuture, AbstractFuture.d param1d1, AbstractFuture.d param1d2);
    
    public abstract boolean b(AbstractFuture<?> param1AbstractFuture, Object param1Object1, Object param1Object2);
    
    public abstract boolean c(AbstractFuture<?> param1AbstractFuture, AbstractFuture.h param1h1, AbstractFuture.h param1h2);
    
    public abstract void d(AbstractFuture.h param1h1, AbstractFuture.h param1h2);
    
    public abstract void e(AbstractFuture.h param1h, Thread param1Thread);
  }
  
  public static final class c {
    public static final c c = new c(true, null);
    
    public static final c d = new c(false, null);
    
    public final boolean a;
    
    public final Throwable b;
    
    static {
    
    }
    
    public c(boolean param1Boolean, Throwable param1Throwable) {
      this.a = param1Boolean;
      this.b = param1Throwable;
    }
    
    static {
      if (AbstractFuture.i) {
        d = null;
        c = null;
        return;
      } 
    }
  }
  
  public static final class d {
    public static final d d = new d(null, null);
    
    public final Runnable a;
    
    public final Executor b;
    
    public d c;
    
    public d(Runnable param1Runnable, Executor param1Executor) {
      this.a = param1Runnable;
      this.b = param1Executor;
    }
  }
  
  public static final class e extends b {
    public final AtomicReferenceFieldUpdater<AbstractFuture.h, Thread> a;
    
    public final AtomicReferenceFieldUpdater<AbstractFuture.h, AbstractFuture.h> b;
    
    public final AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.h> c;
    
    public final AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.d> d;
    
    public final AtomicReferenceFieldUpdater<AbstractFuture, Object> e;
    
    public e(AtomicReferenceFieldUpdater<AbstractFuture.h, Thread> param1AtomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<AbstractFuture.h, AbstractFuture.h> param1AtomicReferenceFieldUpdater1, AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.h> param1AtomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.d> param1AtomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<AbstractFuture, Object> param1AtomicReferenceFieldUpdater4) {
      super(null);
      this.a = param1AtomicReferenceFieldUpdater;
      this.b = param1AtomicReferenceFieldUpdater1;
      this.c = param1AtomicReferenceFieldUpdater2;
      this.d = param1AtomicReferenceFieldUpdater3;
      this.e = param1AtomicReferenceFieldUpdater4;
    }
    
    public boolean a(AbstractFuture<?> param1AbstractFuture, AbstractFuture.d param1d1, AbstractFuture.d param1d2) {
      return this.d.compareAndSet(param1AbstractFuture, param1d1, param1d2);
    }
    
    public boolean b(AbstractFuture<?> param1AbstractFuture, Object param1Object1, Object param1Object2) {
      return this.e.compareAndSet(param1AbstractFuture, param1Object1, param1Object2);
    }
    
    public boolean c(AbstractFuture<?> param1AbstractFuture, AbstractFuture.h param1h1, AbstractFuture.h param1h2) {
      return this.c.compareAndSet(param1AbstractFuture, param1h1, param1h2);
    }
    
    public void d(AbstractFuture.h param1h1, AbstractFuture.h param1h2) {
      this.b.lazySet(param1h1, param1h2);
    }
    
    public void e(AbstractFuture.h param1h, Thread param1Thread) {
      this.a.lazySet(param1h, param1Thread);
    }
  }
  
  public static final class f<V> implements Runnable {
    public final AbstractFuture<V> f;
    
    public final a<? extends V> g;
    
    public f(AbstractFuture<V> param1AbstractFuture, a<? extends V> param1a) {
      this.f = param1AbstractFuture;
      this.g = param1a;
    }
    
    public void run() {
      if (this.f.f != this)
        return; 
      Object object = AbstractFuture.g(this.g);
      if (AbstractFuture.k.b(this.f, this, object))
        AbstractFuture.d(this.f); 
    }
  }
  
  public static final class g extends b {
    public g() {
      super(null);
    }
    
    public boolean a(AbstractFuture<?> param1AbstractFuture, AbstractFuture.d param1d1, AbstractFuture.d param1d2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield g : Landroidx/work/impl/utils/futures/AbstractFuture$d;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield g : Landroidx/work/impl/utils/futures/AbstractFuture$d;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public boolean b(AbstractFuture<?> param1AbstractFuture, Object param1Object1, Object param1Object2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield f : Ljava/lang/Object;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield f : Ljava/lang/Object;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public boolean c(AbstractFuture<?> param1AbstractFuture, AbstractFuture.h param1h1, AbstractFuture.h param1h2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield h : Landroidx/work/impl/utils/futures/AbstractFuture$h;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield h : Landroidx/work/impl/utils/futures/AbstractFuture$h;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    public void d(AbstractFuture.h param1h1, AbstractFuture.h param1h2) {
      param1h1.b = param1h2;
    }
    
    public void e(AbstractFuture.h param1h, Thread param1Thread) {
      param1h.a = param1Thread;
    }
  }
  
  public static final class h {
    public static final h c = new h(false);
    
    public volatile Thread a;
    
    public volatile h b;
    
    public h() {
      AbstractFuture.k.e(this, Thread.currentThread());
    }
    
    public h(boolean param1Boolean) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\imp\\utils\futures\AbstractFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */