package androidx.work;

import android.content.Context;
import java.util.Collections;
import java.util.List;
import k1.b;
import p1.i;
import p1.n;
import q1.k;

public final class WorkManagerInitializer implements b<n> {
  public static final String a = i.e("WrkMgrInitializer");
  
  public List<Class<? extends b<?>>> a() {
    return Collections.emptyList();
  }
  
  public Object b(Context paramContext) {
    i.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    k.c(paramContext, new a(new a.a()));
    return k.b(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */