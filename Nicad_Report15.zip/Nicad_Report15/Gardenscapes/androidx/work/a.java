package androidx.work;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import p1.g;
import p1.h;
import p1.p;
import p1.q;

public final class a {
  public final Executor a = a(false);
  
  public final Executor b = a(true);
  
  public final q c;
  
  public final h d;
  
  public final q1.a e;
  
  public final int f;
  
  public final int g;
  
  public final int h;
  
  public a(a parama) {
    String str = q.a;
    this.c = (q)new p();
    this.d = (h)new g();
    this.e = new q1.a(0);
    this.f = 4;
    this.g = Integer.MAX_VALUE;
    this.h = 20;
  }
  
  public final Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), (ThreadFactory)new p1.a(this, paramBoolean));
  }
  
  public static final class a {}
  
  public static interface b {
    a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */