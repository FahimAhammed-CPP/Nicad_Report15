package androidx.work;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p1.f;

public final class OverwritingInputMerger extends f {
  public b a(List<b> paramList) {
    b.a a = new b.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<b> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(((b)iterator.next()).b()); 
    a.b((Map)hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */