package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;

public abstract class Worker extends ListenableWorker {
  public a2.a<ListenableWorker.a> mFuture;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final m7.a<ListenableWorker.a> startWork() {
    this.mFuture = new a2.a();
    getBackgroundExecutor().execute(new a(this));
    return (m7.a<ListenableWorker.a>)this.mFuture;
  }
  
  public class a implements Runnable {
    public a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.f.mFuture.l(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */