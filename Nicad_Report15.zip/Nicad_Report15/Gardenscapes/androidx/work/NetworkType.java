package androidx.work;

public enum NetworkType {
  f, g, h, i, j, k;
  
  static {
    NetworkType networkType1 = new NetworkType("NOT_REQUIRED", 0);
    f = networkType1;
    NetworkType networkType2 = new NetworkType("CONNECTED", 1);
    g = networkType2;
    NetworkType networkType3 = new NetworkType("UNMETERED", 2);
    h = networkType3;
    NetworkType networkType4 = new NetworkType("NOT_ROAMING", 3);
    i = networkType4;
    NetworkType networkType5 = new NetworkType("METERED", 4);
    j = networkType5;
    NetworkType networkType6 = new NetworkType("TEMPORARILY_UNMETERED", 5);
    k = networkType6;
    l = new NetworkType[] { networkType1, networkType2, networkType3, networkType4, networkType5, networkType6 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\NetworkType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */