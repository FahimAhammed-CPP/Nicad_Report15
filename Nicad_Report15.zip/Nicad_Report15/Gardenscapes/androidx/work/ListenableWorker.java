package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import p1.d;
import p1.e;
import p1.l;
import p1.q;
import z1.o;
import z1.p;
import z1.q;

public abstract class ListenableWorker {
  private Context mAppContext;
  
  private boolean mRunInForeground;
  
  private volatile boolean mStopped;
  
  private boolean mUsed;
  
  private WorkerParameters mWorkerParams;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.mAppContext = paramContext;
        this.mWorkerParams = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.mAppContext;
  }
  
  public Executor getBackgroundExecutor() {
    return this.mWorkerParams.f;
  }
  
  public m7.a<d> getForegroundInfoAsync() {
    a2.a a = new a2.a();
    a.l(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (m7.a<d>)a;
  }
  
  public final UUID getId() {
    return this.mWorkerParams.a;
  }
  
  public final b getInputData() {
    return this.mWorkerParams.b;
  }
  
  public final Network getNetwork() {
    return this.mWorkerParams.d.c;
  }
  
  public final int getRunAttemptCount() {
    return this.mWorkerParams.e;
  }
  
  public final Set<String> getTags() {
    return this.mWorkerParams.c;
  }
  
  public b2.a getTaskExecutor() {
    return this.mWorkerParams.g;
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return this.mWorkerParams.d.a;
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return this.mWorkerParams.d.b;
  }
  
  public q getWorkerFactory() {
    return this.mWorkerParams.h;
  }
  
  public boolean isRunInForeground() {
    return this.mRunInForeground;
  }
  
  public final boolean isStopped() {
    return this.mStopped;
  }
  
  public final boolean isUsed() {
    return this.mUsed;
  }
  
  public void onStopped() {}
  
  public final m7.a<Void> setForegroundAsync(d paramd) {
    this.mRunInForeground = true;
    e e = this.mWorkerParams.j;
    Context context = getApplicationContext();
    UUID uUID = getId();
    return ((o)e).a(context, uUID, paramd);
  }
  
  public m7.a<Void> setProgressAsync(b paramb) {
    l l = this.mWorkerParams.i;
    getApplicationContext();
    UUID uUID = getId();
    q q = (q)l;
    Objects.requireNonNull(q);
    a2.a a = new a2.a();
    b2.a a1 = q.b;
    p p = new p(q, uUID, paramb, a);
    ((b2.b)a1).a.execute((Runnable)p);
    return (m7.a<Void>)a;
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.mRunInForeground = paramBoolean;
  }
  
  public final void setUsed() {
    this.mUsed = true;
  }
  
  public abstract m7.a<a> startWork();
  
  public final void stop() {
    this.mStopped = true;
    onStopped();
  }
  
  public static abstract class a {
    public static final class a extends a {
      public final b a;
      
      public a() {
        this.a = b1;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || a.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((a)param2Object).a);
      }
      
      public int hashCode() {
        int i = a.class.getName().hashCode();
        return this.a.hashCode() + i * 31;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.a.a("Failure {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    public static final class b extends a {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && b.class == param2Object.getClass()));
      }
      
      public int hashCode() {
        return b.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    public static final class c extends a {
      public final b a;
      
      public c() {
        this.a = b1;
      }
      
      public c(b param2b) {
        this.a = param2b;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || c.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((c)param2Object).a);
      }
      
      public int hashCode() {
        int i = c.class.getName().hashCode();
        return this.a.hashCode() + i * 31;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.a.a("Success {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  public static final class a extends a {
    public final b a;
    
    public a() {
      this.a = b1;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || a.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((a)param1Object).a);
    }
    
    public int hashCode() {
      int i = a.class.getName().hashCode();
      return this.a.hashCode() + i * 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("Failure {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends a {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && b.class == param1Object.getClass()));
    }
    
    public int hashCode() {
      return b.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  public static final class c extends a {
    public final b a;
    
    public c() {
      this.a = b1;
    }
    
    public c(b param1b) {
      this.a = param1b;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || c.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      int i = c.class.getName().hashCode();
      return this.a.hashCode() + i * 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("Success {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */