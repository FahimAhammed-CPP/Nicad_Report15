package androidx.startup;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import java.util.HashSet;
import java.util.Objects;
import k1.a;
import k1.b;

public final class InitializationProvider extends ContentProvider {
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public boolean onCreate() {
    Context context = getContext();
    if (context != null) {
      a a = a.b(context);
      Objects.requireNonNull(a);
      try {
        Trace.beginSection("Startup");
        ComponentName componentName = new ComponentName(a.c.getPackageName(), InitializationProvider.class.getName());
        Bundle bundle = (a.c.getPackageManager().getProviderInfo(componentName, 128)).metaData;
        String str = a.c.getString(2131755038);
        if (bundle != null) {
          HashSet hashSet = new HashSet();
          for (String str1 : bundle.keySet()) {
            if (str.equals(bundle.getString(str1, null))) {
              Class<?> clazz = Class.forName(str1);
              if (b.class.isAssignableFrom(clazz)) {
                a.b.add(clazz);
                a.a(clazz, hashSet);
              } 
            } 
          } 
        } 
        Trace.endSection();
        return true;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      
      } catch (ClassNotFoundException classNotFoundException) {
      
      } finally {}
      throw new StartupException(a);
    } 
    StartupException startupException = new StartupException("Context cannot be null");
    throw startupException;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */