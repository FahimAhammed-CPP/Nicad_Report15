package androidx.viewpager2.adapter;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;

class FragmentStateAdapter$5 implements h {
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent != Lifecycle.Event.ON_DESTROY)
      return; 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */