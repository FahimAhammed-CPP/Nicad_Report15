package androidx.viewpager2.adapter;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;

class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements h {
  public void a(j paramj, Lifecycle.Event paramEvent) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */