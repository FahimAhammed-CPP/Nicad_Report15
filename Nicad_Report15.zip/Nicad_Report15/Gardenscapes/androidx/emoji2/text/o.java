package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import l0.e;

public final class o extends SpannableStringBuilder {
  public final Class<?> f;
  
  public final List<a> g = new ArrayList<a>();
  
  public o(Class<?> paramClass, CharSequence paramCharSequence) {
    super(paramCharSequence);
    e.d(paramClass, "watcherClass cannot be null");
    this.f = paramClass;
  }
  
  public o(Class<?> paramClass, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super(paramCharSequence, paramInt1, paramInt2);
    e.d(paramClass, "watcherClass cannot be null");
    this.f = paramClass;
  }
  
  public final void a() {
    for (int i = 0; i < this.g.size(); i++)
      ((a)this.g.get(i)).g.incrementAndGet(); 
  }
  
  public Editable append(char paramChar) {
    super.append(paramChar);
    return (Editable)this;
  }
  
  public Editable append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence) {
    super.append(paramCharSequence);
    return (Editable)this;
  }
  
  public Editable append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super.append(paramCharSequence, paramInt1, paramInt2);
    return (Editable)this;
  }
  
  public SpannableStringBuilder append(char paramChar) {
    super.append(paramChar);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence) {
    super.append(paramCharSequence);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super.append(paramCharSequence, paramInt1, paramInt2);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder append(CharSequence paramCharSequence, Object paramObject, int paramInt) {
    super.append(paramCharSequence, paramObject, paramInt);
    return this;
  }
  
  public Appendable append(char paramChar) {
    super.append(paramChar);
    return (Appendable)this;
  }
  
  public Appendable append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence) {
    super.append(paramCharSequence);
    return (Appendable)this;
  }
  
  public Appendable append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super.append(paramCharSequence, paramInt1, paramInt2);
    return (Appendable)this;
  }
  
  public void b() {
    e();
    for (int i = 0; i < this.g.size(); i++) {
      a a = this.g.get(i);
      int j = length();
      int k = length();
      ((TextWatcher)a.f).onTextChanged((CharSequence)this, 0, j, k);
    } 
  }
  
  public final a c(Object paramObject) {
    for (int i = 0; i < this.g.size(); i++) {
      a a = this.g.get(i);
      if (a.f == paramObject)
        return a; 
    } 
    return null;
  }
  
  public final boolean d(Object<?> paramObject) {
    if (paramObject != null) {
      boolean bool;
      paramObject = (Object<?>)paramObject.getClass();
      if (this.f == paramObject) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  @SuppressLint({"UnknownNullness"})
  public Editable delete(int paramInt1, int paramInt2) {
    super.delete(paramInt1, paramInt2);
    return (Editable)this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder delete(int paramInt1, int paramInt2) {
    super.delete(paramInt1, paramInt2);
    return this;
  }
  
  public final void e() {
    for (int i = 0; i < this.g.size(); i++)
      ((a)this.g.get(i)).g.decrementAndGet(); 
  }
  
  public int getSpanEnd(Object paramObject) {
    Object object = paramObject;
    if (d(paramObject)) {
      a a = c(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanEnd(object);
  }
  
  public int getSpanFlags(Object paramObject) {
    Object object = paramObject;
    if (d(paramObject)) {
      a a = c(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanFlags(object);
  }
  
  public int getSpanStart(Object paramObject) {
    Object object = paramObject;
    if (d(paramObject)) {
      a a = c(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanStart(object);
  }
  
  @SuppressLint({"UnknownNullness"})
  public <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass) {
    Object[] arrayOfObject;
    boolean bool1;
    Class<?> clazz = this.f;
    boolean bool2 = false;
    if (clazz == paramClass) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      a[] arrayOfA = (a[])super.getSpans(paramInt1, paramInt2, a.class);
      arrayOfObject = (Object[])Array.newInstance(paramClass, arrayOfA.length);
      for (paramInt1 = bool2; paramInt1 < arrayOfA.length; paramInt1++)
        arrayOfObject[paramInt1] = (arrayOfA[paramInt1]).f; 
      return (T[])arrayOfObject;
    } 
    return (T[])super.getSpans(paramInt1, paramInt2, (Class)arrayOfObject);
  }
  
  @SuppressLint({"UnknownNullness"})
  public Editable insert(int paramInt, CharSequence paramCharSequence) {
    super.insert(paramInt, paramCharSequence);
    return (Editable)this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public Editable insert(int paramInt1, CharSequence paramCharSequence, int paramInt2, int paramInt3) {
    super.insert(paramInt1, paramCharSequence, paramInt2, paramInt3);
    return (Editable)this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt, CharSequence paramCharSequence) {
    super.insert(paramInt, paramCharSequence);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt1, CharSequence paramCharSequence, int paramInt2, int paramInt3) {
    super.insert(paramInt1, paramCharSequence, paramInt2, paramInt3);
    return this;
  }
  
  public int nextSpanTransition(int paramInt1, int paramInt2, Class<?> paramClass) {
    if (paramClass != null) {
      boolean bool;
      if (this.f == paramClass) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        paramClass = a.class;
        return super.nextSpanTransition(paramInt1, paramInt2, paramClass);
      } 
      return super.nextSpanTransition(paramInt1, paramInt2, paramClass);
    } 
    paramClass = a.class;
    return super.nextSpanTransition(paramInt1, paramInt2, paramClass);
  }
  
  public void removeSpan(Object paramObject) {
    Object object;
    if (d(paramObject)) {
      a a = c(paramObject);
      object = a;
      if (a != null) {
        paramObject = a;
        object = a;
      } 
    } else {
      object = null;
    } 
    super.removeSpan(paramObject);
    if (object != null)
      this.g.remove(object); 
  }
  
  @SuppressLint({"UnknownNullness"})
  public Editable replace(int paramInt1, int paramInt2, CharSequence paramCharSequence) {
    a();
    super.replace(paramInt1, paramInt2, paramCharSequence);
    e();
    return (Editable)this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public Editable replace(int paramInt1, int paramInt2, CharSequence paramCharSequence, int paramInt3, int paramInt4) {
    a();
    super.replace(paramInt1, paramInt2, paramCharSequence, paramInt3, paramInt4);
    e();
    return (Editable)this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence) {
    a();
    super.replace(paramInt1, paramInt2, paramCharSequence);
    e();
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence, int paramInt3, int paramInt4) {
    a();
    super.replace(paramInt1, paramInt2, paramCharSequence, paramInt3, paramInt4);
    e();
    return this;
  }
  
  public void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
    Object object = paramObject;
    if (d(paramObject)) {
      object = new a(paramObject);
      this.g.add(object);
    } 
    super.setSpan(object, paramInt1, paramInt2, paramInt3);
  }
  
  @SuppressLint({"UnknownNullness"})
  public CharSequence subSequence(int paramInt1, int paramInt2) {
    return (CharSequence)new o(this.f, (CharSequence)this, paramInt1, paramInt2);
  }
  
  public static class a implements TextWatcher, SpanWatcher {
    public final Object f;
    
    public final AtomicInteger g = new AtomicInteger(0);
    
    public a(Object param1Object) {
      this.f = param1Object;
    }
    
    public void afterTextChanged(Editable param1Editable) {
      ((TextWatcher)this.f).afterTextChanged(param1Editable);
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.f).beforeTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
    
    public void onSpanAdded(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.g.get() > 0 && param1Object instanceof i)
        return; 
      ((SpanWatcher)this.f).onSpanAdded(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onSpanChanged(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.g.get() > 0 && param1Object instanceof i)
        return; 
      ((SpanWatcher)this.f).onSpanChanged(param1Spannable, param1Object, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void onSpanRemoved(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.g.get() > 0 && param1Object instanceof i)
        return; 
      ((SpanWatcher)this.f).onSpanRemoved(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.f).onTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */