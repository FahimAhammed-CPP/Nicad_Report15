package androidx.emoji2.text;

import a6.h;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.appsflyer.internal.AFb1xSDK;
import com.facebook.bolts.CancellationToken;
import com.facebook.bolts.Task;
import com.facebook.bolts.TaskCompletionSource;
import com.facebook.login.CustomTabLoginMethodHandler;
import com.facebook.login.LoginClient;
import com.facebook.login.NativeAppLoginMethodHandler;
import g8.i;
import io.sentry.SentryLevel;
import io.sentry.android.core.b;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadPoolExecutor;
import m9.o;



/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */