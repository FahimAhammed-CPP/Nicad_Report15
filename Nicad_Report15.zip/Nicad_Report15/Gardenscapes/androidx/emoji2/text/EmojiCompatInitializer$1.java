package androidx.emoji2.text;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.c;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import java.util.Objects;

class EmojiCompatInitializer$1 implements DefaultLifecycleObserver {
  public EmojiCompatInitializer$1(EmojiCompatInitializer paramEmojiCompatInitializer, Lifecycle paramLifecycle) {}
  
  public void onResume(j paramj) {
    Objects.requireNonNull(this.g);
    b.b().postDelayed(new EmojiCompatInitializer.c(), 500L);
    k k = (k)this.f;
    k.d("removeObserver");
    k.a.j(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */