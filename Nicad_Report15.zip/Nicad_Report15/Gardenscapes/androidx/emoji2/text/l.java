package androidx.emoji2.text;

import com.facebook.appevents.codeless.CodelessMatcher;
import com.google.firebase.messaging.FirebaseMessaging;
import com.swrve.sdk.SwrveBase;



/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */