package androidx.emoji2.text;

import android.content.Context;
import android.os.Trace;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import i0.h;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;
import k1.b;

public class EmojiCompatInitializer implements b<Boolean> {
  public List<Class<? extends b<?>>> a() {
    return (List)Collections.singletonList(ProcessLifecycleInitializer.class);
  }
  
  public Boolean c(Context paramContext) {
    a a1 = new a(paramContext);
    if (d.k == null)
      synchronized (d.j) {
        if (d.k == null)
          d.k = new d(a1); 
      }  
    k1.a a = k1.a.b(paramContext);
    Objects.requireNonNull(a);
    Lifecycle lifecycle = ((j)a.a(ProcessLifecycleInitializer.class, new HashSet())).getLifecycle();
    lifecycle.a((i)new EmojiCompatInitializer$1(this, lifecycle));
    return Boolean.TRUE;
  }
  
  public static class a extends d.c {
    public a(Context param1Context) {
      super(new EmojiCompatInitializer.b(param1Context));
      this.b = 1;
    }
  }
  
  public static class b implements d.g {
    public final Context a;
    
    public b(Context param1Context) {
      this.a = param1Context.getApplicationContext();
    }
    
    public void a(d.h param1h) {
      ThreadPoolExecutor threadPoolExecutor = b.a("EmojiCompatInitializer");
      threadPoolExecutor.execute(new e(this, param1h, threadPoolExecutor));
    }
  }
  
  public static class c implements Runnable {
    public void run() {
      try {
        int i = h.a;
        Trace.beginSection("EmojiCompat.EmojiCompatInitializer.run");
        return;
      } finally {
        int i = h.a;
        Trace.endSection();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */