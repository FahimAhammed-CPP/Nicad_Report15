package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.os.Handler;
import j0.e;
import j0.f;
import j0.l;
import j0.m;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import l0.e;

public class j extends d.c {
  public static final a d = new a();
  
  public j(Context paramContext, f paramf) {
    super(new b(paramContext, paramf, d));
  }
  
  public static class a {}
  
  public static class b implements d.g {
    public final Context a;
    
    public final f b;
    
    public final j.a c;
    
    public final Object d = new Object();
    
    public Handler e;
    
    public Executor f;
    
    public ThreadPoolExecutor g;
    
    public d.h h;
    
    public ContentObserver i;
    
    public Runnable j;
    
    public b(Context param1Context, f param1f, j.a param1a) {
      e.d(param1Context, "Context cannot be null");
      e.d(param1f, "FontRequest cannot be null");
      this.a = param1Context.getApplicationContext();
      this.b = param1f;
      this.c = param1a;
    }
    
    public void a(d.h param1h) {
      synchronized (this.d) {
        this.h = param1h;
        c();
        return;
      } 
    }
    
    public final void b() {
      synchronized (this.d) {
        this.h = null;
        ContentObserver contentObserver = this.i;
        if (contentObserver != null) {
          j.a a1 = this.c;
          Context context = this.a;
          Objects.requireNonNull(a1);
          context.getContentResolver().unregisterContentObserver(contentObserver);
          this.i = null;
        } 
        Handler handler = this.e;
        if (handler != null)
          handler.removeCallbacks(this.j); 
        this.e = null;
        ThreadPoolExecutor threadPoolExecutor = this.g;
        if (threadPoolExecutor != null)
          threadPoolExecutor.shutdown(); 
        this.f = null;
        this.g = null;
        return;
      } 
    }
    
    public void c() {
      synchronized (this.d) {
        if (this.h == null)
          return; 
        if (this.f == null) {
          ThreadPoolExecutor threadPoolExecutor = b.a("emojiCompat");
          this.g = threadPoolExecutor;
          this.f = threadPoolExecutor;
        } 
        this.f.execute(new k(this));
        return;
      } 
    }
    
    public final m d() {
      try {
        m[] arrayOfM;
        j.a a1 = this.c;
        Context context = this.a;
        f f1 = this.b;
        Objects.requireNonNull(a1);
        l l = e.a(context, f1, null);
        if (l.a == 0) {
          arrayOfM = l.b;
          if (arrayOfM != null && arrayOfM.length != 0)
            return arrayOfM[0]; 
          throw new RuntimeException("fetchFonts failed (empty result)");
        } 
        StringBuilder stringBuilder = android.support.v4.media.a.a("fetchFonts failed (");
        stringBuilder.append(((l)arrayOfM).a);
        stringBuilder.append(")");
        throw new RuntimeException(stringBuilder.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new RuntimeException("provider not found", nameNotFoundException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */