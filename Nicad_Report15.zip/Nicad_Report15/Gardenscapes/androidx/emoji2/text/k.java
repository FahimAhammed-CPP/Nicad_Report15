package androidx.emoji2.text;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Trace;
import com.facebook.appevents.codeless.CodelessManager;
import e0.e;
import e0.l;
import i0.h;
import j0.m;
import java.nio.ByteBuffer;
import java.util.Objects;



/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */