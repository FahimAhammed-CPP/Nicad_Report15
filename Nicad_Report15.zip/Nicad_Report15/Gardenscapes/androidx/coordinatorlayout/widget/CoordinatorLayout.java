package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.g0;
import m0.l;
import m0.m;
import m0.o;
import m0.p;
import m0.y;

public class CoordinatorLayout extends ViewGroup implements l, m {
  public static final ThreadLocal<Map<String, Constructor<c>>> A;
  
  public static final Comparator<View> B;
  
  public static final u.a<Rect> C;
  
  public static final String y;
  
  public static final Class<?>[] z = new Class[] { Context.class, AttributeSet.class };
  
  public final List<View> f = new ArrayList<View>();
  
  public final w1.g g = new w1.g();
  
  public final List<View> h = new ArrayList<View>();
  
  public final List<View> i = new ArrayList<View>();
  
  public final int[] j = new int[2];
  
  public final int[] k = new int[2];
  
  public boolean l;
  
  public boolean m;
  
  public int[] n;
  
  public View o;
  
  public View p;
  
  public g q;
  
  public boolean r;
  
  public g0 s;
  
  public boolean t;
  
  public Drawable u;
  
  public ViewGroup.OnHierarchyChangeListener v;
  
  public p w;
  
  public final o x;
  
  static {
    A = new ThreadLocal<Map<String, Constructor<c>>>();
    C = (u.a<Rect>)new l0.d(12);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903318);
    int i = 0;
    this.x = new o(0);
    int[] arrayOfInt = y.b.a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 2130903318, 0);
    if (Build.VERSION.SDK_INT >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt, paramAttributeSet, typedArray, 2130903318, 0); 
    int j = typedArray.getResourceId(0, 0);
    if (j != 0) {
      Resources resources = paramContext.getResources();
      this.n = resources.getIntArray(j);
      float f = (resources.getDisplayMetrics()).density;
      j = this.n.length;
      while (i < j) {
        int[] arrayOfInt1 = this.n;
        arrayOfInt1[i] = (int)(arrayOfInt1[i] * f);
        i++;
      } 
    } 
    this.u = typedArray.getDrawable(1);
    typedArray.recycle();
    y();
    super.setOnHierarchyChangeListener(new e(this));
    WeakHashMap weakHashMap = y.a;
    if (y.d.c((View)this) == 0)
      y.d.s((View)this, 1); 
  }
  
  public static Rect a() {
    Rect rect2 = (Rect)C.a();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  public final void b(f paramf, Rect paramRect, int paramInt1, int paramInt2) {
    int j = getWidth();
    int i = getHeight();
    j = Math.max(getPaddingLeft() + paramf.leftMargin, Math.min(paramRect.left, j - getPaddingRight() - paramInt1 - paramf.rightMargin));
    i = Math.max(getPaddingTop() + paramf.topMargin, Math.min(paramRect.top, i - getPaddingBottom() - paramInt2 - paramf.bottomMargin));
    paramRect.set(j, i, paramInt1 + j, paramInt2 + i);
  }
  
  public void c(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      f(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  public List<View> d(View paramView) {
    w1.g g1 = this.g;
    int j = ((s.h)g1.g).h;
    ArrayList<Object> arrayList = null;
    int i = 0;
    while (i < j) {
      ArrayList arrayList2 = (ArrayList)((s.h)g1.g).k(i);
      ArrayList<Object> arrayList1 = arrayList;
      if (arrayList2 != null) {
        arrayList1 = arrayList;
        if (arrayList2.contains(paramView)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(((s.h)g1.g).h(i));
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    this.i.clear();
    if (arrayList != null)
      this.i.addAll(arrayList); 
    return this.i;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    c c = ((f)paramView.getLayoutParams()).a;
    if (c != null)
      Objects.requireNonNull(c); 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.u;
    byte b = 0;
    int i = b;
    if (drawable != null) {
      i = b;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  public List<View> e(View paramView) {
    List<? extends View> list = (List)((s.h)this.g.g).getOrDefault(paramView, null);
    this.i.clear();
    if (list != null)
      this.i.addAll(list); 
    return this.i;
  }
  
  public void f(View paramView, Rect paramRect) {
    ThreadLocal threadLocal = z.a.a;
    paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
    ThreadLocal<Matrix> threadLocal1 = z.a.a;
    Matrix matrix = threadLocal1.get();
    if (matrix == null) {
      matrix = new Matrix();
      threadLocal1.set(matrix);
    } else {
      matrix.reset();
    } 
    z.a.a((ViewParent)this, paramView, matrix);
    ThreadLocal<RectF> threadLocal2 = z.a.b;
    RectF rectF2 = threadLocal2.get();
    RectF rectF1 = rectF2;
    if (rectF2 == null) {
      rectF1 = new RectF();
      threadLocal2.set(rectF1);
    } 
    rectF1.set(paramRect);
    matrix.mapRect(rectF1);
    paramRect.set((int)(rectF1.left + 0.5F), (int)(rectF1.top + 0.5F), (int)(rectF1.right + 0.5F), (int)(rectF1.bottom + 0.5F));
  }
  
  public final void g(int paramInt1, Rect paramRect1, Rect paramRect2, f paramf, int paramInt2, int paramInt3) {
    int j = paramf.c;
    int i = j;
    if (j == 0)
      i = 17; 
    int k = Gravity.getAbsoluteGravity(i, paramInt1);
    j = paramf.d;
    i = j;
    if ((j & 0x7) == 0)
      i = j | 0x800003; 
    j = i;
    if ((i & 0x70) == 0)
      j = i | 0x30; 
    paramInt1 = Gravity.getAbsoluteGravity(j, paramInt1);
    int n = k & 0x7;
    k &= 0x70;
    j = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (j != 1) {
      if (j != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (n != 1) {
      j = paramInt1;
      if (n != 5)
        j = paramInt1 - paramInt2; 
    } else {
      j = paramInt1 - paramInt2 / 2;
    } 
    if (k != 16) {
      paramInt1 = i;
      if (k != 80)
        paramInt1 = i - paramInt3; 
    } else {
      paramInt1 = i - paramInt3 / 2;
    } 
    paramRect2.set(j, paramInt1, paramInt2 + j, paramInt3 + paramInt1);
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new f(-2, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new f(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams)));
  }
  
  public final List<View> getDependencySortedChildren() {
    u();
    return Collections.unmodifiableList(this.f);
  }
  
  public final g0 getLastWindowInsets() {
    return this.s;
  }
  
  public int getNestedScrollAxes() {
    return this.x.a();
  }
  
  public Drawable getStatusBarBackground() {
    return this.u;
  }
  
  public int getSuggestedMinimumHeight() {
    int i = super.getSuggestedMinimumHeight();
    int j = getPaddingTop();
    return Math.max(i, getPaddingBottom() + j);
  }
  
  public int getSuggestedMinimumWidth() {
    int i = super.getSuggestedMinimumWidth();
    int j = getPaddingLeft();
    return Math.max(i, getPaddingRight() + j);
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    o o1 = this.x;
    if (paramInt2 == 1) {
      o1.b = paramInt1;
    } else {
      o1.a = paramInt1;
    } 
    this.p = paramView2;
    int i = getChildCount();
    for (paramInt1 = 0; paramInt1 < i; paramInt1++)
      ((f)getChildAt(paramInt1).getLayoutParams()).a(paramInt2); 
  }
  
  public void i(View paramView, int paramInt) {
    o o1 = this.x;
    if (paramInt == 1) {
      o1.b = 0;
    } else {
      o1.a = 0;
    } 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = (f)view.getLayoutParams();
      if (f.a(paramInt)) {
        c<View> c = f.a;
        if (c != null)
          c.q(this, view, paramView, paramInt); 
        f.b(paramInt, false);
        f.p = false;
      } 
    } 
    this.p = null;
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int n = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < n; j = i1) {
      int i1;
      int i2;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i2 = k;
        i1 = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt3)) {
          i2 = k;
          i1 = j;
        } else {
          c<View> c = f.a;
          i2 = k;
          i1 = j;
          if (c != null) {
            int[] arrayOfInt2 = this.j;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.k(this, view, paramView, paramInt1, paramInt2, arrayOfInt2, paramInt3);
            int[] arrayOfInt1 = this.j;
            if (paramInt1 > 0) {
              i1 = Math.max(k, arrayOfInt1[0]);
            } else {
              i1 = Math.min(k, arrayOfInt1[0]);
            } 
            k = i1;
            arrayOfInt1 = this.j;
            if (paramInt2 > 0) {
              i1 = Math.max(j, arrayOfInt1[1]);
            } else {
              i1 = Math.min(j, arrayOfInt1[1]);
            } 
            bool = true;
            i2 = k;
          } 
        } 
      } 
      i++;
      k = i2;
    } 
    paramArrayOfint[0] = k;
    paramArrayOfint[1] = j;
    if (bool)
      q(1); 
  }
  
  public final int k(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.n;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  public f l(View paramView) {
    f f = (f)paramView.getLayoutParams();
    if (!f.b) {
      d d;
      if (paramView instanceof b) {
        c = ((b)paramView).getBehavior();
        if (c == null)
          Log.e("CoordinatorLayout", "Attached behavior class is null"); 
        c c1 = f.a;
        if (c1 != c) {
          if (c1 != null)
            c1.f(); 
          f.a = c;
          f.b = true;
          if (c != null)
            c.c(f); 
        } 
        f.b = true;
        return f;
      } 
      Class<?> clazz = c.getClass();
      c c = null;
      while (clazz != null) {
        d d1 = clazz.<d>getAnnotation(d.class);
        d = d1;
        if (d1 == null) {
          clazz = clazz.getSuperclass();
          d = d1;
        } 
      } 
      if (d != null)
        try {
          c c1 = d.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
          c c2 = f.a;
          if (c2 != c1) {
            if (c2 != null)
              c2.f(); 
            f.a = c1;
            f.b = true;
            if (c1 != null)
              c1.c(f); 
          } 
        } catch (Exception exception) {
          StringBuilder stringBuilder = android.support.v4.media.a.a("Default behavior class ");
          stringBuilder.append(d.value().getName());
          stringBuilder.append(" could not be instantiated. Did you forget a default constructor?");
          Log.e("CoordinatorLayout", stringBuilder.toString(), exception);
        }  
      f.b = true;
    } 
    return f;
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int n = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < n; j = i1) {
      int i1;
      int i2;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i2 = k;
        i1 = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt5)) {
          i2 = k;
          i1 = j;
        } else {
          c<View> c = f.a;
          i2 = k;
          i1 = j;
          if (c != null) {
            int[] arrayOfInt2 = this.j;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.l(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, arrayOfInt2);
            int[] arrayOfInt1 = this.j;
            if (paramInt3 > 0) {
              i1 = Math.max(k, arrayOfInt1[0]);
            } else {
              i1 = Math.min(k, arrayOfInt1[0]);
            } 
            k = i1;
            if (paramInt4 > 0) {
              i1 = Math.max(j, this.j[1]);
            } else {
              i1 = Math.min(j, this.j[1]);
            } 
            bool = true;
            i2 = k;
          } 
        } 
      } 
      i++;
      k = i2;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + k;
    paramArrayOfint[1] = paramArrayOfint[1] + j;
    if (bool)
      q(1); 
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    m(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.k);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int j = getChildCount();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        c<View> c = f.a;
        if (c != null) {
          boolean bool1 = c.p(this, view, paramView1, paramView2, paramInt1, paramInt2);
          bool |= bool1;
          f.b(paramInt2, bool1);
        } else {
          f.b(paramInt2, false);
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    v(false);
    if (this.r) {
      if (this.q == null)
        this.q = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.q);
    } 
    if (this.s == null) {
      WeakHashMap weakHashMap = y.a;
      if (y.d.b((View)this))
        y.y((View)this); 
    } 
    this.m = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    v(false);
    if (this.r && this.q != null)
      getViewTreeObserver().removeOnPreDrawListener(this.q); 
    View view = this.p;
    if (view != null)
      onStopNestedScroll(view); 
    this.m = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.t && this.u != null) {
      boolean bool;
      g0 g01 = this.s;
      if (g01 != null) {
        bool = g01.d();
      } else {
        bool = false;
      } 
      if (bool) {
        this.u.setBounds(0, 0, getWidth(), bool);
        this.u.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      v(true); 
    boolean bool = t(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      v(true); 
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WeakHashMap weakHashMap = y.a;
    paramInt2 = y.e.d((View)this);
    paramInt3 = this.f.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = this.f.get(paramInt1);
      if (view.getVisibility() != 8) {
        c<View> c = ((f)view.getLayoutParams()).a;
        if (c == null || !c.h(this, view, paramInt2))
          r(view, paramInt2); 
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual u : ()V
    //   4: aload_0
    //   5: invokevirtual getChildCount : ()I
    //   8: istore #5
    //   10: iconst_0
    //   11: istore_3
    //   12: iload_3
    //   13: iload #5
    //   15: if_icmpge -> 123
    //   18: aload_0
    //   19: iload_3
    //   20: invokevirtual getChildAt : (I)Landroid/view/View;
    //   23: astore #26
    //   25: aload_0
    //   26: getfield g : Lw1/g;
    //   29: astore #27
    //   31: aload #27
    //   33: getfield g : Ljava/lang/Object;
    //   36: checkcast s/h
    //   39: getfield h : I
    //   42: istore #6
    //   44: iconst_0
    //   45: istore #4
    //   47: iload #4
    //   49: iload #6
    //   51: if_icmpge -> 102
    //   54: aload #27
    //   56: getfield g : Ljava/lang/Object;
    //   59: checkcast s/h
    //   62: iload #4
    //   64: invokevirtual k : (I)Ljava/lang/Object;
    //   67: checkcast java/util/ArrayList
    //   70: astore #28
    //   72: aload #28
    //   74: ifnull -> 93
    //   77: aload #28
    //   79: aload #26
    //   81: invokevirtual contains : (Ljava/lang/Object;)Z
    //   84: ifeq -> 93
    //   87: iconst_1
    //   88: istore #4
    //   90: goto -> 105
    //   93: iload #4
    //   95: iconst_1
    //   96: iadd
    //   97: istore #4
    //   99: goto -> 47
    //   102: iconst_0
    //   103: istore #4
    //   105: iload #4
    //   107: ifeq -> 116
    //   110: iconst_1
    //   111: istore #25
    //   113: goto -> 126
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: istore_3
    //   120: goto -> 12
    //   123: iconst_0
    //   124: istore #25
    //   126: iload #25
    //   128: aload_0
    //   129: getfield r : Z
    //   132: if_icmpeq -> 215
    //   135: iload #25
    //   137: ifeq -> 185
    //   140: aload_0
    //   141: getfield m : Z
    //   144: ifeq -> 177
    //   147: aload_0
    //   148: getfield q : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   151: ifnonnull -> 166
    //   154: aload_0
    //   155: new androidx/coordinatorlayout/widget/CoordinatorLayout$g
    //   158: dup
    //   159: aload_0
    //   160: invokespecial <init> : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    //   163: putfield q : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   166: aload_0
    //   167: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   170: aload_0
    //   171: getfield q : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   174: invokevirtual addOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   177: aload_0
    //   178: iconst_1
    //   179: putfield r : Z
    //   182: goto -> 215
    //   185: aload_0
    //   186: getfield m : Z
    //   189: ifeq -> 210
    //   192: aload_0
    //   193: getfield q : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   196: ifnull -> 210
    //   199: aload_0
    //   200: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   203: aload_0
    //   204: getfield q : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   207: invokevirtual removeOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   210: aload_0
    //   211: iconst_0
    //   212: putfield r : Z
    //   215: aload_0
    //   216: invokevirtual getPaddingLeft : ()I
    //   219: istore #13
    //   221: aload_0
    //   222: invokevirtual getPaddingTop : ()I
    //   225: istore #15
    //   227: aload_0
    //   228: invokevirtual getPaddingRight : ()I
    //   231: istore #16
    //   233: aload_0
    //   234: invokevirtual getPaddingBottom : ()I
    //   237: istore #17
    //   239: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   242: astore #26
    //   244: aload_0
    //   245: invokestatic d : (Landroid/view/View;)I
    //   248: istore #18
    //   250: iload #18
    //   252: iconst_1
    //   253: if_icmpne -> 262
    //   256: iconst_1
    //   257: istore #5
    //   259: goto -> 265
    //   262: iconst_0
    //   263: istore #5
    //   265: iload_1
    //   266: invokestatic getMode : (I)I
    //   269: istore #19
    //   271: iload_1
    //   272: invokestatic getSize : (I)I
    //   275: istore #20
    //   277: iload_2
    //   278: invokestatic getMode : (I)I
    //   281: istore #21
    //   283: iload_2
    //   284: invokestatic getSize : (I)I
    //   287: istore #22
    //   289: aload_0
    //   290: invokevirtual getSuggestedMinimumWidth : ()I
    //   293: istore #11
    //   295: aload_0
    //   296: invokevirtual getSuggestedMinimumHeight : ()I
    //   299: istore #10
    //   301: aload_0
    //   302: getfield s : Lm0/g0;
    //   305: ifnull -> 321
    //   308: aload_0
    //   309: invokestatic b : (Landroid/view/View;)Z
    //   312: ifeq -> 321
    //   315: iconst_1
    //   316: istore #6
    //   318: goto -> 324
    //   321: iconst_0
    //   322: istore #6
    //   324: aload_0
    //   325: getfield f : Ljava/util/List;
    //   328: invokeinterface size : ()I
    //   333: istore #7
    //   335: iconst_0
    //   336: istore_3
    //   337: iconst_0
    //   338: istore #8
    //   340: iload #13
    //   342: istore #4
    //   344: iload #4
    //   346: istore #9
    //   348: iload #8
    //   350: iload #7
    //   352: if_icmpge -> 748
    //   355: aload_0
    //   356: getfield f : Ljava/util/List;
    //   359: iload #8
    //   361: invokeinterface get : (I)Ljava/lang/Object;
    //   366: checkcast android/view/View
    //   369: astore #27
    //   371: aload #27
    //   373: invokevirtual getVisibility : ()I
    //   376: bipush #8
    //   378: if_icmpne -> 384
    //   381: goto -> 735
    //   384: aload #27
    //   386: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   389: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   392: astore #26
    //   394: aload #26
    //   396: getfield e : I
    //   399: istore #4
    //   401: iload #4
    //   403: iflt -> 530
    //   406: iload #19
    //   408: ifeq -> 530
    //   411: aload_0
    //   412: iload #4
    //   414: invokevirtual k : (I)I
    //   417: istore #14
    //   419: aload #26
    //   421: getfield c : I
    //   424: istore #12
    //   426: iload #12
    //   428: istore #4
    //   430: iload #12
    //   432: ifne -> 440
    //   435: ldc_w 8388661
    //   438: istore #4
    //   440: iload #4
    //   442: iload #18
    //   444: invokestatic getAbsoluteGravity : (II)I
    //   447: bipush #7
    //   449: iand
    //   450: istore #4
    //   452: iload #4
    //   454: iconst_3
    //   455: if_icmpne -> 463
    //   458: iload #5
    //   460: ifeq -> 474
    //   463: iload #4
    //   465: iconst_5
    //   466: if_icmpne -> 491
    //   469: iload #5
    //   471: ifeq -> 491
    //   474: iconst_0
    //   475: iload #20
    //   477: iload #16
    //   479: isub
    //   480: iload #14
    //   482: isub
    //   483: invokestatic max : (II)I
    //   486: istore #4
    //   488: goto -> 533
    //   491: iload #4
    //   493: iconst_5
    //   494: if_icmpne -> 502
    //   497: iload #5
    //   499: ifeq -> 513
    //   502: iload #4
    //   504: iconst_3
    //   505: if_icmpne -> 527
    //   508: iload #5
    //   510: ifeq -> 527
    //   513: iconst_0
    //   514: iload #14
    //   516: iload #9
    //   518: isub
    //   519: invokestatic max : (II)I
    //   522: istore #4
    //   524: goto -> 533
    //   527: goto -> 530
    //   530: iconst_0
    //   531: istore #4
    //   533: iload_3
    //   534: istore #14
    //   536: iload #6
    //   538: ifeq -> 615
    //   541: aload #27
    //   543: invokestatic b : (Landroid/view/View;)Z
    //   546: ifne -> 615
    //   549: aload_0
    //   550: getfield s : Lm0/g0;
    //   553: invokevirtual b : ()I
    //   556: istore_3
    //   557: aload_0
    //   558: getfield s : Lm0/g0;
    //   561: invokevirtual c : ()I
    //   564: istore #24
    //   566: aload_0
    //   567: getfield s : Lm0/g0;
    //   570: invokevirtual d : ()I
    //   573: istore #12
    //   575: aload_0
    //   576: getfield s : Lm0/g0;
    //   579: invokevirtual a : ()I
    //   582: istore #23
    //   584: iload #20
    //   586: iload #24
    //   588: iload_3
    //   589: iadd
    //   590: isub
    //   591: iload #19
    //   593: invokestatic makeMeasureSpec : (II)I
    //   596: istore_3
    //   597: iload #22
    //   599: iload #23
    //   601: iload #12
    //   603: iadd
    //   604: isub
    //   605: iload #21
    //   607: invokestatic makeMeasureSpec : (II)I
    //   610: istore #12
    //   612: goto -> 620
    //   615: iload_1
    //   616: istore_3
    //   617: iload_2
    //   618: istore #12
    //   620: aload #26
    //   622: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   625: astore #28
    //   627: aload #28
    //   629: ifnull -> 652
    //   632: aload #28
    //   634: aload_0
    //   635: aload #27
    //   637: iload_3
    //   638: iload #4
    //   640: iload #12
    //   642: iconst_0
    //   643: invokevirtual i : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   646: ifne -> 664
    //   649: goto -> 652
    //   652: aload_0
    //   653: aload #27
    //   655: iload_3
    //   656: iload #4
    //   658: iload #12
    //   660: iconst_0
    //   661: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   664: iload #11
    //   666: aload #27
    //   668: invokevirtual getMeasuredWidth : ()I
    //   671: iload #13
    //   673: iload #16
    //   675: iadd
    //   676: iadd
    //   677: aload #26
    //   679: getfield leftMargin : I
    //   682: iadd
    //   683: aload #26
    //   685: getfield rightMargin : I
    //   688: iadd
    //   689: invokestatic max : (II)I
    //   692: istore #11
    //   694: iload #10
    //   696: aload #27
    //   698: invokevirtual getMeasuredHeight : ()I
    //   701: iload #15
    //   703: iload #17
    //   705: iadd
    //   706: iadd
    //   707: aload #26
    //   709: getfield topMargin : I
    //   712: iadd
    //   713: aload #26
    //   715: getfield bottomMargin : I
    //   718: iadd
    //   719: invokestatic max : (II)I
    //   722: istore #10
    //   724: iload #14
    //   726: aload #27
    //   728: invokevirtual getMeasuredState : ()I
    //   731: invokestatic combineMeasuredStates : (II)I
    //   734: istore_3
    //   735: iload #8
    //   737: iconst_1
    //   738: iadd
    //   739: istore #8
    //   741: iload #9
    //   743: istore #4
    //   745: goto -> 344
    //   748: aload_0
    //   749: iload #11
    //   751: iload_1
    //   752: ldc_w -16777216
    //   755: iload_3
    //   756: iand
    //   757: invokestatic resolveSizeAndState : (III)I
    //   760: iload #10
    //   762: iload_2
    //   763: iload_3
    //   764: bipush #16
    //   766: ishl
    //   767: invokestatic resolveSizeAndState : (III)I
    //   770: invokevirtual setMeasuredDimension : (II)V
    //   773: return
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      paramView = getChildAt(i);
      if (paramView.getVisibility() != 8) {
        f f = (f)paramView.getLayoutParams();
        if (f.a(0))
          c c = f.a; 
      } 
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(0)) {
          bool1 = bool;
        } else {
          c<View> c = f.a;
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.j(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    j(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    m(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.k);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    h(paramView1, paramView2, paramInt, 0);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof h)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    h h = (h)paramParcelable;
    super.onRestoreInstanceState(h.f);
    SparseArray<Parcelable> sparseArray = h.h;
    int i = 0;
    int j = getChildCount();
    while (i < j) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = (l(view)).a;
      if (k != -1 && c != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(k);
        if (parcelable != null)
          c.n(this, view, parcelable); 
      } 
      i++;
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    h h = new h(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = ((f)view.getLayoutParams()).a;
      if (k != -1 && c != null) {
        Parcelable parcelable = c.o(this, view);
        if (parcelable != null)
          sparseArray.append(k, parcelable); 
      } 
    } 
    h.h = sparseArray;
    return (Parcelable)h;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return o(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    i(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield o : Landroid/view/View;
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokevirtual t : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: istore #4
    //   22: iload_3
    //   23: ifeq -> 76
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield o : Landroid/view/View;
    //   35: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   38: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   41: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   44: astore #8
    //   46: iload_3
    //   47: istore #4
    //   49: aload #8
    //   51: ifnull -> 76
    //   54: aload #8
    //   56: aload_0
    //   57: aload_0
    //   58: getfield o : Landroid/view/View;
    //   61: aload_1
    //   62: invokevirtual r : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   65: istore #5
    //   67: iload_3
    //   68: istore #4
    //   70: iload #5
    //   72: istore_3
    //   73: goto -> 78
    //   76: iconst_0
    //   77: istore_3
    //   78: aload_0
    //   79: getfield o : Landroid/view/View;
    //   82: astore #9
    //   84: aconst_null
    //   85: astore #8
    //   87: aload #9
    //   89: ifnonnull -> 107
    //   92: iload_3
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   98: ior
    //   99: istore #5
    //   101: aload #8
    //   103: astore_1
    //   104: goto -> 144
    //   107: iload_3
    //   108: istore #5
    //   110: aload #8
    //   112: astore_1
    //   113: iload #4
    //   115: ifeq -> 144
    //   118: invokestatic uptimeMillis : ()J
    //   121: lstore #6
    //   123: lload #6
    //   125: lload #6
    //   127: iconst_3
    //   128: fconst_0
    //   129: fconst_0
    //   130: iconst_0
    //   131: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   134: astore_1
    //   135: aload_0
    //   136: aload_1
    //   137: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   140: pop
    //   141: iload_3
    //   142: istore #5
    //   144: aload_1
    //   145: ifnull -> 152
    //   148: aload_1
    //   149: invokevirtual recycle : ()V
    //   152: iload_2
    //   153: iconst_1
    //   154: if_icmpeq -> 162
    //   157: iload_2
    //   158: iconst_3
    //   159: if_icmpne -> 167
    //   162: aload_0
    //   163: iconst_0
    //   164: invokevirtual v : (Z)V
    //   167: iload #5
    //   169: ireturn
  }
  
  public boolean p(View paramView, int paramInt1, int paramInt2) {
    Rect rect = a();
    f(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      rect.setEmpty();
      C.c(rect);
    } 
  }
  
  public final void q(int paramInt) {
    // Byte code:
    //   0: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   3: astore #11
    //   5: aload_0
    //   6: invokestatic d : (Landroid/view/View;)I
    //   9: istore #7
    //   11: aload_0
    //   12: getfield f : Ljava/util/List;
    //   15: invokeinterface size : ()I
    //   20: istore_2
    //   21: invokestatic a : ()Landroid/graphics/Rect;
    //   24: astore #13
    //   26: invokestatic a : ()Landroid/graphics/Rect;
    //   29: astore #14
    //   31: invokestatic a : ()Landroid/graphics/Rect;
    //   34: astore #11
    //   36: iconst_0
    //   37: istore_3
    //   38: iload_3
    //   39: iload_2
    //   40: if_icmpge -> 1324
    //   43: aload_0
    //   44: getfield f : Ljava/util/List;
    //   47: iload_3
    //   48: invokeinterface get : (I)Ljava/lang/Object;
    //   53: checkcast android/view/View
    //   56: astore #15
    //   58: aload #15
    //   60: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   63: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   66: astore #12
    //   68: iload_1
    //   69: ifne -> 88
    //   72: aload #15
    //   74: invokevirtual getVisibility : ()I
    //   77: bipush #8
    //   79: if_icmpne -> 88
    //   82: iload_3
    //   83: istore #6
    //   85: goto -> 1316
    //   88: iconst_0
    //   89: istore #4
    //   91: iload #4
    //   93: iload_3
    //   94: if_icmpge -> 393
    //   97: aload_0
    //   98: getfield f : Ljava/util/List;
    //   101: iload #4
    //   103: invokeinterface get : (I)Ljava/lang/Object;
    //   108: checkcast android/view/View
    //   111: astore #16
    //   113: aload #12
    //   115: getfield l : Landroid/view/View;
    //   118: aload #16
    //   120: if_acmpne -> 384
    //   123: aload #15
    //   125: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   128: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   131: astore #19
    //   133: aload #19
    //   135: getfield k : Landroid/view/View;
    //   138: ifnull -> 384
    //   141: invokestatic a : ()Landroid/graphics/Rect;
    //   144: astore #16
    //   146: invokestatic a : ()Landroid/graphics/Rect;
    //   149: astore #17
    //   151: invokestatic a : ()Landroid/graphics/Rect;
    //   154: astore #18
    //   156: aload_0
    //   157: aload #19
    //   159: getfield k : Landroid/view/View;
    //   162: aload #16
    //   164: invokevirtual f : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   167: aload_0
    //   168: aload #15
    //   170: iconst_0
    //   171: aload #17
    //   173: invokevirtual c : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   176: aload #15
    //   178: invokevirtual getMeasuredWidth : ()I
    //   181: istore #6
    //   183: aload #15
    //   185: invokevirtual getMeasuredHeight : ()I
    //   188: istore #8
    //   190: aload_0
    //   191: iload #7
    //   193: aload #16
    //   195: aload #18
    //   197: aload #19
    //   199: iload #6
    //   201: iload #8
    //   203: invokevirtual g : (ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V
    //   206: aload #18
    //   208: getfield left : I
    //   211: aload #17
    //   213: getfield left : I
    //   216: if_icmpne -> 241
    //   219: aload #18
    //   221: getfield top : I
    //   224: aload #17
    //   226: getfield top : I
    //   229: if_icmpeq -> 235
    //   232: goto -> 241
    //   235: iconst_0
    //   236: istore #5
    //   238: goto -> 244
    //   241: iconst_1
    //   242: istore #5
    //   244: aload_0
    //   245: aload #19
    //   247: aload #18
    //   249: iload #6
    //   251: iload #8
    //   253: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    //   256: aload #18
    //   258: getfield left : I
    //   261: aload #17
    //   263: getfield left : I
    //   266: isub
    //   267: istore #6
    //   269: aload #18
    //   271: getfield top : I
    //   274: aload #17
    //   276: getfield top : I
    //   279: isub
    //   280: istore #8
    //   282: iload #6
    //   284: ifeq -> 294
    //   287: aload #15
    //   289: iload #6
    //   291: invokestatic r : (Landroid/view/View;I)V
    //   294: iload #8
    //   296: ifeq -> 306
    //   299: aload #15
    //   301: iload #8
    //   303: invokestatic s : (Landroid/view/View;I)V
    //   306: iload #5
    //   308: ifeq -> 337
    //   311: aload #19
    //   313: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   316: astore #20
    //   318: aload #20
    //   320: ifnull -> 337
    //   323: aload #20
    //   325: aload_0
    //   326: aload #15
    //   328: aload #19
    //   330: getfield k : Landroid/view/View;
    //   333: invokevirtual d : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   336: pop
    //   337: aload #16
    //   339: invokevirtual setEmpty : ()V
    //   342: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.C : Lu/a;
    //   345: astore #19
    //   347: aload #19
    //   349: aload #16
    //   351: invokevirtual c : (Ljava/lang/Object;)Z
    //   354: pop
    //   355: aload #17
    //   357: invokevirtual setEmpty : ()V
    //   360: aload #19
    //   362: aload #17
    //   364: invokevirtual c : (Ljava/lang/Object;)Z
    //   367: pop
    //   368: aload #18
    //   370: invokevirtual setEmpty : ()V
    //   373: aload #19
    //   375: aload #18
    //   377: invokevirtual c : (Ljava/lang/Object;)Z
    //   380: pop
    //   381: goto -> 384
    //   384: iload #4
    //   386: iconst_1
    //   387: iadd
    //   388: istore #4
    //   390: goto -> 91
    //   393: iload_3
    //   394: istore #4
    //   396: aload_0
    //   397: aload #15
    //   399: iconst_1
    //   400: aload #14
    //   402: invokevirtual c : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   405: aload #12
    //   407: getfield g : I
    //   410: ifeq -> 561
    //   413: aload #14
    //   415: invokevirtual isEmpty : ()Z
    //   418: ifne -> 561
    //   421: aload #12
    //   423: getfield g : I
    //   426: iload #7
    //   428: invokestatic getAbsoluteGravity : (II)I
    //   431: istore_3
    //   432: iload_3
    //   433: bipush #112
    //   435: iand
    //   436: istore #5
    //   438: iload #5
    //   440: bipush #48
    //   442: if_icmpeq -> 481
    //   445: iload #5
    //   447: bipush #80
    //   449: if_icmpeq -> 455
    //   452: goto -> 499
    //   455: aload #13
    //   457: aload #13
    //   459: getfield bottom : I
    //   462: aload_0
    //   463: invokevirtual getHeight : ()I
    //   466: aload #14
    //   468: getfield top : I
    //   471: isub
    //   472: invokestatic max : (II)I
    //   475: putfield bottom : I
    //   478: goto -> 499
    //   481: aload #13
    //   483: aload #13
    //   485: getfield top : I
    //   488: aload #14
    //   490: getfield bottom : I
    //   493: invokestatic max : (II)I
    //   496: putfield top : I
    //   499: iload_3
    //   500: bipush #7
    //   502: iand
    //   503: istore_3
    //   504: iload_3
    //   505: iconst_3
    //   506: if_icmpeq -> 543
    //   509: iload_3
    //   510: iconst_5
    //   511: if_icmpeq -> 517
    //   514: goto -> 561
    //   517: aload #13
    //   519: aload #13
    //   521: getfield right : I
    //   524: aload_0
    //   525: invokevirtual getWidth : ()I
    //   528: aload #14
    //   530: getfield left : I
    //   533: isub
    //   534: invokestatic max : (II)I
    //   537: putfield right : I
    //   540: goto -> 561
    //   543: aload #13
    //   545: aload #13
    //   547: getfield left : I
    //   550: aload #14
    //   552: getfield right : I
    //   555: invokestatic max : (II)I
    //   558: putfield left : I
    //   561: aload #12
    //   563: getfield h : I
    //   566: ifeq -> 1093
    //   569: aload #15
    //   571: invokevirtual getVisibility : ()I
    //   574: ifne -> 1093
    //   577: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   580: astore #12
    //   582: aload #15
    //   584: invokestatic c : (Landroid/view/View;)Z
    //   587: ifne -> 593
    //   590: goto -> 1093
    //   593: aload #15
    //   595: invokevirtual getWidth : ()I
    //   598: ifle -> 1093
    //   601: aload #15
    //   603: invokevirtual getHeight : ()I
    //   606: ifgt -> 612
    //   609: goto -> 1093
    //   612: aload #15
    //   614: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   617: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   620: astore #17
    //   622: aload #17
    //   624: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   627: astore #18
    //   629: invokestatic a : ()Landroid/graphics/Rect;
    //   632: astore #12
    //   634: invokestatic a : ()Landroid/graphics/Rect;
    //   637: astore #16
    //   639: aload #16
    //   641: aload #15
    //   643: invokevirtual getLeft : ()I
    //   646: aload #15
    //   648: invokevirtual getTop : ()I
    //   651: aload #15
    //   653: invokevirtual getRight : ()I
    //   656: aload #15
    //   658: invokevirtual getBottom : ()I
    //   661: invokevirtual set : (IIII)V
    //   664: aload #18
    //   666: ifnull -> 747
    //   669: aload #18
    //   671: aload_0
    //   672: aload #15
    //   674: aload #12
    //   676: invokevirtual a : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   679: ifeq -> 747
    //   682: aload #16
    //   684: aload #12
    //   686: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   689: ifeq -> 695
    //   692: goto -> 754
    //   695: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   698: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   701: astore #11
    //   703: aload #11
    //   705: aload #12
    //   707: invokevirtual toShortString : ()Ljava/lang/String;
    //   710: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   713: pop
    //   714: aload #11
    //   716: ldc_w ' | Bounds:'
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: pop
    //   723: aload #11
    //   725: aload #16
    //   727: invokevirtual toShortString : ()Ljava/lang/String;
    //   730: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: new java/lang/IllegalArgumentException
    //   737: dup
    //   738: aload #11
    //   740: invokevirtual toString : ()Ljava/lang/String;
    //   743: invokespecial <init> : (Ljava/lang/String;)V
    //   746: athrow
    //   747: aload #12
    //   749: aload #16
    //   751: invokevirtual set : (Landroid/graphics/Rect;)V
    //   754: aload #16
    //   756: invokevirtual setEmpty : ()V
    //   759: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.C : Lu/a;
    //   762: astore #18
    //   764: aload #18
    //   766: aload #16
    //   768: invokevirtual c : (Ljava/lang/Object;)Z
    //   771: pop
    //   772: aload #12
    //   774: invokevirtual isEmpty : ()Z
    //   777: ifeq -> 796
    //   780: aload #12
    //   782: invokevirtual setEmpty : ()V
    //   785: aload #18
    //   787: aload #12
    //   789: invokevirtual c : (Ljava/lang/Object;)Z
    //   792: pop
    //   793: goto -> 1093
    //   796: aload #17
    //   798: getfield h : I
    //   801: iload #7
    //   803: invokestatic getAbsoluteGravity : (II)I
    //   806: istore #6
    //   808: iload #6
    //   810: bipush #48
    //   812: iand
    //   813: bipush #48
    //   815: if_icmpne -> 864
    //   818: aload #12
    //   820: getfield top : I
    //   823: aload #17
    //   825: getfield topMargin : I
    //   828: isub
    //   829: aload #17
    //   831: getfield j : I
    //   834: isub
    //   835: istore_3
    //   836: aload #13
    //   838: getfield top : I
    //   841: istore #5
    //   843: iload_3
    //   844: iload #5
    //   846: if_icmpge -> 864
    //   849: aload_0
    //   850: aload #15
    //   852: iload #5
    //   854: iload_3
    //   855: isub
    //   856: invokevirtual x : (Landroid/view/View;I)V
    //   859: iconst_1
    //   860: istore_3
    //   861: goto -> 866
    //   864: iconst_0
    //   865: istore_3
    //   866: iload_3
    //   867: istore #5
    //   869: iload #6
    //   871: bipush #80
    //   873: iand
    //   874: bipush #80
    //   876: if_icmpne -> 934
    //   879: aload_0
    //   880: invokevirtual getHeight : ()I
    //   883: aload #12
    //   885: getfield bottom : I
    //   888: isub
    //   889: aload #17
    //   891: getfield bottomMargin : I
    //   894: isub
    //   895: aload #17
    //   897: getfield j : I
    //   900: iadd
    //   901: istore #8
    //   903: aload #13
    //   905: getfield bottom : I
    //   908: istore #9
    //   910: iload_3
    //   911: istore #5
    //   913: iload #8
    //   915: iload #9
    //   917: if_icmpge -> 934
    //   920: aload_0
    //   921: aload #15
    //   923: iload #8
    //   925: iload #9
    //   927: isub
    //   928: invokevirtual x : (Landroid/view/View;I)V
    //   931: iconst_1
    //   932: istore #5
    //   934: iload #5
    //   936: ifne -> 946
    //   939: aload_0
    //   940: aload #15
    //   942: iconst_0
    //   943: invokevirtual x : (Landroid/view/View;I)V
    //   946: iload #6
    //   948: iconst_3
    //   949: iand
    //   950: iconst_3
    //   951: if_icmpne -> 1000
    //   954: aload #12
    //   956: getfield left : I
    //   959: aload #17
    //   961: getfield leftMargin : I
    //   964: isub
    //   965: aload #17
    //   967: getfield i : I
    //   970: isub
    //   971: istore_3
    //   972: aload #13
    //   974: getfield left : I
    //   977: istore #5
    //   979: iload_3
    //   980: iload #5
    //   982: if_icmpge -> 1000
    //   985: aload_0
    //   986: aload #15
    //   988: iload #5
    //   990: iload_3
    //   991: isub
    //   992: invokevirtual w : (Landroid/view/View;I)V
    //   995: iconst_1
    //   996: istore_3
    //   997: goto -> 1002
    //   1000: iconst_0
    //   1001: istore_3
    //   1002: iload_3
    //   1003: istore #5
    //   1005: iload #6
    //   1007: iconst_5
    //   1008: iand
    //   1009: iconst_5
    //   1010: if_icmpne -> 1068
    //   1013: aload_0
    //   1014: invokevirtual getWidth : ()I
    //   1017: aload #12
    //   1019: getfield right : I
    //   1022: isub
    //   1023: aload #17
    //   1025: getfield rightMargin : I
    //   1028: isub
    //   1029: aload #17
    //   1031: getfield i : I
    //   1034: iadd
    //   1035: istore #6
    //   1037: aload #13
    //   1039: getfield right : I
    //   1042: istore #8
    //   1044: iload_3
    //   1045: istore #5
    //   1047: iload #6
    //   1049: iload #8
    //   1051: if_icmpge -> 1068
    //   1054: aload_0
    //   1055: aload #15
    //   1057: iload #6
    //   1059: iload #8
    //   1061: isub
    //   1062: invokevirtual w : (Landroid/view/View;I)V
    //   1065: iconst_1
    //   1066: istore #5
    //   1068: iload #5
    //   1070: ifne -> 1080
    //   1073: aload_0
    //   1074: aload #15
    //   1076: iconst_0
    //   1077: invokevirtual w : (Landroid/view/View;I)V
    //   1080: aload #12
    //   1082: invokevirtual setEmpty : ()V
    //   1085: aload #18
    //   1087: aload #12
    //   1089: invokevirtual c : (Ljava/lang/Object;)Z
    //   1092: pop
    //   1093: iload_1
    //   1094: iconst_2
    //   1095: if_icmpeq -> 1162
    //   1098: aload #15
    //   1100: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1103: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1106: getfield q : Landroid/graphics/Rect;
    //   1109: astore #16
    //   1111: aload #11
    //   1113: astore #12
    //   1115: aload #12
    //   1117: aload #16
    //   1119: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1122: aload #12
    //   1124: aload #14
    //   1126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1129: ifeq -> 1143
    //   1132: aload #12
    //   1134: astore #11
    //   1136: iload #4
    //   1138: istore #6
    //   1140: goto -> 1316
    //   1143: aload #15
    //   1145: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1148: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1151: getfield q : Landroid/graphics/Rect;
    //   1154: aload #14
    //   1156: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1159: goto -> 1162
    //   1162: aload #11
    //   1164: astore #12
    //   1166: iload #4
    //   1168: iconst_1
    //   1169: iadd
    //   1170: istore #5
    //   1172: iload_2
    //   1173: istore_3
    //   1174: iload_3
    //   1175: istore_2
    //   1176: aload #12
    //   1178: astore #11
    //   1180: iload #4
    //   1182: istore #6
    //   1184: iload #5
    //   1186: iload_3
    //   1187: if_icmpge -> 1316
    //   1190: aload_0
    //   1191: getfield f : Ljava/util/List;
    //   1194: iload #5
    //   1196: invokeinterface get : (I)Ljava/lang/Object;
    //   1201: checkcast android/view/View
    //   1204: astore #11
    //   1206: aload #11
    //   1208: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1211: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1214: astore #16
    //   1216: aload #16
    //   1218: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   1221: astore #17
    //   1223: aload #17
    //   1225: ifnull -> 1307
    //   1228: aload #17
    //   1230: aload_0
    //   1231: aload #11
    //   1233: aload #15
    //   1235: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   1238: ifeq -> 1307
    //   1241: iload_1
    //   1242: ifne -> 1262
    //   1245: aload #16
    //   1247: getfield p : Z
    //   1250: ifeq -> 1262
    //   1253: aload #16
    //   1255: iconst_0
    //   1256: putfield p : Z
    //   1259: goto -> 1307
    //   1262: iload_1
    //   1263: iconst_2
    //   1264: if_icmpeq -> 1282
    //   1267: aload #17
    //   1269: aload_0
    //   1270: aload #11
    //   1272: aload #15
    //   1274: invokevirtual d : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   1277: istore #10
    //   1279: goto -> 1295
    //   1282: aload #17
    //   1284: aload_0
    //   1285: aload #11
    //   1287: aload #15
    //   1289: invokevirtual e : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V
    //   1292: iconst_1
    //   1293: istore #10
    //   1295: iload_1
    //   1296: iconst_1
    //   1297: if_icmpne -> 1307
    //   1300: aload #16
    //   1302: iload #10
    //   1304: putfield p : Z
    //   1307: iload #5
    //   1309: iconst_1
    //   1310: iadd
    //   1311: istore #5
    //   1313: goto -> 1174
    //   1316: iload #6
    //   1318: iconst_1
    //   1319: iadd
    //   1320: istore_3
    //   1321: goto -> 38
    //   1324: aload #13
    //   1326: invokevirtual setEmpty : ()V
    //   1329: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.C : Lu/a;
    //   1332: astore #12
    //   1334: aload #12
    //   1336: aload #13
    //   1338: invokevirtual c : (Ljava/lang/Object;)Z
    //   1341: pop
    //   1342: aload #14
    //   1344: invokevirtual setEmpty : ()V
    //   1347: aload #12
    //   1349: aload #14
    //   1351: invokevirtual c : (Ljava/lang/Object;)Z
    //   1354: pop
    //   1355: aload #11
    //   1357: invokevirtual setEmpty : ()V
    //   1360: aload #12
    //   1362: aload #11
    //   1364: invokevirtual c : (Ljava/lang/Object;)Z
    //   1367: pop
    //   1368: return
  }
  
  public void r(View paramView, int paramInt) {
    int i;
    f f = (f)paramView.getLayoutParams();
    View view = f.k;
    int j = 0;
    if (view == null && f.f != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i) {
      if (view != null) {
        rect1 = a();
        Rect rect = a();
        try {
          f(view, rect1);
          f f2 = (f)paramView.getLayoutParams();
          i = paramView.getMeasuredWidth();
          j = paramView.getMeasuredHeight();
          g(paramInt, rect1, rect, f2, i, j);
          b(f2, rect, i, j);
          paramView.layout(rect.left, rect.top, rect.right, rect.bottom);
          return;
        } finally {
          rect1.setEmpty();
          u.a<Rect> a2 = C;
          a2.c(rect1);
          rect.setEmpty();
          a2.c(rect);
        } 
      } 
      int k = ((f)rect1).e;
      if (k >= 0) {
        f f2 = (f)paramView.getLayoutParams();
        int n = f2.c;
        i = n;
        if (n == 0)
          i = 8388661; 
        i = Gravity.getAbsoluteGravity(i, paramInt);
        int i5 = i & 0x7;
        int i4 = i & 0x70;
        int i3 = getWidth();
        int i2 = getHeight();
        n = paramView.getMeasuredWidth();
        int i1 = paramView.getMeasuredHeight();
        i = k;
        if (paramInt == 1)
          i = i3 - k; 
        paramInt = k(i) - n;
        if (i5 != 1) {
          if (i5 == 5)
            paramInt += n; 
        } else {
          paramInt += n / 2;
        } 
        if (i4 != 16) {
          if (i4 != 80) {
            i = j;
          } else {
            i = i1 + 0;
          } 
        } else {
          i = 0 + i1 / 2;
        } 
        paramInt = Math.max(getPaddingLeft() + f2.leftMargin, Math.min(paramInt, i3 - getPaddingRight() - n - f2.rightMargin));
        i = Math.max(getPaddingTop() + f2.topMargin, Math.min(i, i2 - getPaddingBottom() - i1 - f2.bottomMargin));
        paramView.layout(paramInt, i, n + paramInt, i1 + i);
        return;
      } 
      f f1 = (f)paramView.getLayoutParams();
      Rect rect1 = a();
      rect1.set(getPaddingLeft() + f1.leftMargin, getPaddingTop() + f1.topMargin, getWidth() - getPaddingRight() - f1.rightMargin, getHeight() - getPaddingBottom() - f1.bottomMargin);
      if (this.s != null) {
        WeakHashMap weakHashMap = y.a;
        if (y.d.b((View)this) && !y.d.b(paramView)) {
          i = rect1.left;
          rect1.left = this.s.b() + i;
          i = rect1.top;
          rect1.top = this.s.d() + i;
          rect1.right -= this.s.c();
          rect1.bottom -= this.s.a();
        } 
      } 
      Rect rect2 = a();
      j = f1.c;
      i = j;
      if ((j & 0x7) == 0)
        i = j | 0x800003; 
      j = i;
      if ((i & 0x70) == 0)
        j = i | 0x30; 
      Gravity.apply(j, paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
      paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      rect1.setEmpty();
      u.a<Rect> a1 = C;
      a1.c(rect1);
      rect2.setEmpty();
      a1.c(rect2);
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    c<View> c = ((f)paramView.getLayoutParams()).a;
    return (c != null && c.m(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.l) {
      v(false);
      this.l = true;
    } 
  }
  
  public void s(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    y();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.v = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.u;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.u = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.u.setState(getDrawableState()); 
        paramDrawable = this.u;
        WeakHashMap weakHashMap1 = y.a;
        f0.a.g(paramDrawable, y.e.d((View)this));
        paramDrawable = this.u;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.u.setCallback((Drawable.Callback)this);
      } 
      WeakHashMap weakHashMap = y.a;
      y.d.k((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = c0.a.c(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.u;
    if (drawable != null && drawable.isVisible() != bool)
      this.u.setVisible(bool, false); 
  }
  
  public final boolean t(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    int n = paramMotionEvent.getActionMasked();
    List<View> list = this.h;
    list.clear();
    boolean bool1 = isChildrenDrawingOrderEnabled();
    int k = getChildCount();
    int i;
    for (i = k - 1; i >= 0; i--) {
      int i2;
      if (bool1) {
        i2 = getChildDrawingOrder(k, i);
      } else {
        i2 = i;
      } 
      list.add(getChildAt(i2));
    } 
    Comparator<View> comparator = B;
    if (comparator != null)
      Collections.sort(list, comparator); 
    int i1 = list.size();
    comparator = null;
    int j = 0;
    bool1 = false;
    i = 0;
    while (true) {
      bool2 = bool1;
      if (j < i1) {
        boolean bool;
        MotionEvent motionEvent;
        Comparator<View> comparator1;
        View view = list.get(j);
        f f = (f)view.getLayoutParams();
        c<View> c = f.a;
        if ((bool1 || i != 0) && n != 0) {
          comparator1 = comparator;
          bool = bool1;
          k = i;
          if (c != null) {
            comparator1 = comparator;
            if (comparator == null) {
              long l1 = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l1, l1, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt != 1) {
                bool = bool1;
                k = i;
              } else {
                c.r(this, view, motionEvent);
                bool = bool1;
                k = i;
              } 
            } else {
              c.g(this, view, motionEvent);
              bool = bool1;
              k = i;
            } 
          } 
        } else {
          int i2;
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (c != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = c.r(this, view, paramMotionEvent); 
              } else {
                bool1 = c.g(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.o = view;
                bool2 = bool1;
              } 
            } 
          } 
          if (((f)motionEvent).a == null)
            ((f)motionEvent).m = false; 
          bool = ((f)motionEvent).m;
          if (bool) {
            bool1 = true;
          } else {
            i2 = bool | false;
            ((f)motionEvent).m = i2;
          } 
          if (i2 != 0 && !bool) {
            i = 1;
          } else {
            i = 0;
          } 
          comparator1 = comparator;
          bool = bool2;
          k = i;
          if (i2 != 0) {
            comparator1 = comparator;
            bool = bool2;
            k = i;
            if (i == 0)
              break; 
          } 
        } 
        j++;
        comparator = comparator1;
        bool1 = bool;
        i = k;
        continue;
      } 
      break;
    } 
    list.clear();
    return bool2;
  }
  
  public final void u() {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Ljava/util/List;
    //   4: invokeinterface clear : ()V
    //   9: aload_0
    //   10: getfield g : Lw1/g;
    //   13: astore #7
    //   15: aload #7
    //   17: getfield g : Ljava/lang/Object;
    //   20: checkcast s/h
    //   23: getfield h : I
    //   26: istore_2
    //   27: iconst_0
    //   28: istore #4
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: iload_2
    //   34: if_icmpge -> 73
    //   37: aload #7
    //   39: getfield g : Ljava/lang/Object;
    //   42: checkcast s/h
    //   45: iload_1
    //   46: invokevirtual k : (I)Ljava/lang/Object;
    //   49: checkcast java/util/ArrayList
    //   52: astore #8
    //   54: aload #8
    //   56: ifnull -> 66
    //   59: aload #7
    //   61: aload #8
    //   63: invokevirtual f : (Ljava/util/ArrayList;)V
    //   66: iload_1
    //   67: iconst_1
    //   68: iadd
    //   69: istore_1
    //   70: goto -> 32
    //   73: aload #7
    //   75: getfield g : Ljava/lang/Object;
    //   78: checkcast s/h
    //   81: invokevirtual clear : ()V
    //   84: aload_0
    //   85: invokevirtual getChildCount : ()I
    //   88: istore #5
    //   90: iconst_0
    //   91: istore_1
    //   92: iload_1
    //   93: iload #5
    //   95: if_icmpge -> 815
    //   98: aload_0
    //   99: iload_1
    //   100: invokevirtual getChildAt : (I)Landroid/view/View;
    //   103: astore #9
    //   105: aload_0
    //   106: aload #9
    //   108: invokevirtual l : (Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;
    //   111: astore #10
    //   113: aload #10
    //   115: getfield f : I
    //   118: iconst_m1
    //   119: if_icmpne -> 137
    //   122: aload #10
    //   124: aconst_null
    //   125: putfield l : Landroid/view/View;
    //   128: aload #10
    //   130: aconst_null
    //   131: putfield k : Landroid/view/View;
    //   134: goto -> 433
    //   137: aload #10
    //   139: getfield k : Landroid/view/View;
    //   142: astore #7
    //   144: aload #7
    //   146: ifnull -> 257
    //   149: aload #7
    //   151: invokevirtual getId : ()I
    //   154: aload #10
    //   156: getfield f : I
    //   159: if_icmpeq -> 165
    //   162: goto -> 239
    //   165: aload #10
    //   167: getfield k : Landroid/view/View;
    //   170: astore #8
    //   172: aload #8
    //   174: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   177: astore #7
    //   179: aload #7
    //   181: aload_0
    //   182: if_acmpeq -> 244
    //   185: aload #7
    //   187: ifnull -> 227
    //   190: aload #7
    //   192: aload #9
    //   194: if_acmpne -> 200
    //   197: goto -> 227
    //   200: aload #7
    //   202: instanceof android/view/View
    //   205: ifeq -> 215
    //   208: aload #7
    //   210: checkcast android/view/View
    //   213: astore #8
    //   215: aload #7
    //   217: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   222: astore #7
    //   224: goto -> 179
    //   227: aload #10
    //   229: aconst_null
    //   230: putfield l : Landroid/view/View;
    //   233: aload #10
    //   235: aconst_null
    //   236: putfield k : Landroid/view/View;
    //   239: iconst_0
    //   240: istore_2
    //   241: goto -> 253
    //   244: aload #10
    //   246: aload #8
    //   248: putfield l : Landroid/view/View;
    //   251: iconst_1
    //   252: istore_2
    //   253: iload_2
    //   254: ifne -> 433
    //   257: aload_0
    //   258: aload #10
    //   260: getfield f : I
    //   263: invokevirtual findViewById : (I)Landroid/view/View;
    //   266: astore #8
    //   268: aload #10
    //   270: aload #8
    //   272: putfield k : Landroid/view/View;
    //   275: aload #8
    //   277: ifnull -> 414
    //   280: aload #8
    //   282: aload_0
    //   283: if_acmpne -> 319
    //   286: aload_0
    //   287: invokevirtual isInEditMode : ()Z
    //   290: ifeq -> 308
    //   293: aload #10
    //   295: aconst_null
    //   296: putfield l : Landroid/view/View;
    //   299: aload #10
    //   301: aconst_null
    //   302: putfield k : Landroid/view/View;
    //   305: goto -> 433
    //   308: new java/lang/IllegalStateException
    //   311: dup
    //   312: ldc_w 'View can not be anchored to the the parent CoordinatorLayout'
    //   315: invokespecial <init> : (Ljava/lang/String;)V
    //   318: athrow
    //   319: aload #8
    //   321: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   324: astore #7
    //   326: aload #7
    //   328: aload_0
    //   329: if_acmpeq -> 404
    //   332: aload #7
    //   334: ifnull -> 404
    //   337: aload #7
    //   339: aload #9
    //   341: if_acmpne -> 377
    //   344: aload_0
    //   345: invokevirtual isInEditMode : ()Z
    //   348: ifeq -> 366
    //   351: aload #10
    //   353: aconst_null
    //   354: putfield l : Landroid/view/View;
    //   357: aload #10
    //   359: aconst_null
    //   360: putfield k : Landroid/view/View;
    //   363: goto -> 433
    //   366: new java/lang/IllegalStateException
    //   369: dup
    //   370: ldc_w 'Anchor must not be a descendant of the anchored view'
    //   373: invokespecial <init> : (Ljava/lang/String;)V
    //   376: athrow
    //   377: aload #7
    //   379: instanceof android/view/View
    //   382: ifeq -> 392
    //   385: aload #7
    //   387: checkcast android/view/View
    //   390: astore #8
    //   392: aload #7
    //   394: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   399: astore #7
    //   401: goto -> 326
    //   404: aload #10
    //   406: aload #8
    //   408: putfield l : Landroid/view/View;
    //   411: goto -> 433
    //   414: aload_0
    //   415: invokevirtual isInEditMode : ()Z
    //   418: ifeq -> 759
    //   421: aload #10
    //   423: aconst_null
    //   424: putfield l : Landroid/view/View;
    //   427: aload #10
    //   429: aconst_null
    //   430: putfield k : Landroid/view/View;
    //   433: aload_0
    //   434: getfield g : Lw1/g;
    //   437: aload #9
    //   439: invokevirtual a : (Ljava/lang/Object;)V
    //   442: iconst_0
    //   443: istore_2
    //   444: iload_2
    //   445: iload #5
    //   447: if_icmpge -> 752
    //   450: iload_2
    //   451: iload_1
    //   452: if_icmpne -> 458
    //   455: goto -> 745
    //   458: aload_0
    //   459: iload_2
    //   460: invokevirtual getChildAt : (I)Landroid/view/View;
    //   463: astore #11
    //   465: aload #11
    //   467: aload #10
    //   469: getfield l : Landroid/view/View;
    //   472: if_acmpeq -> 568
    //   475: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   478: astore #7
    //   480: aload_0
    //   481: invokestatic d : (Landroid/view/View;)I
    //   484: istore_3
    //   485: aload #11
    //   487: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   490: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   493: getfield g : I
    //   496: iload_3
    //   497: invokestatic getAbsoluteGravity : (II)I
    //   500: istore #6
    //   502: iload #6
    //   504: ifeq -> 529
    //   507: aload #10
    //   509: getfield h : I
    //   512: iload_3
    //   513: invokestatic getAbsoluteGravity : (II)I
    //   516: iload #6
    //   518: iand
    //   519: iload #6
    //   521: if_icmpne -> 529
    //   524: iconst_1
    //   525: istore_3
    //   526: goto -> 531
    //   529: iconst_0
    //   530: istore_3
    //   531: iload_3
    //   532: ifne -> 568
    //   535: aload #10
    //   537: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   540: astore #7
    //   542: aload #7
    //   544: ifnull -> 563
    //   547: aload #7
    //   549: aload_0
    //   550: aload #9
    //   552: aload #11
    //   554: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   557: ifeq -> 563
    //   560: goto -> 568
    //   563: iconst_0
    //   564: istore_3
    //   565: goto -> 570
    //   568: iconst_1
    //   569: istore_3
    //   570: iload_3
    //   571: ifeq -> 745
    //   574: aload_0
    //   575: getfield g : Lw1/g;
    //   578: getfield g : Ljava/lang/Object;
    //   581: checkcast s/h
    //   584: aload #11
    //   586: invokevirtual e : (Ljava/lang/Object;)I
    //   589: iflt -> 597
    //   592: iconst_1
    //   593: istore_3
    //   594: goto -> 599
    //   597: iconst_0
    //   598: istore_3
    //   599: iload_3
    //   600: ifne -> 612
    //   603: aload_0
    //   604: getfield g : Lw1/g;
    //   607: aload #11
    //   609: invokevirtual a : (Ljava/lang/Object;)V
    //   612: aload_0
    //   613: getfield g : Lw1/g;
    //   616: astore #12
    //   618: aload #12
    //   620: getfield g : Ljava/lang/Object;
    //   623: checkcast s/h
    //   626: aload #11
    //   628: invokevirtual e : (Ljava/lang/Object;)I
    //   631: iflt -> 639
    //   634: iconst_1
    //   635: istore_3
    //   636: goto -> 641
    //   639: iconst_0
    //   640: istore_3
    //   641: iload_3
    //   642: ifeq -> 734
    //   645: aload #12
    //   647: getfield g : Ljava/lang/Object;
    //   650: checkcast s/h
    //   653: aload #9
    //   655: invokevirtual e : (Ljava/lang/Object;)I
    //   658: iflt -> 666
    //   661: iconst_1
    //   662: istore_3
    //   663: goto -> 668
    //   666: iconst_0
    //   667: istore_3
    //   668: iload_3
    //   669: ifeq -> 734
    //   672: aload #12
    //   674: getfield g : Ljava/lang/Object;
    //   677: checkcast s/h
    //   680: aload #11
    //   682: aconst_null
    //   683: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   686: checkcast java/util/ArrayList
    //   689: astore #8
    //   691: aload #8
    //   693: astore #7
    //   695: aload #8
    //   697: ifnonnull -> 723
    //   700: aload #12
    //   702: invokevirtual d : ()Ljava/util/ArrayList;
    //   705: astore #7
    //   707: aload #12
    //   709: getfield g : Ljava/lang/Object;
    //   712: checkcast s/h
    //   715: aload #11
    //   717: aload #7
    //   719: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   722: pop
    //   723: aload #7
    //   725: aload #9
    //   727: invokevirtual add : (Ljava/lang/Object;)Z
    //   730: pop
    //   731: goto -> 745
    //   734: new java/lang/IllegalArgumentException
    //   737: dup
    //   738: ldc_w 'All nodes must be present in the graph before being added as an edge'
    //   741: invokespecial <init> : (Ljava/lang/String;)V
    //   744: athrow
    //   745: iload_2
    //   746: iconst_1
    //   747: iadd
    //   748: istore_2
    //   749: goto -> 444
    //   752: iload_1
    //   753: iconst_1
    //   754: iadd
    //   755: istore_1
    //   756: goto -> 92
    //   759: ldc_w 'Could not find CoordinatorLayout descendant view with id '
    //   762: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   765: astore #7
    //   767: aload #7
    //   769: aload_0
    //   770: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   773: aload #10
    //   775: getfield f : I
    //   778: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   781: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   784: pop
    //   785: aload #7
    //   787: ldc_w ' to anchor view '
    //   790: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   793: pop
    //   794: aload #7
    //   796: aload #9
    //   798: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   801: pop
    //   802: new java/lang/IllegalStateException
    //   805: dup
    //   806: aload #7
    //   808: invokevirtual toString : ()Ljava/lang/String;
    //   811: invokespecial <init> : (Ljava/lang/String;)V
    //   814: athrow
    //   815: aload_0
    //   816: getfield f : Ljava/util/List;
    //   819: astore #7
    //   821: aload_0
    //   822: getfield g : Lw1/g;
    //   825: astore #8
    //   827: aload #8
    //   829: getfield h : Ljava/lang/Object;
    //   832: checkcast java/util/ArrayList
    //   835: invokevirtual clear : ()V
    //   838: aload #8
    //   840: getfield i : Ljava/lang/Object;
    //   843: checkcast java/util/HashSet
    //   846: invokevirtual clear : ()V
    //   849: aload #8
    //   851: getfield g : Ljava/lang/Object;
    //   854: checkcast s/h
    //   857: getfield h : I
    //   860: istore_2
    //   861: iload #4
    //   863: istore_1
    //   864: iload_1
    //   865: iload_2
    //   866: if_icmpge -> 909
    //   869: aload #8
    //   871: aload #8
    //   873: getfield g : Ljava/lang/Object;
    //   876: checkcast s/h
    //   879: iload_1
    //   880: invokevirtual h : (I)Ljava/lang/Object;
    //   883: aload #8
    //   885: getfield h : Ljava/lang/Object;
    //   888: checkcast java/util/ArrayList
    //   891: aload #8
    //   893: getfield i : Ljava/lang/Object;
    //   896: checkcast java/util/HashSet
    //   899: invokevirtual b : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    //   902: iload_1
    //   903: iconst_1
    //   904: iadd
    //   905: istore_1
    //   906: goto -> 864
    //   909: aload #7
    //   911: aload #8
    //   913: getfield h : Ljava/lang/Object;
    //   916: checkcast java/util/ArrayList
    //   919: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   924: pop
    //   925: aload_0
    //   926: getfield f : Ljava/util/List;
    //   929: invokestatic reverse : (Ljava/util/List;)V
    //   932: return
  }
  
  public final void v(boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      c<View> c = ((f)view.getLayoutParams()).a;
      if (c != null) {
        long l1 = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l1, l1, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          c.g(this, view, motionEvent);
        } else {
          c.r(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (i = 0; i < j; i++)
      ((f)getChildAt(i).getLayoutParams()).m = false; 
    this.o = null;
    this.l = false;
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.u);
  }
  
  public final void w(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.i;
    if (i != paramInt) {
      y.r(paramView, paramInt - i);
      f.i = paramInt;
    } 
  }
  
  public final void x(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.j;
    if (i != paramInt) {
      y.s(paramView, paramInt - i);
      f.j = paramInt;
    } 
  }
  
  public final void y() {
    if (Build.VERSION.SDK_INT < 21)
      return; 
    WeakHashMap weakHashMap = y.a;
    if (y.d.b((View)this)) {
      if (this.w == null)
        this.w = new a(this); 
      y.C((View)this, this.w);
      setSystemUiVisibility(1280);
      return;
    } 
    y.C((View)this, null);
  }
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    y = (String)package_;
    if (Build.VERSION.SDK_INT >= 21) {
      B = new i();
    } else {
      B = null;
    } 
  }
  
  public class a implements p {
    public a(CoordinatorLayout this$0) {}
    
    public g0 a(View param1View, g0 param1g0) {
      CoordinatorLayout coordinatorLayout = this.a;
      if (!Objects.equals(coordinatorLayout.s, param1g0)) {
        boolean bool1;
        coordinatorLayout.s = param1g0;
        int j = param1g0.d();
        boolean bool2 = true;
        int i = 0;
        if (j > 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        coordinatorLayout.t = bool1;
        if (!bool1 && coordinatorLayout.getBackground() == null) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        coordinatorLayout.setWillNotDraw(bool1);
        if (!param1g0.f()) {
          j = coordinatorLayout.getChildCount();
          while (i < j) {
            View view = coordinatorLayout.getChildAt(i);
            WeakHashMap weakHashMap = y.a;
            if (y.d.b(view) && ((CoordinatorLayout.f)view.getLayoutParams()).a != null && param1g0.f())
              break; 
            i++;
          } 
        } 
        coordinatorLayout.requestLayout();
      } 
      return param1g0;
    }
  }
  
  public static interface b {
    CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View> {
    public c() {}
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect) {
      return false;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void c(CoordinatorLayout.f param1f) {}
    
    public boolean d(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void e(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void f() {}
    
    public boolean g(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean h(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean i(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean j(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    public void k(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {}
    
    public void l(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int[] param1ArrayOfint) {
      param1ArrayOfint[0] = param1ArrayOfint[0] + param1Int3;
      param1ArrayOfint[1] = param1ArrayOfint[1] + param1Int4;
    }
    
    public boolean m(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public void n(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public Parcelable o(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    public boolean p(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      return false;
    }
    
    public void q(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int) {}
    
    public boolean r(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d {
    Class<? extends CoordinatorLayout.c> value();
  }
  
  public class e implements ViewGroup.OnHierarchyChangeListener {
    public e(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f.v;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.f.q(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f.v;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    public CoordinatorLayout.c a;
    
    public boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    public int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    public int i;
    
    public int j;
    
    public View k;
    
    public View l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public final Rect q = new Rect();
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public f(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_0
      //   8: putfield b : Z
      //   11: aload_0
      //   12: iconst_0
      //   13: putfield c : I
      //   16: aload_0
      //   17: iconst_0
      //   18: putfield d : I
      //   21: aload_0
      //   22: iconst_m1
      //   23: putfield e : I
      //   26: aload_0
      //   27: iconst_m1
      //   28: putfield f : I
      //   31: aload_0
      //   32: iconst_0
      //   33: putfield g : I
      //   36: aload_0
      //   37: iconst_0
      //   38: putfield h : I
      //   41: aload_0
      //   42: new android/graphics/Rect
      //   45: dup
      //   46: invokespecial <init> : ()V
      //   49: putfield q : Landroid/graphics/Rect;
      //   52: aload_1
      //   53: aload_2
      //   54: getstatic y/b.b : [I
      //   57: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   60: astore #8
      //   62: aload_0
      //   63: aload #8
      //   65: iconst_0
      //   66: iconst_0
      //   67: invokevirtual getInteger : (II)I
      //   70: putfield c : I
      //   73: aload_0
      //   74: aload #8
      //   76: iconst_1
      //   77: iconst_m1
      //   78: invokevirtual getResourceId : (II)I
      //   81: putfield f : I
      //   84: aload_0
      //   85: aload #8
      //   87: iconst_2
      //   88: iconst_0
      //   89: invokevirtual getInteger : (II)I
      //   92: putfield d : I
      //   95: aload_0
      //   96: aload #8
      //   98: bipush #6
      //   100: iconst_m1
      //   101: invokevirtual getInteger : (II)I
      //   104: putfield e : I
      //   107: aload_0
      //   108: aload #8
      //   110: iconst_5
      //   111: iconst_0
      //   112: invokevirtual getInt : (II)I
      //   115: putfield g : I
      //   118: aload_0
      //   119: aload #8
      //   121: iconst_4
      //   122: iconst_0
      //   123: invokevirtual getInt : (II)I
      //   126: putfield h : I
      //   129: aload #8
      //   131: iconst_3
      //   132: invokevirtual hasValue : (I)Z
      //   135: istore_3
      //   136: aload_0
      //   137: iload_3
      //   138: putfield b : Z
      //   141: iload_3
      //   142: ifeq -> 437
      //   145: aload #8
      //   147: iconst_3
      //   148: invokevirtual getString : (I)Ljava/lang/String;
      //   151: astore #5
      //   153: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.y : Ljava/lang/String;
      //   156: astore #4
      //   158: aload #5
      //   160: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   163: ifeq -> 171
      //   166: aconst_null
      //   167: astore_1
      //   168: goto -> 412
      //   171: aload #5
      //   173: ldc '.'
      //   175: invokevirtual startsWith : (Ljava/lang/String;)Z
      //   178: ifeq -> 218
      //   181: new java/lang/StringBuilder
      //   184: dup
      //   185: invokespecial <init> : ()V
      //   188: astore #4
      //   190: aload #4
      //   192: aload_1
      //   193: invokevirtual getPackageName : ()Ljava/lang/String;
      //   196: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   199: pop
      //   200: aload #4
      //   202: aload #5
      //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   207: pop
      //   208: aload #4
      //   210: invokevirtual toString : ()Ljava/lang/String;
      //   213: astore #4
      //   215: goto -> 292
      //   218: aload #5
      //   220: bipush #46
      //   222: invokevirtual indexOf : (I)I
      //   225: iflt -> 235
      //   228: aload #5
      //   230: astore #4
      //   232: goto -> 292
      //   235: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.y : Ljava/lang/String;
      //   238: astore #6
      //   240: aload #5
      //   242: astore #4
      //   244: aload #6
      //   246: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   249: ifne -> 292
      //   252: new java/lang/StringBuilder
      //   255: dup
      //   256: invokespecial <init> : ()V
      //   259: astore #4
      //   261: aload #4
      //   263: aload #6
      //   265: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   268: pop
      //   269: aload #4
      //   271: bipush #46
      //   273: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   276: pop
      //   277: aload #4
      //   279: aload #5
      //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   284: pop
      //   285: aload #4
      //   287: invokevirtual toString : ()Ljava/lang/String;
      //   290: astore #4
      //   292: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.A : Ljava/lang/ThreadLocal;
      //   295: astore #7
      //   297: aload #7
      //   299: invokevirtual get : ()Ljava/lang/Object;
      //   302: checkcast java/util/Map
      //   305: astore #6
      //   307: aload #6
      //   309: astore #5
      //   311: aload #6
      //   313: ifnonnull -> 332
      //   316: new java/util/HashMap
      //   319: dup
      //   320: invokespecial <init> : ()V
      //   323: astore #5
      //   325: aload #7
      //   327: aload #5
      //   329: invokevirtual set : (Ljava/lang/Object;)V
      //   332: aload #5
      //   334: aload #4
      //   336: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   341: checkcast java/lang/reflect/Constructor
      //   344: astore #7
      //   346: aload #7
      //   348: astore #6
      //   350: aload #7
      //   352: ifnonnull -> 391
      //   355: aload #4
      //   357: iconst_0
      //   358: aload_1
      //   359: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
      //   362: invokestatic forName : (Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
      //   365: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.z : [Ljava/lang/Class;
      //   368: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
      //   371: astore #6
      //   373: aload #6
      //   375: iconst_1
      //   376: invokevirtual setAccessible : (Z)V
      //   379: aload #5
      //   381: aload #4
      //   383: aload #6
      //   385: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   390: pop
      //   391: aload #6
      //   393: iconst_2
      //   394: anewarray java/lang/Object
      //   397: dup
      //   398: iconst_0
      //   399: aload_1
      //   400: aastore
      //   401: dup
      //   402: iconst_1
      //   403: aload_2
      //   404: aastore
      //   405: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
      //   408: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$c
      //   411: astore_1
      //   412: aload_0
      //   413: aload_1
      //   414: putfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
      //   417: goto -> 437
      //   420: astore_1
      //   421: new java/lang/RuntimeException
      //   424: dup
      //   425: ldc 'Could not inflate Behavior subclass '
      //   427: aload #4
      //   429: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   432: aload_1
      //   433: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
      //   436: athrow
      //   437: aload #8
      //   439: invokevirtual recycle : ()V
      //   442: aload_0
      //   443: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
      //   446: astore_1
      //   447: aload_1
      //   448: ifnull -> 456
      //   451: aload_1
      //   452: aload_0
      //   453: invokevirtual c : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;)V
      //   456: return
      // Exception table:
      //   from	to	target	type
      //   292	307	420	java/lang/Exception
      //   316	332	420	java/lang/Exception
      //   332	346	420	java/lang/Exception
      //   355	391	420	java/lang/Exception
      //   391	412	420	java/lang/Exception
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public f(f param1f) {
      super(param1f);
    }
    
    public boolean a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    public void b(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int != 1)
          return; 
        this.o = param1Boolean;
        return;
      } 
      this.n = param1Boolean;
    }
  }
  
  public class g implements ViewTreeObserver.OnPreDrawListener {
    public g(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.f.q(0);
      return true;
    }
  }
  
  public static class h extends s0.a {
    public static final Parcelable.Creator<h> CREATOR = (Parcelable.Creator<h>)new a();
    
    public SparseArray<Parcelable> h;
    
    public h(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int j = param1Parcel.readInt();
      int[] arrayOfInt = new int[j];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.h = new SparseArray(j);
      for (int i = 0; i < j; i++)
        this.h.append(arrayOfInt[i], arrayOfParcelable[i]); 
    }
    
    public h(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b;
      param1Parcel.writeParcelable(this.f, param1Int);
      SparseArray<Parcelable> sparseArray = this.h;
      int i = 0;
      if (sparseArray != null) {
        b = sparseArray.size();
      } else {
        b = 0;
      } 
      param1Parcel.writeInt(b);
      int[] arrayOfInt = new int[b];
      Parcelable[] arrayOfParcelable = new Parcelable[b];
      while (i < b) {
        arrayOfInt[i] = this.h.keyAt(i);
        arrayOfParcelable[i] = (Parcelable)this.h.valueAt(i);
        i++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<h> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new CoordinatorLayout.h(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.h(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new CoordinatorLayout.h[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<h> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new CoordinatorLayout.h(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.h(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new CoordinatorLayout.h[param1Int];
    }
  }
  
  public static class i implements Comparator<View> {
    public int compare(Object param1Object1, Object param1Object2) {
      float f1;
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      WeakHashMap weakHashMap = y.a;
      int j = Build.VERSION.SDK_INT;
      float f2 = 0.0F;
      if (j >= 21) {
        f1 = y.i.m((View)param1Object1);
      } else {
        f1 = 0.0F;
      } 
      if (j >= 21)
        f2 = y.i.m((View)param1Object2); 
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */