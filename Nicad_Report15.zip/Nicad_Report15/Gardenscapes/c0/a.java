package c0;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import java.io.File;
import java.util.Objects;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class a {
  public static final Object a = new Object();
  
  public static final Object b = new Object();
  
  public static int a(Context paramContext, String paramString) {
    Objects.requireNonNull(paramString, "permission must be non-null");
    return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static int b(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? d.a(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static Drawable c(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 21) ? c.b(paramContext, paramInt) : paramContext.getResources().getDrawable(paramInt);
  }
  
  public static class a {
    public static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    public static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  public static class b {
    public static File[] a(Context param1Context) {
      return param1Context.getExternalCacheDirs();
    }
    
    public static File[] b(Context param1Context, String param1String) {
      return param1Context.getExternalFilesDirs(param1String);
    }
    
    public static File[] c(Context param1Context) {
      return param1Context.getObbDirs();
    }
  }
  
  public static class c {
    public static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    public static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    public static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  public static class d {
    public static int a(Context param1Context, int param1Int) {
      return param1Context.getColor(param1Int);
    }
    
    public static <T> T b(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    public static String c(Context param1Context, Class<?> param1Class) {
      return param1Context.getSystemServiceName(param1Class);
    }
  }
  
  public static class e {
    public static Context a(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext();
    }
    
    public static File b(Context param1Context) {
      return param1Context.getDataDir();
    }
    
    public static boolean c(Context param1Context) {
      return param1Context.isDeviceProtectedStorage();
    }
  }
  
  public static class f {
    public static ComponentName a(Context param1Context, Intent param1Intent) {
      return param1Context.startForegroundService(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */