package c0;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.Build;
import android.os.Process;
import b0.f;
import com.google.android.gms.internal.ads.b3;
import com.google.android.gms.internal.ads.f3;
import com.google.android.gms.internal.ads.g3;
import com.google.android.gms.internal.ads.zzdsi;
import com.google.android.gms.internal.play_billing.zzba;
import h5.ao;
import h5.cg0;
import h5.gi0;
import h5.hi0;
import h5.jm;
import h5.lg0;
import h5.m2;
import h5.mi;
import h5.mo0;
import h5.q2;
import h5.re1;
import h5.vh0;
import h5.y3;
import h5.yh0;
import java.util.Objects;
import java.util.concurrent.Executor;
import q.a;

public final class b {
  public static int a(Context paramContext, String paramString) {
    int i = Process.myPid();
    int j = Process.myUid();
    String str2 = paramContext.getPackageName();
    if (paramContext.checkPermission(paramString, i, j) == -1)
      return -1; 
    int k = Build.VERSION.SDK_INT;
    if (k >= 23) {
      paramString = AppOpsManager.permissionToOp(paramString);
    } else {
      paramString = null;
    } 
    if (paramString == null)
      return 0; 
    String str1 = str2;
    if (str2 == null) {
      String[] arrayOfString = paramContext.getPackageManager().getPackagesForUid(j);
      if (arrayOfString == null || arrayOfString.length <= 0)
        return -1; 
      str1 = arrayOfString[0];
    } 
    i = Process.myUid();
    str2 = paramContext.getPackageName();
    if (i == j && Objects.equals(str2, str1)) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      if (k >= 29) {
        AppOpsManager appOpsManager = f.a.c(paramContext);
        i = f.a.a(appOpsManager, paramString, Binder.getCallingUid(), str1);
        if (i == 0)
          i = f.a.a(appOpsManager, paramString, j, f.a.b(paramContext)); 
      } else {
        i = f.a(paramContext, paramString, str1);
      } 
    } else {
      i = f.a(paramContext, paramString, str1);
    } 
    return (i == 0) ? 0 : -2;
  }
  
  public static String b(zzba paramzzba) {
    StringBuilder stringBuilder = new StringBuilder(paramzzba.e());
    for (int i = 0; i < paramzzba.e(); i++) {
      byte b1 = paramzzba.b(i);
      if (b1 != 34) {
        if (b1 != 39) {
          if (b1 != 92) {
            switch (b1) {
              default:
                if (b1 >= 32 && b1 <= 126) {
                  stringBuilder.append((char)b1);
                  break;
                } 
                stringBuilder.append('\\');
                stringBuilder.append((char)((b1 >>> 6 & 0x3) + 48));
                stringBuilder.append((char)((b1 >>> 3 & 0x7) + 48));
                stringBuilder.append((char)((b1 & 0x7) + 48));
                break;
              case 13:
                stringBuilder.append("\\r");
                break;
              case 12:
                stringBuilder.append("\\f");
                break;
              case 11:
                stringBuilder.append("\\v");
                break;
              case 10:
                stringBuilder.append("\\n");
                break;
              case 9:
                stringBuilder.append("\\t");
                break;
              case 8:
                stringBuilder.append("\\b");
                break;
              case 7:
                stringBuilder.append("\\a");
                break;
            } 
          } else {
            stringBuilder.append("\\\\");
          } 
        } else {
          stringBuilder.append("\\'");
        } 
      } else {
        stringBuilder.append("\\\"");
      } 
    } 
    return stringBuilder.toString();
  }
  
  public static void c(String paramString) {
    if (((Boolean)y3.a.e()).booleanValue())
      a.d(paramString); 
  }
  
  public static <AppOpenAdRequestComponent extends h5.lt<AppOpenAd>, AppOpenAd extends h5.zr> lg0<AppOpenAdRequestComponent, AppOpenAd> d(Context paramContext, vh0 paramvh0, hi0 paramhi0) {
    m2 m2 = q2.d4;
    if (((Integer)re1.j.f.a(m2)).intValue() > 0) {
      cg0 cg0 = new cg0();
      gi0 gi0 = paramhi0.a(zzdsi.h, paramContext, paramvh0, new ao((lg0)cg0));
      g3 g3 = new g3((lg0)new f3());
      yh0 yh0 = gi0.a;
      mo0 mo0 = mi.a;
      return (lg0<AppOpenAdRequestComponent, AppOpenAd>)new b3((lg0)g3, (lg0)new jm(yh0, (Executor)mo0), gi0.b, (Executor)mo0);
    } 
    return (lg0<AppOpenAdRequestComponent, AppOpenAd>)new f3();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */