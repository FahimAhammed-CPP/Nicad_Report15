package b7;

import android.widget.AutoCompleteTextView;
import com.google.android.material.textfield.b;

public class i implements AutoCompleteTextView.OnDismissListener {
  public i(b paramb) {}
  
  public void onDismiss() {
    b b1 = this.a;
    b1.j = true;
    b1.l = System.currentTimeMillis();
    b.f(this.a, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */