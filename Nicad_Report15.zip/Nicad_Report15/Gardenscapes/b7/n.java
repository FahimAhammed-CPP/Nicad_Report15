package b7;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.widget.ListAdapter;
import androidx.appcompat.widget.e;
import androidx.appcompat.widget.p0;
import b6.a;
import c7.a;
import com.google.android.material.textfield.TextInputLayout;
import java.util.Locale;
import s6.i;

public class n extends e {
  public final p0 j;
  
  public final AccessibilityManager k;
  
  public final Rect l = new Rect();
  
  public n(Context paramContext, AttributeSet paramAttributeSet) {
    super(a.a(paramContext, paramAttributeSet, 2130903096, 0), paramAttributeSet, 2130903096);
    paramContext = getContext();
    TypedArray typedArray = i.d(paramContext, paramAttributeSet, a.k, 2130903096, 2131821242, new int[0]);
    if (typedArray.hasValue(0) && typedArray.getInt(0, 0) == 0)
      setKeyListener(null); 
    this.k = (AccessibilityManager)paramContext.getSystemService("accessibility");
    p0 p01 = new p0(paramContext, null, 2130903654, 0);
    this.j = p01;
    p01.r(true);
    p01.t = (View)this;
    p01.D.setInputMethodMode(2);
    p01.o(getAdapter());
    p01.u = new m(this);
    typedArray.recycle();
  }
  
  public static void a(n paramn, Object paramObject) {
    paramn.setText(paramn.convertSelectionToString(paramObject), false);
  }
  
  public final TextInputLayout b() {
    for (ViewParent viewParent = getParent(); viewParent != null; viewParent = viewParent.getParent()) {
      if (viewParent instanceof TextInputLayout)
        return (TextInputLayout)viewParent; 
    } 
    return null;
  }
  
  public CharSequence getHint() {
    TextInputLayout textInputLayout = b();
    return (textInputLayout != null && textInputLayout.J) ? textInputLayout.getHint() : super.getHint();
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    TextInputLayout textInputLayout = b();
    if (textInputLayout != null && textInputLayout.J && super.getHint() == null && Build.MANUFACTURER.toLowerCase(Locale.ENGLISH).equals("meizu"))
      setHint(""); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE) {
      int k = getMeasuredWidth();
      ListAdapter listAdapter = getAdapter();
      TextInputLayout textInputLayout = b();
      int i = 0;
      int j = 0;
      paramInt2 = i;
      if (listAdapter != null)
        if (textInputLayout == null) {
          paramInt2 = i;
        } else {
          int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
          int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
          p0 p01 = this.j;
          if (!p01.isShowing()) {
            paramInt2 = -1;
          } else {
            paramInt2 = p01.h.getSelectedItemPosition();
          } 
          paramInt2 = Math.max(0, paramInt2);
          int i2 = Math.min(listAdapter.getCount(), paramInt2 + 15);
          i = Math.max(0, i2 - 15);
          p01 = null;
          paramInt2 = 0;
          while (i < i2) {
            int i4 = listAdapter.getItemViewType(i);
            int i3 = j;
            if (i4 != j) {
              p01 = null;
              i3 = i4;
            } 
            View view = listAdapter.getView(i, (View)p01, (ViewGroup)textInputLayout);
            if (view.getLayoutParams() == null)
              view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
            view.measure(m, i1);
            paramInt2 = Math.max(paramInt2, view.getMeasuredWidth());
            i++;
            j = i3;
          } 
          Drawable drawable = this.j.e();
          i = paramInt2;
          if (drawable != null) {
            drawable.getPadding(this.l);
            Rect rect = this.l;
            i = paramInt2 + rect.left + rect.right;
          } 
          paramInt2 = textInputLayout.getEndIconView().getMeasuredWidth() + i;
        }  
      setMeasuredDimension(Math.min(Math.max(k, paramInt2), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight());
    } 
  }
  
  public <T extends ListAdapter & android.widget.Filterable> void setAdapter(T paramT) {
    super.setAdapter((ListAdapter)paramT);
    this.j.o(getAdapter());
  }
  
  public void showDropDown() {
    AccessibilityManager accessibilityManager = this.k;
    if (accessibilityManager != null && accessibilityManager.isTouchExplorationEnabled()) {
      this.j.c();
      return;
    } 
    super.showDropDown();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */