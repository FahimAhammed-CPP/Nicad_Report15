package b7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.textfield.b;

public class j extends AnimatorListenerAdapter {
  public j(b paramb) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    b b1 = this.a;
    ((k)b1).c.setChecked(b1.k);
    this.a.q.start();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */