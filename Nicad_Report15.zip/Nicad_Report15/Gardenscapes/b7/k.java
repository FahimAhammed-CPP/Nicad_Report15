package b7;

import android.content.Context;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;

public abstract class k {
  public TextInputLayout a;
  
  public Context b;
  
  public CheckableImageButton c;
  
  public final int d;
  
  public k(TextInputLayout paramTextInputLayout, int paramInt) {
    this.a = paramTextInputLayout;
    this.b = paramTextInputLayout.getContext();
    this.c = paramTextInputLayout.getEndIconView();
    this.d = paramInt;
  }
  
  public abstract void a();
  
  public boolean b(int paramInt) {
    return true;
  }
  
  public void c(boolean paramBoolean) {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */