package b7;

import android.animation.ValueAnimator;
import com.google.android.material.textfield.a;

public class c implements ValueAnimator.AnimatorUpdateListener {
  public c(a parama) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    float f = ((Float)paramValueAnimator.getAnimatedValue()).floatValue();
    ((k)this.a).c.setAlpha(f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */