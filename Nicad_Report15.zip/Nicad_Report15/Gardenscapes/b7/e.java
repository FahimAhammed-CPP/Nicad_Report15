package b7;

import com.google.android.material.textfield.TextInputLayout;

public class e extends k {
  public e(TextInputLayout paramTextInputLayout, int paramInt) {
    super(paramTextInputLayout, paramInt);
  }
  
  public void a() {
    this.a.setEndIconDrawable(this.d);
    this.a.setEndIconOnClickListener(null);
    this.a.setEndIconOnLongClickListener(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */