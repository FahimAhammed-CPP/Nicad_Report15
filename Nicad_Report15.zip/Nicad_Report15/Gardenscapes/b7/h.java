package b7;

import android.view.MotionEvent;
import android.view.View;
import android.widget.AutoCompleteTextView;
import com.google.android.material.textfield.b;

public class h implements View.OnTouchListener {
  public h(b paramb, AutoCompleteTextView paramAutoCompleteTextView) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 1) {
      if (this.g.i())
        this.g.j = false; 
      b.g(this.g, this.f);
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */