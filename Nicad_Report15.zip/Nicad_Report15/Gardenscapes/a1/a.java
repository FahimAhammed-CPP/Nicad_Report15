package a1;

import android.content.Context;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import androidx.loader.content.ModernAsyncTask;
import com.google.android.gms.common.api.c;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import r4.d;
import v4.k;
import z0.b;

public abstract class a<D> extends b<D> {
  public final Executor g;
  
  public volatile a h;
  
  public volatile a i;
  
  public a(Context paramContext) {
    super(paramContext);
    this.g = executor;
  }
  
  public void b(a parama, D paramD) {
    if (this.h != parama) {
      if (this.i == parama) {
        SystemClock.uptimeMillis();
        this.i = null;
        c();
        return;
      } 
    } else {
      if (this.d)
        return; 
      SystemClock.uptimeMillis();
      this.h = null;
      b.a<D> a1 = this.b;
      if (a1 != null) {
        b.a a2 = (b.a)a1;
        if (Looper.myLooper() == Looper.getMainLooper()) {
          a2.i(paramD);
          return;
        } 
        a2.j(paramD);
      } 
    } 
  }
  
  public void c() {
    if (this.i == null && this.h != null) {
      Objects.requireNonNull(this.h);
      a a1 = this.h;
      Executor executor = this.g;
      if (a1.h != ModernAsyncTask.Status.f) {
        int i = a1.h.ordinal();
        if (i != 1) {
          if (i != 2)
            throw new IllegalStateException("We should never reach this state"); 
          throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
        } 
        throw new IllegalStateException("Cannot execute task: the task is already running.");
      } 
      a1.h = ModernAsyncTask.Status.g;
      a1.f.f = null;
      executor.execute(a1.g);
    } 
  }
  
  public D d() {
    d d = (d)this;
    Iterator<c> iterator = d.k.iterator();
    int i = 0;
    while (iterator.hasNext()) {
      if (((c)iterator.next()).k((k)d))
        i++; 
    } 
    try {
      d.j.tryAcquire(i, 5L, TimeUnit.SECONDS);
    } catch (InterruptedException interruptedException) {
      Log.i("GACSignInLoader", "Unexpected InterruptedException", interruptedException);
      Thread.currentThread().interrupt();
    } 
    return null;
  }
  
  public final class a extends ModernAsyncTask<Void, Void, D> implements Runnable {
    public final CountDownLatch m = new CountDownLatch(1);
    
    public a(a this$0) {}
    
    public Object a(Object[] param1ArrayOfObject) {
      Void[] arrayOfVoid = (Void[])param1ArrayOfObject;
      this.n.d();
      return null;
    }
    
    public void b(D param1D) {
      try {
        a a1 = this.n;
        if (a1.i == this) {
          SystemClock.uptimeMillis();
          a1.i = null;
          a1.c();
        } 
        return;
      } finally {
        this.m.countDown();
      } 
    }
    
    public void c(D param1D) {
      try {
        this.n.b(this, param1D);
        return;
      } finally {
        this.m.countDown();
      } 
    }
    
    public void run() {
      this.n.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */