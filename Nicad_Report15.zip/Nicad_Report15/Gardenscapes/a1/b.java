package a1;

import android.content.Context;
import java.util.Objects;

public class b<D> {
  public int a;
  
  public a<D> b;
  
  public boolean c = false;
  
  public boolean d = false;
  
  public boolean e = true;
  
  public boolean f = false;
  
  public b(Context paramContext) {
    paramContext.getApplicationContext();
  }
  
  public boolean a() {
    a a1 = (a)this;
    a<D>.a a2 = a1.h;
    boolean bool = false;
    if (a2 != null) {
      if (!a1.c)
        a1.f = true; 
      if (a1.i != null) {
        Objects.requireNonNull(a1.h);
        a1.h = null;
        return false;
      } 
      Objects.requireNonNull(a1.h);
      a2 = a1.h;
      a2.i.set(true);
      bool = a2.g.cancel(false);
      if (bool)
        a1.i = a1.h; 
      a1.h = null;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(64);
    l0.b.a(this, stringBuilder);
    stringBuilder.append(" id=");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static interface a<D> {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */