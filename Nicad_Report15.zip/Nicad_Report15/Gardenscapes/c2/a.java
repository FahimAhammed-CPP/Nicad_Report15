package c2;

import androidx.work.impl.workers.ConstraintTrackingWorker;

public class a implements Runnable {
  public a(ConstraintTrackingWorker paramConstraintTrackingWorker, m7.a parama) {}
  
  public void run() {
    synchronized (this.g.g) {
      if (this.g.h) {
        this.g.b();
      } else {
        this.g.i.m(this.f);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */