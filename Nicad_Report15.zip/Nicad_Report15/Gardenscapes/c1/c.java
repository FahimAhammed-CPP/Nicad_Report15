package c1;

import androidx.multidex.MultiDexExtractor;
import java.io.File;
import java.io.FileFilter;

public class c implements FileFilter {
  public c(MultiDexExtractor paramMultiDexExtractor) {}
  
  public boolean accept(File paramFile) {
    return paramFile.getName().equals("MultiDex.lock") ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */